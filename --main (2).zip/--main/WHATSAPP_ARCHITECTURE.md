# Rawdaty Smart (روضتي الذكية) — WhatsApp Cloud API Architecture

**Document Version:** 1.0.0  
**Integration Type:** Meta WhatsApp Business Platform (Cloud API)  
**Target:** High-Reliability Parental Communication & Instant Peace-of-Mind  

---

## 1. Overview & Strategic Value

In the kindergarten domain, communication speed directly influences parental peace of mind. An email notification about morning arrival or sudden fever is often buried in spam or checked hours later. WhatsApp delivers near **98% open rates within 5 minutes**.

Rawdaty Smart integrates with the official **Meta WhatsApp Cloud API** to deliver:
- **Instant Attendance Check-in / Check-out:** Time-stamped notification confirming safe drop-off and pickup.
- **Urgent Emergency Alerts:** Weather closures, bus delays, or urgent health updates.
- **Weekly Developmental Loop Digests:** Secure deep links to the child's home play cards.
- **Administrative Invitations:** Direct tokenized onboarding links sent straight to parents' verified mobile numbers.
- **Tuition & Payment Receipts:** Instant receipt delivery with PDF links.

---

## 2. Infrastructure & Webhook Topology

```
+-----------------------------------------------------------------------------------+
| META WHATSAPP CLOUD SERVERS (graph.facebook.com)                                  |
+-----------------------------------------------------------------------------------+
       |                                                            ^
       | Inbound Webhook (Delivery Status, Inbound Text)            | Outbound HTTPS
       v                                                            | (Template Msg)
+-------------------------------------------------------------------+---------------+
| RAWDATY SMART EDGE API GATEWAY                                                    |
|                                                                                   |
| 1. Endpoint: POST /api/webhooks/whatsapp                                          |
| 2. HMAC-SHA256 Signature Verification against WHATSAPP_APP_SECRET                 |
| 3. Acknowledge with HTTP 200 within 3 seconds (as required by Meta)               |
| 4. Dispatch payload to Internal Worker Queue                                      |
+-----------------------------------------------------------------------------------+
       |
       v
+-----------------------------------------------------------------------------------+
| ASYNCHRONOUS NOTIFICATION WORKER & RATE-LIMIT MANAGER                             |
|                                                                                   |
| - Outbound Rate Limiter: Enforces Meta tier limits (e.g., 80 msgs/second)         |
| - Exponential Backoff Retry (1m, 5m, 15m) on network or temporary 5xx errors      |
| - Updates `notifications.whatsapp_status` (queued -> sent -> delivered -> read)  |
+-----------------------------------------------------------------------------------+
       |
       v
+-----------------------------------------------------------------------------------+
| POSTGRESQL DATABASE (`notifications` table & `audit_logs`)                        |
+-----------------------------------------------------------------------------------+
```

---

## 3. Cryptographic Webhook Security (HMAC-SHA256)

To prevent spoofed incoming webhooks, every incoming HTTP request header `X-Hub-Signature-256` is strictly verified against the server-side `WHATSAPP_APP_SECRET`:

```typescript
// src/server/webhooks/whatsapp-signature.ts
import crypto from 'node:crypto';

export function verifyWhatsAppSignature(
  rawPayloadBody: string,
  signatureHeader: string | null
): boolean {
  if (!signatureHeader) return false;

  const appSecret = process.env.WHATSAPP_APP_SECRET;
  if (!appSecret) {
    throw new Error('SERVER CONFIG ERROR: WHATSAPP_APP_SECRET is not configured.');
  }

  // Header format is: sha256={hash}
  const parts = signatureHeader.split('=');
  if (parts.length !== 2 || parts[0] !== 'sha256') {
    return false;
  }
  const expectedHash = parts[1];

  const calculatedHash = crypto
    .createHmac('sha256', appSecret)
    .update(rawPayloadBody)
    .digest('hex');

  // Constant-time string comparison to prevent timing attacks
  return crypto.timingSafeEqual(
    Buffer.from(expectedHash, 'hex'),
    Buffer.from(calculatedHash, 'hex')
  );
}
```

---

## 4. Pre-Approved WhatsApp Message Templates

Meta requires all business-initiated messages outside of a 24-hour customer care window to use pre-approved templates:

### Template 1: Safe Morning Check-in (`attendance_checkin_v1`)
- **Category:** Utility
- **Languages:** Arabic (`ar`), English (`en`)
- **Header:** 🏫 Rawdaty Smart | روضتي الذكية
- **Body:**
  > "مرحباً {{1}}، نود إعلامكم بأن طفلكم {{2}} قد وصل بأمان إلى روضته (فصل: {{3}}) في تمام الساعة {{4}}. يوم سعيد وممتع! 🌟"
- **Variables:**
  - `{{1}}`: Parent Name (e.g., "أبو عمر")
  - `{{2}}`: Child Name (e.g., "عمر")
  - `{{3}}`: Classroom Name (e.g., "نجوم الغد")
  - `{{4}}`: Check-in Time (e.g., "07:45 ص")

### Template 2: Afternoon Check-out & Pickup (`attendance_checkout_v1`)
- **Category:** Utility
- **Body:**
  > "مرحباً {{1}}، تم استلام طفلكم {{2}} في تمام الساعة {{3}} بواسطة {{4}}. نرجو لكم قضاء بقية يوم ممتعة معاً! 🚗"
- **Variables:**
  - `{{1}}`: Parent Name
  - `{{2}}`: Child Name
  - `{{3}}`: Check-out Time
  - `{{4}}`: Authorized Pickup Person Name

### Template 3: Cryptographic Onboarding Invitation (`invite_parent_v1`)
- **Category:** Utility / Authentication
- **Body:**
  > "مرحباً بك في روضتي الذكية! تدعوكم إدارة روضة {{1}} لتفعيل حساب ولي أمر الطفل {{2}} لمتابعة يومياته وتطوره. يرجى النقر على الرابط الآمن أدناه لإتمام التفعيل (صالح لمدة 48 ساعة):"
- **Interactive Button:**
  - Type: URL
  - Dynamic URL Parameter: `{{3}}` (the 256-bit token string)

### Template 4: Urgent Kindergarten Alert (`emergency_broadcast_v1`)
- **Category:** Utility / Important Notice
- **Body:**
  > "تنبيه هام من إدارة روضة {{1}}: {{2}}. لمزيد من التفاصيل يرجى مراجعة التطبيق فوراً."

---

## 5. Opt-in, Privacy Compliance & The "STOP" Protocol

1. **Explicit Consent During Enrollment:**
   - When a child is registered, parents check an explicit consent box: *"I consent to receiving critical attendance and developmental updates via WhatsApp on my registered mobile number."*
2. **Instant Opt-Out (STOP Protocol):**
   - If a parent replies `STOP`, `إلغاء`, or `توقف` via WhatsApp, the inbound webhook triggers an immediate update:
   - Sets `user_profiles.whatsapp_opt_in = FALSE`.
   - The system automatically downgrades communication to in-app PWA push notifications and email.
3. **No Unencrypted Child PII in Media Headers:**
   - Child photos are **never** blasted directly inside WhatsApp media messages.
   - WhatsApp messages contain short summaries and a secure, time-limited magic link pointing back to the encrypted PWA parent portal.
