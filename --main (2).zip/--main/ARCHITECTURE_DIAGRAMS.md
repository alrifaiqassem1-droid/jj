# Rawdaty Smart (روضتي الذكية) — Visual Architecture Diagrams & Entity Relationships

**Document Version:** 1.0.0  
**Status:** Visual Specification Reference  

---

## Diagram 1: End-to-End System Topology

```
+-----------------------------------------------------------------------------------------------------------------+
|                                                   CLIENT ACTORS                                                 |
|                                                                                                                 |
|   +-----------------------+     +-------------------------------+     +-------------------------------------+   |
|   |  Super Admin Console  |     |  Admin & Teacher Workstation  |     |   Parent Progressive Web App (PWA)  |   |
|   |  - Tenant Management  |     |  - Classroom Ops & Attendance |     |   - Daily Arrival Confirmations     |   |
|   |  - Global Platform    |     |  - Teacher Observations Logs  |     |   - Home Play Moments & Observations|   |
|   |  - Audit Oversight    |     |  - Cryptographic Invitations  |     |   - Milestone Badges & Invoices     |   |
|   +-----------+-----------+     +---------------+---------------+     +------------------+------------------+   |
+---------------|---------------------------------|----------------------------------------|----------------------+
                |                                 |                                        |
                | HTTPS (TLS 1.3)                 | HTTPS (TLS 1.3)                        | HTTPS (TLS 1.3)
                v                                 v                                        v
+-----------------------------------------------------------------------------------------------------------------+
|                                            EDGE API & MIDDLEWARE LAYER                                          |
|                                                                                                                 |
|  - Rate Limiting & Origin Verification                                                                          |
|  - Session Token Verification & Custom JWT Claims Injection                                                     |
|  - Input Validation via Zod Schemas                                                                             |
|  - Cryptographic Salt/Pepper Invitation Token Hasher                                                            |
|  - Audit Log Event Dispatcher                                                                                   |
+-----------------------------------------------------------------------------------------------------------------+
          |                                        |                                        |
          | Authenticated PostgREST / GraphQL      | Secure Background Worker / RPC         | Webhook Verification
          v                                        v                                        v
+------------------------------------+   +------------------------------------+   +-------------------------------+
|     SUPABASE POSTGRESQL (v16)      |   |   SERVER-SIDE ENGINE & WORKERS     |   |    META WHATSAPP CLOUD API    |
|                                    |   |                                    |   |                               |
| - Row Level Security on ALL tables |   | - Gemini Pedagogical AI Synthesizer|   | - HMAC SHA-256 Webhooks       |
| - Tenant Isolation (kindergarten_id|   |   (Non-Diagnostic Guardrail Engine)|   | - Instant Attendance Alerts   |
| - Encrypted Child Medical Records  |   | - Attendance Digest Dispatcher     |   | - One-Time Deep Links         |
| - Strict Foreign Key Integrity     |   | - WhatsApp Async Message Queue     |   | - Emergency Parent Broadcasts |
+------------------------------------+   +------------------------------------+   +-------------------------------+
          |
          v
+------------------------------------+
|    PRIVATE S3 STORAGE BUCKET       |
|                                    |
| - Public Access: Strictly False    |
| - 60-Second Ephemeral Signed URLs  |
| - Isolated per Kindergarten        |
+------------------------------------+
```

---

## Diagram 2: Multi-Role Row Level Security (RLS) Matrix

| Entity Table | SUPER_ADMIN | ADMIN | TEACHER | STAFF | PARENT |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **`kindergartens`** | Full Read/Write | Own Tenant Read/Edit | Own Tenant Read | Own Tenant Read | Own Tenant Read-Only |
| **`classes`** | Full Read/Write | Own Tenant Read/Write | Assigned Classes Only | Own Tenant Read | Child's Class Read-Only |
| **`children`** | Full Read | Own Tenant Full | Assigned Class Children | Safety / Allergy Read | **Own Linked Children Only** |
| **`parent_child_relationships`** | Full Read | Own Tenant Full | Assigned Class Children | Pickup Auth Only | **Own Family Link Only** |
| **`attendance`** | Full Read | Own Tenant Full | Assigned Class Read/Write | Check-in/Check-out Log | **Own Child History Only** |
| **`media_vault`** | Full Read | Own Tenant Full | Class Media Read/Upload | None | **Tagged Child Media Only** |
| **`teacher_observations`** | Full Read | Own Tenant Full | Assigned Class Read/Write | None | **Own Child Read-Only** |
| **`parent_observations`** | Full Read | Own Tenant Full | Assigned Class Read/Review | None | **Own Child Read/Write** |
| **`ai_development_insights`** | Full Read | Own Tenant Full | Review & Approve Drafts | None | **Approved Summaries Only** |
| **`invitations`** | Full Read/Write | **Create & Revoke** | **NO ACCESS (403)** | **NO ACCESS (403)** | **NO ACCESS (403)** |
| **`tuition_invoices`** | Full Read | Own Tenant Full | None | None | **Own Child Invoices Only** |
| **`audit_logs`** | Platform-Wide | Own Tenant Audit | None | None | None |

---

## Diagram 3: Cryptographic Invitation & Redemption State Machine

```
              [ Admin / Super Admin Initiates Invitation ]
                                   |
                                   | Server generates 256-bit CSPRNG token
                                   | Computes token_hash = sha256(raw_token + pepper)
                                   v
                      +-------------------------+
                      |     Status: PENDING     |
                      |  (Stored: token_hash)   |
                      +------------+------------+
                                   |
                 +-----------------+-----------------+
                 |                                   |
                 | User redeems within TTL           | Admin Revokes or TTL passes
                 v                                   v
    +-------------------------+         +-------------------------+
    | Atomic Validation Check |         |   Status: REVOKED or    |
    | - token_hash matches?   |         |         EXPIRED         |
    | - uses_count < max_uses?|         +-------------------------+
    | - now() < expires_at?   |
    +------------+------------+
                 | Success
                 v
    +-------------------------+
    | Atomic DB Transaction:  |
    | - Increment uses_count  |
    | - Assign Membership     |
    | - Bind Child or Class   |
    | - Write to Redemptions  |
    +------------+------------+
                 | If uses_count == max_uses
                 v
    +-------------------------+
    |    Status: ACCEPTED     |
    +-------------------------+
```

---

## Diagram 4: The Bi-Directional Home-School Loop & AI Pipeline

```
           CLASSROOM ENVIRONMENT                              FAMILY HOME ENVIRONMENT
       +----------------------------+                     +----------------------------+
       | Teacher Classroom Stations |                     | Daily Home Routines & Play |
       +--------------+-------------+                     +-------------+--------------+
                      |                                                 |
                      v                                                 v
       +----------------------------+                     +----------------------------+
       | Teacher Observations Table |                     | Parent Observations Table  |
       | (Domain, Milestone, Media) |                     | (Home Context, Voice/Text) |
       +--------------+-------------+                     +-------------+--------------+
                      \                                                 /
                       \                                               /
                        \                                             /
                         v                                           v
               +-----------------------------------------------------------+
               |            SERVER-SIDE EVIDENCE INTEGRATION WORKER        |
               |                                                           |
               | - Extracts structured evidence arrays with database UUIDs |
               | - Applies Non-Diagnostic System Prompt Instructions       |
               +-----------------------------+-----------------------------+
                                             |
                                             v
               +-----------------------------------------------------------+
               |               GOOGLE GEMINI 2.5 / FLASH ENGINE            |
               |                                                           |
               | - Synthesizes strengths across school & home contexts     |
               | - Generates 10-Minute Home Play Catalyst Idea             |
               | - Explicitly cites observation IDs for every suggestion   |
               | - Strictly forbids clinical diagnostic terminology        |
               +-----------------------------+-----------------------------+
                                             |
                                             v
               +-----------------------------------------------------------+
               |               AUTOMATED SAFETY REGEX AUDITOR              |
               |                                                           |
               | Scans for forbidden words (autism, ADHD, deficit, delay)  |
               +-----------------------------+-----------------------------+
                                             | Passes Guardrails
                                             v
               +-----------------------------------------------------------+
               |                TEACHER PEDAGOGICAL REVIEW                 |
               |                                                           |
               | Teacher inspects synthesis, adjusts note, approves badge  |
               +-----------------------------+-----------------------------+
                                             | Approved by Teacher
                                             v
               +-----------------------------------------------------------+
               |                 PARENT PWA REFLECTION CARD                |
               |                                                           |
               | Accessible to verified parent with full citation audit    |
               +-----------------------------------------------------------+
```
