-- ==============================================================================
-- Rawdaty Smart (روضتي الذكية) — Migration 00008: Health Profile Lifecycle & Audit Hardening
-- Gate SEC-07: Closed RLS Surface, Clinical Review Authority, Scope Defense & Atomic Deduplication
-- ==============================================================================

-- 1. Extend staff_permission Enum
-- Note: Cast to text[] is used in PL/pgSQL function bodies to ensure 100% transaction safety
ALTER TYPE public.staff_permission ADD VALUE IF NOT EXISTS 'PERFORM_CLINICAL_REVIEW';

-- ==============================================================================
-- 2. Lock Down child_health_profiles RLS and Table Privileges
-- ==============================================================================

-- Drop previous permissive policies from Migration 00002
DROP POLICY IF EXISTS "Health Profiles: Clinical Access Read" ON public.child_health_profiles;
DROP POLICY IF EXISTS "Health Profiles: Clinical Manage" ON public.child_health_profiles;
DROP POLICY IF EXISTS "Health Profiles: Deny Direct Read" ON public.child_health_profiles;
DROP POLICY IF EXISTS "Health Profiles: Deny Direct Mutations" ON public.child_health_profiles;

-- Create explicit default-deny policies (Defense-in-Depth)
CREATE POLICY "Health Profiles: Deny Direct Read" ON public.child_health_profiles
FOR SELECT TO authenticated, anon
USING (FALSE);

CREATE POLICY "Health Profiles: Deny Direct Mutations" ON public.child_health_profiles
FOR ALL TO authenticated, anon
USING (FALSE) WITH CHECK (FALSE);

-- Revoke all direct client table grants
REVOKE ALL ON public.child_health_profiles FROM PUBLIC, anon, authenticated;

-- ==============================================================================
-- 3. Harden rpc_initiate_support_session Scope Allowlist
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.rpc_initiate_support_session(
    p_target_kindergarten_id UUID,
    p_reason TEXT,
    p_duration_minutes INT DEFAULT 60,
    p_scope VARCHAR(100) DEFAULT 'EMERGENCY_SUPPORT'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_caller_id UUID;
    v_clean_reason TEXT;
    v_clean_scope VARCHAR(100);
    v_kg kindergartens%ROWTYPE;
    v_now TIMESTAMPTZ;
    v_expires_at TIMESTAMPTZ;
    v_session super_admin_support_sessions%ROWTYPE;
BEGIN
    -- 1. Identity & Authentication check
    v_caller_id := auth.uid();
    IF v_caller_id IS NULL THEN
        RAISE EXCEPTION 'UNAUTHENTICATED: Must be logged in to initiate a support session.';
    END IF;

    -- 2. Authorization check: Caller must be a verified platform SUPER_ADMIN
    IF NOT (auth.is_super_admin() IS TRUE) THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: Caller does not possess platform SUPER_ADMIN authorization.';
    END IF;

    -- 3. Target Kindergarten validation
    SELECT * INTO v_kg FROM public.kindergartens
    WHERE id = p_target_kindergarten_id AND deleted_at IS NULL;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'KINDERGARTEN_NOT_FOUND: Target kindergarten does not exist or is deleted.';
    END IF;

    -- 4. Scope Allowlist Validation (Strictly enforced)
    v_clean_scope := trim(COALESCE(p_scope, 'EMERGENCY_SUPPORT'));
    IF v_clean_scope NOT IN ('EMERGENCY_SUPPORT', 'ATTENDANCE_CORRUPTION', 'CHILD_HEALTH_EMERGENCY') THEN
        RAISE EXCEPTION 'INVALID_SCOPE: Scope "%" is not an approved support session scope.', v_clean_scope;
    END IF;

    -- 5. Reason validation: Minimum 30 trimmed characters
    v_clean_reason := trim(p_reason);
    IF v_clean_reason IS NULL OR length(v_clean_reason) < 30 THEN
        RAISE EXCEPTION 'SESSION_REASON_TOO_SHORT: Support session reason must be at least 30 characters (got % characters).', length(COALESCE(v_clean_reason, ''));
    END IF;

    -- 6. Duration bounds validation: Between 1 and 60 minutes
    IF p_duration_minutes IS NULL OR p_duration_minutes < 1 THEN
        RAISE EXCEPTION 'INVALID_SESSION_DURATION: Duration must be at least 1 minute.';
    END IF;

    IF p_duration_minutes > 60 THEN
        RAISE EXCEPTION 'SESSION_DURATION_EXCEEDED: Support session duration cannot exceed 60 minutes (requested: % minutes).', p_duration_minutes;
    END IF;

    -- 7. Deactivate prior active sessions for this (super_admin, target_kindergarten) pair
    UPDATE public.super_admin_support_sessions
    SET is_active = FALSE,
        revoked_at = NOW(),
        revoked_by = v_caller_id
    WHERE super_admin_id = v_caller_id
      AND target_kindergarten_id = p_target_kindergarten_id
      AND is_active = TRUE
      AND revoked_at IS NULL;

    -- 8. Calculate timestamps
    v_now := NOW();
    v_expires_at := v_now + (p_duration_minutes || ' minutes')::INTERVAL;

    -- 9. Insert new support session record
    INSERT INTO public.super_admin_support_sessions (
        id,
        super_admin_id,
        target_kindergarten_id,
        reason,
        scope,
        is_active,
        initiated_at,
        expires_at,
        created_at
    ) VALUES (
        gen_random_uuid(),
        v_caller_id,
        p_target_kindergarten_id,
        v_clean_reason,
        v_clean_scope,
        TRUE,
        v_now,
        v_expires_at,
        v_now
    ) RETURNING * INTO v_session;

    -- 10. Mandatory Append-Only Audit Event
    INSERT INTO public.audit_logs (
        kindergarten_id,
        actor_id,
        actor_role,
        action,
        resource_type,
        resource_id,
        request_session_id,
        reason,
        metadata
    ) VALUES (
        p_target_kindergarten_id,
        v_caller_id,
        'SUPER_ADMIN',
        'SUPER_ADMIN_SUPPORT_SESSION_INITIATED',
        'super_admin_support_sessions',
        v_session.id,
        v_session.id::text,
        v_clean_reason,
        jsonb_build_object(
            'session_id', v_session.id,
            'scope', v_session.scope,
            'duration_minutes', p_duration_minutes,
            'initiated_at', v_now,
            'expires_at', v_expires_at
        )
    );

    RETURN to_jsonb(v_session);
END;
$$;

-- ==============================================================================
-- 4. Hardened Audited Health Read RPC: rpc_get_child_health_profile
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.rpc_get_child_health_profile(
    p_child_id UUID,
    p_access_reason TEXT DEFAULT 'Standard clinical inspection'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_caller_id UUID;
    v_clean_reason TEXT;
    v_child children%ROWTYPE;
    v_health child_health_profiles%ROWTYPE;
    v_is_authorized BOOLEAN := FALSE;
    v_actor_role app_role;
    v_session_id UUID;
    v_session super_admin_support_sessions%ROWTYPE;
    v_recent_denials INT;
    v_admin_user_id UUID;
BEGIN
    -- 1. Identity & Session verification
    v_caller_id := auth.uid();
    IF v_caller_id IS NULL THEN
        RETURN jsonb_build_object(
            'success', false,
            'error_code', 'UNAUTHENTICATED',
            'message', 'Valid authentication session required.'
        );
    END IF;

    -- 2. Validate Reason
    v_clean_reason := trim(COALESCE(p_access_reason, ''));
    IF length(v_clean_reason) < 10 THEN
        RETURN jsonb_build_object(
            'success', false,
            'error_code', 'REASON_TOO_SHORT',
            'message', 'Access reason must be at least 10 characters.'
        );
    END IF;

    -- 3. Lookup child
    SELECT * INTO v_child FROM public.children WHERE id = p_child_id AND deleted_at IS NULL;
    IF NOT FOUND THEN
        -- Uniform rejection: do not leak whether child exists
        RETURN jsonb_build_object(
            'success', false,
            'error_code', 'ACCESS_DENIED',
            'message', 'Access denied or record unavailable.'
        );
    END IF;

    -- 4. Evaluate Authorization Hierarchy
    -- Case A: School Administrator
    IF auth.is_admin_for(v_child.kindergarten_id) THEN
        v_is_authorized := TRUE;
        v_actor_role := 'ADMIN';

    -- Case B: Staff with Health Viewing Permission
    ELSIF EXISTS (
        SELECT 1 FROM public.kindergarten_memberships km
        WHERE km.user_id = v_caller_id
          AND km.kindergarten_id = v_child.kindergarten_id
          AND km.is_active = TRUE
          AND km.deleted_at IS NULL
          AND 'VIEW_CHILD_HEALTH_INFO' = ANY(km.permissions::text[])
    ) THEN
        v_is_authorized := TRUE;
        v_actor_role := 'STAFF';

    -- Case C: Verified Legal Custody Parent
    ELSIF auth.is_parent_of_child(p_child_id) THEN
        v_is_authorized := TRUE;
        v_actor_role := 'PARENT';

    -- Case D: Verified Platform Super Admin with Active Emergency Health Support Session
    ELSIF (auth.is_super_admin() IS TRUE) THEN
        SELECT * INTO v_session
        FROM public.super_admin_support_sessions sass
        WHERE sass.super_admin_id = v_caller_id
          AND sass.target_kindergarten_id = v_child.kindergarten_id
          AND sass.is_active = TRUE
          AND sass.revoked_at IS NULL
          AND sass.expires_at > NOW()
          AND sass.scope = 'CHILD_HEALTH_EMERGENCY'
        ORDER BY sass.initiated_at DESC
        LIMIT 1;

        IF FOUND THEN
            v_is_authorized := TRUE;
            v_actor_role := 'SUPER_ADMIN';
            v_session_id := v_session.id;
        END IF;
    END IF;

    -- 5. Denial Handling with Concurrency-Safe Rate Limiting
    IF NOT v_is_authorized THEN
        -- Acquire user-scoped transaction advisory lock to serialize probe bursts per actor
        PERFORM pg_advisory_xact_lock(
            hashtextextended('DENIAL_RATE_LOCK:' || v_caller_id::text, 88::bigint)
        );

        -- Check recent denials for this actor across trailing 60 seconds
        SELECT count(*) INTO v_recent_denials
        FROM public.audit_logs
        WHERE actor_id = v_caller_id
          AND action = 'CHILD_HEALTH_INFO_ACCESS_DENIED'
          AND created_at > NOW() - INTERVAL '1 minute';

        -- Circuit breaker: if >= 10 denials, return rate limit response WITHOUT writing to audit_logs
        -- This completely protects tenant audit chain lock from exhaustion
        IF v_recent_denials >= 10 THEN
            RETURN jsonb_build_object(
                'success', false,
                'error_code', 'RATE_LIMIT_EXCEEDED',
                'message', 'Too many failed attempts. Cooldown active.',
                'audit_logged', false
            );
        END IF;

        -- Record the denial in audit_logs (commits cleanly, maintaining hash chain)
        INSERT INTO public.audit_logs (
            kindergarten_id,
            actor_id,
            actor_role,
            action,
            resource_type,
            resource_id,
            reason,
            metadata
        ) VALUES (
            v_child.kindergarten_id,
            v_caller_id,
            auth.get_role_for_kindergarten(v_child.kindergarten_id),
            'CHILD_HEALTH_INFO_ACCESS_DENIED',
            'child_health_profiles',
            p_child_id,
            v_clean_reason,
            jsonb_build_object('attempted_child_id', p_child_id, 'denied_at', NOW())
        );

        RETURN jsonb_build_object(
            'success', false,
            'error_code', 'ACCESS_DENIED',
            'message', 'Access denied or record unavailable.',
            'audit_logged', true
        );
    END IF;

    -- 6. Fetch active health profile
    SELECT * INTO v_health FROM public.child_health_profiles
    WHERE child_id = p_child_id AND deleted_at IS NULL;
    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'success', false,
            'error_code', 'RECORD_NOT_FOUND',
            'message', 'Health record not found or has been archived.'
        );
    END IF;

    -- 7. If SUPER_ADMIN access: Atomic First-Access Notification Deduplication
    IF v_actor_role = 'SUPER_ADMIN' AND v_session_id IS NOT NULL THEN
        -- Acquire atomic session lock to eliminate concurrent notification duplication
        PERFORM pg_advisory_xact_lock(
            hashtextextended('NOTIF_SESSION_LOCK:' || v_session_id::text, 99::bigint)
        );

        -- Check if notification for this session was already dispatched
        IF NOT EXISTS (
            SELECT 1 FROM public.notifications n
            WHERE n.metadata->>'support_session_id' = v_session_id::text
        ) THEN
            -- Dispatch CRITICAL notification to all active directors
            FOR v_admin_user_id IN
                SELECT km.user_id FROM public.kindergarten_memberships km
                WHERE km.kindergarten_id = v_child.kindergarten_id
                  AND km.role = 'ADMIN'
                  AND km.is_active = TRUE
                  AND km.deleted_at IS NULL
            LOOP
                INSERT INTO public.notifications (
                    kindergarten_id,
                    recipient_user_id,
                    channel,
                    priority,
                    title,
                    body,
                    action_url,
                    metadata
                ) VALUES (
                    v_child.kindergarten_id,
                    v_admin_user_id,
                    'IN_APP',
                    'CRITICAL',
                    'تنبيه أمني طارئ: بدء فحص الملفات الصحية',
                    'قام المشرف العام ببدء معاينة الملفات الصحية لحالة طارئة بموجب جلسة الدعم.',
                    '/admin/support-sessions',
                    jsonb_build_object(
                        'support_session_id', v_session_id,
                        'super_admin_id', v_caller_id,
                        'scope', v_session.scope,
                        'first_accessed_child_id', p_child_id,
                        'accessed_at', NOW()
                    )
                );
            END LOOP;
        END IF;
    END IF;

    -- 8. Mandatory Audit Event for Authorized Access
    INSERT INTO public.audit_logs (
        kindergarten_id,
        actor_id,
        actor_role,
        action,
        resource_type,
        resource_id,
        request_session_id,
        reason,
        metadata
    ) VALUES (
        v_child.kindergarten_id,
        v_caller_id,
        v_actor_role,
        'CHILD_HEALTH_INFO_VIEWED',
        'child_health_profiles',
        v_health.id,
        v_session_id::text,
        v_clean_reason,
        jsonb_build_object(
            'child_id', p_child_id,
            'has_epipen', v_health.has_epipen,
            'accessed_at', NOW()
        )
    );

    -- 9. Role-Based Field Projection (Strict Least-Privilege)
    IF v_actor_role = 'PARENT' THEN
        -- Decision D03: Verified parent receives safety data + clinical_notes
        -- Internal identity (last_reviewed_by) and system fields remain strictly masked
        RETURN jsonb_build_object(
            'success', true,
            'role', 'PARENT',
            'data', jsonb_build_object(
                'child_id', v_health.child_id,
                'blood_type', v_health.blood_type,
                'allergies', v_health.allergies,
                'has_epipen', v_health.has_epipen,
                'epipen_location', v_health.epipen_location,
                'chronic_conditions', v_health.chronic_conditions,
                'emergency_medications', v_health.emergency_medications,
                'dietary_restrictions', v_health.dietary_restrictions,
                'pediatrician_name', v_health.pediatrician_name,
                'pediatrician_phone', v_health.pediatrician_phone,
                'clinical_notes', v_health.clinical_notes,
                'last_reviewed_at', v_health.last_reviewed_at
            )
        );
    ELSE
        -- Clinical Staff, Admin, and Authorized Super Admin receive full operational view
        RETURN jsonb_build_object(
            'success', true,
            'role', v_actor_role,
            'data', jsonb_build_object(
                'id', v_health.id,
                'kindergarten_id', v_health.kindergarten_id,
                'child_id', v_health.child_id,
                'blood_type', v_health.blood_type,
                'allergies', v_health.allergies,
                'has_epipen', v_health.has_epipen,
                'epipen_location', v_health.epipen_location,
                'chronic_conditions', v_health.chronic_conditions,
                'emergency_medications', v_health.emergency_medications,
                'dietary_restrictions', v_health.dietary_restrictions,
                'pediatrician_name', v_health.pediatrician_name,
                'pediatrician_phone', v_health.pediatrician_phone,
                'clinical_notes', v_health.clinical_notes,
                'last_reviewed_at', v_health.last_reviewed_at,
                'last_reviewed_by', v_health.last_reviewed_by,
                'created_at', v_health.created_at,
                'updated_at', v_health.updated_at
            )
        );
    END IF;
END;
$$;

-- ==============================================================================
-- 5. Audited Health Mutation RPC: rpc_update_child_health_profile
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.rpc_update_child_health_profile(
    p_child_id UUID,
    p_patch JSONB,
    p_is_clinical_review BOOLEAN DEFAULT FALSE,
    p_reason TEXT DEFAULT 'Health profile record update'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_caller_id UUID;
    v_clean_reason TEXT;
    v_child children%ROWTYPE;
    v_health child_health_profiles%ROWTYPE;
    v_can_edit BOOLEAN := FALSE;
    v_can_review BOOLEAN := FALSE;
    v_key TEXT;
    v_allowed_keys TEXT[] := ARRAY[
        'blood_type', 'allergies', 'has_epipen', 'epipen_location',
        'chronic_conditions', 'emergency_medications', 'dietary_restrictions',
        'pediatrician_name', 'pediatrician_phone', 'clinical_notes'
    ];
    v_modified_fields TEXT[] := '{}';
    v_action VARCHAR(100);
BEGIN
    -- 1. Identity check
    v_caller_id := auth.uid();
    IF v_caller_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error_code', 'UNAUTHENTICATED');
    END IF;

    -- 2. Validate Reason
    v_clean_reason := trim(COALESCE(p_reason, ''));
    IF length(v_clean_reason) < 10 THEN
        RETURN jsonb_build_object('success', false, 'error_code', 'REASON_TOO_SHORT', 'message', 'Reason must be at least 10 characters.');
    END IF;

    -- 3. Locking Order: Lock parent child row first to avoid deadlocks
    SELECT * INTO v_child FROM public.children WHERE id = p_child_id FOR UPDATE;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error_code', 'CHILD_NOT_FOUND');
    END IF;

    -- 4. Verify caller edit authority
    IF auth.is_admin_for(v_child.kindergarten_id) THEN
        v_can_edit := TRUE;
    ELSIF EXISTS (
        SELECT 1 FROM public.kindergarten_memberships km
        WHERE km.user_id = v_caller_id
          AND km.kindergarten_id = v_child.kindergarten_id
          AND km.is_active = TRUE
          AND km.deleted_at IS NULL
          AND 'EDIT_CHILD_HEALTH_INFO' = ANY(km.permissions::text[])
    ) THEN
        v_can_edit := TRUE;
    END IF;

    IF NOT v_can_edit THEN
        RETURN jsonb_build_object('success', false, 'error_code', 'PERMISSION_DENIED');
    END IF;

    -- 5. Verify Clinical Review Authority (Decision D02: Role ADMIN alone does NOT bypass this)
    IF p_is_clinical_review IS TRUE THEN
        SELECT EXISTS (
            SELECT 1 FROM public.kindergarten_memberships km
            WHERE km.user_id = v_caller_id
              AND km.kindergarten_id = v_child.kindergarten_id
              AND km.is_active = TRUE
              AND km.deleted_at IS NULL
              AND 'PERFORM_CLINICAL_REVIEW' = ANY(km.permissions::text[])
        ) INTO v_can_review;

        IF NOT v_can_review THEN
            RETURN jsonb_build_object(
                'success', false,
                'error_code', 'CLINICAL_REVIEW_UNAUTHORIZED',
                'message', 'Caller is not explicitly authorized for clinical reviews.'
            );
        END IF;
    END IF;

    -- 6. Lock child health profile row second
    SELECT * INTO v_health FROM public.child_health_profiles WHERE child_id = p_child_id FOR UPDATE;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error_code', 'RECORD_NOT_FOUND');
    END IF;

    IF v_health.deleted_at IS NOT NULL THEN
        RETURN jsonb_build_object('success', false, 'error_code', 'RECORD_ARCHIVED', 'message', 'Cannot edit an archived health record.');
    END IF;

    -- 7. Validate Patch Keys against Strict Allowlist
    FOR v_key IN SELECT jsonb_object_keys(p_patch) LOOP
        IF NOT (v_key = ANY(v_allowed_keys)) THEN
            RETURN jsonb_build_object(
                'success', false,
                'error_code', 'INVALID_FIELD_DETECTED',
                'message', 'Field "' || v_key || '" cannot be modified via patch.'
            );
        END IF;
    END LOOP;

    -- 8. Apply modifications and track diffs server-side
    IF p_patch ? 'blood_type' AND (p_patch->>'blood_type' IS DISTINCT FROM v_health.blood_type) THEN
        v_health.blood_type := p_patch->>'blood_type';
        v_modified_fields := array_append(v_modified_fields, 'blood_type');
    END IF;

    IF p_patch ? 'allergies' THEN
        v_health.allergies := ARRAY(SELECT jsonb_array_elements_text(p_patch->'allergies'));
        v_modified_fields := array_append(v_modified_fields, 'allergies');
    END IF;

    IF p_patch ? 'has_epipen' AND ((p_patch->>'has_epipen')::boolean IS DISTINCT FROM v_health.has_epipen) THEN
        v_health.has_epipen := (p_patch->>'has_epipen')::boolean;
        v_modified_fields := array_append(v_modified_fields, 'has_epipen');
    END IF;

    IF p_patch ? 'epipen_location' AND (p_patch->>'epipen_location' IS DISTINCT FROM v_health.epipen_location) THEN
        v_health.epipen_location := p_patch->>'epipen_location';
        v_modified_fields := array_append(v_modified_fields, 'epipen_location');
    END IF;

    IF p_patch ? 'chronic_conditions' THEN
        v_health.chronic_conditions := ARRAY(SELECT jsonb_array_elements_text(p_patch->'chronic_conditions'));
        v_modified_fields := array_append(v_modified_fields, 'chronic_conditions');
    END IF;

    IF p_patch ? 'emergency_medications' AND (p_patch->>'emergency_medications' IS DISTINCT FROM v_health.emergency_medications) THEN
        v_health.emergency_medications := p_patch->>'emergency_medications';
        v_modified_fields := array_append(v_modified_fields, 'emergency_medications');
    END IF;

    IF p_patch ? 'dietary_restrictions' AND (p_patch->>'dietary_restrictions' IS DISTINCT FROM v_health.dietary_restrictions) THEN
        v_health.dietary_restrictions := p_patch->>'dietary_restrictions';
        v_modified_fields := array_append(v_modified_fields, 'dietary_restrictions');
    END IF;

    IF p_patch ? 'pediatrician_name' AND (p_patch->>'pediatrician_name' IS DISTINCT FROM v_health.pediatrician_name) THEN
        v_health.pediatrician_name := p_patch->>'pediatrician_name';
        v_modified_fields := array_append(v_modified_fields, 'pediatrician_name');
    END IF;

    IF p_patch ? 'pediatrician_phone' AND (p_patch->>'pediatrician_phone' IS DISTINCT FROM v_health.pediatrician_phone) THEN
        v_health.pediatrician_phone := p_patch->>'pediatrician_phone';
        v_modified_fields := array_append(v_modified_fields, 'pediatrician_phone');
    END IF;

    IF p_patch ? 'clinical_notes' AND (p_patch->>'clinical_notes' IS DISTINCT FROM v_health.clinical_notes) THEN
        v_health.clinical_notes := p_patch->>'clinical_notes';
        v_modified_fields := array_append(v_modified_fields, 'clinical_notes');
    END IF;

    -- 9. Clinical Review Metadata Invariant
    IF p_is_clinical_review IS TRUE THEN
        v_health.last_reviewed_at := NOW();
        v_health.last_reviewed_by := v_caller_id;
        v_action := 'CHILD_HEALTH_CLINICAL_REVIEW_RECORDED';
    ELSE
        -- Strictly preserve previous review metadata during clerical updates
        v_action := 'CHILD_HEALTH_PROFILE_UPDATED';
    END IF;

    v_health.updated_at := NOW();

    -- 10. Update row in database
    UPDATE public.child_health_profiles
    SET blood_type = v_health.blood_type,
        allergies = v_health.allergies,
        has_epipen = v_health.has_epipen,
        epipen_location = v_health.epipen_location,
        chronic_conditions = v_health.chronic_conditions,
        emergency_medications = v_health.emergency_medications,
        dietary_restrictions = v_health.dietary_restrictions,
        pediatrician_name = v_health.pediatrician_name,
        pediatrician_phone = v_health.pediatrician_phone,
        clinical_notes = v_health.clinical_notes,
        last_reviewed_at = v_health.last_reviewed_at,
        last_reviewed_by = v_health.last_reviewed_by,
        updated_at = v_health.updated_at
    WHERE id = v_health.id;

    -- 11. Mandatory Audit Log Entry
    INSERT INTO public.audit_logs (
        kindergarten_id,
        actor_id,
        actor_role,
        action,
        resource_type,
        resource_id,
        reason,
        metadata
    ) VALUES (
        v_child.kindergarten_id,
        v_caller_id,
        auth.get_role_for_kindergarten(v_child.kindergarten_id),
        v_action,
        'child_health_profiles',
        v_health.id,
        v_clean_reason,
        jsonb_build_object(
            'child_id', p_child_id,
            'is_clinical_review', p_is_clinical_review,
            'modified_fields', v_modified_fields
        )
    );

    RETURN jsonb_build_object(
        'success', true,
        'action', v_action,
        'modified_fields', v_modified_fields,
        'last_reviewed_at', v_health.last_reviewed_at
    );
END;
$$;

-- ==============================================================================
-- 6. Audited Health Restoration RPC: rpc_restore_child_health_profile
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.rpc_restore_child_health_profile(
    p_child_id UUID,
    p_reason TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_caller_id UUID;
    v_clean_reason TEXT;
    v_child children%ROWTYPE;
    v_health child_health_profiles%ROWTYPE;
BEGIN
    -- 1. Identity & Role check
    v_caller_id := auth.uid();
    IF v_caller_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error_code', 'UNAUTHENTICATED');
    END IF;

    -- 2. Validate reason length (>= 20 characters for sensitive restoration)
    v_clean_reason := trim(COALESCE(p_reason, ''));
    IF length(v_clean_reason) < 20 THEN
        RETURN jsonb_build_object(
            'success', false,
            'error_code', 'REASON_TOO_SHORT',
            'message', 'Restoration reason must be at least 20 characters.'
        );
    END IF;

    -- 3. Lock parent child row first
    SELECT * INTO v_child FROM public.children WHERE id = p_child_id FOR UPDATE;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error_code', 'CHILD_NOT_FOUND');
    END IF;

    -- 4. Only School Administrator can restore
    IF NOT auth.is_admin_for(v_child.kindergarten_id) THEN
        RETURN jsonb_build_object('success', false, 'error_code', 'PERMISSION_DENIED');
    END IF;

    -- 5. Lock health profile row second
    SELECT * INTO v_health FROM public.child_health_profiles WHERE child_id = p_child_id FOR UPDATE;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error_code', 'RECORD_NOT_FOUND');
    END IF;

    IF v_health.deleted_at IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error_code', 'RECORD_ALREADY_ACTIVE');
    END IF;

    -- 6. Perform Restoration (Preserves last_reviewed_at and last_reviewed_by intact)
    UPDATE public.child_health_profiles
    SET deleted_at = NULL,
        updated_at = NOW()
    WHERE id = v_health.id;

    -- 7. Mandatory Audit Log Entry
    INSERT INTO public.audit_logs (
        kindergarten_id,
        actor_id,
        actor_role,
        action,
        resource_type,
        resource_id,
        reason,
        metadata
    ) VALUES (
        v_child.kindergarten_id,
        v_caller_id,
        'ADMIN',
        'CHILD_HEALTH_PROFILE_RESTORED',
        'child_health_profiles',
        v_health.id,
        v_clean_reason,
        jsonb_build_object(
            'child_id', p_child_id,
            'restored_at', NOW(),
            'restored_by', v_caller_id
        )
    );

    RETURN jsonb_build_object(
        'success', true,
        'child_id', p_child_id,
        'restored_at', NOW()
    );
END;
$$;

-- ==============================================================================
-- 7. Explicit Function Permissions & DCL Lockdown
-- ==============================================================================

-- 1. rpc_get_child_health_profile
REVOKE ALL ON FUNCTION public.rpc_get_child_health_profile(UUID, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.rpc_get_child_health_profile(UUID, TEXT) TO authenticated;

-- 2. rpc_update_child_health_profile
REVOKE ALL ON FUNCTION public.rpc_update_child_health_profile(UUID, JSONB, BOOLEAN, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.rpc_update_child_health_profile(UUID, JSONB, BOOLEAN, TEXT) TO authenticated;

-- 3. rpc_restore_child_health_profile
REVOKE ALL ON FUNCTION public.rpc_restore_child_health_profile(UUID, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.rpc_restore_child_health_profile(UUID, TEXT) TO authenticated;

-- 4. rpc_initiate_support_session
REVOKE ALL ON FUNCTION public.rpc_initiate_support_session(UUID, TEXT, INT, VARCHAR) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.rpc_initiate_support_session(UUID, TEXT, INT, VARCHAR) TO authenticated;
