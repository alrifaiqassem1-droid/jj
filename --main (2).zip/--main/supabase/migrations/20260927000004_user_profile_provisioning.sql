-- ==============================================================================
-- Rawdaty Smart (روضتي الذكية) — Migration 00004: User Profile Provisioning Trigger
-- Automatically provisions public.user_profiles upon new auth.users registration
-- ==============================================================================

-- 1. Trigger Function: public.handle_new_user
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_full_name VARCHAR(255);
    v_phone VARCHAR(50);
    v_lang VARCHAR(10);
    v_avatar TEXT;
BEGIN
    -- 1. Extract and sanitize full_name with hierarchical fallbacks
    v_full_name := NULLIF(TRIM(COALESCE(
        NEW.raw_user_meta_data->>'full_name',
        NEW.raw_user_meta_data->>'name',
        split_part(NEW.email, '@', 1),
        'مستخدم جديد'
    )), '');

    IF v_full_name IS NULL THEN
        v_full_name := 'مستخدم جديد';
    END IF;

    -- Clamp to VARCHAR(255)
    v_full_name := SUBSTRING(v_full_name, 1, 255);

    -- 2. Extract and sanitize phone number
    v_phone := NULLIF(TRIM(COALESCE(
        NEW.phone,
        NEW.raw_user_meta_data->>'phone',
        NEW.raw_user_meta_data->>'phone_number'
    )), '');

    IF v_phone IS NOT NULL THEN
        v_phone := SUBSTRING(v_phone, 1, 50);
    END IF;

    -- 3. Extract preferred language with default 'ar'
    v_lang := LOWER(NULLIF(TRIM(COALESCE(
        NEW.raw_user_meta_data->>'preferred_language',
        'ar'
    )), ''));

    IF v_lang IS NULL OR LENGTH(v_lang) > 10 THEN
        v_lang := 'ar';
    END IF;

    -- 4. Extract avatar_url
    v_avatar := NULLIF(TRIM(NEW.raw_user_meta_data->>'avatar_url'), '');

    -- 5. Idempotent insertion into public.user_profiles
    BEGIN
        INSERT INTO public.user_profiles (
            id,
            full_name,
            phone_number,
            preferred_language,
            avatar_url,
            created_at,
            updated_at
        ) VALUES (
            NEW.id,
            v_full_name,
            v_phone,
            v_lang,
            v_avatar,
            NOW(),
            NOW()
        )
        ON CONFLICT (id) DO UPDATE SET
            full_name = CASE 
                WHEN user_profiles.full_name = 'مستخدم جديد' AND EXCLUDED.full_name != 'مستخدم جديد' 
                THEN EXCLUDED.full_name 
                ELSE user_profiles.full_name 
            END,
            phone_number = COALESCE(user_profiles.phone_number, EXCLUDED.phone_number),
            avatar_url = COALESCE(user_profiles.avatar_url, EXCLUDED.avatar_url),
            updated_at = NOW();
    EXCEPTION
        WHEN unique_violation THEN
            -- In case of phone_number collision with an existing account, fallback without phone
            INSERT INTO public.user_profiles (
                id,
                full_name,
                phone_number,
                preferred_language,
                avatar_url,
                created_at,
                updated_at
            ) VALUES (
                NEW.id,
                v_full_name,
                NULL,
                v_lang,
                v_avatar,
                NOW(),
                NOW()
            )
            ON CONFLICT (id) DO NOTHING;
    END;

    RETURN NEW;
END;
$$;

-- Security Hardening: Revoke direct execution from public/anon/authenticated roles
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO postgres;

DO $$
BEGIN
    -- Grant execution to Supabase Auth daemon role (GoTrue) if present
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'supabase_auth_admin') THEN
        GRANT EXECUTE ON FUNCTION public.handle_new_user() TO supabase_auth_admin;
    END IF;

    -- Grant execution to backend service_role if present
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
        GRANT EXECUTE ON FUNCTION public.handle_new_user() TO service_role;
    END IF;
END $$;

-- 2. Bind trigger to auth.users table
DROP TRIGGER IF EXISTS trg_on_auth_user_created ON auth.users;
CREATE TRIGGER trg_on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_user();
