-- ==============================================================================
-- Rawdaty Smart (روضتي الذكية) — Migration 00001: Initial Canonical Schema
-- Exactly 25 Entities as defined in FINAL_ENTITY_REGISTRY.md & DATABASE_SCHEMA.md
-- ==============================================================================

-- 1. Custom Types & Enums
CREATE TYPE app_role AS ENUM (
    'SUPER_ADMIN',
    'ADMIN',
    'TEACHER',
    'STAFF',
    'PARENT'
);

CREATE TYPE staff_permission AS ENUM (
    'VIEW_CHILD_BASIC_INFO',
    'EDIT_CHILD_BASIC_INFO',
    'VIEW_CHILD_HEALTH_INFO',
    'EDIT_CHILD_HEALTH_INFO',
    'RECORD_ATTENDANCE',
    'VIEW_ATTENDANCE',
    'MANAGE_MEDIA',
    'VIEW_INVOICES'
);

CREATE TYPE invitation_lifecycle_status AS ENUM (
    'CREATED',
    'OPENED',
    'ACCOUNT_CREATED',
    'IDENTITY_VERIFICATION_PENDING',
    'CLAIMED',
    'REVOKED',
    'EXPIRED'
);

CREATE TYPE attendance_status AS ENUM (
    'UNRECORDED',
    'PRESENT',
    'ABSENT_UNEXCUSED',
    'ABSENT_EXCUSED',
    'CHECKED_OUT',
    'CORRECTED'
);

CREATE TYPE developmental_domain AS ENUM (
    'COGNITIVE',
    'LANGUAGE_COMMUNICATION',
    'SOCIAL_EMOTIONAL',
    'FINE_MOTOR',
    'GROSS_MOTOR',
    'SELF_CARE_INDEPENDENCE'
);

CREATE TYPE relationship_type AS ENUM (
    'MOTHER',
    'FATHER',
    'LEGAL_GUARDIAN',
    'GRANDPARENT',
    'AUTHORIZED_RELATIVE'
);

CREATE TYPE ai_approval_status AS ENUM (
    'PENDING_REVIEW',
    'APPROVED',
    'REJECTED',
    'MODIFIED'
);

CREATE TYPE invoice_status AS ENUM (
    'DRAFT',
    'ISSUED',
    'PAID',
    'OVERDUE',
    'VOID'
);

CREATE TYPE notification_channel AS ENUM (
    'IN_APP',
    'WEB_PUSH',
    'EMAIL'
);

CREATE TYPE notification_priority AS ENUM (
    'LOW',
    'NORMAL',
    'URGENT',
    'CRITICAL'
);

-- ==============================================================================
-- 2. Institutional & User Identity (Entities 1 – 4)
-- ==============================================================================

-- Entity 1: kindergartens
CREATE TABLE kindergartens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    license_number VARCHAR(100) UNIQUE NOT NULL,
    contact_email VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(50) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL DEFAULT 'Riyadh',
    country_code CHAR(2) NOT NULL DEFAULT 'SA',
    timezone VARCHAR(50) NOT NULL DEFAULT 'Asia/Riyadh',
    settings JSONB NOT NULL DEFAULT '{"locale": "ar-SA", "daily_cutoff_time": "14:00"}'::JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,
    deleted_by UUID
);
CREATE INDEX idx_kindergartens_deleted ON kindergartens(deleted_at) WHERE deleted_at IS NULL;

-- Entity 2: user_profiles
CREATE TABLE user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(50) UNIQUE,
    national_id_hash CHAR(64),
    preferred_language VARCHAR(10) NOT NULL DEFAULT 'ar',
    avatar_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_user_profiles_phone ON user_profiles(phone_number);

-- Entity 3: kindergarten_memberships
CREATE TABLE kindergarten_memberships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    user_id UUID NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
    role app_role NOT NULL,
    permissions staff_permission[] NOT NULL DEFAULT '{}',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,
    CONSTRAINT unique_user_kindergarten_membership UNIQUE (kindergarten_id, user_id)
);
CREATE INDEX idx_memberships_lookup ON kindergarten_memberships(kindergarten_id, user_id, is_active);

-- Entity 4: super_admin_support_sessions
CREATE TABLE super_admin_support_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    super_admin_id UUID NOT NULL REFERENCES user_profiles(id) ON DELETE RESTRICT,
    target_kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    reason TEXT NOT NULL CHECK (length(reason) >= 30),
    scope VARCHAR(100) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    initiated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    revoked_by UUID REFERENCES user_profiles(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_support_sessions_active ON super_admin_support_sessions(target_kindergarten_id, super_admin_id)
WHERE is_active = TRUE AND revoked_at IS NULL;

-- ==============================================================================
-- 3. Classrooms, Children & Custody Gate (Entities 5 – 9)
-- ==============================================================================

-- Entity 5: classes
CREATE TABLE classes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    name VARCHAR(100) NOT NULL,
    grade_level VARCHAR(50) NOT NULL,
    room_number VARCHAR(50),
    capacity INT NOT NULL DEFAULT 20 CHECK (capacity > 0),
    academic_year VARCHAR(20) NOT NULL DEFAULT '2026-2027',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,
    CONSTRAINT unique_class_name_per_year UNIQUE (kindergarten_id, name, academic_year)
);
CREATE INDEX idx_classes_kindergarten ON classes(kindergarten_id) WHERE deleted_at IS NULL;

-- Entity 6: teacher_class_assignments
CREATE TABLE teacher_class_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
    teacher_id UUID NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
    is_lead_teacher BOOLEAN NOT NULL DEFAULT FALSE,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT unique_teacher_class_assignment UNIQUE (class_id, teacher_id)
);
CREATE INDEX idx_teacher_assignments ON teacher_class_assignments(teacher_id, class_id);

-- Entity 7: children
CREATE TABLE children (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    class_id UUID NOT NULL REFERENCES classes(id) ON DELETE RESTRICT,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    dob DATE NOT NULL,
    gender VARCHAR(10) NOT NULL CHECK (gender IN ('MALE', 'FEMALE')),
    emergency_contact_name VARCHAR(255) NOT NULL,
    emergency_contact_phone VARCHAR(50) NOT NULL,
    enrollment_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,
    deleted_by UUID
);
CREATE INDEX idx_children_class ON children(class_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_children_kindergarten ON children(kindergarten_id) WHERE deleted_at IS NULL;

-- Entity 8: child_health_profiles
CREATE TABLE child_health_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    child_id UUID NOT NULL UNIQUE REFERENCES children(id) ON DELETE CASCADE,
    blood_type VARCHAR(10),
    allergies TEXT[] NOT NULL DEFAULT '{}',
    has_epipen BOOLEAN NOT NULL DEFAULT FALSE,
    epipen_location TEXT,
    chronic_conditions TEXT[] NOT NULL DEFAULT '{}',
    emergency_medications TEXT,
    dietary_restrictions TEXT,
    pediatrician_name VARCHAR(255),
    pediatrician_phone VARCHAR(50),
    clinical_notes TEXT,
    last_reviewed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_reviewed_by UUID REFERENCES user_profiles(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_health_profiles_child ON child_health_profiles(child_id) WHERE deleted_at IS NULL;

-- Entity 9: parent_child_relationships (Custody Gate)
CREATE TABLE parent_child_relationships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    parent_id UUID NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
    child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    relationship relationship_type NOT NULL,
    is_primary_contact BOOLEAN NOT NULL DEFAULT FALSE,
    authorized_for_pickup BOOLEAN NOT NULL DEFAULT FALSE,
    verified_at TIMESTAMPTZ, -- Mandatory Legal Verification Gate
    verified_by_admin_id UUID REFERENCES user_profiles(id),
    verification_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,
    CONSTRAINT unique_parent_child UNIQUE (parent_id, child_id)
);
CREATE INDEX idx_parent_child_lookup ON parent_child_relationships(parent_id, child_id, verified_at)
WHERE deleted_at IS NULL;

-- ==============================================================================
-- 4. Onboarding & Invitations (Entities 10 – 11)
-- ==============================================================================

-- Entity 10: invitations
CREATE TABLE invitations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    created_by UUID NOT NULL REFERENCES user_profiles(id) ON DELETE RESTRICT,
    target_role app_role NOT NULL,
    target_email VARCHAR(255) NOT NULL,
    target_phone VARCHAR(50),
    token_hash CHAR(64) NOT NULL UNIQUE,
    target_child_id UUID REFERENCES children(id) ON DELETE RESTRICT,
    target_relationship relationship_type,
    target_class_id UUID REFERENCES classes(id) ON DELETE RESTRICT,
    status invitation_lifecycle_status NOT NULL DEFAULT 'CREATED',
    max_uses INT NOT NULL DEFAULT 1 CHECK (max_uses >= 1),
    uses_count INT NOT NULL DEFAULT 0 CHECK (uses_count <= max_uses),
    opened_at TIMESTAMPTZ,
    account_created_at TIMESTAMPTZ,
    claimed_at TIMESTAMPTZ,
    claimed_by_user_id UUID REFERENCES user_profiles(id),
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    revoked_by UUID REFERENCES user_profiles(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_invitations_token_hash ON invitations(token_hash);
CREATE INDEX idx_invitations_tenant ON invitations(kindergarten_id, status);

-- Entity 11: invitation_redemptions
CREATE TABLE invitation_redemptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invitation_id UUID NOT NULL REFERENCES invitations(id) ON DELETE CASCADE,
    redeemed_by UUID NOT NULL REFERENCES user_profiles(id) ON DELETE RESTRICT,
    ip_address INET,
    user_agent TEXT,
    redeemed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION freeze_invitation_redemptions()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'TAMPER_ALERT: invitation_redemptions is immutable.';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_freeze_invitation_redemptions
BEFORE UPDATE OR DELETE ON invitation_redemptions
FOR EACH ROW EXECUTE FUNCTION freeze_invitation_redemptions();

-- ==============================================================================
-- 5. Daily Attendance & Immutability Ledger (Entities 12 – 13)
-- ==============================================================================

-- Entity 12: attendance
CREATE TABLE attendance (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_attendance_uuid UUID UNIQUE,
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    class_id UUID NOT NULL REFERENCES classes(id) ON DELETE RESTRICT,
    child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    status attendance_status NOT NULL DEFAULT 'UNRECORDED',
    check_in_time TIMESTAMPTZ,
    check_out_time TIMESTAMPTZ,
    recorded_by UUID NOT NULL REFERENCES user_profiles(id),
    picked_up_by_name VARCHAR(255),
    notes TEXT,
    client_recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    server_synced_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,
    deleted_by UUID,
    CONSTRAINT unique_child_daily_attendance UNIQUE (child_id, date)
);
CREATE INDEX idx_attendance_date ON attendance(kindergarten_id, class_id, date);

-- Entity 13: attendance_corrections
CREATE TABLE attendance_corrections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    attendance_id UUID NOT NULL REFERENCES attendance(id) ON DELETE CASCADE,
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    previous_status attendance_status NOT NULL,
    new_status attendance_status NOT NULL,
    corrected_by_user_id UUID NOT NULL REFERENCES user_profiles(id),
    reason TEXT NOT NULL CHECK (length(reason) >= 10),
    source VARCHAR(50) NOT NULL DEFAULT 'TEACHER_WEB_MANUAL',
    request_session_id VARCHAR(100),
    client_timestamp TIMESTAMPTZ NOT NULL,
    server_synced_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_corrections_attendance ON attendance_corrections(attendance_id);

CREATE OR REPLACE FUNCTION freeze_attendance_corrections()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'TAMPER_ALERT: attendance_corrections records are immutable and append-only.';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_freeze_attendance_corrections
BEFORE UPDATE OR DELETE ON attendance_corrections
FOR EACH ROW EXECUTE FUNCTION freeze_attendance_corrections();

-- ==============================================================================
-- 6. Observations Loop (Entities 14 – 15)
-- ==============================================================================

-- Entity 14: teacher_observations
CREATE TABLE teacher_observations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    class_id UUID NOT NULL REFERENCES classes(id) ON DELETE RESTRICT,
    child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    teacher_id UUID NOT NULL REFERENCES user_profiles(id) ON DELETE RESTRICT,
    activity_context VARCHAR(255) NOT NULL,
    observed_behavior TEXT NOT NULL,
    primary_domain developmental_domain NOT NULL,
    secondary_domains developmental_domain[] NOT NULL DEFAULT '{}',
    media_ids UUID[] DEFAULT '{}',
    observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_teacher_obs_child ON teacher_observations(child_id, observed_at) WHERE deleted_at IS NULL;

-- Entity 15: parent_observations
CREATE TABLE parent_observations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    parent_id UUID NOT NULL REFERENCES user_profiles(id) ON DELETE RESTRICT,
    play_context VARCHAR(255) NOT NULL,
    parent_reflection TEXT NOT NULL,
    domain_hint developmental_domain,
    media_ids UUID[] DEFAULT '{}',
    observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_parent_obs_child ON parent_observations(child_id, observed_at) WHERE deleted_at IS NULL;

-- ==============================================================================
-- 7. AI Derived Pipeline (Entities 16 – 20)
-- ==============================================================================

-- Entity 16: ai_analysis
CREATE TABLE ai_analysis (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    model_version VARCHAR(100) NOT NULL,
    prompt_tokens INT NOT NULL CHECK (prompt_tokens >= 0),
    completion_tokens INT NOT NULL CHECK (completion_tokens >= 0),
    latency_ms INT NOT NULL CHECK (latency_ms >= 0),
    raw_response_hash CHAR(64) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'COMPLETED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_ai_analysis_child ON ai_analysis(child_id, created_at);

-- Entity 17: ai_evidence
CREATE TABLE ai_evidence (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    analysis_id UUID NOT NULL REFERENCES ai_analysis(id) ON DELETE CASCADE,
    source_table VARCHAR(50) NOT NULL CHECK (source_table IN ('teacher_observations', 'parent_observations')),
    source_record_id UUID NOT NULL,
    evidence_quote TEXT NOT NULL,
    relevance_score NUMERIC(4,3) NOT NULL CHECK (relevance_score >= 0.000 AND relevance_score <= 1.000),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_ai_evidence_analysis ON ai_evidence(analysis_id);

-- Entity 18: ai_insights
CREATE TABLE ai_insights (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    analysis_id UUID NOT NULL REFERENCES ai_analysis(id) ON DELETE CASCADE,
    domain developmental_domain NOT NULL,
    synthesized_summary TEXT NOT NULL,
    observed_strengths TEXT[] NOT NULL DEFAULT '{}',
    growth_opportunities TEXT[] NOT NULL DEFAULT '{}',
    is_signed_off_by_teacher BOOLEAN NOT NULL DEFAULT FALSE,
    signed_off_teacher_id UUID REFERENCES user_profiles(id),
    signed_off_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_ai_insights_child ON ai_insights(child_id, created_at);

-- Entity 19: ai_recommendations
CREATE TABLE ai_recommendations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    insight_id UUID NOT NULL REFERENCES ai_insights(id) ON DELETE CASCADE,
    activity_title VARCHAR(255) NOT NULL,
    activity_duration_minutes INT NOT NULL DEFAULT 10 CHECK (activity_duration_minutes BETWEEN 5 AND 30),
    materials_needed TEXT[] NOT NULL DEFAULT '{}',
    step_by_step_instructions TEXT[] NOT NULL CHECK (array_length(step_by_step_instructions, 1) >= 2),
    purpose_description TEXT NOT NULL,
    parent_tips TEXT,
    approval_status ai_approval_status NOT NULL DEFAULT 'PENDING_REVIEW',
    approved_by_teacher_id UUID REFERENCES user_profiles(id),
    approved_at TIMESTAMPTZ,
    rejection_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_ai_recommendations_child ON ai_recommendations(child_id, approval_status);

-- Entity 20: ai_followups
CREATE TABLE ai_followups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    recommendation_id UUID NOT NULL REFERENCES ai_recommendations(id) ON DELETE CASCADE,
    child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    logged_by_user_id UUID NOT NULL REFERENCES user_profiles(id) ON DELETE RESTRICT,
    activity_completed BOOLEAN NOT NULL DEFAULT FALSE,
    child_engagement_rating INT CHECK (child_engagement_rating BETWEEN 1 AND 5),
    parent_feedback_notes TEXT,
    teacher_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_ai_followups_rec ON ai_followups(recommendation_id);

-- ==============================================================================
-- 8. Storage Metadata & Tag Isolation (Entities 21 – 22)
-- ==============================================================================

-- Entity 21: media_vault
CREATE TABLE media_vault (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    storage_path TEXT NOT NULL UNIQUE,
    mime_type VARCHAR(100) NOT NULL,
    file_size_bytes BIGINT NOT NULL CHECK (file_size_bytes > 0),
    sha256_checksum CHAR(64) NOT NULL,
    uploaded_by UUID NOT NULL REFERENCES user_profiles(id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_media_vault_tenant ON media_vault(kindergarten_id) WHERE deleted_at IS NULL;

-- Entity 22: media_child_tags
CREATE TABLE media_child_tags (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    media_id UUID NOT NULL REFERENCES media_vault(id) ON DELETE CASCADE,
    child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    tagged_by UUID NOT NULL REFERENCES user_profiles(id) ON DELETE RESTRICT,
    tagged_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT unique_media_child_tag UNIQUE (media_id, child_id)
);
CREATE INDEX idx_media_tags_child ON media_child_tags(child_id, media_id);

-- ==============================================================================
-- 9. Billing, Notifications & Audit Log (Entities 23 – 25)
-- ==============================================================================

-- Entity 23: tuition_invoices (Phase 5 Deferred)
CREATE TABLE tuition_invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    child_id UUID NOT NULL REFERENCES children(id) ON DELETE RESTRICT,
    parent_id UUID NOT NULL REFERENCES user_profiles(id) ON DELETE RESTRICT,
    invoice_number VARCHAR(100) NOT NULL UNIQUE,
    amount_sar NUMERIC(10,2) NOT NULL CHECK (amount_sar >= 0),
    vat_sar NUMERIC(10,2) NOT NULL DEFAULT 0.00 CHECK (vat_sar >= 0),
    total_sar NUMERIC(10,2) NOT NULL CHECK (total_sar >= 0),
    status invoice_status NOT NULL DEFAULT 'DRAFT',
    due_date DATE NOT NULL,
    paid_at TIMESTAMPTZ,
    payment_reference VARCHAR(100),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,
    CONSTRAINT unique_invoice_num_tenant UNIQUE (kindergarten_id, invoice_number)
);
CREATE INDEX idx_invoices_child ON tuition_invoices(child_id, status);

-- Entity 24: notifications
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID NOT NULL REFERENCES kindergartens(id) ON DELETE RESTRICT,
    recipient_user_id UUID NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
    channel notification_channel NOT NULL DEFAULT 'IN_APP',
    priority notification_priority NOT NULL DEFAULT 'NORMAL',
    title VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    action_url TEXT,
    metadata JSONB NOT NULL DEFAULT '{}'::JSONB,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_notifications_recipient ON notifications(recipient_user_id, read_at);

-- Entity 25: audit_logs
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kindergarten_id UUID REFERENCES kindergartens(id) ON DELETE SET NULL,
    actor_id UUID REFERENCES user_profiles(id) ON DELETE SET NULL,
    actor_role app_role,
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(100) NOT NULL,
    resource_id UUID,
    request_session_id VARCHAR(100),
    ip_address INET,
    user_agent TEXT,
    reason TEXT,
    metadata JSONB DEFAULT '{}'::JSONB,
    previous_log_hash CHAR(64),
    current_log_hash CHAR(64) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_audit_logs_actor ON audit_logs(actor_id, created_at);
CREATE INDEX idx_audit_logs_resource ON audit_logs(resource_type, resource_id);

-- Tamper-Evident Cryptographic Hash Chaining Trigger
CREATE OR REPLACE FUNCTION set_audit_log_hash()
RETURNS TRIGGER AS $$
DECLARE
    v_prev_hash CHAR(64);
BEGIN
    NEW.id := COALESCE(NEW.id, gen_random_uuid());
    NEW.created_at := COALESCE(NEW.created_at, NOW());

    -- 1. Acquire transaction-level advisory lock per kindergarten chain (serialized linear chain, no forks)
    PERFORM pg_advisory_xact_lock(
        hashtextextended(
            COALESCE(NEW.kindergarten_id::text, 'GLOBAL_NULL_KINDERGARTEN_CHAIN'),
            42::bigint
        )
    );

    -- 2. Fetch previous log hash in chain for this kindergarten (or global if null)
    SELECT current_log_hash INTO v_prev_hash
    FROM audit_logs
    WHERE (kindergarten_id = NEW.kindergarten_id OR (kindergarten_id IS NULL AND NEW.kindergarten_id IS NULL))
    ORDER BY created_at DESC, id DESC
    LIMIT 1;

    NEW.previous_log_hash := COALESCE(v_prev_hash, repeat('0', 64));

    -- 3. Unconditionally compute authoritative current_log_hash over canonical structured JSONB payload
    NEW.current_log_hash := encode(
        sha256(
            jsonb_build_object(
                'id', NEW.id,
                'kindergarten_id', NEW.kindergarten_id,
                'actor_id', NEW.actor_id,
                'actor_role', NEW.actor_role,
                'action', NEW.action,
                'resource_type', NEW.resource_type,
                'resource_id', NEW.resource_id,
                'request_session_id', NEW.request_session_id,
                'ip_address', NEW.ip_address::text,
                'user_agent', NEW.user_agent,
                'reason', NEW.reason,
                'previous_log_hash', NEW.previous_log_hash,
                'metadata', COALESCE(NEW.metadata, '{}'::jsonb),
                'created_at', to_char(NEW.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"')
            )::text::bytea
        ),
        'hex'
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_set_audit_log_hash
BEFORE INSERT ON audit_logs
FOR EACH ROW EXECUTE FUNCTION set_audit_log_hash();

CREATE OR REPLACE FUNCTION freeze_audit_logs()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'TAMPER_ALERT: audit_logs is append-only and strictly immutable.';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_freeze_audit_logs
BEFORE UPDATE OR DELETE ON audit_logs
FOR EACH ROW EXECUTE FUNCTION freeze_audit_logs();
