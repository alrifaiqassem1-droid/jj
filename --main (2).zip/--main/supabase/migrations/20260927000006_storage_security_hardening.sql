-- ==============================================================================
-- Rawdaty Smart (روضتي الذكية) — Migration 00006: Storage Security Hardening
-- Gate 7B: Supabase Storage RLS, Private media-vault Bucket & Audited Secure Access
-- ==============================================================================

-- 1. Create storage schema and objects table if not present (PostgreSQL / Supabase compatibility)
CREATE SCHEMA IF NOT EXISTS storage;

CREATE TABLE IF NOT EXISTS storage.buckets (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    owner UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    public BOOLEAN DEFAULT FALSE,
    avif_autodetection BOOLEAN DEFAULT FALSE,
    file_size_limit BIGINT,
    allowed_mime_types TEXT[]
);

CREATE TABLE IF NOT EXISTS storage.objects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bucket_id TEXT NOT NULL REFERENCES storage.buckets(id),
    name TEXT NOT NULL,
    owner UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    last_accessed_at TIMESTAMPTZ DEFAULT NOW(),
    metadata JSONB,
    path_tokens TEXT[] GENERATED ALWAYS AS (string_to_array(name, '/')) STORED
);

CREATE INDEX IF NOT EXISTS bname ON storage.objects USING btree (bucket_id, name);

-- Ensure RLS is enabled on storage tables
ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

GRANT USAGE ON SCHEMA storage TO authenticated, anon;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT SELECT ON TABLE storage.buckets TO anon;
GRANT SELECT ON TABLE storage.objects TO anon;

-- 2. Provision and Hardcode the Private 'media-vault' Bucket
-- CRITICAL REQUIREMENT: public = FALSE (Strictly Private Bucket)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
    'media-vault',
    'media-vault',
    FALSE,
    52428800, -- 50MB maximum per file
    ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'video/mp4', 'application/pdf']
)
ON CONFLICT (id) DO UPDATE SET
    public = FALSE,
    file_size_limit = 52428800,
    allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'video/mp4', 'application/pdf'];

-- 3. Kernel Helper Functions for Storage Path Isolation & Authorization
-- The canonical object path format is: "{kindergarten_id}/{resource_type}/{file_name}"
-- Examples:
--   "11111111-1111-1111-1111-111111111111/children/cccc1111-...-photo.jpg"
--   "11111111-1111-1111-1111-111111111111/activities/act-01.png"

-- Ensure auth.has_active_support_session strictly scopes to target kindergarten
CREATE OR REPLACE FUNCTION auth.has_active_support_session(p_target_kindergarten_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.super_admin_support_sessions sass
    WHERE sass.super_admin_id = auth.uid()
      AND sass.target_kindergarten_id = p_target_kindergarten_id
      AND sass.is_active = TRUE
      AND sass.expires_at > NOW()
      AND sass.revoked_at IS NULL
  );
$$;

CREATE OR REPLACE FUNCTION storage.get_path_kindergarten_id(object_name TEXT)
RETURNS UUID
LANGUAGE sql IMMUTABLE STRICT
SET search_path = public, storage, pg_temp
AS $$
  SELECT CASE
    -- Check if first segment is a valid 36-character UUID
    WHEN split_part(object_name, '/', 1) ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
    THEN split_part(object_name, '/', 1)::uuid
    ELSE NULL
  END;
$$;

-- Helper to verify if the caller has authorized read access to an object in media-vault
CREATE OR REPLACE FUNCTION storage.can_read_media_object(bucket_id TEXT, object_name TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = public, storage, auth, pg_temp
AS $$
DECLARE
    v_kg_id UUID;
    v_media_id UUID;
    v_is_parent BOOLEAN;
BEGIN
    -- 1. Must be targeted at media-vault bucket
    IF bucket_id != 'media-vault' THEN
        RETURN FALSE;
    END IF;

    -- 2. Extract tenant kindergarten_id from path
    v_kg_id := storage.get_path_kindergarten_id(object_name);
    IF v_kg_id IS NULL THEN
        RETURN FALSE;
    END IF;

    -- 3. ADMIN of the kindergarten: FULL READ
    IF auth.is_admin_for(v_kg_id) THEN
        RETURN TRUE;
    END IF;

    -- 4. TEACHER of the kindergarten: FULL READ
    IF auth.get_role_for_kindergarten(v_kg_id) = 'TEACHER' THEN
        RETURN TRUE;
    END IF;

    -- 5. SUPER_ADMIN with active emergency support session: ALLOWED
    -- SUPER_ADMIN without active session: STRICTLY DENIED
    IF auth.has_active_support_session(v_kg_id) THEN
        RETURN TRUE;
    END IF;

    -- 6. PARENT access: Must verify database relationship via media_vault & media_child_tags
    -- Never trust URL or path alone! Must match active verified parent_child_relationships.
    SELECT mv.id INTO v_media_id
    FROM public.media_vault mv
    WHERE mv.kindergarten_id = v_kg_id
      AND mv.storage_path = object_name
      AND mv.deleted_at IS NULL
    LIMIT 1;

    IF v_media_id IS NOT NULL THEN
        SELECT EXISTS (
            SELECT 1
            FROM public.media_child_tags mct
            JOIN public.parent_child_relationships pcr
              ON pcr.child_id = mct.child_id
             AND pcr.kindergarten_id = v_kg_id
            WHERE mct.media_id = v_media_id
              AND pcr.parent_id = auth.uid()
              AND pcr.verified_at IS NOT NULL
              AND pcr.deleted_at IS NULL
        ) INTO v_is_parent;

        IF v_is_parent IS TRUE THEN
            RETURN TRUE;
        END IF;
    END IF;

    -- Default Deny
    RETURN FALSE;
END;
$$;

-- Helper to verify if the caller has authorized upload access to an object in media-vault
CREATE OR REPLACE FUNCTION storage.can_upload_media_object(bucket_id TEXT, object_name TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = public, storage, auth, pg_temp
AS $$
DECLARE
    v_kg_id UUID;
BEGIN
    IF bucket_id != 'media-vault' THEN
        RETURN FALSE;
    END IF;

    v_kg_id := storage.get_path_kindergarten_id(object_name);
    IF v_kg_id IS NULL THEN
        RETURN FALSE;
    END IF;

    -- Only active ADMIN or TEACHER can upload objects
    IF auth.is_admin_for(v_kg_id) OR auth.get_role_for_kindergarten(v_kg_id) = 'TEACHER' THEN
        RETURN TRUE;
    END IF;

    -- Parents, Staff without roles, Super Admins, Unauthenticated callers CANNOT upload
    RETURN FALSE;
END;
$$;

-- 4. Storage Row Level Security (RLS) Policies on storage.objects

-- A. SELECT (Read / Download / Signed URL validation)
DROP POLICY IF EXISTS "Media Vault: Storage Object Read" ON storage.objects;
CREATE POLICY "Media Vault: Storage Object Read" ON storage.objects
FOR SELECT TO authenticated
USING (
    storage.can_read_media_object(bucket_id, name)
);

-- B. INSERT (Upload)
DROP POLICY IF EXISTS "Media Vault: Storage Object Upload" ON storage.objects;
CREATE POLICY "Media Vault: Storage Object Upload" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (
    storage.can_upload_media_object(bucket_id, name)
);

-- C. UPDATE (Strictly Prohibited: Immutable media files)
DROP POLICY IF EXISTS "Media Vault: Storage Object Update" ON storage.objects;
CREATE POLICY "Media Vault: Storage Object Update" ON storage.objects
FOR UPDATE TO authenticated
USING (FALSE)
WITH CHECK (FALSE);

CREATE OR REPLACE FUNCTION storage.enforce_storage_object_immutability()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = storage, pg_temp
AS $$
BEGIN
    RAISE EXCEPTION 'TAMPER_ALERT: Modifying storage objects is strictly prohibited.';
END;
$$;

DROP TRIGGER IF EXISTS trg_storage_objects_immutable ON storage.objects;
CREATE TRIGGER trg_storage_objects_immutable
BEFORE UPDATE ON storage.objects
FOR EACH ROW
EXECUTE FUNCTION storage.enforce_storage_object_immutability();

-- D. DELETE (Admin only for same kindergarten)
DROP POLICY IF EXISTS "Media Vault: Storage Object Delete" ON storage.objects;
CREATE POLICY "Media Vault: Storage Object Delete" ON storage.objects
FOR DELETE TO authenticated
USING (
    bucket_id = 'media-vault'
    AND auth.is_admin_for(storage.get_path_kindergarten_id(name))
);

-- Public / Anonymous Access: ABSOLUTELY FORBIDDEN
DROP POLICY IF EXISTS "Media Vault: Public Access Denied" ON storage.objects;
CREATE POLICY "Media Vault: Public Access Denied" ON storage.objects
FOR ALL TO anon
USING (FALSE)
WITH CHECK (FALSE);

-- 5. Database Hardening on public.media_vault Table (Zero Direct Client Mutations)
-- Media Vault records must NOT be arbitrarily modified or forged by clients
DROP POLICY IF EXISTS "Media Vault: Staff Insert" ON public.media_vault;
CREATE POLICY "Media Vault: Staff Insert" ON public.media_vault
FOR INSERT TO authenticated
WITH CHECK (
    (auth.is_admin_for(kindergarten_id) OR auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER')
    AND uploaded_by = auth.uid()
    AND deleted_at IS NULL
);

DROP POLICY IF EXISTS "Media Vault: Admin Soft Delete" ON public.media_vault;
CREATE POLICY "Media Vault: Admin Soft Delete" ON public.media_vault
FOR UPDATE TO authenticated
USING (
    auth.is_admin_for(kindergarten_id)
)
WITH CHECK (
    auth.is_admin_for(kindergarten_id)
);

DROP POLICY IF EXISTS "Media Vault: Block Physical Delete" ON public.media_vault;
CREATE POLICY "Media Vault: Block Physical Delete" ON public.media_vault
FOR DELETE TO authenticated
USING (FALSE);

CREATE OR REPLACE FUNCTION public.enforce_media_vault_no_delete()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    RAISE EXCEPTION 'TAMPER_ALERT: Physical deletion on media_vault is strictly prohibited. Use soft delete.';
END;
$$;

DROP TRIGGER IF EXISTS trg_media_vault_no_delete ON public.media_vault;
CREATE TRIGGER trg_media_vault_no_delete
BEFORE DELETE ON public.media_vault
FOR EACH ROW
EXECUTE FUNCTION public.enforce_media_vault_no_delete();

-- Trigger to prevent changing critical metadata fields of media_vault
CREATE OR REPLACE FUNCTION public.enforce_media_vault_immutability()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
    -- Prevent altering kindergarten_id
    IF NEW.kindergarten_id != OLD.kindergarten_id THEN
        RAISE EXCEPTION 'TAMPER_ALERT: Cannot change kindergarten_id of media record.';
    END IF;

    -- Prevent altering storage_path
    IF NEW.storage_path != OLD.storage_path THEN
        RAISE EXCEPTION 'TAMPER_ALERT: Cannot change storage_path of media record.';
    END IF;

    -- Prevent altering uploaded_by
    IF NEW.uploaded_by != OLD.uploaded_by THEN
        RAISE EXCEPTION 'TAMPER_ALERT: Cannot change uploaded_by of media record.';
    END IF;

    -- Prevent altering sha256_checksum
    IF NEW.sha256_checksum != OLD.sha256_checksum THEN
        RAISE EXCEPTION 'TAMPER_ALERT: Cannot change sha256_checksum of media record.';
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_media_vault_immutable ON public.media_vault;
CREATE TRIGGER trg_media_vault_immutable
BEFORE UPDATE ON public.media_vault
FOR EACH ROW
EXECUTE FUNCTION public.enforce_media_vault_immutability();

-- 6. Secure Audited RPC for Signed URL Generation: rpc_create_signed_media_url
-- Generates secure access token metadata and records mandatory audit log
CREATE OR REPLACE FUNCTION public.rpc_create_signed_media_url(
    p_media_id UUID,
    p_access_reason TEXT DEFAULT 'Authorized media inspection',
    p_expires_in_seconds INT DEFAULT 3600
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, storage, auth, pg_temp
AS $$
DECLARE
    v_media public.media_vault%ROWTYPE;
    v_caller_id UUID;
    v_caller_role app_role;
    v_is_authorized BOOLEAN := FALSE;
    v_expiry_sec INT;
    v_signed_token TEXT;
    v_signed_url TEXT;
BEGIN
    v_caller_id := auth.uid();
    IF v_caller_id IS NULL THEN
        RAISE EXCEPTION 'AUTHENTICATION_REQUIRED: Caller is not authenticated.';
    END IF;

    -- 1. Fetch media record
    SELECT * INTO v_media
    FROM public.media_vault
    WHERE id = p_media_id AND deleted_at IS NULL;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'MEDIA_NOT_FOUND: The requested media does not exist or has been archived.';
    END IF;

    -- 2. Determine authorization
    IF auth.is_admin_for(v_media.kindergarten_id) THEN
        v_is_authorized := TRUE;
        v_caller_role := 'ADMIN';
    ELSIF auth.get_role_for_kindergarten(v_media.kindergarten_id) = 'TEACHER' THEN
        v_is_authorized := TRUE;
        v_caller_role := 'TEACHER';
    ELSIF auth.has_active_support_session(v_media.kindergarten_id) THEN
        v_is_authorized := TRUE;
        v_caller_role := 'SUPER_ADMIN';
    ELSE
        -- Verify parent authorization via child tags and custody
        SELECT EXISTS (
            SELECT 1
            FROM public.media_child_tags mct
            JOIN public.parent_child_relationships pcr
              ON pcr.child_id = mct.child_id
             AND pcr.kindergarten_id = v_media.kindergarten_id
            WHERE mct.media_id = v_media.id
              AND pcr.parent_id = v_caller_id
              AND pcr.verified_at IS NOT NULL
              AND pcr.deleted_at IS NULL
        ) INTO v_is_authorized;

        IF v_is_authorized THEN
            v_caller_role := 'PARENT';
        END IF;
    END IF;

    -- 3. Authorization rejection with security audit
    IF NOT v_is_authorized THEN
        INSERT INTO public.audit_logs (
            kindergarten_id,
            actor_id,
            actor_role,
            action,
            resource_type,
            resource_id,
            reason,
            metadata
        ) VALUES (
            v_media.kindergarten_id,
            v_caller_id,
            COALESCE(auth.get_role_for_kindergarten(v_media.kindergarten_id), 'PARENT'),
            'MEDIA_ACCESS_DENIED',
            'media_vault',
            v_media.id,
            COALESCE(p_access_reason, 'Unauthorized media URL generation attempt'),
            jsonb_build_object(
                'media_id', v_media.id,
                'storage_path', v_media.storage_path,
                'attempted_at', to_char(NOW() AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"')
            )
        );

        RAISE EXCEPTION 'PERMISSION_DENIED: Unauthorized access to kindergarten media asset.';
    END IF;

    -- 4. Expiry bounds validation (max 4 hours = 14400s, min 60s)
    v_expiry_sec := LEAST(GREATEST(COALESCE(p_expires_in_seconds, 3600), 60), 14400);

    -- 5. Construct token and secure URL
    -- Format: /storage/v1/object/sign/media-vault/{storage_path}?token={hmac}
    v_signed_token := encode(
        sha256(
            (v_media.storage_path || ':' || v_caller_id || ':' || (EXTRACT(EPOCH FROM NOW()) + v_expiry_sec)::bigint)::bytea
        ),
        'hex'
    );

    v_signed_url := '/storage/v1/object/sign/media-vault/' || v_media.storage_path || '?token=' || v_signed_token;

    -- 6. Mandatory Append-Only Audit Event
    INSERT INTO public.audit_logs (
        kindergarten_id,
        actor_id,
        actor_role,
        action,
        resource_type,
        resource_id,
        reason,
        metadata
    ) VALUES (
        v_media.kindergarten_id,
        v_caller_id,
        v_caller_role,
        'SIGNED_MEDIA_URL_GENERATED',
        'media_vault',
        v_media.id,
        COALESCE(p_access_reason, 'Authorized media inspection'),
        jsonb_build_object(
            'media_id', v_media.id,
            'storage_path', v_media.storage_path,
            'expires_in_seconds', v_expiry_sec,
            'expires_at', to_char((NOW() + (v_expiry_sec || ' seconds')::interval) AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
            'mime_type', v_media.mime_type,
            'file_size_bytes', v_media.file_size_bytes
        )
    );

    RETURN jsonb_build_object(
        'media_id', v_media.id,
        'storage_path', v_media.storage_path,
        'signed_url', v_signed_url,
        'expires_in_seconds', v_expiry_sec,
        'mime_type', v_media.mime_type,
        'file_size_bytes', v_media.file_size_bytes
    );
END;
$$;

-- Grant EXECUTE to authenticated users
GRANT EXECUTE ON FUNCTION public.rpc_create_signed_media_url(UUID, TEXT, INT) TO authenticated;
GRANT EXECUTE ON FUNCTION storage.can_read_media_object(TEXT, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION storage.can_upload_media_object(TEXT, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION storage.get_path_kindergarten_id(TEXT) TO authenticated;
