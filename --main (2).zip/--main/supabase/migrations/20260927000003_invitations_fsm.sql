-- ==============================================================================
-- Rawdaty Smart (روضتي الذكية) — Migration 00003: Cryptographic Invitation RPCs
-- Implements FSM, Strict Email Matching, and Pre-bound Child Locking
-- ==============================================================================

-- 1. Step 1: Open Invitation (Audit & State Transition)
CREATE OR REPLACE FUNCTION rpc_open_invitation(
    p_token_hash CHAR(64),
    p_ip_address INET,
    p_user_agent TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_inv invitations%ROWTYPE;
BEGIN
    SELECT * INTO v_inv FROM invitations
    WHERE token_hash = p_token_hash
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'code', 'INVALID_TOKEN', 'message', 'Invitation not found.');
    END IF;

    IF v_inv.status = 'REVOKED' OR v_inv.revoked_at IS NOT NULL THEN
        RETURN jsonb_build_object('success', false, 'code', 'REVOKED', 'message', 'Invitation has been revoked.');
    END IF;

    IF NOW() > v_inv.expires_at OR v_inv.status = 'EXPIRED' THEN
        UPDATE invitations SET status = 'EXPIRED' WHERE id = v_inv.id;
        RETURN jsonb_build_object('success', false, 'code', 'EXPIRED', 'message', 'Invitation has expired.');
    END IF;

    IF v_inv.status IN ('IDENTITY_VERIFICATION_PENDING', 'CLAIMED') THEN
        RETURN jsonb_build_object('success', false, 'code', 'ALREADY_CLAIMED', 'message', 'Invitation has already been claimed.');
    END IF;

    IF v_inv.status = 'CREATED' THEN
        UPDATE invitations
        SET status = 'OPENED', opened_at = NOW()
        WHERE id = v_inv.id;
    END IF;

    RETURN jsonb_build_object(
        'success', true,
        'kindergarten_id', v_inv.kindergarten_id,
        'target_email', v_inv.target_email,
        'target_role', v_inv.target_role,
        'status', 'OPENED'
    );
END;
$$;

-- 2. Step 2: Atomic Claim RPC with Identity Matching
CREATE OR REPLACE FUNCTION claim_parent_invitation(
    p_token_hash CHAR(64),
    p_ip_address INET,
    p_user_agent TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_inv invitations%ROWTYPE;
    v_caller_id UUID;
    v_caller_email VARCHAR(255);
BEGIN
    v_caller_id := auth.uid();
    IF v_caller_id IS NULL THEN
        RAISE EXCEPTION 'UNAUTHENTICATED: Must be logged in to claim an invitation.';
    END IF;

    SELECT email INTO v_caller_email FROM auth.users WHERE id = v_caller_id;

    SELECT * INTO v_inv FROM invitations
    WHERE token_hash = p_token_hash
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'code', 'NOT_FOUND', 'message', 'Invalid invitation token.');
    END IF;

    IF v_inv.status = 'REVOKED' OR v_inv.revoked_at IS NOT NULL THEN
        RETURN jsonb_build_object('success', false, 'code', 'REVOKED', 'message', 'This invitation was revoked.');
    END IF;

    IF NOW() > v_inv.expires_at OR v_inv.status = 'EXPIRED' THEN
        UPDATE invitations SET status = 'EXPIRED' WHERE id = v_inv.id;
        RETURN jsonb_build_object('success', false, 'code', 'EXPIRED', 'message', 'Invitation link has expired.');
    END IF;

    IF v_inv.status IN ('IDENTITY_VERIFICATION_PENDING', 'CLAIMED') OR v_inv.uses_count >= v_inv.max_uses THEN
        RETURN jsonb_build_object('success', false, 'code', 'ALREADY_CLAIMED', 'message', 'Invitation already claimed.');
    END IF;

    -- Anti-Takeover: Assert exact email match
    IF lower(v_caller_email) != lower(v_inv.target_email) THEN
        INSERT INTO audit_logs (
            kindergarten_id, actor_id, action, resource_type, resource_id, reason, metadata
        ) VALUES (
            v_inv.kindergarten_id,
            v_caller_id,
            'INVITATION_EMAIL_MISMATCH_REJECTED',
            'invitations',
            v_inv.id,
            'Logged-in user email does not match invitation target_email.',
            jsonb_build_object(
                'caller_email', v_caller_email,
                'target_email', v_inv.target_email,
                'token_hash', p_token_hash
            )
        );
        RETURN jsonb_build_object(
            'success', false,
            'code', 'IDENTITY_MISMATCH',
            'message', 'Your account email does not match the recipient email for this invitation.'
        );
    END IF;

    INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role, is_active)
    VALUES (v_inv.kindergarten_id, v_caller_id, v_inv.target_role, TRUE)
    ON CONFLICT (kindergarten_id, user_id) DO NOTHING;

    -- Insert unverified parent custody link (verified_at remains NULL)
    IF v_inv.target_role = 'PARENT' AND v_inv.target_child_id IS NOT NULL THEN
        INSERT INTO parent_child_relationships (
            kindergarten_id,
            parent_id,
            child_id,
            relationship,
            is_primary_contact,
            authorized_for_pickup,
            verified_at
        ) VALUES (
            v_inv.kindergarten_id,
            v_caller_id,
            v_inv.target_child_id,
            COALESCE(v_inv.target_relationship, 'LEGAL_GUARDIAN'),
            FALSE,
            FALSE,
            NULL
        )
        ON CONFLICT (parent_id, child_id) DO NOTHING;
    END IF;

    UPDATE invitations
    SET status = 'IDENTITY_VERIFICATION_PENDING',
        uses_count = uses_count + 1,
        claimed_at = NOW(),
        claimed_by_user_id = v_caller_id
    WHERE id = v_inv.id;

    INSERT INTO invitation_redemptions (invitation_id, redeemed_by, ip_address, user_agent)
    VALUES (v_inv.id, v_caller_id, p_ip_address, p_user_agent);

    RETURN jsonb_build_object(
        'success', true,
        'kindergarten_id', v_inv.kindergarten_id,
        'target_child_id', v_inv.target_child_id,
        'status', 'IDENTITY_VERIFICATION_PENDING',
        'message', 'Account linked. Child records will unlock upon kindergarten director document verification.'
    );
END;
$$;

-- 3. Step 3: Administrative Custody Verification RPC
CREATE OR REPLACE FUNCTION rpc_verify_parent_custody(
    p_parent_id UUID,
    p_child_id UUID,
    p_verification_notes TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_rel parent_child_relationships%ROWTYPE;
BEGIN
    SELECT * INTO v_rel FROM parent_child_relationships
    WHERE parent_id = p_parent_id AND child_id = p_child_id AND deleted_at IS NULL;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'RELATIONSHIP_NOT_FOUND: Relationship record does not exist.';
    END IF;

    IF NOT auth.is_admin_for(v_rel.kindergarten_id) THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: Only the kindergarten director can verify custody.';
    END IF;

    UPDATE parent_child_relationships
    SET verified_at = NOW(),
        verified_by_admin_id = auth.uid(),
        verification_notes = p_verification_notes
    WHERE id = v_rel.id;

    UPDATE invitations
    SET status = 'CLAIMED'
    WHERE kindergarten_id = v_rel.kindergarten_id
      AND target_child_id = p_child_id
      AND claimed_by_user_id = p_parent_id
      AND status = 'IDENTITY_VERIFICATION_PENDING';

    INSERT INTO audit_logs (
        kindergarten_id, actor_id, actor_role, action, resource_type, resource_id, reason, metadata
    ) VALUES (
        v_rel.kindergarten_id,
        auth.uid(),
        'ADMIN',
        'PARENT_CHILD_CUSTODY_VERIFIED',
        'parent_child_relationships',
        v_rel.id,
        p_verification_notes,
        jsonb_build_object('parent_id', p_parent_id, 'child_id', p_child_id, 'unlocked_at', NOW())
    );

    RETURN jsonb_build_object('success', true, 'status', 'CLAIMED', 'verified_at', NOW());
END;
$$;
