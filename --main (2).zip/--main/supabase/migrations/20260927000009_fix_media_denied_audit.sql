-- ==============================================================================
-- Rawdaty Smart (روضتي الذكية) — Migration 00009: Fix Media Access Denied Audit Persistence
-- SEC-08 Storage Audit Hardening: Structured Rejection Response & Transactional Commit
-- Replaces RAISE EXCEPTION on unauthorized media access with structured rejection payload
-- ensuring public.audit_logs commits cleanly without transaction rollback.
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.rpc_create_signed_media_url(
    p_media_id UUID,
    p_access_reason TEXT DEFAULT 'Authorized media inspection',
    p_expires_in_seconds INT DEFAULT 3600
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, storage, auth, pg_temp
AS $$
DECLARE
    v_media public.media_vault%ROWTYPE;
    v_caller_id UUID;
    v_caller_role app_role;
    v_is_authorized BOOLEAN := FALSE;
    v_expiry_sec INT;
    v_signed_token TEXT;
    v_signed_url TEXT;
BEGIN
    -- 1. Identity & Session verification
    v_caller_id := auth.uid();
    IF v_caller_id IS NULL THEN
        RETURN jsonb_build_object(
            'success', false,
            'error_code', 'UNAUTHENTICATED',
            'message', 'AUTHENTICATION_REQUIRED: Caller is not authenticated.'
        );
    END IF;

    -- 2. Fetch media record (active only)
    SELECT * INTO v_media
    FROM public.media_vault
    WHERE id = p_media_id AND deleted_at IS NULL;

    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'success', false,
            'error_code', 'MEDIA_NOT_FOUND',
            'message', 'MEDIA_NOT_FOUND: The requested media does not exist or has been archived.'
        );
    END IF;

    -- 3. Determine authorization hierarchy
    IF auth.is_admin_for(v_media.kindergarten_id) THEN
        v_is_authorized := TRUE;
        v_caller_role := 'ADMIN';
    ELSIF auth.get_role_for_kindergarten(v_media.kindergarten_id) = 'TEACHER' THEN
        v_is_authorized := TRUE;
        v_caller_role := 'TEACHER';
    ELSIF auth.has_active_support_session(v_media.kindergarten_id) THEN
        v_is_authorized := TRUE;
        v_caller_role := 'SUPER_ADMIN';
    ELSE
        -- Verify parent authorization via child tags and custody
        SELECT EXISTS (
            SELECT 1
            FROM public.media_child_tags mct
            JOIN public.parent_child_relationships pcr
              ON pcr.child_id = mct.child_id
             AND pcr.kindergarten_id = v_media.kindergarten_id
            WHERE mct.media_id = v_media.id
              AND pcr.parent_id = v_caller_id
              AND pcr.verified_at IS NOT NULL
              AND pcr.deleted_at IS NULL
        ) INTO v_is_authorized;

        IF v_is_authorized THEN
            v_caller_role := 'PARENT';
        END IF;
    END IF;

    -- 4. Authorization rejection with guaranteed audit persistence
    -- Notice: We do NOT use RAISE EXCEPTION here because PostgreSQL transaction abort
    -- rolls back any pending DML, destroying the audit event. Returning structured
    -- JSON ensures the audit log commits cleanly into public.audit_logs.
    IF NOT v_is_authorized THEN
        INSERT INTO public.audit_logs (
            kindergarten_id,
            actor_id,
            actor_role,
            action,
            resource_type,
            resource_id,
            reason,
            metadata
        ) VALUES (
            v_media.kindergarten_id,
            v_caller_id,
            COALESCE(auth.get_role_for_kindergarten(v_media.kindergarten_id), 'PARENT'),
            'MEDIA_ACCESS_DENIED',
            'media_vault',
            v_media.id,
            COALESCE(p_access_reason, 'Unauthorized media URL generation attempt'),
            jsonb_build_object(
                'media_id', v_media.id,
                'storage_path', v_media.storage_path,
                'attempted_at', to_char(NOW() AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"')
            )
        );

        RETURN jsonb_build_object(
            'success', false,
            'error_code', 'PERMISSION_DENIED',
            'message', 'PERMISSION_DENIED: Unauthorized access to kindergarten media asset.',
            'audit_logged', true
        );
    END IF;

    -- 5. Expiry bounds validation (max 4 hours = 14400s, min 60s)
    v_expiry_sec := LEAST(GREATEST(COALESCE(p_expires_in_seconds, 3600), 60), 14400);

    -- 6. Construct token and secure URL
    -- Format: /storage/v1/object/sign/media-vault/{storage_path}?token={hmac}
    v_signed_token := encode(
        sha256(
            (v_media.storage_path || ':' || v_caller_id || ':' || (EXTRACT(EPOCH FROM NOW()) + v_expiry_sec)::bigint)::bytea
        ),
        'hex'
    );

    v_signed_url := '/storage/v1/object/sign/media-vault/' || v_media.storage_path || '?token=' || v_signed_token;

    -- 7. Mandatory Append-Only Audit Event
    INSERT INTO public.audit_logs (
        kindergarten_id,
        actor_id,
        actor_role,
        action,
        resource_type,
        resource_id,
        reason,
        metadata
    ) VALUES (
        v_media.kindergarten_id,
        v_caller_id,
        v_caller_role,
        'SIGNED_MEDIA_URL_GENERATED',
        'media_vault',
        v_media.id,
        COALESCE(p_access_reason, 'Authorized media inspection'),
        jsonb_build_object(
            'media_id', v_media.id,
            'storage_path', v_media.storage_path,
            'expires_in_seconds', v_expiry_sec,
            'expires_at', to_char((NOW() + (v_expiry_sec || ' seconds')::interval) AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
            'mime_type', v_media.mime_type,
            'file_size_bytes', v_media.file_size_bytes
        )
    );

    RETURN jsonb_build_object(
        'success', true,
        'media_id', v_media.id,
        'storage_path', v_media.storage_path,
        'signed_url', v_signed_url,
        'expires_in_seconds', v_expiry_sec,
        'mime_type', v_media.mime_type,
        'file_size_bytes', v_media.file_size_bytes
    );
END;
$$;

-- Grant EXECUTE to authenticated users
GRANT EXECUTE ON FUNCTION public.rpc_create_signed_media_url(UUID, TEXT, INT) TO authenticated;
