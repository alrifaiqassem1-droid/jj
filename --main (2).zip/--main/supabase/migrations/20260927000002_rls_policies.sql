-- ==============================================================================
-- Rawdaty Smart (روضتي الذكية) — Migration 00002: Kernel Functions & RLS Policies
-- Defense-in-depth, Parent Custody Gate, and Audited Health Gateway
-- ==============================================================================

-- ==============================================================================
-- 1. Helper Functions (SECURITY DEFINER, explicit search_path)
-- ==============================================================================

CREATE OR REPLACE FUNCTION auth.is_admin_for(target_kindergarten_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.kindergarten_memberships km
    WHERE km.user_id = auth.uid()
      AND km.kindergarten_id = target_kindergarten_id
      AND km.role = 'ADMIN'
      AND km.is_active = TRUE
      AND km.deleted_at IS NULL
  );
$$;

CREATE OR REPLACE FUNCTION auth.get_role_for_kindergarten(target_kindergarten_id UUID)
RETURNS app_role
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT km.role FROM public.kindergarten_memberships km
  WHERE km.user_id = auth.uid()
    AND km.kindergarten_id = target_kindergarten_id
    AND km.is_active = TRUE
    AND km.deleted_at IS NULL
  LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION auth.is_teacher_assigned_to_class(target_class_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.teacher_class_assignments tca
    WHERE tca.teacher_id = auth.uid()
      AND tca.class_id = target_class_id
  );
$$;

-- Critical Remediation: Invariant requiring verified_at IS NOT NULL
CREATE OR REPLACE FUNCTION auth.is_parent_of_child(target_child_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.parent_child_relationships pcr
    WHERE pcr.parent_id = auth.uid()
      AND pcr.child_id = target_child_id
      AND pcr.verified_at IS NOT NULL
      AND pcr.deleted_at IS NULL
  );
$$;

CREATE OR REPLACE FUNCTION auth.has_health_permission(target_kindergarten_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.kindergarten_memberships km
    WHERE km.user_id = auth.uid()
      AND km.kindergarten_id = target_kindergarten_id
      AND km.is_active = TRUE
      AND km.deleted_at IS NULL
      AND (
        km.role = 'ADMIN'
        OR 'VIEW_CHILD_HEALTH_INFO' = ANY(km.permissions)
      )
  );
$$;

CREATE OR REPLACE FUNCTION auth.has_active_support_session(p_target_kindergarten_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.super_admin_support_sessions sass
    WHERE sass.super_admin_id = auth.uid()
      AND sass.target_kindergarten_id = p_target_kindergarten_id
      AND sass.is_active = TRUE
      AND sass.expires_at > NOW()
      AND sass.revoked_at IS NULL
  );
$$;

-- ==============================================================================
-- 2. Enable RLS on All 25 Tables
-- ==============================================================================

ALTER TABLE kindergartens ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE kindergarten_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE super_admin_support_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE teacher_class_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE children ENABLE ROW LEVEL SECURITY;
ALTER TABLE child_health_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE parent_child_relationships ENABLE ROW LEVEL SECURITY;
ALTER TABLE invitations ENABLE ROW LEVEL SECURITY;
ALTER TABLE invitation_redemptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_corrections ENABLE ROW LEVEL SECURITY;
ALTER TABLE teacher_observations ENABLE ROW LEVEL SECURITY;
ALTER TABLE parent_observations ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_analysis ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_evidence ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_followups ENABLE ROW LEVEL SECURITY;
ALTER TABLE media_vault ENABLE ROW LEVEL SECURITY;
ALTER TABLE media_child_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE tuition_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- ==============================================================================
-- 3. Row Level Security Policies (25 Tables)
-- ==============================================================================

-- 1. kindergartens
CREATE POLICY "Kindergartens: Read Access" ON kindergartens
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(id)
    OR EXISTS (
      SELECT 1 FROM kindergarten_memberships km
      WHERE km.user_id = auth.uid() AND km.kindergarten_id = id AND km.is_active = TRUE
    )
    OR auth.has_active_support_session(id)
  )
);
CREATE POLICY "Kindergartens: Admin Update" ON kindergartens
FOR UPDATE USING (auth.is_admin_for(id)) WITH CHECK (auth.is_admin_for(id));

-- 2. user_profiles
CREATE POLICY "User Profiles: Read Self or School Affiliated" ON user_profiles
FOR SELECT USING (
  deleted_at IS NULL AND (
    id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM kindergarten_memberships my_km
      JOIN kindergarten_memberships target_km ON target_km.kindergarten_id = my_km.kindergarten_id
      WHERE my_km.user_id = auth.uid()
        AND target_km.user_id = user_profiles.id
        AND (my_km.role = 'ADMIN' OR my_km.role = 'TEACHER')
    )
  )
);
CREATE POLICY "User Profiles: Self Update" ON user_profiles
FOR UPDATE USING (id = auth.uid()) WITH CHECK (id = auth.uid());

-- 3. kindergarten_memberships
CREATE POLICY "Memberships: Read" ON kindergarten_memberships
FOR SELECT USING (
  deleted_at IS NULL AND (
    user_id = auth.uid()
    OR auth.is_admin_for(kindergarten_id)
    OR auth.has_active_support_session(kindergarten_id)
  )
);
CREATE POLICY "Memberships: Admin Manage" ON kindergarten_memberships
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 4. super_admin_support_sessions
CREATE POLICY "Support Sessions: View" ON super_admin_support_sessions
FOR SELECT USING (
  super_admin_id = auth.uid()
  OR auth.is_admin_for(target_kindergarten_id)
);

-- 5. classes
CREATE POLICY "Classes: Read" ON classes
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR auth.is_teacher_assigned_to_class(id)
    OR EXISTS (
      SELECT 1 FROM children c
      WHERE c.class_id = classes.id
        AND auth.is_parent_of_child(c.id)
    )
    OR auth.has_active_support_session(kindergarten_id)
  )
);
CREATE POLICY "Classes: Admin Manage" ON classes
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 6. teacher_class_assignments
CREATE POLICY "Teacher Assignments: Read" ON teacher_class_assignments
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR teacher_id = auth.uid()
  OR auth.has_active_support_session(kindergarten_id)
);
CREATE POLICY "Teacher Assignments: Admin Manage" ON teacher_class_assignments
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 7. children (Demographic & Emergency Base Info)
CREATE POLICY "Children: Basic Info Tiered Read" ON children
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
      AND auth.is_teacher_assigned_to_class(class_id)
    )
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'STAFF'
      AND EXISTS (
        SELECT 1 FROM kindergarten_memberships km
        WHERE km.user_id = auth.uid()
          AND km.kindergarten_id = children.kindergarten_id
          AND 'VIEW_CHILD_BASIC_INFO' = ANY(km.permissions)
      )
    )
    -- STRICT INVARIANT: Legal parent with verified_at IS NOT NULL
    OR auth.is_parent_of_child(id)
    OR auth.has_active_support_session(kindergarten_id)
  )
);
CREATE POLICY "Children: Admin Manage" ON children
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 8. child_health_profiles (Clinical Data)
CREATE POLICY "Health Profiles: Clinical Access Read" ON child_health_profiles
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR auth.has_health_permission(kindergarten_id)
    OR auth.is_parent_of_child(child_id)
    OR auth.has_active_support_session(kindergarten_id)
  )
);
CREATE POLICY "Health Profiles: Clinical Manage" ON child_health_profiles
FOR ALL USING (
  auth.is_admin_for(kindergarten_id)
  OR auth.has_health_permission(kindergarten_id)
) WITH CHECK (
  auth.is_admin_for(kindergarten_id)
  OR auth.has_health_permission(kindergarten_id)
);

-- 9. parent_child_relationships (Custody Gate)
CREATE POLICY "Parent Child Relationships: Read" ON parent_child_relationships
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR parent_id = auth.uid()
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
      AND EXISTS (
        SELECT 1 FROM children c
        WHERE c.id = parent_child_relationships.child_id
          AND auth.is_teacher_assigned_to_class(c.class_id)
      )
    )
    OR auth.has_active_support_session(kindergarten_id)
  )
);
CREATE POLICY "Parent Child Relationships: Admin Manage" ON parent_child_relationships
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 10. invitations
CREATE POLICY "Invitations: Admin Manage" ON invitations
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 11. invitation_redemptions
CREATE POLICY "Invitation Redemptions: Admin Read" ON invitation_redemptions
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM invitations inv
    WHERE inv.id = invitation_redemptions.invitation_id
      AND auth.is_admin_for(inv.kindergarten_id)
  )
);

-- 12. attendance
CREATE POLICY "Attendance: Read" ON attendance
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
      AND auth.is_teacher_assigned_to_class(class_id)
    )
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'STAFF'
      AND EXISTS (
        SELECT 1 FROM kindergarten_memberships km
        WHERE km.user_id = auth.uid()
          AND km.kindergarten_id = attendance.kindergarten_id
          AND 'VIEW_ATTENDANCE' = ANY(km.permissions)
      )
    )
    OR auth.is_parent_of_child(child_id)
    OR auth.has_active_support_session(kindergarten_id)
  )
);
CREATE POLICY "Attendance: Teacher/Staff Record" ON attendance
FOR INSERT WITH CHECK (
  auth.is_admin_for(kindergarten_id)
  OR (
    auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
    AND auth.is_teacher_assigned_to_class(class_id)
  )
  OR (
    auth.get_role_for_kindergarten(kindergarten_id) = 'STAFF'
    AND EXISTS (
      SELECT 1 FROM kindergarten_memberships km
      WHERE km.user_id = auth.uid()
        AND km.kindergarten_id = attendance.kindergarten_id
        AND 'RECORD_ATTENDANCE' = ANY(km.permissions)
    )
  )
);
CREATE POLICY "Attendance: Teacher Update" ON attendance
FOR UPDATE USING (
  auth.is_admin_for(kindergarten_id)
  OR (
    auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
    AND auth.is_teacher_assigned_to_class(class_id)
  )
) WITH CHECK (
  auth.is_admin_for(kindergarten_id)
  OR (
    auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
    AND auth.is_teacher_assigned_to_class(class_id)
  )
);

-- 13. attendance_corrections
CREATE POLICY "Attendance Corrections: Read" ON attendance_corrections
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = attendance_corrections.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  OR auth.has_active_support_session(kindergarten_id)
);
CREATE POLICY "Attendance Corrections: Insert" ON attendance_corrections
FOR INSERT WITH CHECK (
  corrected_by_user_id = auth.uid()
  AND (
    auth.is_admin_for(kindergarten_id)
    OR EXISTS (
      SELECT 1 FROM children c
      WHERE c.id = attendance_corrections.child_id
        AND auth.is_teacher_assigned_to_class(c.class_id)
    )
  )
);

-- 14. teacher_observations
CREATE POLICY "Teacher Observations: Read" ON teacher_observations
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
      AND auth.is_teacher_assigned_to_class(class_id)
    )
    OR auth.is_parent_of_child(child_id)
    OR auth.has_active_support_session(kindergarten_id)
  )
);
CREATE POLICY "Teacher Observations: Teacher Insert" ON teacher_observations
FOR INSERT WITH CHECK (
  teacher_id = auth.uid()
  AND (
    auth.is_admin_for(kindergarten_id)
    OR auth.is_teacher_assigned_to_class(class_id)
  )
);

-- 15. parent_observations
CREATE POLICY "Parent Observations: Read" ON parent_observations
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR EXISTS (
      SELECT 1 FROM children c
      WHERE c.id = parent_observations.child_id
        AND auth.is_teacher_assigned_to_class(c.class_id)
    )
    OR (parent_id = auth.uid() AND auth.is_parent_of_child(child_id))
    OR auth.has_active_support_session(kindergarten_id)
  )
);
CREATE POLICY "Parent Observations: Parent Insert" ON parent_observations
FOR INSERT WITH CHECK (
  parent_id = auth.uid()
  AND auth.is_parent_of_child(child_id)
);

-- 16. ai_analysis
CREATE POLICY "AI Analysis: Read" ON ai_analysis
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_analysis.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  OR auth.has_active_support_session(kindergarten_id)
);

-- 17. ai_evidence
CREATE POLICY "AI Evidence: Read" ON ai_evidence
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM ai_analysis a
    JOIN children c ON c.id = a.child_id
    WHERE a.id = ai_evidence.analysis_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  OR auth.has_active_support_session(kindergarten_id)
);

-- 18. ai_insights
CREATE POLICY "AI Insights: Read" ON ai_insights
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_insights.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  OR (
    is_signed_off_by_teacher = TRUE
    AND auth.is_parent_of_child(child_id)
  )
  OR auth.has_active_support_session(kindergarten_id)
);
CREATE POLICY "AI Insights: Teacher Signoff Update" ON ai_insights
FOR UPDATE USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_insights.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
);

-- 19. ai_recommendations
CREATE POLICY "AI Recommendations: Read" ON ai_recommendations
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_recommendations.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  OR (
    approval_status = 'APPROVED'
    AND auth.is_parent_of_child(child_id)
  )
  OR auth.has_active_support_session(kindergarten_id)
);
CREATE POLICY "AI Recommendations: Teacher Review" ON ai_recommendations
FOR UPDATE USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_recommendations.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
);

-- 20. ai_followups
CREATE POLICY "AI Followups: Read" ON ai_followups
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_followups.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  OR auth.is_parent_of_child(child_id)
  OR auth.has_active_support_session(kindergarten_id)
);
CREATE POLICY "AI Followups: Insert" ON ai_followups
FOR INSERT WITH CHECK (
  logged_by_user_id = auth.uid()
  AND (
    auth.is_admin_for(kindergarten_id)
    OR auth.is_parent_of_child(child_id)
  )
);

-- 21. media_vault
CREATE POLICY "Media Vault: Metadata Read" ON media_vault
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
    OR EXISTS (
      SELECT 1 FROM media_child_tags mct
      WHERE mct.media_id = media_vault.id
        AND auth.is_parent_of_child(mct.child_id)
    )
    OR auth.has_active_support_session(kindergarten_id)
  )
);

-- 22. media_child_tags
CREATE POLICY "Media Child Tags: Read" ON media_child_tags
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
  OR auth.is_parent_of_child(child_id)
  OR auth.has_active_support_session(kindergarten_id)
);
CREATE POLICY "Media Child Tags: Admin/Teacher Manage" ON media_child_tags
FOR ALL USING (
  auth.is_admin_for(kindergarten_id)
  OR auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
);

-- 23. tuition_invoices (Phase 5)
CREATE POLICY "Invoices: Read" ON tuition_invoices
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR (
      parent_id = auth.uid()
      AND auth.is_parent_of_child(child_id)
    )
    OR auth.has_active_support_session(kindergarten_id)
  )
);
CREATE POLICY "Invoices: Admin Manage" ON tuition_invoices
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 24. notifications
CREATE POLICY "Notifications: Recipient Read" ON notifications
FOR SELECT USING (recipient_user_id = auth.uid());
CREATE POLICY "Notifications: Recipient Mark Read" ON notifications
FOR UPDATE USING (recipient_user_id = auth.uid()) WITH CHECK (recipient_user_id = auth.uid());

-- 25. audit_logs
CREATE POLICY "Audit Logs: Admin Read Own School" ON audit_logs
FOR SELECT USING (
  (kindergarten_id IS NOT NULL AND auth.is_admin_for(kindergarten_id))
  OR auth.has_active_support_session(kindergarten_id)
);

-- ==============================================================================
-- 4. Audited Clinical Health Data Access RPC
-- ==============================================================================

CREATE OR REPLACE FUNCTION rpc_get_child_health_profile(
    p_child_id UUID,
    p_access_reason TEXT DEFAULT 'Standard clinical inspection'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_child children%ROWTYPE;
    v_health child_health_profiles%ROWTYPE;
    v_is_authorized BOOLEAN := FALSE;
    v_actor_role app_role;
BEGIN
    SELECT * INTO v_child FROM children WHERE id = p_child_id AND deleted_at IS NULL;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'CHILD_NOT_FOUND: Requested child does not exist.';
    END IF;

    IF auth.is_admin_for(v_child.kindergarten_id) THEN
        v_is_authorized := TRUE;
        v_actor_role := 'ADMIN';
    ELSIF auth.has_health_permission(v_child.kindergarten_id) THEN
        v_is_authorized := TRUE;
        v_actor_role := 'STAFF';
    ELSIF auth.is_parent_of_child(p_child_id) THEN
        v_is_authorized := TRUE;
        v_actor_role := 'PARENT';
    ELSIF auth.has_active_support_session(v_child.kindergarten_id) THEN
        v_is_authorized := TRUE;
        v_actor_role := 'SUPER_ADMIN';
    END IF;

    IF NOT v_is_authorized THEN
        INSERT INTO audit_logs (
            kindergarten_id, actor_id, actor_role, action, resource_type, resource_id, reason, metadata
        ) VALUES (
            v_child.kindergarten_id,
            auth.uid(),
            auth.get_role_for_kindergarten(v_child.kindergarten_id),
            'CHILD_HEALTH_INFO_ACCESS_DENIED',
            'child_health_profiles',
            p_child_id,
            p_access_reason,
            jsonb_build_object('attempted_child_id', p_child_id, 'denied_at', NOW())
        );
        RAISE EXCEPTION 'PERMISSION_DENIED: Unauthorized access to confidential health data.';
    END IF;

    SELECT * INTO v_health FROM child_health_profiles
    WHERE child_id = p_child_id AND deleted_at IS NULL;

    INSERT INTO audit_logs (
        kindergarten_id, actor_id, actor_role, action, resource_type, resource_id, reason, metadata
    ) VALUES (
        v_child.kindergarten_id,
        auth.uid(),
        v_actor_role,
        'CHILD_HEALTH_INFO_VIEWED',
        'child_health_profiles',
        v_health.id,
        p_access_reason,
        jsonb_build_object(
            'child_id', p_child_id,
            'has_epipen', v_health.has_epipen,
            'accessed_at', NOW()
        )
    );

    RETURN to_jsonb(v_health);
END;
$$;
