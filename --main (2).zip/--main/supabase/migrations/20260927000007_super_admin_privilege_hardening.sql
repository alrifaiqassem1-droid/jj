-- ==============================================================================
-- Rawdaty Smart (روضتي الذكية) — Migration 00007: Super Admin Privilege Hardening
-- Gate 7C: Dedicated platform_super_admins Table, Zero-Trust is_super_admin(),
-- and Complete Elimination of Local Admin & Metadata Escalation Vectors
-- ==============================================================================

-- 1. Create public.platform_super_admins as the SOLE Platform Authority
CREATE TABLE IF NOT EXISTS public.platform_super_admins (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by UUID,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    notes TEXT
);

-- Enable Row Level Security
ALTER TABLE public.platform_super_admins ENABLE ROW LEVEL SECURITY;

-- Revoke all permissions from anon
REVOKE ALL ON public.platform_super_admins FROM anon;

-- Policy 1: Authenticated users can only read their own record
DROP POLICY IF EXISTS "Platform Super Admins: Read Self" ON public.platform_super_admins;
CREATE POLICY "Platform Super Admins: Read Self" ON public.platform_super_admins
FOR SELECT TO authenticated
USING (user_id = auth.uid());

-- Policies 2, 3, 4: Strictly block all client INSERT / UPDATE / DELETE operations
DROP POLICY IF EXISTS "Platform Super Admins: Block Client Insert" ON public.platform_super_admins;
CREATE POLICY "Platform Super Admins: Block Client Insert" ON public.platform_super_admins
FOR INSERT TO authenticated
WITH CHECK (FALSE);

DROP POLICY IF EXISTS "Platform Super Admins: Block Client Update" ON public.platform_super_admins;
CREATE POLICY "Platform Super Admins: Block Client Update" ON public.platform_super_admins
FOR UPDATE TO authenticated
USING (FALSE) WITH CHECK (FALSE);

DROP POLICY IF EXISTS "Platform Super Admins: Block Client Delete" ON public.platform_super_admins;
CREATE POLICY "Platform Super Admins: Block Client Delete" ON public.platform_super_admins
FOR DELETE TO authenticated
USING (FALSE);

-- Trigger to prevent any direct modification by untrusted client roles
CREATE OR REPLACE FUNCTION public.enforce_platform_super_admins_freeze()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF current_user != 'postgres' AND current_user != 'service_role' THEN
        RAISE EXCEPTION 'TAMPER_ALERT: Direct mutation of platform_super_admins is strictly blocked.';
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_platform_super_admins_freeze ON public.platform_super_admins;
CREATE TRIGGER trg_platform_super_admins_freeze
BEFORE INSERT OR UPDATE OR DELETE ON public.platform_super_admins
FOR EACH ROW
EXECUTE FUNCTION public.enforce_platform_super_admins_freeze();

-- 2. Pure Zero-Trust auth.is_super_admin() Function
-- Checked EXCLUSIVELY against public.platform_super_admins.
-- ZERO reliance on JWT metadata, user names, test UUIDs, or school memberships.
CREATE OR REPLACE FUNCTION auth.is_super_admin()
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.platform_super_admins psa
    WHERE psa.user_id = auth.uid()
      AND psa.is_active = TRUE
  );
$$;

-- 3. Block Local Kindergarten Admins from Granting SUPER_ADMIN
-- DDL Constraint on kindergarten_memberships
ALTER TABLE public.kindergarten_memberships
  DROP CONSTRAINT IF EXISTS check_membership_no_super_admin,
  ADD CONSTRAINT check_membership_no_super_admin
  CHECK (role != 'SUPER_ADMIN');

-- DDL Constraint on invitations
ALTER TABLE public.invitations
  DROP CONSTRAINT IF EXISTS check_invitation_no_super_admin,
  ADD CONSTRAINT check_invitation_no_super_admin
  CHECK (target_role != 'SUPER_ADMIN');

-- Hardened RLS Policy on kindergarten_memberships
DROP POLICY IF EXISTS "Memberships: Admin Manage" ON public.kindergarten_memberships;
CREATE POLICY "Memberships: Admin Manage" ON public.kindergarten_memberships
FOR ALL TO authenticated
USING (
  auth.is_admin_for(kindergarten_id)
)
WITH CHECK (
  auth.is_admin_for(kindergarten_id)
  AND role != 'SUPER_ADMIN'
);

-- Hardened RLS Policy on invitations
DROP POLICY IF EXISTS "Invitations: Admin Manage" ON public.invitations;
CREATE POLICY "Invitations: Admin Manage" ON public.invitations
FOR ALL TO authenticated
USING (
  auth.is_admin_for(kindergarten_id)
)
WITH CHECK (
  auth.is_admin_for(kindergarten_id)
  AND target_role != 'SUPER_ADMIN'
);

-- 4. Fail-Safe Revocation of Support Sessions
-- Deactivate any active sessions whose creator is not in platform_super_admins
UPDATE public.super_admin_support_sessions
SET is_active = FALSE,
    revoked_at = NOW(),
    revoked_by = super_admin_id
WHERE is_active = TRUE
  AND NOT EXISTS (
    SELECT 1 FROM public.platform_super_admins psa
    WHERE psa.user_id = super_admin_support_sessions.super_admin_id
      AND psa.is_active = TRUE
  );

-- 5. Permission Grants
GRANT SELECT ON public.platform_super_admins TO authenticated;
GRANT EXECUTE ON FUNCTION auth.is_super_admin() TO authenticated, anon;
