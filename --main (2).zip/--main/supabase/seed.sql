-- ==============================================================================
-- روضة الأدهم الذكية (Al-Adham Smart Kindergarten) — Official Database Seed
-- Idempotent & Fully Aligned with 25-Entity Schema & Row Level Security (RLS)
-- ==============================================================================

-- 1. Ensure auth schema and auth.users exist for local/pglite testing
CREATE SCHEMA IF NOT EXISTS auth;
CREATE TABLE IF NOT EXISTS auth.users (
    id UUID PRIMARY KEY,
    email TEXT UNIQUE,
    encrypted_password TEXT DEFAULT '',
    email_confirmed_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 2. Institutional Tenant (Entity 1: kindergartens)
-- ==============================================================================
INSERT INTO kindergartens (
    id,
    name,
    license_number,
    contact_email,
    contact_phone,
    address,
    city,
    country_code,
    timezone,
    settings
) VALUES (
    '11111111-1111-1111-1111-111111111111',
    'روضة الأدهم الذكية',
    'LIC-ALADHAM-2026-RYD',
    'admin@aladham-smart.edu.sa',
    '+966501234567',
    'حي النخيل، طريق الإمام سعود بن عبد العزيز، الرياض',
    'الرياض',
    'SA',
    'Asia/Riyadh',
    '{"locale": "ar-SA", "daily_cutoff_time": "14:00", "smart_features_enabled": true}'::jsonb
) ON CONFLICT (id) DO NOTHING;

-- ==============================================================================
-- 3. Core Identities (auth.users & Entity 2: user_profiles)
-- ==============================================================================

-- 3.1 Super Admin (مدير النظام العام)
INSERT INTO auth.users (id, email) VALUES
    ('00000000-0000-0000-0000-000000000001', 'superadmin@rawdaty.smart')
    ON CONFLICT (id) DO NOTHING;

INSERT INTO user_profiles (id, full_name, phone_number, preferred_language) VALUES
    ('00000000-0000-0000-0000-000000000001', 'مدير النظام العام (الدعم الهندسي)', '+966500000000', 'ar')
    ON CONFLICT (id) DO NOTHING;

-- 3.2 Kindergarten Principal / Admin (أ. منيرة الدوسري - مديرة الروضة)
INSERT INTO auth.users (id, email) VALUES
    ('ffff0001-0000-0000-0000-000000000001', 'principal@aladham-smart.edu.sa')
    ON CONFLICT (id) DO NOTHING;

INSERT INTO user_profiles (id, full_name, phone_number, preferred_language) VALUES
    ('ffff0001-0000-0000-0000-000000000001', 'أ. منيرة الدوسري (مديرة الروضة)', '+966501111111', 'ar')
    ON CONFLICT (id) DO NOTHING;

-- 3.3 Lead Teacher (أ. نورة الشمري - معلمة الصف)
INSERT INTO auth.users (id, email) VALUES
    ('ffff0002-0000-0000-0000-000000000002', 'noura@aladham-smart.edu.sa')
    ON CONFLICT (id) DO NOTHING;

INSERT INTO user_profiles (id, full_name, phone_number, preferred_language) VALUES
    ('ffff0002-0000-0000-0000-000000000002', 'أ. نورة الشمري (معلمة فصل الزهور)', '+966502222222', 'ar')
    ON CONFLICT (id) DO NOTHING;

-- 3.4 Verified Parent (د. قاسم الرفاعي - ولي أمر موثق وصايته)
INSERT INTO auth.users (id, email) VALUES
    ('ffff0003-0000-0000-0000-000000000003', 'qassem.parent@aladham.sa')
    ON CONFLICT (id) DO NOTHING;

INSERT INTO user_profiles (id, full_name, phone_number, preferred_language) VALUES
    ('ffff0003-0000-0000-0000-000000000003', 'د. قاسم الرفاعي (ولي أمر أدهم وسارة)', '+966503333333', 'ar')
    ON CONFLICT (id) DO NOTHING;

-- 3.5 Pending / Unverified Parent (أ. خالد التميمي - بانتظار التحقق من الوصاية)
INSERT INTO auth.users (id, email) VALUES
    ('ffff0004-0000-0000-0000-000000000004', 'khalid.pending@aladham.sa')
    ON CONFLICT (id) DO NOTHING;

INSERT INTO user_profiles (id, full_name, phone_number, preferred_language) VALUES
    ('ffff0004-0000-0000-0000-000000000004', 'أ. خالد التميمي (بانتظار التحقق)', '+966504444444', 'ar')
    ON CONFLICT (id) DO NOTHING;

-- ==============================================================================
-- 4. Institutional Memberships (Entity 3: kindergarten_memberships)
-- ==============================================================================

-- Principal Membership
INSERT INTO kindergarten_memberships (
    kindergarten_id, user_id, role, permissions, is_active
) VALUES (
    '11111111-1111-1111-1111-111111111111',
    'ffff0001-0000-0000-0000-000000000001',
    'ADMIN',
    '{VIEW_CHILD_BASIC_INFO, EDIT_CHILD_BASIC_INFO, VIEW_CHILD_HEALTH_INFO, EDIT_CHILD_HEALTH_INFO, RECORD_ATTENDANCE, VIEW_ATTENDANCE, MANAGE_MEDIA, VIEW_INVOICES}',
    TRUE
) ON CONFLICT (kindergarten_id, user_id) DO NOTHING;

-- Teacher Membership
INSERT INTO kindergarten_memberships (
    kindergarten_id, user_id, role, permissions, is_active
) VALUES (
    '11111111-1111-1111-1111-111111111111',
    'ffff0002-0000-0000-0000-000000000002',
    'TEACHER',
    '{VIEW_CHILD_BASIC_INFO, EDIT_CHILD_BASIC_INFO, VIEW_CHILD_HEALTH_INFO, RECORD_ATTENDANCE, VIEW_ATTENDANCE, MANAGE_MEDIA}',
    TRUE
) ON CONFLICT (kindergarten_id, user_id) DO NOTHING;

-- Verified Parent Membership
INSERT INTO kindergarten_memberships (
    kindergarten_id, user_id, role, permissions, is_active
) VALUES (
    '11111111-1111-1111-1111-111111111111',
    'ffff0003-0000-0000-0000-000000000003',
    'PARENT',
    '{}',
    TRUE
) ON CONFLICT (kindergarten_id, user_id) DO NOTHING;

-- Pending Parent Membership
INSERT INTO kindergarten_memberships (
    kindergarten_id, user_id, role, permissions, is_active
) VALUES (
    '11111111-1111-1111-1111-111111111111',
    'ffff0004-0000-0000-0000-000000000004',
    'PARENT',
    '{}',
    TRUE
) ON CONFLICT (kindergarten_id, user_id) DO NOTHING;

-- ==============================================================================
-- 5. Classrooms & Teacher Assignments (Entities 5 & 6)
-- ==============================================================================

-- 5.1 Class 1: فصل الزهور (المستوى الثاني - KG2)
INSERT INTO classes (
    id, kindergarten_id, name, grade_level, room_number, capacity, academic_year
) VALUES (
    'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    '11111111-1111-1111-1111-111111111111',
    'فصل الزهور',
    'KG2',
    '101-A',
    20,
    '2026-2027'
) ON CONFLICT (id) DO NOTHING;

-- 5.2 Class 2: فصل النجوم (المستوى الأول - KG1)
INSERT INTO classes (
    id, kindergarten_id, name, grade_level, room_number, capacity, academic_year
) VALUES (
    'aaaa2222-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    '11111111-1111-1111-1111-111111111111',
    'فصل النجوم',
    'KG1',
    '102-B',
    18,
    '2026-2027'
) ON CONFLICT (id) DO NOTHING;

-- 5.3 Teacher Assignment
INSERT INTO teacher_class_assignments (
    id, kindergarten_id, class_id, teacher_id, is_lead_teacher
) VALUES (
    'bbbb1111-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    '11111111-1111-1111-1111-111111111111',
    'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    'ffff0002-0000-0000-0000-000000000002',
    TRUE
) ON CONFLICT (class_id, teacher_id) DO NOTHING;

-- ==============================================================================
-- 6. Children & Health Profiles (Entities 7 & 8)
-- ==============================================================================

-- Child 1: أدهم الرفاعي (فصل الزهور)
INSERT INTO children (
    id,
    kindergarten_id,
    class_id,
    first_name,
    last_name,
    dob,
    gender,
    emergency_contact_name,
    emergency_contact_phone,
    enrollment_date
) VALUES (
    'cccc1111-cccc-cccc-cccc-cccccccccccc',
    '11111111-1111-1111-1111-111111111111',
    'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    'أدهم',
    'الرفاعي',
    '2022-04-12',
    'MALE',
    'د. قاسم الرفاعي',
    '+966503333333',
    '2026-09-01'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO child_health_profiles (
    id,
    kindergarten_id,
    child_id,
    blood_type,
    allergies,
    has_epipen,
    clinical_notes
) VALUES (
    'dddd1111-dddd-dddd-dddd-dddddddddddd',
    '11111111-1111-1111-1111-111111111111',
    'cccc1111-cccc-cccc-cccc-cccccccccccc',
    'O+',
    '{"الفول السوداني"}',
    FALSE,
    'حساسية طفيفة للفول السوداني تم إشعار الطبيب ومعلمة الصف بها، صحة الطفل ممتازة.'
) ON CONFLICT (child_id) DO NOTHING;

-- Child 2: سارة الرفاعي (فصل النجوم)
INSERT INTO children (
    id,
    kindergarten_id,
    class_id,
    first_name,
    last_name,
    dob,
    gender,
    emergency_contact_name,
    emergency_contact_phone,
    enrollment_date
) VALUES (
    'cccc2222-cccc-cccc-cccc-cccccccccccc',
    '11111111-1111-1111-1111-111111111111',
    'aaaa2222-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    'سارة',
    'الرفاعي',
    '2023-08-25',
    'FEMALE',
    'د. قاسم الرفاعي',
    '+966503333333',
    '2026-09-01'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO child_health_profiles (
    id,
    kindergarten_id,
    child_id,
    blood_type,
    allergies,
    has_epipen,
    clinical_notes
) VALUES (
    'dddd2222-dddd-dddd-dddd-dddddddddddd',
    '11111111-1111-1111-1111-111111111111',
    'cccc2222-cccc-cccc-cccc-cccccccccccc',
    'A+',
    '{}',
    FALSE,
    'الطفلة سليمة ومعافاة ولا توجد أي حساسية سريرية أو دوائية مسجلة.'
) ON CONFLICT (child_id) DO NOTHING;

-- ==============================================================================
-- 7. Parent-Child Relationships & Legal Custody Gate (Entity 9)
-- ==============================================================================

-- 7.1 Verified Custody for Adham (Dr. Qassem Al-Rifai)
INSERT INTO parent_child_relationships (
    id,
    kindergarten_id,
    parent_id,
    child_id,
    relationship,
    is_primary_contact,
    authorized_for_pickup,
    verified_at,
    verified_by_admin_id,
    verification_notes
) VALUES (
    'eeee1111-eeee-eeee-eeee-eeeeeeeeeeee',
    '11111111-1111-1111-1111-111111111111',
    'ffff0003-0000-0000-0000-000000000003',
    'cccc1111-cccc-cccc-cccc-cccccccccccc',
    'FATHER',
    TRUE,
    TRUE,
    NOW(),
    'ffff0001-0000-0000-0000-000000000001',
    'تم التحقق الرسمي من سجل الأسرة وبطاقة الهوية الوطنية والولاية الشرعية.'
) ON CONFLICT (parent_id, child_id) DO NOTHING;

-- 7.2 Verified Custody for Sara (Dr. Qassem Al-Rifai)
INSERT INTO parent_child_relationships (
    id,
    kindergarten_id,
    parent_id,
    child_id,
    relationship,
    is_primary_contact,
    authorized_for_pickup,
    verified_at,
    verified_by_admin_id,
    verification_notes
) VALUES (
    'eeee2222-eeee-eeee-eeee-eeeeeeeeeeee',
    '11111111-1111-1111-1111-111111111111',
    'ffff0003-0000-0000-0000-000000000003',
    'cccc2222-cccc-cccc-cccc-cccccccccccc',
    'FATHER',
    TRUE,
    TRUE,
    NOW(),
    'ffff0001-0000-0000-0000-000000000001',
    'تم التحقق الرسمي من سجل الأسرة والوصاية الشرعية.'
) ON CONFLICT (parent_id, child_id) DO NOTHING;

-- 7.3 Unverified / Pending Custody Relationship (To test Custody Gate in Admin Panel)
INSERT INTO parent_child_relationships (
    id,
    kindergarten_id,
    parent_id,
    child_id,
    relationship,
    is_primary_contact,
    authorized_for_pickup,
    verified_at,
    verified_by_admin_id,
    verification_notes
) VALUES (
    'eeee3333-eeee-eeee-eeee-eeeeeeeeeeee',
    '11111111-1111-1111-1111-111111111111',
    'ffff0004-0000-0000-0000-000000000004',
    'cccc1111-cccc-cccc-cccc-cccccccccccc',
    'LEGAL_GUARDIAN',
    FALSE,
    FALSE,
    NULL, -- UNVERIFIED (Awaiting admin approval in VerifyCustodyDialog)
    NULL,
    'مقدم كوصي قانوني بديل، يتطلب إحضار صك الولاية الأصلي قبل المصادقة.'
) ON CONFLICT (parent_id, child_id) DO NOTHING;

-- ==============================================================================
-- 8. Daily Morning Attendance (Entity 12: attendance)
-- ==============================================================================

-- Adham: Present this morning
INSERT INTO attendance (
    id,
    client_attendance_uuid,
    kindergarten_id,
    class_id,
    child_id,
    date,
    status,
    check_in_time,
    recorded_by,
    notes
) VALUES (
    '88881111-8888-8888-8888-888888888881',
    '88881111-8888-8888-8888-888888888881',
    '11111111-1111-1111-1111-111111111111',
    'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    'cccc1111-cccc-cccc-cccc-cccccccccccc',
    CURRENT_DATE,
    'PRESENT',
    CURRENT_DATE + TIME '08:05:00',
    'ffff0002-0000-0000-0000-000000000002',
    'حضر أدهم بنشاط وشارك في حلقة الصباح الأولى.'
) ON CONFLICT (child_id, date) DO NOTHING;

-- Sara: Present this morning
INSERT INTO attendance (
    id,
    client_attendance_uuid,
    kindergarten_id,
    class_id,
    child_id,
    date,
    status,
    check_in_time,
    recorded_by,
    notes
) VALUES (
    '88882222-8888-8888-8888-888888888882',
    '88882222-8888-8888-8888-888888888882',
    '11111111-1111-1111-1111-111111111111',
    'aaaa2222-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    'cccc2222-cccc-cccc-cccc-cccccccccccc',
    CURRENT_DATE,
    'PRESENT',
    CURRENT_DATE + TIME '08:12:00',
    'ffff0002-0000-0000-0000-000000000002',
    'حضرت سارة مبتسمة واستلمتها معلمة الصف.'
) ON CONFLICT (child_id, date) DO NOTHING;

-- ==============================================================================
-- 9. Teacher Pedagogical Observations (Entity 14)
-- ==============================================================================
INSERT INTO teacher_observations (
    id,
    kindergarten_id,
    child_id,
    teacher_id,
    domain,
    observation_text,
    status,
    verified_at
) VALUES (
    '66661111-6666-6666-6666-666666666661',
    '11111111-1111-1111-1111-111111111111',
    'cccc1111-cccc-cccc-cccc-cccccccccccc',
    'ffff0002-0000-0000-0000-000000000002',
    'FINE_MOTOR',
    'خلال ورشة الفنون الصباحية، قام أدهم باختيار الألوان بنفسه ومزج درجات البرتقالي والأزرق للتعبير عن مشاعره، وأظهر براعة فائقة في مسك الفرشاة.',
    'PUBLISHED',
    NOW()
) ON CONFLICT (id) DO NOTHING;

-- ==============================================================================
-- 10. AI Developmental Analysis & Recommendations (Entities 16 – 19)
-- ==============================================================================
INSERT INTO ai_analysis (
    id,
    kindergarten_id,
    child_id,
    model_version,
    prompt_tokens,
    completion_tokens,
    latency_ms,
    raw_response_hash
) VALUES (
    '99990001-0000-0000-0000-000000000001',
    '11111111-1111-1111-1111-111111111111',
    'cccc1111-cccc-cccc-cccc-cccccccccccc',
    'gemini-2.5-flash-pedagogical',
    180,
    95,
    320,
    'hash_adham_pedagogical_rec_001'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO ai_insights (
    id,
    kindergarten_id,
    child_id,
    analysis_id,
    domain,
    title,
    summary,
    confidence_score,
    status
) VALUES (
    '99990002-0000-0000-0000-000000000002',
    '11111111-1111-1111-1111-111111111111',
    'cccc1111-cccc-cccc-cccc-cccccccccccc',
    '99990001-0000-0000-0000-000000000001',
    'FINE_MOTOR',
    'تطور التآزر البصري الحركي والقوة الإصبعية',
    'أظهر أدهم تقدماً ملحوظاً في السيطرة الثلاثية على أدوات الرسم والتركيز في الأنشطة الدقيقة.',
    0.95,
    'APPROVED'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO ai_recommendations (
    id,
    kindergarten_id,
    child_id,
    insight_id,
    target_audience,
    activity_title,
    activity_instructions,
    status
) VALUES (
    '99990003-0000-0000-0000-000000000003',
    '11111111-1111-1111-1111-111111111111',
    'cccc1111-cccc-cccc-cccc-cccccccccccc',
    '99990002-0000-0000-0000-000000000002',
    'TEACHERS',
    'تحدي المتاهة الملونة والتوازن بالأصابع',
    'تجهيز مسار خيوط ملونة يتبعها الطفل بنقل خرزات خشبية بالملقط الخفيف في ركن الفنون.',
    'APPROVED'
) ON CONFLICT (id) DO NOTHING;
