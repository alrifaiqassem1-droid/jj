# Rawdaty Smart (روضتي الذكية) — Architecture Review V2 & Decision Log

**Document Version:** 2.0.0-PROPOSED  
**Status:** Under Architectural Review (Awaiting Stakeholder Approval for Phase 1)  
**Author:** Principal Software Architect  
**Scope:** Complete Architectural Corrections, Risk Analysis, and Governance Matrix  

---

## 1. Executive Summary of V2 Corrections

This second architectural review establishes a hardened foundation for Rawdaty Smart prior to writing any production application code. Based on the 20-point architectural mandate, the platform architecture has been recalibrated from a standard SaaS model to a **high-assurance, privacy-first educational and healthcare-adjacent architectural framework**.

### Summary of Major Structural Shifts
1. **Multi-Tenancy Disconnect:** `SUPER_ADMIN` is strictly a platform-level operator with **zero default read access** to child records, health profiles, or family media. Cross-kindergarten access is physically impossible via kernel-level RLS.
2. **Sensitive Child Health Data Isolation:** Segregated from basic demographic data. Staff roles are granted granular permissions (`VIEW_CHILD_BASIC_INFO`, `VIEW_CHILD_HEALTH_INFO`) where health access requires explicit assignment and triggers mandatory audit logs.
3. **AI Source Record Immutability:** AI models are architecturally classified as **read-only consumers**. AI creates independent derivative entities (`ai_analysis`, `ai_evidence`, `ai_insight`, `ai_recommendation`, `ai_followup`) referencing immutable source records.
4. **Offline-First Attendance Resiliency:** Implemented as a dedicated, controlled IndexedDB queue with client-side UUIDv7, deterministic conflict resolution, and idempotent server reconciliation.
5. **Break-Glass Super Admin Support Access:** Time-boxed, audited, reason-bound temporary privilege elevation. No permanent administrative super-user access to child data.
6. **Realistic Backup Targets:** Re-framed RPO/RTO as **targets** with clear differentiation between engineering targets, cloud provider SLA realities, and cost implications.
7. **Complete Data Ownership & Soft-Delete Matrix:** Defined for every single database entity, establishing retention and deletion lifecycles.

---

## 2. Key Architectural Decisions, Reasons & Rejected Alternatives

### Decision 1: Strict Modular Monolith over Microservices
- **Decision:** Build Rawdaty Smart as a modular monolith (Next.js 15 Server Components, isolated domain modules, PostgreSQL relational core) rather than distributed microservices.
- **Reason:** For early-stage and medium-scale kindergarten deployments (1 to 200 kindergartens), distributed microservices introduce severe network latency, distributed transaction failure modes (two-phase commit overhead), operational tooling costs (Kubernetes, service meshes), and complex debugging without architectural benefit.
- **Rejected Alternative:** Microservices architecture (separate Auth service, Attendance service, AI service, Notification service). Rejected due to unnecessary cost, operational fragility, and failure to support transactional consistency across attendance and child custody.

### Decision 2: Super Admin Data Redaction & "Break-Glass" Access
- **Decision:** `SUPER_ADMIN` users receive zero default visibility into child profiles, attendance logs, observations, and media. To assist a kindergarten experiencing technical failure, a `super_admin_support_sessions` break-glass protocol requires a recorded justification, sets a hard 60-minute time-to-live (TTL), notifies the kindergarten `ADMIN`, and logs every accessed row.
- **Reason:** In many jurisdictions (GDPR-K, COPPA, Saudi PDPL), platform operators having unfettered access to minor children's medical and location data constitutes an unacceptable privacy liability and breach of trust.
- **Rejected Alternative:** Global super-admin bypass (`WHERE auth.is_super_admin() OR ...`). Rejected as a fatal security and compliance flaw.

### Decision 3: Separation of Basic vs. Sensitive Child Health Data
- **Decision:** Split child records into `children` (basic demographic, class link, avatar) and `child_health_profiles` (allergies, medical conditions, medication regimens, pediatric contacts). Staff can view basic identity without being exposed to clinical/medical notes unless granted explicit `VIEW_CHILD_HEALTH_INFO` permission.
- **Reason:** Bus drivers, receptionists, or cafeteria aides need to know a child's name, parent contact, and pickup permissions, but do not need access to comprehensive diagnostic health histories or psychological notes.
- **Rejected Alternative:** Storing medical notes in an unrestricted column on the main `children` table accessible to all staff. Rejected due to over-privileged data exposure.

### Decision 4: AI Derivative Entity Isolation (Zero Modification of Source Records)
- **Decision:** AI services have read-only access to teacher observations, parent observations, and attendance. AI writes exclusively to five decoupled tables:
  1. `ai_analysis`: Job metadata, model version, execution latency, token count.
  2. `ai_evidence`: Normalized pointers to the exact source record IDs cited.
  3. `ai_insight`: Synthesized strengths and cross-context milestones.
  4. `ai_recommendation`: Play activities and classroom strategies.
  5. `ai_followup`: Verification tracking whether the recommendation was adopted.
- **Reason:** Guarantees historical educational integrity. Educators and legal auditors must be 100% confident that child records were entered by humans and have not been altered or hallucinations introduced by an automated model.
- **Rejected Alternative:** Adding AI fields directly as editable columns on `teacher_observations` or allowing AI to update skill mastery levels. Rejected due to contamination of primary source records.

### Decision 5: Phased Communication Architecture (WhatsApp Deferred)
- **Decision:** WhatsApp Cloud API architecture is fully designed (HMAC-SHA256 webhooks, template schemas, rate-limiting queue), but **deferred to Phase 5**. Phase 1–4 focus on in-app PWA push and email.
- **Reason:** Meta WhatsApp Cloud API incurs per-conversation utility and marketing fees, requires Meta Business verification, and introduces third-party webhook dependencies. Core identity, student rosters, attendance, and privacy isolation must be battle-tested before adding outbound paid messaging.
- **Rejected Alternative:** Implementing WhatsApp in Phase 1. Rejected as an unnecessary operational cost and distraction from core database hardening.

### Decision 6: Offline Attendance via Idempotent Sync Queue
- **Decision:** Build an offline-first sync mechanism specifically for attendance (and later daily logs) using browser IndexedDB with UUIDv7 client-generated IDs, storing status transitions and idempotently merging on reconnect.
- **Reason:** Kindergarten classrooms frequently experience intermittent Wi-Fi or tablet disconnections during morning outdoor drop-offs. Teachers cannot be blocked from checking in children.
- **Rejected Alternative:** Making the entire application offline-first with full bi-directional CRDT database replication. Rejected as an over-engineered risk that adds immense client storage complexity.

---

## 3. Data Ownership, Lifecycle & Audit Matrix

Every database table in Rawdaty Smart is assigned strict governance rules:

| Table Name | Tenant Owner | SELECT Permitted | INSERT Permitted | UPDATE Permitted | DELETE Permitted | Soft Delete? | Audit Required? |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **`kindergartens`** | Platform / Tenant | Admin (own), Super Admin | Super Admin only | Admin (own), Super Admin | Super Admin only | Yes (`deleted_at`) | **Yes** (Tenancy) |
| **`user_profiles`** | Global / Self | Self, Admin (school members) | Supabase Auth trigger | Self, Super Admin | Self / Admin request | Yes (`deleted_at`) | **Yes** (Identity) |
| **`kindergarten_memberships`**| Tenant | Self, Admin (own school) | Admin (own school) | Admin (own school) | Admin (own school) | Yes (`deleted_at`) | **Yes** (Role/Perms) |
| **`classes`** | Tenant | Admin, Assigned Teachers, Parents (child class) | Admin (own school) | Admin (own school) | Admin (own school) | Yes (`deleted_at`) | No (Standard) |
| **`teacher_class_assignments`**| Tenant | Admin, Assigned Teacher | Admin (own school) | Admin (own school) | Admin (own school) | No (Relational) | **Yes** (Access Scope) |
| **`children`** | Tenant | Admin, Assigned Teachers, Verified Parents | Admin (own school) | Admin (own school) | Admin (own school) | **Yes (`deleted_at`)** | **Yes** (Core Student) |
| **`child_health_profiles`** | Tenant | Admin, Authorized Staff (`VIEW_CHILD_HEALTH_INFO`), Parents | Admin, Authorized Staff | Admin, Authorized Staff | Admin only | **Yes (`deleted_at`)** | **YES (MANDATORY)** |
| **`parent_child_relationships`**| Tenant | Admin, Linked Parent, Assigned Teachers | Admin (verified) | Admin (verified) | Admin only | No (Hard revoke) | **YES (MANDATORY)** |
| **`invitations`** | Tenant | Admin (own school) only | Admin (own school) | Admin (Revoke only) | Never (Immutable) | Status: `REVOKED` | **YES (MANDATORY)** |
| **`invitation_redemptions`** | Tenant | Admin (own school) only | System (Atomic RPC) | Never (Immutable) | Never (Immutable) | No (Immutable) | **YES (MANDATORY)** |
| **`attendance`** | Tenant | Admin, Assigned Teachers, Linked Parent (own child) | Assigned Teacher, Staff | Assigned Teacher (same day) | Admin only | Yes (`deleted_at`) | If altered post-day |
| **`media_vault`** | Tenant | Admin, Assigned Teachers, Tagged Parents | Admin, Assigned Teachers | Admin (metadata) | Admin only | Yes (`deleted_at`) | **Yes** (Media access) |
| **`teacher_observations`** | Tenant | Admin, Assigned Teachers, Linked Parents | Assigned Teacher | Assigned Teacher (24h edit window) | Admin only | Yes (`deleted_at`) | **Yes** (Pedagogical) |
| **`parent_observations`** | Tenant | Admin, Linked Parent, Assigned Teachers | Verified Parent (own child) | Verified Parent (24h edit window) | Parent (own) | Yes (`deleted_at`) | No (Source Record) |
| **`ai_analysis`** | Tenant | Admin, Assigned Teachers | AI Worker (System) | Never (Immutable) | Admin only | No (Immutable) | **Yes** (AI Audit) |
| **`ai_insight`** | Tenant | Admin, Assigned Teachers, Parents (if approved) | AI Worker (System) | Teacher (Approve/Reject) | Admin only | No (Immutable) | **Yes** (AI Approval) |
| **`ai_recommendation`** | Tenant | Admin, Assigned Teachers, Parents (if approved) | AI Worker (System) | Teacher (Approve/Reject) | Admin only | No (Immutable) | **Yes** (AI Approval) |
| **`audit_logs`** | Tenant / Platform | Admin (own tenant), Super Admin | System Append-Only | **NEVER (BLOCKED)** | **NEVER (BLOCKED)** | **NO (IMMUTABLE)** | Self-auditing |
| **`super_admin_support_sessions`**| Platform | Super Admin, Audited Kindergarten Admin | Super Admin (with reason) | System (Expire) | Never (Immutable) | No (Immutable) | **YES (CRITICAL)** |

---

## 4. Cost Engineering & Free-Tier Optimization Strategy

To satisfy the requirement that **the first kindergarten can operate at near-zero or low cost**, the architecture specifies infrastructure tiers:

### 4.1 Zero/Low-Cost Foundation (1 to 3 Kindergartens)
- **Supabase Free/Pro Tier ($0 to $25/month):**
  - Database: Shared PostgreSQL with RLS.
  - Storage: 1 GB free (scales to 100 GB for $25/mo on Pro).
  - Auth: 50,000 monthly active users included.
- **Vercel / Cloud Run Hosting:** Free tier for hobby/developer builds, migrating to standard Cloud Run pay-per-request (~$5–$15/mo under normal traffic).
- **In-App & Email Notifications:** Free via transactional email (Resend / Postmark free tiers: 3,000 emails/mo).
- **Gemini AI API:** Google AI Studio free tier / pay-as-you-go Flash model (~$0.075 per 1M input tokens; 100 observations cost less than $0.02).

### 4.2 Paid Infrastructure Flagging (Explicitly Labeled)
The following modules require paid commercial commitments and will NOT be activated until a kindergarten reaches commercial scale:
1. **Meta WhatsApp Cloud API (Phase 5):** Requires Meta Business verification and per-conversation fees (approx. $0.03–$0.06 per marketing conversation, $0.015 per utility conversation depending on country).
2. **Supabase Point-in-Time Recovery (PITR):** Available on Supabase Pro ($25/mo) + PITR add-on ($100/mo). For Phase 1–3, nightly encrypted logical dumps to cold storage will provide zero-cost disaster protection until commercial PITR is funded.
3. **Dedicated High-Capacity S3 Cold Storage Vault:** Pay-as-you-go AWS S3 Glacier Instant Retrieval (~$0.004 per GB/mo).

---

## 5. Explicit List of Remaining Architectural Risks & Mitigation

Prior to requesting approval to proceed with Phase 1, the following 5 residual risks are highlighted for transparent architectural governance:

| Risk Description | Severity | Likelihood | Architectural Mitigation in V2 |
| :--- | :---: | :---: | :--- |
| **1. Complex RLS Performance at Scale**<br>Extensive helper functions (`is_parent_of_child`, `is_teacher_assigned_to_class`) executed across tens of thousands of rows could slow query times. | Medium | Medium | **Mitigation:** Wrap helper functions in `SECURITY DEFINER STABLE`, inject cached claims into the JWT (`assigned_class_ids`, `linked_child_ids`), and enforce composite indexes on all lookup keys. |
| **2. Offline Attendance Clock Drift & Ordering**<br>If a teacher's tablet device clock is incorrectly set, attendance timestamps could record false check-in times. | Low | Medium | **Mitigation:** Use client-generated UUIDv7 (time-ordered) combined with server reconciliation timestamps (`client_recorded_at` vs. `server_synced_at`). The server records both values for auditability. |
| **3. Parent-Child Identity Verification Bottleneck**<br>Parents registering via invitation links must be strictly verified before gaining access to private child photos and observations. | High | Low | **Mitigation:** Admin-generated invitation tokens can be explicitly pre-bound to `target_child_id` with `target_relationship`. If an unbound link is used, custody remains in `PENDING_ADMIN_VERIFICATION` status until an Admin reviews official documents. |
| **4. AI Hallucination & Subconscious Bias**<br>Even with strict prompting, LLMs can subtly imply developmental concerns. | High | Low | **Mitigation:** Dual-layer guardrails: (1) System prompt banning clinical terms, (2) Automated post-processing regex scanner that rejects any response containing clinical or diagnostic keywords, and (3) Mandatory human teacher approval before display to parents. |
| **5. Third-Party Provider Downtime (Supabase / Cloud Hosting)**<br>Single cloud region outage could temporarily disrupt morning check-ins. | Medium | Low | **Mitigation:** Offline-first PWA attendance ensures teachers can continue morning check-ins on local tablet memory without interruption; records sync automatically once connectivity resumes. |

---

## 6. Architecture Review Recommendation

The V2 Architecture incorporates all 20 mandates with defense-in-depth security, strict multi-tenancy, immutable AI derivative structures, break-glass access controls, and low-cost staging feasibility.

**Recommendation:** Proceed to Phase 1 implementation upon explicit user confirmation of this V2 specification.
