# Rawdaty Smart (روضتي الذكية) — Technical Developer Guide

Welcome to the engineering foundation of **Rawdaty Smart (روضتي الذكية)**.  
This repository implements an early childhood kindergarten management and home-school pedagogical observation loop built upon a multi-tenant PostgreSQL / Supabase architecture.

---

## 1. Architectural Stack

- **Runtime & Language:** Node.js 20+, TypeScript (Strict Mode)
- **Frontend Framework:** React 19 + Vite 8
- **Styling:** Tailwind CSS v4
- **Database Engine:** PostgreSQL 16+ (Supabase)
- **Data Model:** Exactly 25 Entities cataloged in `FINAL_ENTITY_REGISTRY.md`
- **Security:** 100% kernel Row Level Security (RLS), Parent Custody Verification Gate, Cryptographic SHA-256 Audit Chaining
- **Testing:** pgTAP automated database regression suite (23 tests)

---

## 2. Directory Structure

```text
├── .github/
│   └── workflows/
│       └── ci.yml                 # Automated CI (TypeScript, build, migrations, pgTAP)
├── supabase/
│   └── migrations/
│       ├── 20260927000001_initial_schema.sql    # 25 Entities DDL & Triggers
│       ├── 20260927000002_rls_policies.sql      # RLS Policies & Audited Health RPC
│       └── 20260927000003_invitations_fsm.sql   # 7-State FSM Invitation RPCs
├── tests/
│   └── pgtap/
│       └── 01_security_suite.sql  # 23 Automated Security & Authorization Tests
├── src/
│   ├── lib/
│   │   ├── config/
│   │   │   └── env.ts             # Zod environment validation
│   │   └── supabase/
│   │       ├── client.ts          # Client-side user session Supabase client
│   │       └── server.ts          # Server-side user bearer & audited admin clients
│   ├── modules/
│   │   └── auth/
│   │       └── serverAuth.ts      # Server-side JWT bearer parser & permission guards
│   ├── types/
│   │   └── database.ts            # Canonical TypeScript types for all 25 Entities
│   ├── App.tsx                    # Architectural Gate Dashboard & Audit Matrix
│   ├── main.tsx                   # React client bootstrap
│   └── index.css                  # Global Tailwind styles
├── FINAL_ENTITY_REGISTRY.md       # Canonical Single Source of Truth for Entity Model
├── DATABASE_SCHEMA.md             # Complete DDL specifications
├── SECURITY_ARCHITECTURE.md       # Security Architecture & RLS policies
├── INVITATION_SYSTEM.md           # Onboarding FSM lifecycle specifications
├── TESTING_STRATEGY.md            # Testing strategy documentation
├── AI_DEVELOPMENT_ENGINE.md       # 7-Stage Non-Diagnostic AI pipeline
├── ARCHITECTURE_GATE_V4.md        # Architecture Gate V4 re-audit report
├── package.json
└── tsconfig.json
```

---

## 3. Local Development Setup

### 3.1 Prerequisites
- Node.js 20+
- npm or bun
- Optional for database testing: Docker or local PostgreSQL instance

### 3.2 Installation
```bash
# Clone repository
git clone <repository_url>
cd <repository_directory>

# Install dependencies
npm install

# Copy environment template
cp .env.example .env
```

### 3.3 Running Development Server
```bash
# Starts local Vite server on port 3000
npm run dev
```

### 3.4 Validating TypeScript & Production Build
```bash
# Strict type check
npm run lint

# Compile production bundle
npm run build
```

---

## 4. Database Migrations & Automated Security Tests

### 4.1 Applying Migrations to Local Supabase
```bash
# If using Supabase CLI
supabase db reset
# Or manually via psql
psql -h localhost -U postgres -d postgres -f supabase/migrations/20260927000001_initial_schema.sql
psql -h localhost -U postgres -d postgres -f supabase/migrations/20260927000002_rls_policies.sql
psql -h localhost -U postgres -d postgres -f supabase/migrations/20260927000003_invitations_fsm.sql
```

### 4.2 Executing 23 Automated Security Tests
```bash
# Run pgTAP test runner
pg_prove -h localhost -U postgres -d postgres tests/pgtap/01_security_suite.sql
```

---

## 5. Security Invariants

1. **Custody Verification Invariant:** Parents can never access child records until `parent_child_relationships.verified_at IS NOT NULL`.
2. **Multi-Tenancy Invariant:** No query can bypass `kindergarten_id` tenant isolation.
3. **Audit Log Invariant:** `audit_logs` and `attendance_corrections` are append-only. UPDATE and DELETE are prohibited by kernel triggers.
4. **AI Safety Invariant:** AI models can never execute INSERT, UPDATE, or DELETE on source observation records.
