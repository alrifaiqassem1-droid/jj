import { spawnSync } from 'child_process';
import fs from 'fs';

/**
 * Rawdaty Smart (روضتي الذكية) — pgTAP Suite Runner
 * 
 * Strict Integrity & Security Policy:
 * 1. Zero-Mock Policy: Never simulate pgTAP test outcomes or hardcode PASS results.
 * 2. Native Verification: pgTAP suite (tests/pgtap/01_security_suite.sql) requires a real
 *    PostgreSQL kernel with the native C-extension 'pgtap' and the 'pg_prove' harness.
 * 3. WASM / PGlite Limitation: PGlite does not bundle the native C 'pgtap' extension.
 * 4. Safe Execution: Uses spawnSync with explicit arguments array and shell: false.
 * 5. Loopback Enforcement: Rejects any host that is not strictly confirmed loopback (127.0.0.1, localhost, ::1).
 * 6. Isolated Database Guard: Default database is 'rawdaty_ephemeral_test'. Rejects shared or public databases like 'postgres'.
 * 7. Non-Assertion Guard: The mere presence of 'pg_prove' does NOT prove that an isolated database is present.
 */
function checkPgProveAvailable() {
  try {
    const res = spawnSync('which', ['pg_prove'], { shell: false, stdio: 'ignore' });
    return res.status === 0;
  } catch {
    return false;
  }
}

function runPgTapSuite() {
  console.log('================================================================');
  console.log('RAWDATY SMART — PGTAP SECURITY TEST SUITE RUNNER');
  console.log('Target Suite: tests/pgtap/01_security_suite.sql');
  console.log('================================================================\n');

  const defaultSuites = [
    'tests/pgtap/01_security_suite.sql',
    'tests/pgtap/02_sec07_health_privacy_suite.sql'
  ];
  const targetSuites = process.argv[2] ? [process.argv[2]] : defaultSuites;
  for (const s of targetSuites) {
    if (!fs.existsSync(s)) {
      console.error(`❌ FATAL: Test suite file not found at ${s}`);
      process.exit(1);
    }
  }

  const hasPgProve = checkPgProveAvailable();

  if (!hasPgProve) {
    console.error('🛑 EXECUTION STOPPED: NATIVE PGTAP ENVIRONMENT NOT DETECTED');
    console.error('----------------------------------------------------------------');
    console.error('Diagnostic & Integrity Findings:');
    console.error(`1. The test suites (${targetSuites.join(', ')}) use native pgTAP assertions`);
    console.error('   (plan, results_eq, is_empty, isnt_empty, throws_ok, finish).');
    console.error('2. PGlite (WASM) does NOT bundle the native C extension "pgtap" (CREATE EXTENSION fails).');
    console.error('3. The command-line test runner "pg_prove" is not installed in the local environment.');
    console.error('4. INTEGRITY ENFORCEMENT: Printing simulated or hardcoded PASS results is strictly removed.');
    console.error('5. NOTE: The mere presence of pg_prove would NOT prove that an isolated test database is running.');
    console.error('----------------------------------------------------------------');
    console.error('Secure Isolated Execution Guide (For CI / Local Isolated Container):');
    console.error('  Step 1: Start isolated container bound strictly to localhost:');
    console.error('          TEST_PG_PASS=$(openssl rand -hex 16)');
    console.error('          docker run -d --name rawdaty-test-pg -p 127.0.0.1:5432:5432 \\');
    console.error('            -e POSTGRES_PASSWORD="${TEST_PG_PASS}" supabase/postgres:15.1.0.147');
    console.error('  Step 2: Create a dedicated ephemeral test database (never use "postgres"):');
    console.error('          PGPASSWORD="${TEST_PG_PASS}" psql -h 127.0.0.1 -U postgres \\');
    console.error('            -c "CREATE DATABASE rawdaty_ephemeral_test;"');
    console.error('  Step 3: Apply canonical migrations to the ephemeral database:');
    console.error('          PGPASSWORD="${TEST_PG_PASS}" psql -h 127.0.0.1 -U postgres -d rawdaty_ephemeral_test \\');
    console.error('            -f supabase/migrations/20260927000001_initial_schema.sql \\');
    console.error('            -f supabase/migrations/20260927000002_rls_policies.sql \\');
    console.error('            -f supabase/migrations/20260927000003_invitations_fsm.sql \\');
    console.error('            -f supabase/migrations/20260927000004_user_profile_provisioning.sql \\');
    console.error('            -f supabase/migrations/20260927000005_super_admin_support_sessions.sql \\');
    console.error('            -f supabase/migrations/20260927000006_storage_security_hardening.sql \\');
    console.error('            -f supabase/migrations/20260927000007_super_admin_privilege_hardening.sql \\');
    console.error('            -f supabase/migrations/20260927000008_health_profile_lifecycle_and_audit.sql');
    console.error('  Step 4: Execute pg_prove safely against the isolated database:');
    console.error('          PGPASSWORD="${TEST_PG_PASS}" PGHOST=127.0.0.1 PGDATABASE=rawdaty_ephemeral_test \\');
    console.error('            npm run test:pgtap');
    console.error('----------------------------------------------------------------');
    console.error('Reference CI Pipeline: Configured in .github/workflows/ci.yml.');
    console.error('Status: STOPPED — Missing native pgTAP environment. Exiting with non-zero code.');
    process.exit(1);
  }

  // Configuration retrieval
  const host = (process.env.PGHOST || '127.0.0.1').trim();
  const portStr = (process.env.PGPORT || '5432').trim();
  const user = (process.env.PGUSER || 'postgres').trim();
  const dbname = (process.env.PGDATABASE || 'rawdaty_ephemeral_test').trim();

  // 1. Host Strict Loopback Enforcement
  const allowedLoopbacks = new Set(['127.0.0.1', 'localhost', '::1']);
  if (!allowedLoopbacks.has(host)) {
    console.error(`🚨 SECURITY HALT: Target host "${host}" is rejected.`);
    console.error('Tests can ONLY be executed against confirmed local loopback interfaces (127.0.0.1, localhost, ::1).');
    process.exit(1);
  }

  // 2. Port Validation
  const port = parseInt(portStr, 10);
  if (isNaN(port) || port < 1 || port > 65535 || !/^\d+$/.test(portStr)) {
    console.error(`🚨 SECURITY HALT: Invalid port number "${portStr}". Must be an integer between 1 and 65535.`);
    process.exit(1);
  }

  // 3. User Validation (Prevent injection)
  if (!/^[a-zA-Z0-9_-]+$/.test(user)) {
    console.error(`🚨 SECURITY HALT: Invalid PostgreSQL username "${user}".`);
    process.exit(1);
  }

  // 4. Database Name Strict Isolation Guard
  const forbiddenDatabases = new Set([
    'postgres',
    'production',
    'prod',
    'master',
    'main',
    'supabase',
    'template0',
    'template1'
  ]);
  if (forbiddenDatabases.has(dbname.toLowerCase())) {
    console.error(`🚨 SECURITY HALT: Target database name "${dbname}" is strictly forbidden.`);
    console.error('Running pgTAP against public, system, or production database names is blocked.');
    console.error('Please configure a dedicated disposable test database (e.g. rawdaty_ephemeral_test).');
    process.exit(1);
  }
  if (!/^[a-zA-Z0-9_-]+$/.test(dbname)) {
    console.error(`🚨 SECURITY HALT: Invalid database name "${dbname}". Must contain only alphanumeric/underscore characters.`);
    process.exit(1);
  }

  console.log(`Executing native pgTAP suite via pg_prove on ${host}:${port}/${dbname}...`);
  const pgProveArgs = ['-h', host, '-p', String(port), '-U', user, '-d', dbname, ...targetSuites];

  try {
    const proveResult = spawnSync('pg_prove', pgProveArgs, {
      shell: false,
      stdio: 'inherit'
    });
    if (proveResult.error) {
      console.error('\n❌ Error executing pg_prove:', proveResult.error.message);
      process.exit(1);
    }
    if (proveResult.status !== 0) {
      console.error(`\n❌ pgTAP test suite failed with status code ${proveResult.status}.`);
      process.exit(proveResult.status || 1);
    }
    console.log('\n✓ All native pgTAP tests executed and verified successfully.');
    process.exit(0);
  } catch (err) {
    console.error('\n❌ Unexpected error running pgTAP runner:', err.message);
    process.exit(1);
  }
}

runPgTapSuite();
