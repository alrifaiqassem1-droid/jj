import { PGlite } from '@electric-sql/pglite';
import fs from 'fs';

async function testSeed() {
  const db = new PGlite();
  await db.exec(`
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (id UUID PRIMARY KEY, email TEXT UNIQUE);
    CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID AS $$
      SELECT NULLIF(current_setting('request.jwt.claims', true)::jsonb->>'sub', '')::uuid;
    $$ LANGUAGE sql STABLE;
    CREATE OR REPLACE FUNCTION auth.jwt() RETURNS JSONB AS $$
      SELECT COALESCE(current_setting('request.jwt.claims', true)::jsonb, '{}'::jsonb);
    $$ LANGUAGE sql STABLE;
  `);

  await db.exec(fs.readFileSync('supabase/migrations/20260927000001_initial_schema.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000002_rls_policies.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000003_invitations_fsm.sql', 'utf-8'));

  const steps = [
    { name: 'kindergartens', sql: `INSERT INTO kindergartens (id, name, license_number, contact_email, contact_phone, address) VALUES ('11111111-1111-1111-1111-111111111111', 'Kindergarten Alpha', 'LIC-001', 'kg1@test.com', '0500000001', 'Riyadh 1');` },
    { name: 'classes', sql: `INSERT INTO classes (id, kindergarten_id, name, grade_level) VALUES ('aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '11111111-1111-1111-1111-111111111111', 'Class 1A', 'KG1');` },
    { name: 'auth.users', sql: `INSERT INTO auth.users (id, email) VALUES ('ffff0001-0000-0000-0000-000000000001', 'admin@alpha.com');` },
    { name: 'user_profiles', sql: `INSERT INTO user_profiles (id, full_name, phone_number) VALUES ('ffff0001-0000-0000-0000-000000000001', 'Admin Alpha', '0511111111');` },
    { name: 'kindergarten_memberships', sql: `INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role) VALUES ('11111111-1111-1111-1111-111111111111', 'ffff0001-0000-0000-0000-000000000001', 'ADMIN');` },
    { name: 'children', sql: `INSERT INTO children (id, kindergarten_id, class_id, first_name, last_name, dob, gender, emergency_contact_name, emergency_contact_phone) VALUES ('cccc1111-cccc-cccc-cccc-cccccccccccc', '11111111-1111-1111-1111-111111111111', 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Child A', 'Family A', '2022-01-01', 'MALE', 'Contact A', '0501111111');` },
    { name: 'parent_child_relationships', sql: `INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at) VALUES ('11111111-1111-1111-1111-111111111111', 'ffff0001-0000-0000-0000-000000000001', 'cccc1111-cccc-cccc-cccc-cccccccccccc', 'FATHER', NOW());` },
    { name: 'child_health_profiles', sql: `INSERT INTO child_health_profiles (kindergarten_id, child_id, blood_type, allergies, clinical_notes) VALUES ('11111111-1111-1111-1111-111111111111', 'cccc1111-cccc-cccc-cccc-cccccccccccc', 'O+', '{"Peanuts"}', 'Severe peanut allergy');` },
    { name: 'attendance', sql: `INSERT INTO attendance (client_attendance_uuid, kindergarten_id, class_id, child_id, date, status, recorded_by) VALUES ('88880001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'cccc1111-cccc-cccc-cccc-cccccccccccc', '2026-09-27', 'PRESENT', 'ffff0001-0000-0000-0000-000000000001');` },
    { name: 'teacher_observations', sql: `INSERT INTO teacher_observations (kindergarten_id, child_id, teacher_id, domain, observation_text, status) VALUES ('11111111-1111-1111-1111-111111111111', 'cccc1111-cccc-cccc-cccc-cccccccccccc', 'ffff0001-0000-0000-0000-000000000001', 'COGNITIVE', 'Observation text', 'PUBLISHED');` },
    { name: 'ai_analysis', sql: `INSERT INTO ai_analysis (id, kindergarten_id, child_id, model_version, prompt_tokens, completion_tokens, latency_ms, raw_response_hash) VALUES ('99990001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'cccc1111-cccc-cccc-cccc-cccccccccccc', 'gemini-1.5-pro', 100, 50, 450, 'hash_ai_001');` },
    { name: 'ai_insights', sql: `INSERT INTO ai_insights (id, kindergarten_id, child_id, analysis_id, domain, title, summary, confidence_score, status) VALUES ('99990002-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', 'cccc1111-cccc-cccc-cccc-cccccccccccc', '99990001-0000-0000-0000-000000000001', 'COGNITIVE', 'Spatial Aptitude', 'Summary', 0.94, 'APPROVED');` },
    { name: 'ai_recommendations', sql: `INSERT INTO ai_recommendations (id, kindergarten_id, child_id, insight_id, target_audience, activity_title, activity_instructions, status) VALUES ('99990003-0000-0000-0000-000000000003', '11111111-1111-1111-1111-111111111111', 'cccc1111-cccc-cccc-cccc-cccccccccccc', '99990002-0000-0000-0000-000000000002', 'PARENTS', 'Title', 'Instructions', 'APPROVED');` },
    { name: 'media_vault', sql: `INSERT INTO media_vault (id, kindergarten_id, uploaded_by, storage_path, file_size_bytes, mime_type, sha256_checksum) VALUES ('77771111-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'ffff0001-0000-0000-0000-000000000001', 'media/art.jpg', 2048, 'image/jpeg', 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');` },
    { name: 'media_child_tags', sql: `INSERT INTO media_child_tags (media_id, child_id, kindergarten_id, tagged_by) VALUES ('77771111-0000-0000-0000-000000000001', 'cccc1111-cccc-cccc-cccc-cccccccccccc', '11111111-1111-1111-1111-111111111111', 'ffff0001-0000-0000-0000-000000000001');` },
  ];

  for (const step of steps) {
    try {
      await db.exec(step.sql);
      console.log(`Step ${step.name}: SUCCESS`);
    } catch (e) {
      console.error(`Step ${step.name} ERROR:`, e.message);
    }
  }
}

testSeed().catch(console.error);
