-- ==============================================================================
-- Rawdaty Smart (روضتي الذكية) — SEC-07 pgTAP Security Suite
-- Gate SEC-07: Health Privacy, Closed RLS Surface, Clinical Authority, and Audited RPCs
-- ==============================================================================

\set ON_ERROR_STOP on
BEGIN;

CREATE EXTENSION IF NOT EXISTS pgtap;

SELECT plan(16);

-- Fixtures Setup
INSERT INTO kindergartens (id, name, license_number, contact_email, contact_phone, address)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'Kindergarten Alpha', 'LIC-SEC07-1', 'kg1@sec07.com', '0500000001', 'Riyadh 1'),
  ('22222222-2222-2222-2222-222222222222', 'Kindergarten Beta', 'LIC-SEC07-2', 'kg2@sec07.com', '0500000002', 'Riyadh 2')
ON CONFLICT (id) DO NOTHING;

INSERT INTO classes (id, kindergarten_id, name, grade_level)
VALUES 
  ('aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '11111111-1111-1111-1111-111111111111', 'Class 1A', 'KG1')
ON CONFLICT (id) DO NOTHING;

INSERT INTO user_profiles (id, full_name, phone_number)
VALUES 
  ('ffff0001-0000-0000-0000-000000000001', 'Admin Alpha', '0511111101'),
  ('ffff0002-0000-0000-0000-000000000002', 'Staff Clerical', '0522222202'),
  ('ffff0003-0000-0000-0000-000000000003', 'Staff Clinical Nurse', '0533333303'),
  ('ffff0004-0000-0000-0000-000000000004', 'Parent Verified A', '0544444404'),
  ('ffff0005-0000-0000-0000-000000000005', 'Parent Unverified B', '0555555505'),
  ('ffff0007-0000-0000-0000-000000000007', 'Super Admin Operator', '0577777707')
ON CONFLICT (id) DO NOTHING;

-- Platform Super Admin registration for Zero-Trust auth.is_super_admin()
INSERT INTO platform_super_admins (user_id)
VALUES ('ffff0007-0000-0000-0000-000000000007')
ON CONFLICT (user_id) DO NOTHING;

INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role, permissions)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'ffff0001-0000-0000-0000-000000000001', 'ADMIN', '{}'),
  ('11111111-1111-1111-1111-111111111111', 'ffff0002-0000-0000-0000-000000000002', 'STAFF', '{"VIEW_CHILD_HEALTH_INFO", "EDIT_CHILD_HEALTH_INFO"}'),
  ('11111111-1111-1111-1111-111111111111', 'ffff0003-0000-0000-0000-000000000003', 'STAFF', '{"VIEW_CHILD_HEALTH_INFO", "EDIT_CHILD_HEALTH_INFO", "PERFORM_CLINICAL_REVIEW"}'),
  ('11111111-1111-1111-1111-111111111111', 'ffff0004-0000-0000-0000-000000000004', 'PARENT', '{}'),
  ('11111111-1111-1111-1111-111111111111', 'ffff0005-0000-0000-0000-000000000005', 'PARENT', '{}')
ON CONFLICT (kindergarten_id, user_id) DO NOTHING;

INSERT INTO children (id, kindergarten_id, class_id, first_name, last_name, dob, gender, emergency_contact_name, emergency_contact_phone)
VALUES 
  ('cccc1111-cccc-cccc-cccc-cccccccccccc', '11111111-1111-1111-1111-111111111111', 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Child One', 'Alpha', '2022-01-01', 'MALE', 'Contact 1', '0501111111'),
  ('cccc2222-cccc-cccc-cccc-cccccccccccc', '11111111-1111-1111-1111-111111111111', 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Child Two', 'Beta', '2022-02-02', 'FEMALE', 'Contact 2', '0502222222')
ON CONFLICT (id) DO NOTHING;

INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'ffff0004-0000-0000-0000-000000000004', 'cccc1111-cccc-cccc-cccc-cccccccccccc', 'FATHER', NOW())
ON CONFLICT (parent_id, child_id) DO NOTHING;

INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'ffff0005-0000-0000-0000-000000000005', 'cccc2222-cccc-cccc-cccc-cccccccccccc', 'MOTHER', NULL)
ON CONFLICT (parent_id, child_id) DO NOTHING;

-- Initial health profile for Child One
INSERT INTO child_health_profiles (
  id, kindergarten_id, child_id, blood_type, allergies, has_epipen, epipen_location,
  chronic_conditions, emergency_medications, dietary_restrictions, pediatrician_name, pediatrician_phone,
  clinical_notes, last_reviewed_at, last_reviewed_by
) VALUES (
  '99990001-0000-0000-0000-000000000001',
  '11111111-1111-1111-1111-111111111111',
  'cccc1111-cccc-cccc-cccc-cccccccccccc',
  'O+', ARRAY['Peanuts'], TRUE, 'Cabinet A1',
  ARRAY['Asthma'], 'Ventolin', 'Peanut-free', 'Dr. Zaid', '0509999999',
  'Severe anaphylaxis risk on peanut exposure', '2026-09-01 10:00:00+00', 'ffff0003-0000-0000-0000-000000000003'
) ON CONFLICT (child_id) DO NOTHING;

-- TEST-01: Direct SELECT on child_health_profiles blocked via RLS
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0004-0000-0000-0000-000000000004"}';
SELECT is_empty(
  'SELECT * FROM child_health_profiles WHERE child_id = ''cccc1111-cccc-cccc-cccc-cccccccccccc''',
  'TEST-01: Direct client SELECT on child_health_profiles is blocked by default-deny RLS'
);

-- TEST-02: Direct UPDATE on child_health_profiles blocked via RLS
SELECT throws_ok(
  $$UPDATE child_health_profiles SET blood_type = 'AB+' WHERE child_id = 'cccc1111-cccc-cccc-cccc-cccccccccccc'$$,
  'TEST-02: Direct client UPDATE on child_health_profiles is strictly blocked by RLS'
);

-- TEST-03: Verified Parent receives clinical_notes and safety fields via RPC
SELECT is(
  (rpc_get_child_health_profile('cccc1111-cccc-cccc-cccc-cccccccccccc', 'Parent checking allergy status')->'data'->>'blood_type'),
  'O+',
  'TEST-03a: Verified Parent receives child blood type via RPC'
);

SELECT is(
  (rpc_get_child_health_profile('cccc1111-cccc-cccc-cccc-cccccccccccc', 'Parent checking allergy status')->'data'->>'clinical_notes'),
  'Severe anaphylaxis risk on peanut exposure',
  'TEST-03b: Decision D03: Verified Parent receives clinical_notes'
);

-- TEST-04: System internal field last_reviewed_by is masked for Parent
SELECT is(
  (rpc_get_child_health_profile('cccc1111-cccc-cccc-cccc-cccccccccccc', 'Parent checking allergy status')->'data'->>'last_reviewed_by'),
  NULL,
  'TEST-04: Internal staff ID last_reviewed_by is masked from Parent response'
);

-- TEST-05: Unverified Parent receives ACCESS_DENIED and denial is committed to audit_logs
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0005-0000-0000-0000-000000000005"}';
SELECT is(
  (rpc_get_child_health_profile('cccc2222-cccc-cccc-cccc-cccccccccccc', 'Unverified parent inspection')->>'error_code'),
  'ACCESS_DENIED',
  'TEST-05: Unverified parent access rejected with ACCESS_DENIED'
);

-- TEST-06: Denial event exists in audit_logs and transaction did not roll back
SELECT isnt_empty(
  'SELECT id FROM audit_logs WHERE action = ''CHILD_HEALTH_INFO_ACCESS_DENIED'' AND actor_id = ''ffff0005-0000-0000-0000-000000000005''',
  'TEST-06: Access denial event is reliably preserved in audit_logs'
);

-- TEST-07: Super Admin with unapproved scope EMERGENCY_SUPPORT is DENIED health access
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0007-0000-0000-0000-000000000007"}';
INSERT INTO super_admin_support_sessions (id, super_admin_id, target_kindergarten_id, reason, scope, expires_at)
VALUES ('77770001-0000-0000-0000-000000000001', 'ffff0007-0000-0000-0000-000000000007', '11111111-1111-1111-1111-111111111111', 'Emergency debugging of server attendance ledger', 'EMERGENCY_SUPPORT', NOW() + INTERVAL '30 minutes');

SELECT is(
  (rpc_get_child_health_profile('cccc1111-cccc-cccc-cccc-cccccccccccc', 'Super Admin general probe')->>'error_code'),
  'ACCESS_DENIED',
  'TEST-07: Super Admin with general scope EMERGENCY_SUPPORT cannot access health data'
);

-- TEST-08: Super Admin with exact scope CHILD_HEALTH_EMERGENCY is ALLOWED
INSERT INTO super_admin_support_sessions (id, super_admin_id, target_kindergarten_id, reason, scope, expires_at)
VALUES ('77770002-0000-0000-0000-000000000002', 'ffff0007-0000-0000-0000-000000000007', '11111111-1111-1111-1111-111111111111', 'Severe medical allergic emergency dispatch incident', 'CHILD_HEALTH_EMERGENCY', NOW() + INTERVAL '30 minutes');

SELECT is(
  (rpc_get_child_health_profile('cccc1111-cccc-cccc-cccc-cccccccccccc', 'Medical emergency consultation')->>'success')::boolean,
  TRUE,
  'TEST-08: Super Admin with exact scope CHILD_HEALTH_EMERGENCY is granted health access'
);

-- TEST-09: Emergency notification dispatched to school director on health access
SELECT isnt_empty(
  'SELECT id FROM notifications WHERE priority = ''CRITICAL'' AND metadata->>''support_session_id'' = ''77770002-0000-0000-0000-000000000002''',
  'TEST-09: CRITICAL notification created for school director upon emergency health inspection'
);

-- TEST-10: Clerical staff with EDIT_CHILD_HEALTH_INFO can update phone without clinical review
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0002-0000-0000-0000-000000000002"}';
SELECT is(
  (rpc_update_child_health_profile('cccc1111-cccc-cccc-cccc-cccccccccccc', '{"pediatrician_phone": "0555555555"}'::jsonb, FALSE, 'Clerical contact phone update')->>'success')::boolean,
  TRUE,
  'TEST-10: Staff with EDIT_CHILD_HEALTH_INFO successfully updates pediatrician phone'
);

-- TEST-11: Clerical update preserves last_reviewed_at and last_reviewed_by
SELECT is(
  (SELECT last_reviewed_by FROM child_health_profiles WHERE child_id = 'cccc1111-cccc-cccc-cccc-cccccccccccc')::uuid,
  'ffff0003-0000-0000-0000-000000000003'::uuid,
  'TEST-11: Clerical edit preserves last_reviewed_by intact without falsifying clinical review'
);

-- TEST-12: Clerical staff attempting clinical review is REJECTED
SELECT is(
  (rpc_update_child_health_profile('cccc1111-cccc-cccc-cccc-cccccccccccc', '{"clinical_notes": "Attempted nurse review"}'::jsonb, TRUE, 'Unqualified clinical review attempt')->>'error_code'),
  'CLINICAL_REVIEW_UNAUTHORIZED',
  'TEST-12: Staff lacking PERFORM_CLINICAL_REVIEW is rejected with CLINICAL_REVIEW_UNAUTHORIZED'
);

-- TEST-13: Qualified Clinical Nurse with PERFORM_CLINICAL_REVIEW records clinical review
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0003-0000-0000-0000-000000000003"}';
SELECT is(
  (rpc_update_child_health_profile('cccc1111-cccc-cccc-cccc-cccccccccccc', '{"clinical_notes": "Annual medical allergy review completed"}'::jsonb, TRUE, 'Annual routine medical checkup')->>'action'),
  'CHILD_HEALTH_CLINICAL_REVIEW_RECORDED',
  'TEST-13: Qualified nurse successfully records CHILD_HEALTH_CLINICAL_REVIEW_RECORDED'
);

-- TEST-14: Unauthorized field in patch is rejected
SELECT is(
  (rpc_update_child_health_profile('cccc1111-cccc-cccc-cccc-cccccccccccc', '{"id": "00000000-0000-0000-0000-000000000000"}'::jsonb, FALSE, 'Tamper attempt on primary key')->>'error_code'),
  'INVALID_FIELD_DETECTED',
  'TEST-14: Attempting to modify non-allowlisted system field is rejected'
);

-- TEST-15: Soft-deleted health record restoration by Admin
UPDATE child_health_profiles SET deleted_at = NOW() WHERE child_id = 'cccc1111-cccc-cccc-cccc-cccccccccccc';
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0001-0000-0000-0000-000000000001"}';

SELECT is(
  (rpc_restore_child_health_profile('cccc1111-cccc-cccc-cccc-cccccccccccc', 'Director restoring archived student medical record upon re-enrollment')->>'success')::boolean,
  TRUE,
  'TEST-15: Director successfully restores archived health profile with valid reason'
);

-- TEST-16: Restoration preserves deleted_at as NULL and logs audit event
SELECT is(
  (SELECT deleted_at FROM child_health_profiles WHERE child_id = 'cccc1111-cccc-cccc-cccc-cccccccccccc'),
  NULL,
  'TEST-16: Restored health profile has deleted_at cleared to NULL'
);

SELECT * FROM finish();
ROLLBACK;
