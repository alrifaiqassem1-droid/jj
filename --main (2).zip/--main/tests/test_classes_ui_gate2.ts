import fs from 'fs';
import path from 'path';

let passedTests = 0;
let failedTests = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    passedTests++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    failedTests++;
    console.error(`  ✗ FAIL: ${testName}${detail ? ` - ${detail}` : ''}`);
  }
}

console.log('===============================================================');
console.log('PHASE 1 — VERTICAL SLICE 1: GATE 2 UI IMPLEMENTATION TESTS');
console.log('===============================================================\n');

const componentsDir = path.join(process.cwd(), 'src/modules/classes/components');

// -----------------------------------------------------------------------------
// Group 1: Component File Integrity & Presence
// -----------------------------------------------------------------------------
console.log('--- 1. Component Presence & Exports ---');

const requiredComponents = [
  'ClassBadge.tsx',
  'KindergartenContextBanner.tsx',
  'ClassCardSkeleton.tsx',
  'ClassCard.tsx',
  'ClassesToolbar.tsx',
  'CreateClassDrawer.tsx',
  'EditClassDrawer.tsx',
  'ClassDetailsSheet.tsx',
  'ArchiveClassDialog.tsx',
  'ClassesView.tsx',
];

requiredComponents.forEach((filename) => {
  const filePath = path.join(componentsDir, filename);
  const exists = fs.existsSync(filePath);
  assert(exists, `Component exists: ${filename}`);
});

// -----------------------------------------------------------------------------
// Group 2: Architectural & Security Invariants in UI
// -----------------------------------------------------------------------------
console.log('\n--- 2. Security & Architectural Invariants in UI ---');

// Check that no UI component contains physical delete `.delete(`
let hasPhysicalDelete = false;
let hasDirectAuditLogWrite = false;

requiredComponents.forEach((filename) => {
  const code = fs.readFileSync(path.join(componentsDir, filename), 'utf8');
  if (/\.delete\s*\(/i.test(code)) {
    hasPhysicalDelete = true;
    console.error(`Found physical delete call in ${filename}`);
  }
  if (/from\s*\(\s*['"]audit_logs['"]\s*\)/i.test(code)) {
    hasDirectAuditLogWrite = true;
    console.error(`Found direct audit_logs write in ${filename}`);
  }
});

assert(!hasPhysicalDelete, 'Test: Zero physical `.delete()` in all Gate 2 UI components');
assert(!hasDirectAuditLogWrite, 'Test: Zero direct `audit_logs` writes in all Gate 2 UI components');

// -----------------------------------------------------------------------------
// Group 3: Design System v1.4 Drawer Semantics
// -----------------------------------------------------------------------------
console.log('\n--- 3. Design System v1.4 Drawer & Sheet Semantics ---');

const createDrawerCode = fs.readFileSync(path.join(componentsDir, 'CreateClassDrawer.tsx'), 'utf8');
const editDrawerCode = fs.readFileSync(path.join(componentsDir, 'EditClassDrawer.tsx'), 'utf8');
const sheetCode = fs.readFileSync(path.join(componentsDir, 'ClassDetailsSheet.tsx'), 'utf8');

// Drawer must use logical end / start
const usesLogicalEndPositioning =
  createDrawerCode.includes('justify-end') &&
  editDrawerCode.includes('justify-end') &&
  !createDrawerCode.includes('left-0') &&
  !createDrawerCode.includes('right-0');

assert(
  usesLogicalEndPositioning,
  'Test: Create & Edit Drawers adhere to logical inline-end positioning'
);

// Check default academic year in CreateClassDrawer
const hasDefaultAcademicYear =
  createDrawerCode.includes("'2026-2027'") || createDrawerCode.includes('"2026-2027"');
assert(
  hasDefaultAcademicYear,
  'Test: CreateClassDrawer uses approved UI form default "2026-2027"'
);

// Check that EditClassDrawer does NOT display raw UUID or kindergarten_id input fields
const hasRawUuidOrTenantInput =
  editDrawerCode.includes('id="edit-class-id"') ||
  editDrawerCode.includes('id="edit-class-tenant"') ||
  editDrawerCode.includes('kindergarten_id');
assert(
  !hasRawUuidOrTenantInput,
  'Test: EditClassDrawer strictly excludes technical UUID and tenant ID inputs'
);

// Check that DetailsSheet contains drag handle for mobile per DS 14.3
const hasDragHandle = sheetCode.includes('rounded-full bg-slate-300');
assert(
  hasDragHandle,
  'Test: ClassDetailsSheet contains drag handle indicator for mobile per DS 14.3'
);

// -----------------------------------------------------------------------------
// Group 4: Admin Shell Integration
// -----------------------------------------------------------------------------
console.log('\n--- 4. Admin Shell Integration ---');

const sidebarCode = fs.readFileSync(
  path.join(process.cwd(), 'src/modules/admin/components/AdminSidebar.tsx'),
  'utf8'
);
const shellCode = fs.readFileSync(
  path.join(process.cwd(), 'src/modules/admin/components/AdminShell.tsx'),
  'utf8'
);

assert(
  sidebarCode.includes("id: 'classes'") && sidebarCode.includes('t.classes.title'),
  'Test: AdminSidebar has classes navItem'
);

assert(
  shellCode.includes("<ClassesView />") && shellCode.includes("currentTab === 'classes'"),
  'Test: AdminShell renders <ClassesView /> for classes tab'
);

// -----------------------------------------------------------------------------
// Group 5: i18n Dictionary Integrity
// -----------------------------------------------------------------------------
console.log('\n--- 5. i18n Integrity ---');

const arCode = fs.readFileSync(path.join(process.cwd(), 'src/lib/i18n/ar.ts'), 'utf8');
const enCode = fs.readFileSync(path.join(process.cwd(), 'src/lib/i18n/en.ts'), 'utf8');

assert(
  arCode.includes("cancelAction: 'إلغاء'"),
  'Test: ar.ts uses standard Arabic "إلغاء" for cancelAction'
);

assert(
  arCode.includes('classes: {') && enCode.includes('classes: {'),
  'Test: Both ar.ts and en.ts include the classes translation dictionary'
);

// Check new i18n keys
assert(
  arCode.includes('keepEditingAction:') &&
  arCode.includes('discardChangesAction:') &&
  arCode.includes('phaseTag:'),
  'Test: ar.ts contains refined unsaved changes actions and phaseTag'
);

// Check zero hardcoded Arabic text in components
let hardcodedArabicFound = false;
requiredComponents.forEach((filename) => {
  const code = fs.readFileSync(path.join(componentsDir, filename), 'utf8');
  if (/[\u0600-\u06FF]/.test(code)) {
    hardcodedArabicFound = true;
    console.error(`Found hardcoded Arabic text in ${filename}`);
  }
});
assert(!hardcodedArabicFound, 'Test: Zero hardcoded Arabic strings in all Gate 2 UI components');

// Check dynamic date locale in ClassDetailsSheet
assert(
  sheetCode.includes("locale === 'ar' ? 'ar-SA' : 'en-US'"),
  'Test: ClassDetailsSheet uses dynamic locale for date formatting'
);

// Check drawer animation direction in RTL
assert(
  createDrawerCode.includes("dir === 'rtl' ? 'slide-in-from-left' : 'slide-in-from-right'") &&
  editDrawerCode.includes("dir === 'rtl' ? 'slide-in-from-left' : 'slide-in-from-right'"),
  'Test: Create & Edit Drawers animate smoothly from logical inline-end in RTL'
);

console.log('\n===============================================================');
console.log(`TEST SUMMARY: ${passedTests} PASSED, ${failedTests} FAILED`);
console.log('===============================================================');

if (failedTests > 0) {
  process.exit(1);
}
