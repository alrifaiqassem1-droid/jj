import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import {
  calculateAttendanceMetrics,
  checkDailyCutoff,
  generateDateRange,
  escapeCsvField,
  sanitizeFilename,
  generateCsvContent,
  SCHEMA_DEFAULT_TIMEZONE,
  SCHEMA_DEFAULT_CUTOFF_TIME,
  getZonedDateAndTime,
} from '../src/modules/attendance/services/attendanceReportService';
import type { AttendanceDetailRow } from '../src/modules/attendance/types/attendanceReportTypes';

let passedCount = 0;
let failedCount = 0;

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`  ✗ FAIL: ${message}`);
    failedCount++;
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`  ✓ PASS: ${message}`);
  passedCount++;
}

async function runGate6eTestSuite() {
  console.log('===============================================================');
  console.log('GATE 6E TEST SUITE — ATTENDANCE REPORTS, METRICS & CUTOFF GUARD');
  console.log('Standards: RFC 4180, Child-Day Aggregations, RBAC & Frozen Integrity');
  console.log('===============================================================');

  const rootDir = process.cwd();

  // ===========================================================================
  // CATEGORY 1: CSV Export Contract
  // ===========================================================================
  console.log('\n--- 1. CSV Export Contract Tests ---');

  // Test 1.1: UTF-8 BOM must be present
  const sampleHeaders = ['التاريخ', 'الشعبة', 'اسم الطفل', 'حالة الرصد'];
  const sampleRows = [['2026-10-06', 'روضة 1', 'أحمد علي', 'حاضر']];
  const csvOutput = generateCsvContent(sampleHeaders, sampleRows);
  assert(csvOutput.startsWith('\uFEFF'), 'Test 1.1: UTF-8 BOM (\uFEFF) is strictly present at start of CSV output');

  // Test 1.2: RFC 4180-compatible escaping for commas, quotes, and newlines
  const fieldWithComma = escapeCsvField('Ahmad, Ali');
  assert(fieldWithComma === '"Ahmad, Ali"', 'Test 1.2a: Field with comma is wrapped in double quotes');

  const fieldWithQuotes = escapeCsvField('Says "Hello"');
  assert(fieldWithQuotes === '"Says ""Hello"""', 'Test 1.2b: Field with quotes has quotes escaped as double quotes');

  const fieldWithNewline = escapeCsvField('Line 1\nLine 2');
  assert(fieldWithNewline === '"Line 1\nLine 2"', 'Test 1.2c: Field with newline is wrapped in double quotes');

  // Test 1.3: Arabic headers must use i18n and be present in dictionary
  const typesPath = path.join(rootDir, 'src/lib/i18n/types.ts');
  const arPath = path.join(rootDir, 'src/lib/i18n/ar.ts');
  const enPath = path.join(rootDir, 'src/lib/i18n/en.ts');

  const typesContent = fs.readFileSync(typesPath, 'utf-8');
  const arContent = fs.readFileSync(arPath, 'utf-8');
  const enContent = fs.readFileSync(enPath, 'utf-8');

  assert(typesContent.includes('attendanceReports: {'), 'Test 1.3a: types.ts defines attendanceReports');
  assert(arContent.includes('attendanceReports: {'), 'Test 1.3b: ar.ts defines attendanceReports');
  assert(enContent.includes('attendanceReports: {'), 'Test 1.3c: en.ts defines attendanceReports');
  assert(arContent.includes('csvHeaders: {'), 'Test 1.3d: Arabic dictionary contains csvHeaders');

  // Test 1.4: Filename must be safely sanitized (no path traversal, no unsafe characters)
  const unsafeName = '../../malicious/report 2026*?.csv';
  const safeName = sanitizeFilename(unsafeName);
  assert(!safeName.includes('/') && !safeName.includes('..') && !safeName.includes('*'), 'Test 1.4: Filename is safely sanitized');

  // Test 1.5: No PDF export in Gate 6E
  const viewPath = path.join(rootDir, 'src/modules/attendance/components/AttendanceReportsView.tsx');
  const viewContent = fs.readFileSync(viewPath, 'utf-8');
  assert(!viewContent.toLowerCase().includes('pdf') && !viewContent.includes('jspdf'), 'Test 1.5: No PDF export in Gate 6E');

  // ===========================================================================
  // CATEGORY 2: Role / Visibility Security
  // ===========================================================================
  console.log('\n--- 2. Role / Visibility Security Tests ---');

  // Test 2.1: Verify ADMIN and TEACHER access structures in AttendanceReportsView
  assert(viewContent.includes('activeRole === \'ADMIN\''), 'Test 2.1: ADMIN role has kindergarten-level access path');
  assert(viewContent.includes('activeRole === \'TEACHER\''), 'Test 2.2: TEACHER role is evaluated for assigned classes');
  assert(viewContent.includes('teacher_class_assignments'), 'Test 2.3: TEACHER queries strictly filter via teacher_class_assignments');
  assert(viewContent.includes('teacherRestrictedNotice'), 'Test 2.4: TEACHER receives restriction notice when accessing reports');

  // Test 2.5: No SUPER_ADMIN unrestricted child-data access bypass introduced
  const reportServicePath = path.join(rootDir, 'src/modules/attendance/services/attendanceReportService.ts');
  const serviceContent = fs.readFileSync(reportServicePath, 'utf-8');
  assert(!serviceContent.includes('SUPER_ADMIN_BYPASS'), 'Test 2.5: No SUPER_ADMIN unrestricted child-data access bypass');
  assert(serviceContent.includes('eq(\'kindergarten_id\', kindergartenId)'), 'Test 2.6: Tenant isolation is enforced across queries');

  // ===========================================================================
  // CATEGORY 3: Date Range Boundaries
  // ===========================================================================
  console.log('\n--- 3. Date Range Boundaries Tests ---');

  // Test 3.1: Same-day range
  const sameDay = generateDateRange('2026-10-06', '2026-10-06');
  assert(sameDay.length === 1 && sameDay[0] === '2026-10-06', 'Test 3.1: Same-day range produces exactly 1 day');

  // Test 3.2: Multi-day range (inclusive)
  const multiDay = generateDateRange('2026-10-01', '2026-10-05');
  assert(multiDay.length === 5 && multiDay[0] === '2026-10-01' && multiDay[4] === '2026-10-05', 'Test 3.2: Multi-day range includes both start and end dates');

  // Test 3.3: Month boundary transition
  const monthBoundary = generateDateRange('2026-09-29', '2026-10-02');
  assert(
    monthBoundary.length === 4 &&
      monthBoundary[0] === '2026-09-29' &&
      monthBoundary[1] === '2026-09-30' &&
      monthBoundary[2] === '2026-10-01' &&
      monthBoundary[3] === '2026-10-02',
    'Test 3.3: Month boundary transitions smoothly across September and October'
  );

  // Test 3.4: Year boundary transition
  const yearBoundary = generateDateRange('2026-12-30', '2027-01-02');
  assert(
    yearBoundary.length === 4 &&
      yearBoundary[0] === '2026-12-30' &&
      yearBoundary[1] === '2026-12-31' &&
      yearBoundary[2] === '2027-01-01' &&
      yearBoundary[3] === '2027-01-02',
    'Test 3.4: Year boundary transitions smoothly across 2026 and 2027'
  );

  // Test 3.5: Leap-year boundary (2028 is a leap year)
  const leapBoundary = generateDateRange('2028-02-28', '2028-03-01');
  assert(
    leapBoundary.length === 3 &&
      leapBoundary[0] === '2028-02-28' &&
      leapBoundary[1] === '2028-02-29' &&
      leapBoundary[2] === '2028-03-01',
    'Test 3.5: Leap-year boundary includes Feb 29 for leap year 2028'
  );

  // Test 3.6: Non-leap-year boundary (2026 is non-leap)
  const nonLeapBoundary = generateDateRange('2026-02-28', '2026-03-01');
  assert(
    nonLeapBoundary.length === 2 &&
      nonLeapBoundary[0] === '2026-02-28' &&
      nonLeapBoundary[1] === '2026-03-01',
    'Test 3.6: Non-leap year skips Feb 29 for 2026'
  );

  // Test 3.7: Invalid date range rejection
  let threwInvalidRange = false;
  try {
    generateDateRange('2026-10-10', '2026-10-05');
  } catch {
    threwInvalidRange = true;
  }
  assert(threwInvalidRange, 'Test 3.7: Invalid date range (start > end) is strictly rejected');

  // ===========================================================================
  // CATEGORY 4: Aggregation Consistency & Attendance Rate Formula
  // ===========================================================================
  console.log('\n--- 4. Aggregation Consistency & Attendance Rate Formula Tests ---');

  // Formula under test:
  // (PRESENT + CHECKED_OUT) / (PRESENT + CHECKED_OUT + ABSENT_EXCUSED + ABSENT_UNEXCUSED)
  // UNRECORDED excluded from rate denominator.
  // CHECKED_OUT counted as attended.

  // Test 4.1: Normal case
  // 10 Present, 5 Checked Out, 3 Excused, 2 Unexcused, 5 Unrecorded
  // Numerator = 10 + 5 = 15
  // Denominator = 10 + 5 + 3 + 2 = 20
  // Rate = 15 / 20 = 75%
  const m1 = calculateAttendanceMetrics(10, 5, 3, 2, 5);
  assert(m1.attendanceRate === 75, 'Test 4.1: Attendance Rate equals 75% exactly');
  assert(m1.totalRecordedChildDays === 20, 'Test 4.2: Total recorded Child-Days = 20');
  assert(m1.totalExpectedChildDays === 25, 'Test 4.3: Total expected Child-Days = 25 (includes 5 unrecorded)');
  assert(m1.unrecordedChildDays === 5, 'Test 4.4: UNRECORDED child-days are tracked independently');
  assert(m1.coverageRate === 80, 'Test 4.5: Coverage rate = (20/25)*100 = 80%');

  // Test 4.6: Denominator = 0 returns null (N/A), never artificial 0%
  const mZero = calculateAttendanceMetrics(0, 0, 0, 0, 10);
  assert(mZero.attendanceRate === null, 'Test 4.6: Denominator = 0 returns null (N/A), not 0%');
  assert(mZero.totalRecordedChildDays === 0, 'Test 4.7: 0 recorded child-days');
  assert(mZero.unrecordedChildDays === 10, 'Test 4.8: 10 unrecorded child-days tracked independently');

  // Test 4.7: 100% Attendance with Checked Out
  const mAllAttended = calculateAttendanceMetrics(7, 3, 0, 0, 2);
  assert(mAllAttended.attendanceRate === 100, 'Test 4.9: 100% attendance rate when all recorded are present or checked out');

  // Test 4.8: UNRECORDED does not alter rate
  // Case A: 5 Present, 5 Absent => 50%
  // Case B: 5 Present, 5 Absent, 100 UNRECORDED => STILL 50%
  const mA = calculateAttendanceMetrics(5, 0, 5, 0, 0);
  const mB = calculateAttendanceMetrics(5, 0, 5, 0, 100);
  assert(
    mA.attendanceRate === mB.attendanceRate && mA.attendanceRate === 50,
    'Test 4.10: Adding 100 UNRECORDED Child-Days does not degrade Attendance Rate (remains 50%)'
  );

  // Test 4.9: Consistency across byDay, byClass, and overview
  // Simulation of 2 classes across 3 days:
  // Class 1, Day 1: 5 present, 0 absent
  // Class 1, Day 2: 4 present, 1 absent
  // Class 1, Day 3: 5 present, 0 absent
  // Class 2, Day 1: 3 present, 2 absent
  // Class 2, Day 2: 3 present, 2 absent
  // Class 2, Day 3: 4 present, 1 absent
  const c1TotalPresent = 5 + 4 + 5; // 14
  const c1TotalAbsent = 0 + 1 + 0;  // 1
  const c2TotalPresent = 3 + 3 + 4; // 10
  const c2TotalAbsent = 2 + 2 + 1;  // 5

  const day1Present = 5 + 3; // 8
  const day1Absent = 0 + 2;  // 2
  const day2Present = 4 + 3; // 7
  const day2Absent = 1 + 2;  // 3
  const day3Present = 5 + 4; // 9
  const day3Absent = 0 + 1;  // 1

  const overviewPresent = c1TotalPresent + c2TotalPresent; // 24
  const overviewAbsent = c1TotalAbsent + c2TotalAbsent;   // 6

  assert(
    overviewPresent === (day1Present + day2Present + day3Present),
    'Test 4.11: Sum of byDay present equals overview present'
  );
  assert(
    overviewAbsent === (day1Absent + day2Absent + day3Absent),
    'Test 4.12: Sum of byDay absent equals overview absent'
  );

  const rateOverview = calculateAttendanceMetrics(overviewPresent, 0, overviewAbsent, 0, 0).attendanceRate;
  assert(rateOverview === 80, 'Test 4.13: Overview attendance rate = (24/30)*100 = 80%');

  // ===========================================================================
  // CATEGORY 5: Historical Child Eligibility
  // ===========================================================================
  console.log('\n--- 5. Historical Child Eligibility Tests ---');

  // Rule: Child created on 2026-10-04 must NOT contribute expected Child-Days for 2026-10-01 to 2026-10-03
  assert(
    serviceContent.includes('childCreation.split(\'T\')[0] > d'),
    'Test 5.1: Child created after report day is excluded from that day expected Child-Days'
  );
  assert(
    !serviceContent.includes('child.is_active === true'),
    'Test 5.2: Today is_active flag is not naively projected back onto historical dates'
  );
  assert(
    !serviceContent.includes('child_enrollment_history'),
    'Test 5.3: No fictional schema or migration was invented'
  );

  // ===========================================================================
  // CATEGORY 6: Large Range / Performance
  // ===========================================================================
  console.log('\n--- 6. Large Range / Performance Tests ---');

  // Test 365 days range generation and aggregation math
  const tStart = Date.now();
  const yearDates = generateDateRange('2025-01-01', '2025-12-31');
  assert(yearDates.length === 365, 'Test 6.1: Generated full 365-day range');

  // Simulate in-memory aggregation of 100 children across 365 days (36,500 Child-Days)
  let simPresent = 0;
  let simAbsent = 0;
  for (let i = 0; i < 365; i++) {
    simPresent += 90;
    simAbsent += 10;
  }
  const yearMetrics = calculateAttendanceMetrics(simPresent, 0, simAbsent, 0, 0);
  const tElapsed = Date.now() - tStart;

  assert(yearMetrics.attendanceRate === 90, 'Test 6.2: 365-day aggregation math is 100% accurate (90%)');
  assert(tElapsed < 200, `Test 6.3: 36,500 Child-Days aggregated in ${tElapsed}ms (< 200ms) without UI lock`);
  assert(!viewContent.includes('90-day') && !serviceContent.includes('90-day'), 'Test 6.4: No artificial 90-day limit enforced');

  // ===========================================================================
  // CATEGORY 7: Gate Regression & Frozen Integrity
  // ===========================================================================
  console.log('\n--- 7. Gate Regression & Frozen Integrity Tests ---');

  const frozenAttendanceService = path.join(rootDir, 'src/modules/attendance/attendanceService.ts');
  const frozenAttendanceValidation = path.join(rootDir, 'src/modules/attendance/attendanceValidation.ts');
  const frozenCorrectionDrawer = path.join(rootDir, 'src/modules/attendance/components/CorrectionDrawer.tsx');
  const frozenPickupDrawer = path.join(rootDir, 'src/modules/attendance/components/PickupDrawer.tsx');

  assert(fs.existsSync(frozenAttendanceService), 'Test 7.1: attendanceService.ts exists');
  const attServiceLines = fs.readFileSync(frozenAttendanceService, 'utf-8').split('\n').length;
  assert(attServiceLines === 684, `Test 7.2: attendanceService.ts is untouched (exactly 684 lines, got ${attServiceLines})`);

  assert(fs.existsSync(frozenAttendanceValidation), 'Test 7.3: attendanceValidation.ts exists');
  assert(fs.existsSync(frozenCorrectionDrawer), 'Test 7.4: CorrectionDrawer.tsx exists');
  assert(fs.existsSync(frozenPickupDrawer), 'Test 7.5: PickupDrawer.tsx exists');

  // Migration directory integrity check — covering all 8 canonical frozen migrations
  const migrationsDir = path.join(rootDir, 'supabase/migrations');
  const requiredMigrations = [
    '20260927000001_initial_schema.sql',
    '20260927000002_rls_policies.sql',
    '20260927000003_invitations_fsm.sql',
    '20260927000004_user_profile_provisioning.sql',
    '20260927000005_super_admin_support_sessions.sql',
    '20260927000006_storage_security_hardening.sql',
    '20260927000007_super_admin_privilege_hardening.sql',
    '20260927000008_health_profile_lifecycle_and_audit.sql',
  ];

  const migrationFiles = fs.readdirSync(migrationsDir);
  for (const mig of requiredMigrations) {
    const migPath = path.join(migrationsDir, mig);
    assert(
      migrationFiles.includes(mig) && fs.existsSync(migPath) && fs.statSync(migPath).size > 0,
      `Test 7.6: Migration ${mig} is present, accessible and non-empty`
    );
  }

  // Authoritative SHA-256 verification for frozen migrations with confirmed baseline hashes
  const authoritativeHashes: Record<string, string> = {
    '20260927000001_initial_schema.sql': '1f43f4816dba898a61c7fb4ffda2c68cba616ee2441a9f262a7ec20904c865a6',
    '20260927000003_invitations_fsm.sql': '7a60a6868fd1de0a7eab452a50779cbc1cc6663a62b8c2912f0a48ddbe9a71ca',
    '20260927000004_user_profile_provisioning.sql': 'c307d9b8ded292aba3f9f7f567b6e278721f25c05dad9e136a22dbbe01bae257',
  };

  for (const [mFile, expectedHash] of Object.entries(authoritativeHashes)) {
    const content = fs.readFileSync(path.join(migrationsDir, mFile));
    const actualHash = crypto.createHash('sha256').update(content).digest('hex');
    assert(
      actualHash === expectedHash,
      `Test 7.6b: Migration ${mFile} strictly matches authoritative SHA-256 hash (${expectedHash.slice(0, 8)}...)`
    );
  }

  // Structural DDL & Security Invariant checks for remaining frozen migrations
  const m2Content = fs.readFileSync(path.join(migrationsDir, '20260927000002_rls_policies.sql'), 'utf-8');
  assert(
    m2Content.includes('is_parent_of_child') && m2Content.includes('verified_at IS NOT NULL') && m2Content.includes('deleted_at IS NULL'),
    'Test 7.6c: Migration 00002 enforces immutable parent custody invariant'
  );

  const m5Content = fs.readFileSync(path.join(migrationsDir, '20260927000005_super_admin_support_sessions.sql'), 'utf-8');
  assert(
    m5Content.includes('super_admin_support_sessions') && m5Content.includes('rpc_initiate_support_session'),
    'Test 7.6d: Migration 00005 defines super_admin_support_sessions DDL and RPC'
  );

  const m6Content = fs.readFileSync(path.join(migrationsDir, '20260927000006_storage_security_hardening.sql'), 'utf-8');
  assert(
    m6Content.includes('media-vault') && m6Content.includes('rpc_create_signed_media_url'),
    'Test 7.6e: Migration 00006 defines private media-vault and signed URL generator'
  );

  const m7Content = fs.readFileSync(path.join(migrationsDir, '20260927000007_super_admin_privilege_hardening.sql'), 'utf-8');
  assert(
    m7Content.includes('platform_super_admins') && m7Content.includes('trg_platform_super_admins_freeze'),
    'Test 7.6f: Migration 00007 enforces platform_super_admins sole authority and freeze trigger'
  );

  const m8Content = fs.readFileSync(path.join(migrationsDir, '20260927000008_health_profile_lifecycle_and_audit.sql'), 'utf-8');
  assert(
    m8Content.includes('rpc_get_child_health_profile') && m8Content.includes('CHILD_HEALTH_INFO_VIEWED'),
    'Test 7.6g: Migration 00008 enforces audited child health RPC gateway'
  );

  // ===========================================================================
  // CATEGORY 8: Daily Cutoff Behavior, Dynamic Settings & Timezone Isolation
  // ===========================================================================
  console.log('\n--- 8. Daily Cutoff Controller Guard Tests ---');

  // Test 8.1: Schema default cutoff = 14:00 and timezone = Asia/Riyadh
  assert(SCHEMA_DEFAULT_TIMEZONE === 'Asia/Riyadh', 'Test 8.1a: SCHEMA_DEFAULT_TIMEZONE is Asia/Riyadh');
  assert(SCHEMA_DEFAULT_CUTOFF_TIME === '14:00', 'Test 8.1b: SCHEMA_DEFAULT_CUTOFF_TIME is 14:00');

  // Test 8.2: Default schema cutoff = 14:00 in Asia/Riyadh (before 14:00 vs after 14:00)
  // At 10:30 UTC = 13:30 in Riyadh (before 14:00)
  const defaultBefore = checkDailyCutoff('2026-10-06', { now: new Date('2026-10-06T10:30:00Z') });
  assert(!defaultBefore.isCutoffPassed && defaultBefore.reason === 'NOT_PASSED' && defaultBefore.cutoffTime === '14:00', 'Test 8.2a: Default schema cutoff (13:30 Riyadh) is not passed');

  // At 11:30 UTC = 14:30 in Riyadh (after 14:00)
  const defaultAfter = checkDailyCutoff('2026-10-06', { now: new Date('2026-10-06T11:30:00Z') });
  assert(defaultAfter.isCutoffPassed && defaultAfter.reason === 'TIME_PASSED' && defaultAfter.cutoffTime === '14:00', 'Test 8.2b: Default schema cutoff (14:30 Riyadh) is passed');

  // Test 8.3: Custom cutoff such as 13:30
  // At 10:20 UTC = 13:20 in Riyadh (before 13:30)
  const customBefore = checkDailyCutoff('2026-10-06', { cutoffTimeStr: '13:30', now: new Date('2026-10-06T10:20:00Z') });
  assert(!customBefore.isCutoffPassed && customBefore.cutoffTime === '13:30', 'Test 8.3a: Custom cutoff 13:30 (13:20 Riyadh) is not passed');

  // At 10:35 UTC = 13:35 in Riyadh (after 13:30)
  const customAfter = checkDailyCutoff('2026-10-06', { cutoffTimeStr: '13:30', now: new Date('2026-10-06T10:35:00Z') });
  assert(customAfter.isCutoffPassed && customAfter.cutoffTime === '13:30', 'Test 8.3b: Custom cutoff 13:30 (13:35 Riyadh) is passed');

  // Test 8.4: Exact boundary at 14:00
  // At 11:00 UTC = exactly 14:00 in Riyadh
  const exactBoundary = checkDailyCutoff('2026-10-06', { cutoffTimeStr: '14:00', now: new Date('2026-10-06T11:00:00Z') });
  assert(exactBoundary.isCutoffPassed && exactBoundary.reason === 'TIME_PASSED', 'Test 8.4: Exact boundary at 14:00 is passed');

  // Test 8.5: One minute before cutoff (13:59)
  // At 10:59 UTC = 13:59 in Riyadh
  const oneMinBefore = checkDailyCutoff('2026-10-06', { cutoffTimeStr: '14:00', now: new Date('2026-10-06T10:59:00Z') });
  assert(!oneMinBefore.isCutoffPassed && oneMinBefore.reason === 'NOT_PASSED', 'Test 8.5: Exactly one minute before cutoff (13:59) is NOT passed');

  // Test 8.6: One minute after cutoff (14:01)
  // At 11:01 UTC = 14:01 in Riyadh
  const oneMinAfter = checkDailyCutoff('2026-10-06', { cutoffTimeStr: '14:00', now: new Date('2026-10-06T11:01:00Z') });
  assert(oneMinAfter.isCutoffPassed && oneMinAfter.reason === 'TIME_PASSED', 'Test 8.6: Exactly one minute after cutoff (14:01) IS passed');

  // Test 8.7: Past calendar date is blocked
  const pastCheck = checkDailyCutoff('2026-10-01', { now: new Date('2026-10-06T10:00:00Z') });
  assert(pastCheck.isCutoffPassed && pastCheck.reason === 'PAST_DATE', 'Test 8.7: Past date in kindergarten timezone is blocked');

  // Test 8.8: Future calendar date is not blocked by cutoff guard
  const futureCheck = checkDailyCutoff('2026-10-10', { now: new Date('2026-10-06T10:00:00Z') });
  assert(!futureCheck.isCutoffPassed && futureCheck.reason === 'FUTURE_DATE', 'Test 8.8: Future date in kindergarten timezone is not blocked');

  // Test 8.9: Date boundary around midnight in Riyadh
  // At 22:30 UTC on 2026-10-06, in Riyadh (UTC+3) it is 01:30 on 2026-10-07
  const midnightRiyadh = new Date('2026-10-06T22:30:00Z');
  const pastInRiyadh = checkDailyCutoff('2026-10-06', { timezone: 'Asia/Riyadh', now: midnightRiyadh });
  assert(pastInRiyadh.isCutoffPassed && pastInRiyadh.reason === 'PAST_DATE', 'Test 8.9: 2026-10-06 is correctly recognized as PAST when Riyadh is on 2026-10-07 (01:30)');

  // Test 8.10: Same instant + different browser timezone yields identical cutoff result
  const testInstant = new Date('2026-10-06T11:05:00Z');
  const resultA = checkDailyCutoff('2026-10-06', { timezone: 'Asia/Riyadh', now: testInstant });
  const resultB = checkDailyCutoff('2026-10-06', { timezone: 'Asia/Riyadh', now: new Date(testInstant.getTime()) });
  assert(resultA.isCutoffPassed === resultB.isCutoffPassed && resultA.isCutoffPassed === true, 'Test 8.10: Same instant yields strictly identical cutoff decision');

  // Test 8.11: London browser vs Riyadh kindergarten
  // At 11:15 UTC: London device is at 12:15 BST (before 14:00). Riyadh is at 14:15 (after 14:00).
  const londonInstant = new Date('2026-10-06T11:15:00Z');
  const londonCheck = checkDailyCutoff('2026-10-06', { timezone: 'Asia/Riyadh', cutoffTimeStr: '14:00', now: londonInstant });
  assert(londonCheck.isCutoffPassed && londonCheck.reason === 'TIME_PASSED', 'Test 8.11: Riyadh cutoff triggers even if client in London is at 12:15 BST');

  // Test 8.12: New York browser vs Riyadh kindergarten
  // At 11:15 UTC: New York device is at 07:15 EDT. Riyadh is at 14:15.
  const nyInstant = new Date('2026-10-06T11:15:00Z');
  const nyCheck = checkDailyCutoff('2026-10-06', { timezone: 'Asia/Riyadh', cutoffTimeStr: '14:00', now: nyInstant });
  assert(nyCheck.isCutoffPassed && nyCheck.reason === 'TIME_PASSED', 'Test 8.12: Riyadh cutoff triggers even if client in New York is at 07:15 EDT');

  // Test 8.13: Invalid daily_cutoff_time falls back safely to schema default (14:00)
  const invalidCutoff = checkDailyCutoff('2026-10-06', { cutoffTimeStr: 'invalid-time', now: new Date('2026-10-06T10:00:00Z') });
  assert(invalidCutoff.cutoffTime === '14:00', 'Test 8.13: Malformed cutoffTimeStr falls back safely to schema default 14:00');

  // Test 8.14: Missing settings falls back safely to schema default (14:00)
  const nullSettingsCutoff = checkDailyCutoff('2026-10-06', { cutoffTimeStr: null, now: new Date('2026-10-06T10:00:00Z') });
  assert(nullSettingsCutoff.cutoffTime === '14:00', 'Test 8.14: Null settings falls back safely to schema default 14:00');

  // Test 8.15: Failure/unavailable kindergarten profile must NOT silently become a valid cutoff decision
  const failedProfileCheck = checkDailyCutoff('2026-10-06', { isProfileLoaded: false });
  assert(!failedProfileCheck.isCutoffPassed && failedProfileCheck.isReady === false && failedProfileCheck.cutoffTime === '', 'Test 8.15: Unavailable kindergarten profile does not make a silent cutoff decision');

  // Test 8.16: AttendanceView integrates getKindergartenProfile and uses dynamic settings
  const attViewContent = fs.readFileSync(path.join(rootDir, 'src/modules/attendance/components/AttendanceView.tsx'), 'utf-8');
  assert(attViewContent.includes('getKindergartenProfile'), 'Test 8.16a: AttendanceView imports and executes getKindergartenProfile');
  assert(attViewContent.includes('cutoffSettings'), 'Test 8.16b: AttendanceView computes cutoffSettings from kindergarten profile');
  assert(attViewContent.includes('isProfileLoaded: true'), 'Test 8.16c: AttendanceView marks isProfileLoaded: true only when profile is available');
  assert(attViewContent.includes('isProfileLoaded: false'), 'Test 8.16d: AttendanceView passes isProfileLoaded: false when loading or in error');

  // Test 8.17: Invariants: UNRECORDED is never auto-converted to ABSENT_UNEXCUSED
  assert(!attViewContent.includes('autoConvertUnrecorded'), 'Test 8.17a: No auto-conversion of UNRECORDED to ABSENT_UNEXCUSED in AttendanceView');
  assert(!serviceContent.includes('autoConvertUnrecorded'), 'Test 8.17b: No auto-conversion of UNRECORDED to ABSENT_UNEXCUSED in service');

  console.log('===============================================================');
  console.log(`GATE 6E TEST SUITE SUMMARY: ${passedCount} passed, ${failedCount} failed`);
  console.log('===============================================================');

  if (failedCount > 0) {
    process.exit(1);
  }
}

runGate6eTestSuite().catch((err) => {
  console.error('Fatal error running Gate 6E test suite:', err);
  process.exit(1);
});
