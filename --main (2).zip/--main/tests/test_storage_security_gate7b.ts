import { PGlite } from '@electric-sql/pglite';
import fs from 'fs';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    passed++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    failed++;
    console.error(`  ✗ FAIL: ${testName}${detail ? ` - ${detail}` : ''}`);
    throw new Error(`Assertion failed: ${testName}`);
  }
}

async function runGate7bTestSuite() {
  console.log('===============================================================');
  console.log('GATE 7B TEST SUITE — STORAGE SECURITY HARDENING');
  console.log('Standards: Private Media Vault, Storage RLS, Tenant Isolation, Parent Verification, Signed URLs');
  console.log('===============================================================\n');

  const db = new PGlite();

  // 1. Setup Auth Schema & Mock Functions
  await db.exec(`
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (
      id UUID PRIMARY KEY,
      email TEXT UNIQUE,
      phone TEXT,
      raw_user_meta_data JSONB,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );

    CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID AS $$
      SELECT NULLIF(current_setting('request.jwt.claims', true)::jsonb->>'sub', '')::uuid;
    $$ LANGUAGE sql STABLE;

    CREATE OR REPLACE FUNCTION auth.jwt() RETURNS JSONB AS $$
      SELECT COALESCE(current_setting('request.jwt.claims', true)::jsonb, '{}'::jsonb);
    $$ LANGUAGE sql STABLE;

    CREATE ROLE authenticated NOLOGIN;
    CREATE ROLE anon NOLOGIN;
    GRANT USAGE ON SCHEMA public, auth TO authenticated, anon;
  `);

  // 2. Load Migrations 1 to 6 + 9
  console.log('--- 1. Executing Migrations (1 to 6 + 9) ---');
  await db.exec(fs.readFileSync('supabase/migrations/20260927000001_initial_schema.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000002_rls_policies.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000003_invitations_fsm.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000004_user_profile_provisioning.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000005_super_admin_support_sessions.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000006_storage_security_hardening.sql', 'utf-8'));
  if (fs.existsSync('supabase/migrations/20260927000009_fix_media_denied_audit.sql')) {
    await db.exec(fs.readFileSync('supabase/migrations/20260927000009_fix_media_denied_audit.sql', 'utf-8'));
    console.log('  ✓ Migration 00009 loaded: SEC-08 Storage Audit Hardening (Structured Rejection).');
  }
  console.log('  ✓ Migrations loaded successfully into PostgreSQL engine.\n');

  await db.exec(`
    GRANT ALL ON ALL TABLES IN SCHEMA public, storage TO authenticated;
    GRANT ALL ON ALL ROUTINES IN SCHEMA public, storage, auth TO authenticated;
  `);

  // 3. Seed test fixtures: 2 kindergartens, staff, parents, children, custody
  const kgAlpha = '11111111-1111-1111-1111-111111111111';
  const kgBeta = '22222222-2222-2222-2222-222222222222';

  const adminAlpha = 'ffff0001-0000-0000-0000-000000000001';
  const adminBeta = 'ffff0002-0000-0000-0000-000000000002';
  const teacherAlpha = 'ffff0003-0000-0000-0000-000000000003';
  const parentVerifiedAlpha = 'ffff0004-0000-0000-0000-000000000004';
  const parentUnverifiedAlpha = 'ffff0005-0000-0000-0000-000000000005';
  const parentOtherAlpha = 'ffff0006-0000-0000-0000-000000000006';
  const superAdmin = 'ffff0007-0000-0000-0000-000000000007';

  const childA = 'cccc1111-cccc-cccc-cccc-cccccccccccc';
  const childB = 'cccc2222-cccc-cccc-cccc-cccccccccccc';
  const classA = 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa';

  await db.exec(`
    INSERT INTO auth.users (id, email) VALUES
      ('${adminAlpha}', 'admin_alpha@rawdaty.sa'),
      ('${adminBeta}', 'admin_beta@rawdaty.sa'),
      ('${teacherAlpha}', 'teacher_alpha@rawdaty.sa'),
      ('${parentVerifiedAlpha}', 'parent_verified@rawdaty.sa'),
      ('${parentUnverifiedAlpha}', 'parent_unverified@rawdaty.sa'),
      ('${parentOtherAlpha}', 'parent_other@rawdaty.sa'),
      ('${superAdmin}', 'super_admin@rawdaty.sa');

    INSERT INTO kindergartens (id, name, license_number, contact_email, contact_phone, address) VALUES
      ('${kgAlpha}', 'Rawdaty Alpha', 'LIC-ALPHA-01', 'alpha@rawdaty.sa', '0501111111', 'Riyadh Alpha'),
      ('${kgBeta}', 'Rawdaty Beta', 'LIC-BETA-02', 'beta@rawdaty.sa', '0502222222', 'Riyadh Beta');

    INSERT INTO user_profiles (id, full_name, phone_number) VALUES
      ('${adminAlpha}', 'Admin Alpha', '0511111111'),
      ('${adminBeta}', 'Admin Beta', '0522222222'),
      ('${teacherAlpha}', 'Teacher Alpha', '0533333333'),
      ('${parentVerifiedAlpha}', 'Parent Verified', '0544444444'),
      ('${parentUnverifiedAlpha}', 'Parent Unverified', '0555555555'),
      ('${parentOtherAlpha}', 'Parent Other', '0566666666'),
      ('${superAdmin}', 'Super Admin Operator', '0577777777')
    ON CONFLICT (id) DO UPDATE SET full_name = EXCLUDED.full_name, phone_number = EXCLUDED.phone_number;

    INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role) VALUES
      ('${kgAlpha}', '${adminAlpha}', 'ADMIN'),
      ('${kgBeta}', '${adminBeta}', 'ADMIN'),
      ('${kgAlpha}', '${teacherAlpha}', 'TEACHER'),
      ('${kgAlpha}', '${parentVerifiedAlpha}', 'PARENT'),
      ('${kgAlpha}', '${parentUnverifiedAlpha}', 'PARENT'),
      ('${kgAlpha}', '${parentOtherAlpha}', 'PARENT');

    INSERT INTO classes (id, kindergarten_id, name, grade_level) VALUES
      ('${classA}', '${kgAlpha}', 'Class Emerald', 'KG1');

    INSERT INTO children (id, kindergarten_id, class_id, first_name, last_name, dob, gender, emergency_contact_name, emergency_contact_phone) VALUES
      ('${childA}', '${kgAlpha}', '${classA}', 'Ahmad', 'Al-Mansoor', '2021-01-01', 'MALE', 'Contact Alpha', '0501112233'),
      ('${childB}', '${kgAlpha}', '${classA}', 'Reem', 'Al-Mansoor', '2021-05-05', 'FEMALE', 'Contact Beta', '0504445566');

    -- Verified relationship: parentVerifiedAlpha -> childA
    INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at) VALUES
      ('${kgAlpha}', '${parentVerifiedAlpha}', '${childA}', 'FATHER', NOW());

    -- Unverified relationship: parentUnverifiedAlpha -> childB (verified_at IS NULL)
    INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at) VALUES
      ('${kgAlpha}', '${parentUnverifiedAlpha}', '${childB}', 'MOTHER', NULL);

    -- Deleted relationship: parentOtherAlpha -> childA (deleted_at IS NOT NULL)
    INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at, deleted_at) VALUES
      ('${kgAlpha}', '${parentOtherAlpha}', '${childA}', 'LEGAL_GUARDIAN', NOW(), NOW());
  `);

  async function setAuth(userId: string | null, role: string = 'authenticated') {
    if (!userId) {
      await db.query("SELECT set_config('request.jwt.claims', '{}', false);");
      await db.exec('SET ROLE anon;');
    } else {
      await db.query("SELECT set_config('request.jwt.claims', $1, false);", [JSON.stringify({ sub: userId, role })]);
      await db.exec('SET ROLE authenticated;');
    }
  }

  // ===========================================================================
  // TEST GROUP 1: Bucket Privacy & Schema Invariants
  // ===========================================================================
  console.log('--- 2. Bucket Privacy & Definition Invariants ---');

  const bucketRes = await db.query("SELECT id, name, public FROM storage.buckets WHERE id = 'media-vault';");
  assert(bucketRes.rows.length === 1, 'Bucket media-vault exists in database');
  assert((bucketRes.rows[0] as { public: boolean }).public === false, 'CRITICAL: media-vault bucket is strictly PRIVATE (public = false)');

  // ===========================================================================
  // TEST GROUP 2: Media Vault Metadata & Object Seeding
  // ===========================================================================
  console.log('--- 3. Seeding Test Media & Storage Objects ---');

  const mediaIdAlpha = '90000001-0000-0000-0000-000000000001';
  const mediaIdBeta = '90000002-0000-0000-0000-000000000002';

  const pathAlpha = `${kgAlpha}/children/${childA}-photo.jpg`;
  const pathBeta = `${kgBeta}/children/beta-photo.jpg`;

  await setAuth(adminAlpha);
  await db.exec(`
    INSERT INTO public.media_vault (id, kindergarten_id, storage_path, mime_type, file_size_bytes, sha256_checksum, uploaded_by) VALUES
      ('${mediaIdAlpha}', '${kgAlpha}', '${pathAlpha}', 'image/jpeg', 1048576, 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '${adminAlpha}');

    INSERT INTO public.media_child_tags (kindergarten_id, media_id, child_id, tagged_by) VALUES
      ('${kgAlpha}', '${mediaIdAlpha}', '${childA}', '${adminAlpha}');

    INSERT INTO storage.objects (bucket_id, name, owner) VALUES
      ('media-vault', '${pathAlpha}', '${adminAlpha}');
  `);

  await setAuth(adminBeta);
  await db.exec(`
    INSERT INTO public.media_vault (id, kindergarten_id, storage_path, mime_type, file_size_bytes, sha256_checksum, uploaded_by) VALUES
      ('${mediaIdBeta}', '${kgBeta}', '${pathBeta}', 'image/jpeg', 2048576, 'd41d8cd98f00b204e9800998ecf8427e00000000000000000000000000000000', '${adminBeta}');

    INSERT INTO storage.objects (bucket_id, name, owner) VALUES
      ('media-vault', '${pathBeta}', '${adminBeta}');
  `);

  // ===========================================================================
  // TEST GROUP 3: Public / Anonymous Access Denied
  // ===========================================================================
  console.log('--- 4. Public / Anonymous Access Tests ---');

  await setAuth(null); // anonymous
  const anonRead = await db.query("SELECT * FROM storage.objects WHERE bucket_id = 'media-vault';");
  assert(anonRead.rows.length === 0, 'Anonymous caller receives 0 rows from storage.objects (BLOCKED)');

  let anonInsertThrows = false;
  try {
    await db.query(`
      INSERT INTO storage.objects (bucket_id, name)
      VALUES ('media-vault', '${kgAlpha}/test.jpg');
    `);
  } catch (e) {
    anonInsertThrows = true;
  }
  assert(anonInsertThrows, 'Anonymous caller cannot insert into storage.objects (BLOCKED)');

  // ===========================================================================
  // TEST GROUP 4: Storage RLS Tenant Isolation (Cross-Kindergarten)
  // ===========================================================================
  console.log('--- 5. Tenant Isolation (Cross-School Access) ---');

  // Admin Alpha tries to read Kindergarten Beta object
  await setAuth(adminAlpha);
  const crossRead = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${pathBeta}';
  `);
  assert(crossRead.rows.length === 0, 'Admin of Alpha cannot read Beta storage object (0 rows - TENANT ISOLATION)');

  // Admin Alpha tries to upload to Beta path
  let crossUploadThrows = false;
  try {
    await db.query(`
      INSERT INTO storage.objects (bucket_id, name, owner)
      VALUES ('media-vault', '${kgBeta}/hack.jpg', '${adminAlpha}');
    `);
  } catch (e) {
    crossUploadThrows = true;
  }
  assert(crossUploadThrows, 'Admin Alpha cannot upload into Kindergarten Beta storage path (BLOCKED)');

  // ===========================================================================
  // TEST GROUP 5: Role-Based Storage Access (Admin & Teacher)
  // ===========================================================================
  console.log('--- 6. Staff Storage Access (Admin & Teacher) ---');

  // Admin Alpha reads Alpha object -> ALLOW
  await setAuth(adminAlpha);
  const adminRead = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${pathAlpha}';
  `);
  assert(adminRead.rows.length === 1, 'Admin Alpha can read media object within own kindergarten (ALLOW)');

  // Teacher Alpha reads Alpha object -> ALLOW
  await setAuth(teacherAlpha);
  const teacherRead = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${pathAlpha}';
  `);
  assert(teacherRead.rows.length === 1, 'Teacher Alpha can read media object within assigned kindergarten (ALLOW)');

  // Teacher Alpha uploads to Alpha path -> ALLOW
  const teacherUploadPath = `${kgAlpha}/activities/drawing-01.png`;
  await db.query(`
    INSERT INTO storage.objects (bucket_id, name, owner)
    VALUES ('media-vault', '${teacherUploadPath}', '${teacherAlpha}');
  `);
  const teacherUploaded = await db.query(`SELECT * FROM storage.objects WHERE name = '${teacherUploadPath}';`);
  assert(teacherUploaded.rows.length === 1, 'Teacher Alpha can upload to own kindergarten storage (ALLOW)');

  // ===========================================================================
  // TEST GROUP 6: Parent-Child Relationship Storage Access
  // ===========================================================================
  console.log('--- 7. Parent Custody Verification Storage Access ---');

  // Scenario A: Verified Parent A -> Child A media (ALLOW)
  await setAuth(parentVerifiedAlpha);
  const parentVerifiedRead = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${pathAlpha}';
  `);
  assert(parentVerifiedRead.rows.length === 1, 'Verified Parent can read media tagged to own child (ALLOW)');

  // Scenario B: Verified Parent A tries to read untagged or other child media -> DENY
  const otherPath = `${kgAlpha}/children/${childB}-photo.jpg`;
  await setAuth(adminAlpha);
  await db.query(`
    INSERT INTO storage.objects (bucket_id, name, owner)
    VALUES ('media-vault', '${otherPath}', '${adminAlpha}');
  `);

  await setAuth(parentVerifiedAlpha);
  const parentOtherRead = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${otherPath}';
  `);
  assert(parentOtherRead.rows.length === 0, 'Parent A cannot read media for Child B (0 rows - DENIED)');

  // Scenario C: Unverified Parent (verified_at IS NULL) -> DENY
  await setAuth(parentUnverifiedAlpha);
  const parentUnverifiedRead = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${pathAlpha}';
  `);
  assert(parentUnverifiedRead.rows.length === 0, 'Unverified parent cannot read media (0 rows - DENIED)');

  // Scenario D: Deleted Parent Relationship (deleted_at IS NOT NULL) -> DENY
  await setAuth(parentOtherAlpha);
  const parentDeletedRead = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${pathAlpha}';
  `);
  assert(parentDeletedRead.rows.length === 0, 'Parent with deleted custody cannot read media (0 rows - DENIED)');

  // Scenario E: Parent cannot upload objects -> DENY
  await setAuth(parentVerifiedAlpha);
  let parentUploadThrows = false;
  try {
    await db.query(`
      INSERT INTO storage.objects (bucket_id, name, owner)
      VALUES ('media-vault', '${kgAlpha}/parent-rogue.jpg', '${parentVerifiedAlpha}');
    `);
  } catch (e) {
    parentUploadThrows = true;
  }
  assert(parentUploadThrows, 'Parent cannot upload objects directly into storage.objects (BLOCKED)');

  // ===========================================================================
  // TEST GROUP 7: Super Admin Emergency Session Boundary
  // ===========================================================================
  console.log('--- 8. Super Admin Break-Glass Storage Access ---');

  // Super Admin normal state (no active session) -> DENY
  await setAuth(superAdmin, 'SUPER_ADMIN');
  const superAdminNorm = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${pathAlpha}';
  `);
  assert(superAdminNorm.rows.length === 0, 'Super Admin without active session receives 0 rows (DENIED)');

  // Super Admin with active session on kgAlpha -> ALLOW
  await setAuth(superAdmin, 'SUPER_ADMIN');
  const sessionRes = await db.query(`
    SELECT rpc_initiate_support_session(
      '${kgAlpha}'::uuid,
      'Emergency investigation for media vault verification with 30 chars reason',
      30,
      'MEDIA_SECURITY'
    ) as result;
  `);
  const activeSessionId = (sessionRes.rows[0] as { result: { session_id: string } }).result.session_id;

  const superAdminActive = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${pathAlpha}';
  `);
  assert(superAdminActive.rows.length === 1, 'Super Admin with active support session can read media object (ALLOW)');

  // Super Admin on other kindergarten (kgBeta) while session is for kgAlpha -> DENY
  const superAdminBetaRead = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${pathBeta}';
  `);
  assert(superAdminBetaRead.rows.length === 0, 'Super Admin session for Alpha does NOT leak Beta objects (DENIED)');

  // Super Admin after session revocation -> DENY
  await db.query(`
    SELECT rpc_revoke_support_session(
      '${activeSessionId}'::uuid,
      'Investigation completed by super admin'
    );
  `);
  const superAdminRevokedRead = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${pathAlpha}';
  `);
  assert(superAdminRevokedRead.rows.length === 0, 'Super Admin with revoked support session receives 0 rows (DENIED)');

  // Super Admin with expired session -> DENY
  const expiredSessionRes = await db.query(`
    SELECT rpc_initiate_support_session(
      '${kgAlpha}'::uuid,
      'Another investigation to test session expiry with 30 chars reason',
      10,
      'MEDIA_SECURITY'
    ) as result;
  `);
  const expSessionId = (expiredSessionRes.rows[0] as { result: { session_id: string } }).result.session_id;

  await db.exec('RESET ROLE;');
  await db.query(`
    UPDATE super_admin_support_sessions
    SET expires_at = NOW() - INTERVAL '5 minutes'
    WHERE id = '${expSessionId}';
  `);
  await setAuth(superAdmin, 'SUPER_ADMIN');
  const superAdminExpiredRead = await db.query(`
    SELECT * FROM storage.objects WHERE name = '${pathAlpha}';
  `);
  assert(superAdminExpiredRead.rows.length === 0, 'Super Admin with expired support session receives 0 rows (DENIED)');

  // ===========================================================================
  // TEST GROUP 8: Object Immutability & Modification Protections
  // ===========================================================================
  console.log('--- 9. Immutability & Anti-Tampering ---');

  // UPDATE on storage.objects is blocked for everyone
  await setAuth(adminAlpha);
  let updateThrows = false;
  try {
    const updateRes = await db.query(`
      UPDATE storage.objects SET name = 'tampered.jpg' WHERE name = '${pathAlpha}';
    `);
    if (updateRes.affectedRows === 0) {
      updateThrows = true;
    }
  } catch (e) {
    updateThrows = true;
  }
  assert(updateThrows, 'Direct UPDATE on storage.objects is strictly prohibited (IMMUTABILITY ENFORCED)');

  // UPDATE on media_vault changing kindergarten_id is blocked by trigger
  let tamperKgThrows = false;
  try {
    await db.query(`
      UPDATE public.media_vault
      SET kindergarten_id = '${kgBeta}'
      WHERE id = '${mediaIdAlpha}';
    `);
  } catch (e) {
    tamperKgThrows = true;
  }
  assert(tamperKgThrows, 'Attempting to change kindergarten_id on media_vault triggers TAMPER_ALERT (BLOCKED)');

  // UPDATE on media_vault changing storage_path is blocked by trigger
  let tamperPathThrows = false;
  try {
    await db.query(`
      UPDATE public.media_vault
      SET storage_path = '${kgAlpha}/tampered.jpg'
      WHERE id = '${mediaIdAlpha}';
    `);
  } catch (e) {
    tamperPathThrows = true;
  }
  assert(tamperPathThrows, 'Attempting to change storage_path on media_vault triggers TAMPER_ALERT (BLOCKED)');

  // Physical DELETE on media_vault is blocked
  let deleteThrows = false;
  try {
    const delRes = await db.query(`
      DELETE FROM public.media_vault WHERE id = '${mediaIdAlpha}';
    `);
    if (delRes.affectedRows === 0) {
      deleteThrows = true;
    }
  } catch (e) {
    deleteThrows = true;
  }
  assert(deleteThrows, 'Physical DELETE on media_vault is prohibited by RLS (BLOCKED)');

  // ===========================================================================
  // TEST GROUP 9: Audited Signed URL RPC Flow
  // ===========================================================================
  console.log('--- 10. Audited Signed URL RPC Tests ---');

  // 1. Authorized Admin generates signed URL -> PASS
  await setAuth(adminAlpha);
  const adminRpcRes = await db.query(`
    SELECT rpc_create_signed_media_url(
      '${mediaIdAlpha}'::uuid,
      'Director inspection for activity report',
      3600
    ) as result;
  `);
  const rpcData = (adminRpcRes.rows[0] as { result: { success?: boolean; signed_url: string; expires_in_seconds: number } }).result;
  assert(rpcData.success !== false, 'Admin request returned success');
  assert(Boolean(rpcData.signed_url), 'Signed URL generated successfully for Admin');
  assert(rpcData.expires_in_seconds === 3600, 'Expiry seconds matches requested 3600s');

  // Check audit log recorded SIGNED_MEDIA_URL_GENERATED
  const auditRes = await db.query(`
    SELECT * FROM public.audit_logs
    WHERE resource_id = '${mediaIdAlpha}' AND action = 'SIGNED_MEDIA_URL_GENERATED';
  `);
  assert(auditRes.rows.length === 1, 'Audit event SIGNED_MEDIA_URL_GENERATED recorded with full metadata');

  // 2. Verified Parent generates signed URL for own child media -> PASS
  await setAuth(parentVerifiedAlpha);
  const parentRpcRes = await db.query(`
    SELECT rpc_create_signed_media_url(
      '${mediaIdAlpha}'::uuid,
      'Parent checking child memory album',
      1800
    ) as result;
  `);
  const parentData = (parentRpcRes.rows[0] as { result: { success?: boolean; signed_url: string } }).result;
  assert(parentData.success !== false, 'Verified Parent request returned success');
  assert(Boolean(parentData.signed_url), 'Verified Parent can generate signed URL for own child');

  // 3. Unauthorized Parent generates signed URL for other kindergarten media -> REJECTED with audit
  const unauthRpcRes = await db.query(`
    SELECT rpc_create_signed_media_url(
      '${mediaIdBeta}'::uuid,
      'Malicious probe into Beta school',
      3600
    ) as result;
  `);
  const unauthData = (unauthRpcRes.rows[0] as { result: any }).result;
  assert(unauthData.success === false, 'Unauthorized parent request rejected with success=false');
  assert(unauthData.error_code === 'PERMISSION_DENIED', 'Unauthorized parent request returns PERMISSION_DENIED error_code');
  assert(!unauthData.signed_url, 'Zero signed URL returned/leaked on unauthorized rejection');
  assert(!unauthData.storage_path, 'Zero storage path returned/leaked on unauthorized rejection');

  // Verify that unauthorized parent CANNOT view audit_logs directly due to RLS
  const parentAuditRes = await db.query(`
    SELECT * FROM public.audit_logs
    WHERE resource_id = '${mediaIdBeta}' AND action = 'MEDIA_ACCESS_DENIED';
  `);
  assert(parentAuditRes.rows.length === 0, 'Parents cannot read audit_logs directly (RLS tenant security enforced)');

  // Administrative truth check: RESET ROLE to verify database record created by SECURITY DEFINER RPC
  await db.exec('RESET ROLE;');
  const denyAuditRes = await db.query(`
    SELECT * FROM public.audit_logs
    WHERE resource_id = '${mediaIdBeta}' AND action = 'MEDIA_ACCESS_DENIED';
  `);
  assert(
    denyAuditRes.rows.length === 1,
    'Security rejection creates mandatory MEDIA_ACCESS_DENIED audit log in database',
    `Audit persistence verification failed: Got ${denyAuditRes.rows.length} rows in database (expected 1)`
  );

  // Cryptographic hash chain verification for the MEDIA_ACCESS_DENIED log
  const denyLog = denyAuditRes.rows[0] as {
    current_log_hash: string;
    previous_log_hash: string;
    actor_id: string;
    kindergarten_id: string;
  };
  assert(
    Boolean(denyLog.current_log_hash && denyLog.current_log_hash.length === 64),
    'Denial audit log entry contains valid 64-char SHA256 current_log_hash'
  );
  assert(
    Boolean(denyLog.previous_log_hash && denyLog.previous_log_hash.length === 64),
    'Denial audit log entry contains valid 64-char previous_log_hash in hash chain'
  );
  assert(
    denyLog.actor_id === parentVerifiedAlpha,
    'Denial audit log accurately records unauthorized caller actor_id'
  );

  // 4. Non-existent Media ID -> REJECTED (MEDIA_NOT_FOUND)
  const nonExistentMediaId = '00000000-0000-0000-0000-000000000099';
  const notFoundRpcRes = await db.query(`
    SELECT rpc_create_signed_media_url(
      '${nonExistentMediaId}'::uuid,
      'Probe non-existent asset',
      3600
    ) as result;
  `);
  const notFoundData = (notFoundRpcRes.rows[0] as { result: any }).result;
  assert(notFoundData.success === false, 'Non-existent media request rejected with success=false');
  assert(notFoundData.error_code === 'MEDIA_NOT_FOUND', 'Non-existent media request returns MEDIA_NOT_FOUND error_code');
  assert(!notFoundData.signed_url, 'Zero signed URL generated for non-existent media asset');

  // 5. Unauthenticated Caller -> REJECTED (UNAUTHENTICATED)
  await setAuth(null);
  const unauthCallerRes = await db.query(`
    SELECT rpc_create_signed_media_url(
      '${mediaIdAlpha}'::uuid,
      'Anonymous probe',
      3600
    ) as result;
  `);
  const unauthCallerData = (unauthCallerRes.rows[0] as { result: any }).result;
  assert(unauthCallerData.success === false, 'Unauthenticated caller request rejected with success=false');
  assert(unauthCallerData.error_code === 'UNAUTHENTICATED', 'Unauthenticated caller returns UNAUTHENTICATED error_code');
  assert(!unauthCallerData.signed_url, 'Zero signed URL generated for unauthenticated caller');

  console.log('\n===============================================================');
  console.log(`GATE 7B TEST SUMMARY: ${passed} passed, ${failed} failed`);
  console.log('===============================================================');
}

runGate7bTestSuite().catch((err) => {
  console.error('\n❌ Gate 7B Test Suite Failed:', err);
  process.exit(1);
});
