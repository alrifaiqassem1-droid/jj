/**
 * Test Harness for Parent Authorization Logic
 * Verifies exact RLS logic and auth.is_parent_of_child using real PostgreSQL engine (PGlite).
 */
import { PGlite } from '@electric-sql/pglite';
import fs from 'fs';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    passed++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    failed++;
    console.error(`  ✗ FAIL: ${testName}${detail ? ` - ${detail}` : ''}`);
    throw new Error(`Assertion failed: ${testName}${detail ? ` - ${detail}` : ''}`);
  }
}

async function runParentAuthorizationHarness() {
  console.log('================================================================');
  console.log('REAL SQL EXECUTION HARNESS: 5 PARENT AUTHORIZATION SCENARIOS');
  console.log('Engine: PostgreSQL (PGlite WASM Isolated Clean Environment)');
  console.log('================================================================\n');

  const db = new PGlite();

  // 1. Setup Auth Schema & Roles
  await db.exec(`
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (
      id UUID PRIMARY KEY,
      email TEXT UNIQUE,
      raw_user_meta_data JSONB,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );

    CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID AS $$
      SELECT NULLIF(current_setting('request.jwt.claims', true)::jsonb->>'sub', '')::uuid;
    $$ LANGUAGE sql STABLE;

    CREATE OR REPLACE FUNCTION auth.jwt() RETURNS JSONB AS $$
      SELECT COALESCE(current_setting('request.jwt.claims', true)::jsonb, '{}'::jsonb);
    $$ LANGUAGE sql STABLE;

    CREATE ROLE authenticated NOLOGIN;
    CREATE ROLE anon NOLOGIN;
    GRANT USAGE ON SCHEMA public, auth TO authenticated, anon;
  `);

  // 2. Execute canonical migrations (00001, 00002, 00003)
  const m1 = fs.readFileSync('supabase/migrations/20260927000001_initial_schema.sql', 'utf-8');
  await db.exec(m1);
  const m2 = fs.readFileSync('supabase/migrations/20260927000002_rls_policies.sql', 'utf-8');
  await db.exec(m2);
  const m3 = fs.readFileSync('supabase/migrations/20260927000003_invitations_fsm.sql', 'utf-8');
  await db.exec(m3);

  await db.exec(`
    GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
    GRANT ALL ON ALL ROUTINES IN SCHEMA public, auth TO authenticated;
  `);

  // 3. Seed synthetic test fixtures
  const kg1 = '11111111-1111-1111-1111-111111111111';
  const kg2 = '22222222-2222-2222-2222-222222222222';

  const class1 = 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
  const class2 = 'aaaa2222-aaaa-aaaa-aaaa-aaaaaaaaaaaa';

  const parentA = 'ffff0004-0000-0000-0000-000000000004';
  const parentB = 'ffff0005-0000-0000-0000-000000000005';
  const parentC = 'ffff0006-0000-0000-0000-000000000006';

  const childA = 'cccc1111-cccc-cccc-cccc-cccccccccccc';
  const childB = 'cccc2222-cccc-cccc-cccc-cccccccccccc';
  const childC = 'cccc3333-cccc-cccc-cccc-cccccccccccc';
  const childX = 'cccc4444-cccc-cccc-cccc-cccccccccccc';

  await db.exec(`
    INSERT INTO kindergartens (id, name, license_number, contact_email, contact_phone, address)
    VALUES 
      ('${kg1}', 'Kindergarten Alpha', 'LIC-001', 'kg1@test.com', '0500000001', 'Riyadh 1'),
      ('${kg2}', 'Kindergarten Beta', 'LIC-002', 'kg2@test.com', '0500000002', 'Riyadh 2');

    INSERT INTO classes (id, kindergarten_id, name, grade_level)
    VALUES 
      ('${class1}', '${kg1}', 'Class 1A', 'KG1'),
      ('${class2}', '${kg2}', 'Class 2A', 'KG1');

    INSERT INTO auth.users (id, email)
    VALUES 
      ('${parentA}', 'parent_a@test.com'),
      ('${parentB}', 'parent_b@test.com'),
      ('${parentC}', 'parent_c@test.com');

    INSERT INTO user_profiles (id, full_name, phone_number)
    VALUES 
      ('${parentA}', 'Zaid Father (Parent A)', '0544444444'),
      ('${parentB}', 'Sara Mother (Parent B)', '0555555555'),
      ('${parentC}', 'Omar Former Guardian (Parent C)', '0566666666');

    INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role)
    VALUES 
      ('${kg1}', '${parentA}', 'PARENT'),
      ('${kg1}', '${parentB}', 'PARENT'),
      ('${kg1}', '${parentC}', 'PARENT');

    INSERT INTO children (id, kindergarten_id, class_id, first_name, last_name, dob, gender, emergency_contact_name, emergency_contact_phone)
    VALUES 
      ('${childA}', '${kg1}', '${class1}', 'Zaid', 'Al-Harbi', '2022-01-01', 'MALE', 'Contact A', '0501111111'),
      ('${childB}', '${kg1}', '${class1}', 'Sara', 'Al-Otaibi', '2022-02-02', 'FEMALE', 'Contact B', '0502222222'),
      ('${childC}', '${kg1}', '${class1}', 'Omar', 'Al-Ghamdi', '2022-03-03', 'MALE', 'Contact C', '0503333333'),
      ('${childX}', '${kg2}', '${class2}', 'Layla', 'Al-Shehri', '2022-04-04', 'FEMALE', 'Contact X', '0504444444');

    -- Scenario A: Verified Relationship Parent A -> Child A (verified_at NOT NULL, deleted_at NULL)
    INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at, deleted_at)
    VALUES ('${kg1}', '${parentA}', '${childA}', 'FATHER', NOW(), NULL);

    -- Scenario B: Unverified Relationship Parent B -> Child B (verified_at IS NULL, deleted_at NULL)
    INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at, deleted_at)
    VALUES ('${kg1}', '${parentB}', '${childB}', 'MOTHER', NULL, NULL);

    -- Scenario C: Deleted Custody Relationship Parent C -> Child C (verified_at NOT NULL, deleted_at NOT NULL)
    INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at, deleted_at)
    VALUES ('${kg1}', '${parentC}', '${childC}', 'LEGAL_GUARDIAN', NOW(), NOW());
  `);

  async function queryAsUser(userId: string, sql: string) {
    await db.query("SELECT set_config('request.jwt.claims', $1, false);", [JSON.stringify({ sub: userId })]);
    await db.exec('SET ROLE authenticated;');
    try {
      const res = await db.query(sql);
      return res.rows;
    } finally {
      await db.exec('RESET ROLE;');
    }
  }

  // Scenario A: Verified Relationship (Parent A -> Child A) -> ALLOW (1 row) & auth.is_parent_of_child = true
  const rowsA = await queryAsUser(parentA, `SELECT first_name FROM children WHERE id = '${childA}';`);
  const fnA = (await queryAsUser(parentA, `SELECT auth.is_parent_of_child('${childA}') as is_p;`))[0] as { is_p: boolean };
  assert(rowsA.length === 1 && fnA.is_p === true, 'Scenario A: Verified Parent A successfully selects own Child A via RLS & auth.is_parent_of_child()');

  // Scenario B: Unverified Relationship (Parent B -> Child B) -> DENY (0 rows) & auth.is_parent_of_child = false
  const rowsB = await queryAsUser(parentB, `SELECT * FROM children WHERE id = '${childB}';`);
  const fnB = (await queryAsUser(parentB, `SELECT auth.is_parent_of_child('${childB}') as is_p;`))[0] as { is_p: boolean };
  assert(rowsB.length === 0 && fnB.is_p === false, 'Scenario B: Unverified Parent B strictly denied access to Child B (0 rows returned)');

  // Scenario C: Deleted Relationship (Parent C -> Child C) -> DENY (0 rows) & auth.is_parent_of_child = false
  const rowsC = await queryAsUser(parentC, `SELECT * FROM children WHERE id = '${childC}';`);
  const fnC = (await queryAsUser(parentC, `SELECT auth.is_parent_of_child('${childC}') as is_p;`))[0] as { is_p: boolean };
  assert(rowsC.length === 0 && fnC.is_p === false, 'Scenario C: Deleted Custody Parent C strictly denied access to Child C (0 rows returned)');

  // Scenario D: Parent A -> Child B (Horizontal Unauthorized Probe) -> DENY (0 rows) & auth.is_parent_of_child = false
  const rowsD = await queryAsUser(parentA, `SELECT * FROM children WHERE id = '${childB}';`);
  const fnD = (await queryAsUser(parentA, `SELECT auth.is_parent_of_child('${childB}') as is_p;`))[0] as { is_p: boolean };
  assert(rowsD.length === 0 && fnD.is_p === false, 'Scenario D: Parent A horizontal probe to other Child B strictly blocked by RLS');

  // Scenario E: Arbitrary / Unknown Child ID Probe -> DENY (0 rows) & auth.is_parent_of_child = false
  const arbitraryId = '99999999-9999-9999-9999-999999999999';
  const rowsE = await queryAsUser(parentA, `SELECT * FROM children WHERE id = '${arbitraryId}';`);
  const fnE = (await queryAsUser(parentA, `SELECT auth.is_parent_of_child('${arbitraryId}') as is_p;`))[0] as { is_p: boolean };
  assert(rowsE.length === 0 && fnE.is_p === false, 'Scenario E: Arbitrary UUID injection probe strictly blocked by RLS');

  console.log('\n================================================================');
  console.log(`REAL SQL PARENT AUTHORIZATION HARNESS: ${passed} PASSED, ${failed} FAILED`);
  console.log('================================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runParentAuthorizationHarness().catch(err => {
  console.error('\n❌ FATAL HARNESS ERROR:', err);
  process.exit(1);
});
