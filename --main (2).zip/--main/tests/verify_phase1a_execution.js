import fs from 'fs';
import path from 'path';

console.log('================================================================');
console.log('PHASE 1A — VERIFICATION & EXECUTION EVIDENCE RUNNER');
console.log('================================================================');

// 1. Entities from Registry
const registryContent = fs.readFileSync('FINAL_ENTITY_REGISTRY.md', 'utf-8');
const schemaContent = fs.readFileSync('DATABASE_SCHEMA.md', 'utf-8');
const securityContent = fs.readFileSync('SECURITY_ARCHITECTURE.md', 'utf-8');
const migration1 = fs.readFileSync('supabase/migrations/20260927000001_initial_schema.sql', 'utf-8');
const migration2 = fs.readFileSync('supabase/migrations/20260927000002_rls_policies.sql', 'utf-8');
const migration3 = fs.readFileSync('supabase/migrations/20260927000003_invitations_fsm.sql', 'utf-8');

const expectedEntities = [
  'kindergartens',
  'user_profiles',
  'kindergarten_memberships',
  'super_admin_support_sessions',
  'classes',
  'teacher_class_assignments',
  'children',
  'child_health_profiles',
  'parent_child_relationships',
  'invitations',
  'invitation_redemptions',
  'attendance',
  'attendance_corrections',
  'teacher_observations',
  'parent_observations',
  'ai_analysis',
  'ai_evidence',
  'ai_insights',
  'ai_recommendations',
  'ai_followups',
  'media_vault',
  'media_child_tags',
  'tuition_invoices',
  'notifications',
  'audit_logs'
];

console.log(`\n[CHECK 1] Entity Count in expectedEntities: ${expectedEntities.length}`);

// Extract CREATE TABLE from migration 1
const tablesCreated = [];
const tableRegex = /CREATE\s+TABLE\s+([a-z_]+)\s*\(/g;
let match;
while ((match = tableRegex.exec(migration1)) !== null) {
  tablesCreated.push(match[1]);
}

console.log(`[CHECK 2] Tables Created in Migration 1: ${tablesCreated.length}`);

// Compare registry, schema, security, migration1
console.log('\n--- 25 ENTITY COMPARISON TABLE ---');
console.log('| # | Entity Name | Registry | Schema | Security | Migration 1 (DDL) | RLS Enabled (Mig 2) | Match Status |');
console.log('|---|-------------|----------|--------|----------|-------------------|---------------------|--------------|');

let mismatchCount = 0;
expectedEntities.forEach((entity, idx) => {
  const inRegistry = registryContent.includes(entity) ? 'YES' : 'NO';
  const inSchema = schemaContent.includes(entity) ? 'YES' : 'NO';
  const inSecurity = securityContent.includes(entity) ? 'YES' : 'NO';
  const inMigration1 = tablesCreated.includes(entity) ? 'YES' : 'NO';
  const rlsRegex = new RegExp(`ALTER\\s+TABLE\\s+${entity}\\s+ENABLE\\s+ROW\\s+LEVEL\\s+SECURITY`, 'i');
  const hasRLS = rlsRegex.test(migration2) ? 'YES' : 'NO';

  const isMatch = inRegistry === 'YES' && inSchema === 'YES' && inSecurity === 'YES' && inMigration1 === 'YES' && hasRLS === 'YES';
  if (!isMatch) mismatchCount++;

  console.log(`| ${idx + 1} | ${entity} | ${inRegistry} | ${inSchema} | ${inSecurity} | ${inMigration1} | ${hasRLS} | ${isMatch ? 'PERFECT MATCH' : 'MISMATCH'} |`);
});

console.log(`\nTotal Entities Checked: ${expectedEntities.length}`);
console.log(`Total Mismatches: ${mismatchCount}`);

// Check for any extra tables in migration 1
const extraTables = tablesCreated.filter(t => !expectedEntities.includes(t));
console.log(`Extra Tables in Migration 1: ${extraTables.length === 0 ? 'NONE (Exactly 25 tables)' : extraTables.join(', ')}`);

// Check RLS Policies per table in Migration 2
console.log('\n--- RLS POLICIES EXTRACTION FROM MIGRATION 2 ---');
expectedEntities.forEach(entity => {
  const policyMatches = [];
  const policyRegex = new RegExp(`CREATE\\s+POLICY\\s+"([^"]+)"\\s+ON\\s+${entity}\\s+FOR\\s+([A-Z]+)`, 'gi');
  let pMatch;
  while ((pMatch = policyRegex.exec(migration2)) !== null) {
    policyMatches.push(`${pMatch[2]}: ${pMatch[1]}`);
  }
  console.log(`\nEntity: ${entity} (Total Policies: ${policyMatches.length})`);
  policyMatches.forEach(p => console.log(`  - ${p}`));
});

// Check Parent Invariant in helper function and policies
console.log('\n--- PARENT AUTHORIZATION INVARIANT CHECK ---');
const parentHelperRegex = /is_parent_of_child[\s\S]*?verified_at IS NOT NULL[\s\S]*?deleted_at IS NULL/;
console.log(`Helper Function is_parent_of_child enforces (verified_at IS NOT NULL AND deleted_at IS NULL): ${parentHelperRegex.test(migration2) ? 'PASS' : 'FAIL'}`);

console.log('\n================================================================');
console.log('VERIFICATION SCRIPT COMPLETED');
console.log('================================================================');
