import fs from 'fs';
import path from 'path';

function runPhase1B1AdminShellTests() {
  console.log('================================================================');
  console.log('PHASE 1B.1: ADMIN SHELL & AUTHORIZATION TEST SUITE');
  console.log('================================================================\n');

  // TEST 1: Check AdminGuard authorization logic
  console.log('[TEST 1] Verifying Admin Authorization logic in AdminGuard.tsx...');
  const guardPath = 'src/modules/admin/components/AdminGuard.tsx';
  if (!fs.existsSync(guardPath)) {
    throw new Error('TEST 1 FAILED: AdminGuard.tsx is missing!');
  }
  const guardContent = fs.readFileSync(guardPath, 'utf-8');

  // Verification 1.1: Unauthenticated rejection
  if (!guardContent.includes('!user') || !guardContent.includes('unauthenticatedTitle')) {
    throw new Error('TEST 1 FAILED: AdminGuard does not gate unauthenticated users!');
  }
  // Verification 1.2: Role check (must restrict to ADMIN / SUPER_ADMIN)
  if (!guardContent.includes("activeRole === 'ADMIN'") || !guardContent.includes("activeRole === 'SUPER_ADMIN'")) {
    throw new Error('TEST 1 FAILED: AdminGuard does not restrict access to ADMIN / SUPER_ADMIN!');
  }
  // Verification 1.3: Access denied rejection
  if (!guardContent.includes('accessDeniedTitle')) {
    throw new Error('TEST 1 FAILED: AdminGuard does not provide access denied rejection view!');
  }
  console.log('✓ TEST 1 PASS: AdminGuard strictly enforces unauthenticated & non-admin rejection.\n');

  // TEST 2: Check AdminShell modular components existence
  console.log('[TEST 2] Verifying Admin Shell modular architecture...');
  const adminComponents = [
    'src/modules/admin/components/AdminShell.tsx',
    'src/modules/admin/components/AdminSidebar.tsx',
    'src/modules/admin/components/AdminHeader.tsx',
    'src/modules/admin/components/AdminGuard.tsx',
    'src/modules/admin/components/AdminOverviewView.tsx',
    'src/modules/admin/components/AdminPlaceholderView.tsx',
  ];

  for (const comp of adminComponents) {
    if (!fs.existsSync(comp)) {
      throw new Error(`TEST 2 FAILED: Missing modular component: ${comp}`);
    }
  }
  console.log('✓ TEST 2 PASS: All 6 Admin Shell components exist and are modularly decoupled.\n');

  // TEST 3: Check i18n key parity and Arabic-first completeness
  console.log('[TEST 3] Verifying 100% key parity for adminShell in ar.ts & en.ts...');
  const arPath = 'src/lib/i18n/ar.ts';
  const enPath = 'src/lib/i18n/en.ts';
  const arContent = fs.readFileSync(arPath, 'utf-8');
  const enContent = fs.readFileSync(enPath, 'utf-8');

  const requiredAdminKeys = [
    'title',
    'subtitle',
    'roleBadge',
    'activeKindergarten',
    'noActiveKindergarten',
    'switchKindergarten',
    'navOverview',
    'navActivities',
    'navChildren',
    'navTeachers',
    'navAttendance',
    'navReports',
    'navSettings',
    'placeholderTitle',
    'placeholderDesc',
    'placeholderPhaseNote',
    'accessDeniedTitle',
    'accessDeniedDesc',
    'accessDeniedAction',
    'unauthenticatedTitle',
    'unauthenticatedDesc',
    'backToHome',
    'userProfile',
    'collapseSidebar',
    'expandSidebar',
    'goToAdminPanel',
    'backToBaseline',
  ];

  for (const k of requiredAdminKeys) {
    if (!arContent.includes(`${k}:`)) {
      throw new Error(`TEST 3 FAILED: ar.ts is missing adminShell key: ${k}`);
    }
    if (!enContent.includes(`${k}:`)) {
      throw new Error(`TEST 3 FAILED: en.ts is missing adminShell key: ${k}`);
    }
  }
  console.log(`✓ TEST 3 PASS: All ${requiredAdminKeys.length} adminShell keys verified in both ar.ts and en.ts.\n`);

  // TEST 4: Check that NO hard-coded Arabic user strings exist in admin components
  console.log('[TEST 4] Verifying no hard-coded Arabic user strings in admin components...');
  for (const comp of adminComponents) {
    const content = fs.readFileSync(comp, 'utf-8');
    // Regex for Arabic characters outside comments
    const lines = content.split('\n');
    lines.forEach((line, idx) => {
      const trimmed = line.trim();
      if (trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*')) {
        return; // Comment line
      }
      // Check if JSX text contains Arabic without t.*
      const arabicMatch = /[\u0600-\u06FF]/.test(line);
      if (arabicMatch && !line.includes('title="تبديل اللغة / Toggle Language"')) {
        throw new Error(`TEST 4 FAILED: Hardcoded Arabic string detected in ${comp} line ${idx + 1}: ${line}`);
      }
    });
  }
  console.log('✓ TEST 4 PASS: Zero hard-coded Arabic strings; all user text flows through i18n.\n');

  // TEST 5: Verify Active Kindergarten Context is read from AuthContext
  console.log('[TEST 5] Verifying Active Kindergarten Context is used in Admin Shell...');
  const overviewContent = fs.readFileSync('src/modules/admin/components/AdminOverviewView.tsx', 'utf-8');
  const headerContent = fs.readFileSync('src/modules/admin/components/AdminHeader.tsx', 'utf-8');

  if (!overviewContent.includes('activeMembership') || !headerContent.includes('activeMembership')) {
    throw new Error('TEST 5 FAILED: Admin Shell does not read activeMembership context!');
  }
  console.log('✓ TEST 5 PASS: Active kindergarten context is cleanly propagated to Admin Shell.\n');

  // TEST 6: Verify Frozen Migrations SHA-256 hashes remain strictly unchanged
  console.log('[TEST 6] Verifying immutable SHA-256 hashes of frozen migrations...');
  const expectedHashes = {
    'supabase/migrations/20260927000001_initial_schema.sql': '1f43f4816dba898a61c7fb4ffda2c68cba616ee2441a9f262a7ec20904c865a6',
    'supabase/migrations/20260927000002_rls_policies.sql': '23cb78d9fff93e8b6e135239e321b8951691befbd1a91b95565d19fea8f7cf81',
    'supabase/migrations/20260927000003_invitations_fsm.sql': '7a60a6868fd1de0a7eab452a50779cbc1cc6663a62b8c2912f0a48ddbe9a71ca',
    'supabase/migrations/20260927000004_user_profile_provisioning.sql': 'c307d9b8ded292aba3f9f7f567b6e278721f25c05dad9e136a22dbbe01bae257',
  };

  import('crypto').then((crypto) => {
    for (const [filePath, expectedHash] of Object.entries(expectedHashes)) {
      const fileBuffer = fs.readFileSync(filePath);
      const actualHash = crypto.createHash('sha256').update(fileBuffer).digest('hex');
      if (actualHash !== expectedHash) {
        throw new Error(`TEST 6 FAILED: Frozen migration ${filePath} hash mismatch! Expected ${expectedHash}, got ${actualHash}`);
      }
    }
    console.log('✓ TEST 6 PASS: All 4 frozen migrations strictly match immutable SHA-256 hashes.\n');

    console.log('================================================================');
    console.log('ALL 6 PHASE 1B.1 ADMIN SHELL TESTS PASSED (100% SUCCESS)');
    console.log('================================================================');
  });
}

try {
  runPhase1B1AdminShellTests();
} catch (err) {
  console.error('\n❌ PHASE 1B.1 TEST FAILED:', err.message);
  process.exit(1);
}
