import fs from 'fs';
import path from 'path';
import {
  linkParentSchema,
  updateRelationshipSchema,
  verifyCustodySchema,
} from '../src/modules/parents/parentValidation';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`  ✗ FAIL: ${message}`);
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`  ✓ PASS: ${message}`);
}

console.log('===============================================================');
console.log('PHASE 1 — VERTICAL SLICE 4: IMPLEMENTATION GATE 5 TEST SUITE');
console.log('Parent–Child Relationships & Custody Verification');
console.log('===============================================================');

// -----------------------------------------------------------------------------
// Group 1: Validation Rules Execution Tests (Zod Contracts)
// -----------------------------------------------------------------------------
console.log('\n--- 1. Validation Rules Execution Tests ---');

// Test 1: Valid link parent input parses successfully
const validLink = {
  child_id: 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
  parent_id: 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22',
  relationship: 'MOTHER',
  is_primary_contact: true,
  authorized_for_pickup: true,
  auto_verify: true,
  verification_notes: 'Birth certificate copy verified',
};
const parseResult1 = linkParentSchema.safeParse(validLink);
assert(parseResult1.success, 'Test 1: Valid link parent input parses successfully');

// Test 2: Invalid child UUID rejected
const invalidChildUuid = {
  child_id: 'invalid-uuid-123',
  parent_id: 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22',
  relationship: 'FATHER',
};
const parseResult2 = linkParentSchema.safeParse(invalidChildUuid);
assert(!parseResult2.success, 'Test 2: Malformed child_id UUID is rejected');

// Test 3: Invalid parent UUID rejected
const invalidParentUuid = {
  child_id: 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
  parent_id: 'not-a-parent-uuid',
  relationship: 'LEGAL_GUARDIAN',
};
const parseResult3 = linkParentSchema.safeParse(invalidParentUuid);
assert(!parseResult3.success, 'Test 3: Malformed parent_id UUID is rejected');

// Test 4: Invalid relationship type enum rejected
const invalidRelType = {
  child_id: 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
  parent_id: 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22',
  relationship: 'NEIGHBOR',
};
const parseResult4 = linkParentSchema.safeParse(invalidRelType);
assert(!parseResult4.success, 'Test 4: Non-canonical relationship type enum is rejected');

// Test 5: Verify custody schema parses valid notes
const validNotes = { verification_notes: 'Family court custody order #412/1447' };
const parseResult5 = verifyCustodySchema.safeParse(validNotes);
assert(parseResult5.success, 'Test 5: Valid custody verification input parses successfully');

// Test 6: Update relationship schema parses partial inputs
const validUpdate = { authorized_for_pickup: false };
const parseResult6 = updateRelationshipSchema.safeParse(validUpdate);
assert(parseResult6.success, 'Test 6: Partial update relationship schema parses successfully');

// -----------------------------------------------------------------------------
// Group 2: Architectural & Security Invariant Tests
// -----------------------------------------------------------------------------
console.log('\n--- 2. Architectural & Security Invariants ---');

const servicePath = path.join(process.cwd(), 'src/modules/parents/parentRelationshipsService.ts');
assert(fs.existsSync(servicePath), 'Test 7: parentRelationshipsService.ts exists');
const serviceCode = fs.readFileSync(servicePath, 'utf8');

// Test 8: Zero physical delete on primary entities
const deletesClasses = /\.from\(['"]classes['"]\)\s*\.delete\(\)/.test(serviceCode);
const deletesChildren = /\.from\(['"]children['"]\)\s*\.delete\(\)/.test(serviceCode);
const deletesMemberships = /\.from\(['"]kindergarten_memberships['"]\)\s*\.delete\(\)/.test(serviceCode);
const deletesProfiles = /\.from\(['"]user_profiles['"]\)\s*\.delete\(\)/.test(serviceCode);
const deletesRelationships = /\.from\(['"]parent_child_relationships['"]\)\s*\.delete\(\)/.test(serviceCode);
assert(
  !deletesClasses && !deletesChildren && !deletesMemberships && !deletesProfiles && !deletesRelationships,
  'Test 8: parentRelationshipsService.ts contains ZERO physical .delete() on any table (uses soft-delete exclusively)'
);

// Test 9: Zero client-side audit writes
const writesToAuditLogs = /audit_logs/i.test(serviceCode);
assert(!writesToAuditLogs, 'Test 9: parentRelationshipsService.ts does NOT perform direct client writes to audit_logs');

// Test 10: Security Constraint #1: Tenant enforcement checks child.kindergarten_id === target kindergartenId
const checksTenant = /child\.kindergarten_id\s*!==\s*kindergartenId/.test(serviceCode);
const returnsCrossTenantError = /CROSS_TENANT_CHILD/.test(serviceCode);
assert(
  checksTenant && returnsCrossTenantError,
  'Test 10: SECURITY CONSTRAINT #1: linkParentToChild strictly verifies child.kindergarten_id === target kindergartenId'
);

// Test 11: Security Constraint #2: Parent eligibility checks role = 'PARENT' and active
const checksParentRole = /eq\(['"]role['"],\s*['"]PARENT['"]\)/.test(serviceCode);
const checksParentActive = /eq\(['"]is_active['"],\s*true\)/.test(serviceCode);
const checksParentNonDeleted = /is\(['"]deleted_at['"],\s*null\)/.test(serviceCode);
const returnsNotEligible = /PARENT_NOT_ELIGIBLE/.test(serviceCode);
assert(
  checksParentRole && checksParentActive && checksParentNonDeleted && returnsNotEligible,
  'Test 11: SECURITY CONSTRAINT #2: linkParentToChild enforces active, non-deleted PARENT role membership'
);

// Test 12: Security Constraint #3: Relationship uniqueness check
const checksExistingRel = /from\(['"]parent_child_relationships['"]\)/.test(serviceCode) &&
  /eq\(['"]parent_id['"],\s*parent_id\)/.test(serviceCode) &&
  /eq\(['"]child_id['"],\s*child_id\)/.test(serviceCode);
const returnsDuplicate = /RELATIONSHIP_ALREADY_EXISTS/.test(serviceCode);
assert(
  checksExistingRel && returnsDuplicate,
  'Test 12: SECURITY CONSTRAINT #3: Uniqueness check prevents duplicate active relationship records'
);

// Test 13: Child archive verification rejects archived children
const checksChildArchived = /child\.deleted_at\s*!==\s*null/.test(serviceCode) && /CHILD_ARCHIVED/.test(serviceCode);
assert(checksChildArchived, 'Test 13: linkParentToChild strictly blocks linking to archived children');

// Test 14: Verification records verified_at and verified_by_admin_id
const recordsVerifiedAt = /verified_at:\s*new Date\(\)\.toISOString\(\)/.test(serviceCode);
const recordsAdminId = /verified_by_admin_id:\s*adminId/.test(serviceCode) || /verified_by_admin_id:\s*currentAdminId/.test(serviceCode);
assert(
  recordsVerifiedAt && recordsAdminId,
  'Test 14: Custody verification formally records timestamp and verifying admin ID'
);

// Test 15: Archive sets deleted_at timestamp
const archivesWithTimestamp = /update\(\{\s*deleted_at:\s*new Date\(\)\.toISOString\(\)\s*\}\)/.test(serviceCode);
assert(archivesWithTimestamp, 'Test 15: archiveParentRelationship performs soft-delete by setting deleted_at');

// -----------------------------------------------------------------------------
// Group 3: UI Components Presence & Export Integrity
// -----------------------------------------------------------------------------
console.log('\n--- 3. UI Components Presence & Export Integrity ---');

const parentsComponentsDir = path.join(process.cwd(), 'src/modules/parents/components');
const expectedComponents = [
  'ChildRelationshipsList.tsx',
  'LinkParentDrawer.tsx',
  'VerifyCustodyDialog.tsx',
  'ArchiveRelationshipDialog.tsx',
];

for (const comp of expectedComponents) {
  const compPath = path.join(parentsComponentsDir, comp);
  assert(fs.existsSync(compPath), `Test 16+: Component exists: ${comp}`);
}

const parentsViewPath = path.join(process.cwd(), 'src/modules/parents/ParentsView.tsx');
assert(fs.existsSync(parentsViewPath), 'Test 20: ParentsView.tsx exists at module root');

// Test 21: Zero physical delete in UI components
for (const comp of expectedComponents) {
  const code = fs.readFileSync(path.join(parentsComponentsDir, comp), 'utf8');
  assert(!/\.delete\(/.test(code), `Test 21+: Zero direct .delete() in UI component: ${comp}`);
}

// -----------------------------------------------------------------------------
// Group 4: Design System Semantics & Accessibility
// -----------------------------------------------------------------------------
console.log('\n--- 4. Design System Semantics & Accessibility ---');

const drawerCode = fs.readFileSync(path.join(parentsComponentsDir, 'LinkParentDrawer.tsx'), 'utf8');
const archiveDialogCode = fs.readFileSync(path.join(parentsComponentsDir, 'ArchiveRelationshipDialog.tsx'), 'utf8');

// Test 25: Drawer uses logical inline-end positioning and direction-aware animation
const hasInlineEndDrawer = /inset-inline-end-0/i.test(drawerCode);
const hasLogicalAnimation = drawerCode.includes("dir === 'rtl' ? 'slide-in-from-left' : 'slide-in-from-right'");
assert(
  hasInlineEndDrawer && hasLogicalAnimation,
  'Test 25: LinkParentDrawer adheres to logical inline-end positioning & direction-aware animation'
);

// Test 26: Archive dialog uses alertdialog accessibility semantics
const hasAlertDialogRole = /role="alertdialog"/i.test(archiveDialogCode);
const hasAriaModal = /aria-modal="true"/i.test(archiveDialogCode);
assert(
  hasAlertDialogRole && hasAriaModal,
  'Test 26: ArchiveRelationshipDialog adheres to alertdialog accessibility semantics'
);

// -----------------------------------------------------------------------------
// Group 5: Admin Shell & Sidebar Integration
// -----------------------------------------------------------------------------
console.log('\n--- 5. Admin Shell & Sidebar Integration ---');

const adminShellCode = fs.readFileSync(path.join(process.cwd(), 'src/modules/admin/components/AdminShell.tsx'), 'utf8');
const adminSidebarCode = fs.readFileSync(path.join(process.cwd(), 'src/modules/admin/components/AdminSidebar.tsx'), 'utf8');

const rendersParentsView = /<ParentsView\s*\/>/.test(adminShellCode);
const hasParentsTab = /['"]parents['"]/.test(adminSidebarCode);
assert(rendersParentsView, 'Test 27: AdminShell renders <ParentsView /> for parents tab');
assert(hasParentsTab, 'Test 28: AdminSidebar includes parents tab definition');

// -----------------------------------------------------------------------------
// Group 6: i18n Dictionary Integrity & Zero Hardcoded Strings
// -----------------------------------------------------------------------------
console.log('\n--- 6. i18n Dictionary Integrity & Zero Hardcoded Strings ---');

const typesPath = path.join(process.cwd(), 'src/lib/i18n/types.ts');
const arPath = path.join(process.cwd(), 'src/lib/i18n/ar.ts');
const enPath = path.join(process.cwd(), 'src/lib/i18n/en.ts');

const typesCode = fs.readFileSync(typesPath, 'utf8');
const arCode = fs.readFileSync(arPath, 'utf8');
const enCode = fs.readFileSync(enPath, 'utf8');

assert(/parents:\s*\{/.test(typesCode), 'Test 29: types.ts defines parents dictionary');
assert(/parents:\s*\{/.test(arCode), 'Test 30: ar.ts includes parents dictionary');
assert(/parents:\s*\{/.test(enCode), 'Test 31: en.ts includes parents dictionary');

// Test 32+: Zero hardcoded Arabic in parents UI components
for (const comp of expectedComponents) {
  const code = fs.readFileSync(path.join(parentsComponentsDir, comp), 'utf8');
  const cleanCode = code.replace(/\/\*[\s\S]*?\*\/|\/\/.*/g, '');
  const hasHardcodedArabic = /[\u0600-\u06FF]/.test(cleanCode);
  assert(!hasHardcodedArabic, `Test 32+: Zero hardcoded Arabic text in ${comp} (uses i18n)`);
}

const parentsViewCode = fs.readFileSync(parentsViewPath, 'utf8');
const cleanParentsView = parentsViewCode.replace(/\/\*[\s\S]*?\*\/|\/\/.*/g, '');
assert(!/[\u0600-\u06FF]/.test(cleanParentsView), 'Test 36: Zero hardcoded Arabic text in ParentsView.tsx');

console.log('===============================================================');
console.log('TEST SUMMARY: ALL GATE 5 INVARIANT TESTS PASSED (36/36)');
console.log('===============================================================');
