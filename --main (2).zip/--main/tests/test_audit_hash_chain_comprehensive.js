import { PGlite } from '@electric-sql/pglite';
import fs from 'fs';

async function runComprehensiveAuditHashTests() {
  console.log('================================================================');
  console.log('TARGETED AUDIT LOG HASH-CHAIN & CONCURRENCY SECURITY TEST SUITE');
  console.log('================================================================\n');

  const db = new PGlite();

  // Setup auth & run migrations
  await db.exec(`
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (id UUID PRIMARY KEY, email TEXT UNIQUE);
    CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID AS $$
      SELECT NULLIF(current_setting('request.jwt.claims', true)::jsonb->>'sub', '')::uuid;
    $$ LANGUAGE sql STABLE;
    CREATE OR REPLACE FUNCTION auth.jwt() RETURNS JSONB AS $$
      SELECT COALESCE(current_setting('request.jwt.claims', true)::jsonb, '{}'::jsonb);
    $$ LANGUAGE sql STABLE;

    CREATE ROLE authenticated NOLOGIN;
    GRANT USAGE ON SCHEMA public, auth TO authenticated;
  `);

  await db.exec(fs.readFileSync('supabase/migrations/20260927000001_initial_schema.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000002_rls_policies.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000003_invitations_fsm.sql', 'utf-8'));

  const k1 = '11111111-1111-1111-1111-111111111111';
  const k2 = '22222222-2222-2222-2222-222222222222';
  const u1 = 'ffff0001-0000-0000-0000-000000000001';

  // Seed minimum kindergarten row & user profile for FK integrity
  await db.exec(`
    INSERT INTO auth.users (id, email) VALUES
      ('${u1}', 'test@test.com')
    ON CONFLICT (id) DO NOTHING;

    INSERT INTO kindergartens (id, name, license_number, contact_email, contact_phone, address) VALUES 
      ('${k1}', 'School 1', 'LIC-001', 'kg1@test.com', '0500000001', 'Riyadh 1'),
      ('${k2}', 'School 2', 'LIC-002', 'kg2@test.com', '0500000002', 'Riyadh 2')
    ON CONFLICT (id) DO NOTHING;

    INSERT INTO user_profiles (id, full_name, phone_number) VALUES
      ('${u1}', 'Test Actor', '0500000000')
    ON CONFLICT (id) DO NOTHING;
  `);

  console.log('--- TEST A: FORGED CURRENT_LOG_HASH MUST BE OVERWRITTEN ---');
  const maliciousHash = 'malicious_forged_hash_value_123456789012345678901234567890123456';
  await db.query(`
    INSERT INTO audit_logs (id, kindergarten_id, actor_id, action, resource_type, reason, current_log_hash)
    VALUES ('aa000001-0000-0000-0000-000000000001', '${k1}', '${u1}', 'FORGERY_ATTEMPT', 'auth', 'Testing rogue hash injection', '${maliciousHash}');
  `);
  const forgedRes = await db.query("SELECT current_log_hash, previous_log_hash FROM audit_logs WHERE id = 'aa000001-0000-0000-0000-000000000001';");
  const storedHashA = forgedRes.rows[0].current_log_hash.trim();
  const forgeryRejected = storedHashA !== maliciousHash && storedHashA.length === 64;
  console.log(`Supplied rogue hash: ${maliciousHash}`);
  console.log(`Stored hash in DB:  ${storedHashA}`);
  console.log(`TEST A Result: ${forgeryRejected ? 'PASS (Rogue hash completely overwritten with authoritative SHA256)' : 'FAIL'}`);
  if (!forgeryRejected) throw new Error('TEST A FAILED: Caller-supplied hash was preserved!');

  console.log('\n--- TEST B: SAME-KINDERGARTEN CHAIN CONTINUITY & SERIALIZATION ---');
  await db.query(`
    INSERT INTO audit_logs (id, kindergarten_id, actor_id, action, resource_type, reason)
    VALUES ('aa000002-0000-0000-0000-000000000002', '${k1}', '${u1}', 'SECOND_ACTION', 'auth', 'Sequential action for same kindergarten');
  `);
  const chainResK1 = await db.query(`
    SELECT id, action, previous_log_hash, current_log_hash 
    FROM audit_logs 
    WHERE kindergarten_id = '${k1}' 
    ORDER BY created_at ASC, id ASC;
  `);
  const row1 = chainResK1.rows[0];
  const row2 = chainResK1.rows[1];
  const k1ChainLinked = row2.previous_log_hash.trim() === row1.current_log_hash.trim();
  console.log(`Row 1 current_log_hash:  ${row1.current_log_hash.trim()}`);
  console.log(`Row 2 previous_log_hash: ${row2.previous_log_hash.trim()}`);
  console.log(`TEST B Result: ${k1ChainLinked ? 'PASS (Linear chain verified: row2.previous = row1.current, no fork)' : 'FAIL'}`);
  if (!k1ChainLinked) throw new Error('TEST B FAILED: Chain broken or forked!');

  console.log('\n--- TEST C: DIFFERENT-KINDERGARTEN CHAIN ISOLATION ---');
  await db.query(`
    INSERT INTO audit_logs (id, kindergarten_id, actor_id, action, resource_type, reason)
    VALUES ('aa000003-0000-0000-0000-000000000003', '${k2}', '${u1}', 'K2_FIRST_ACTION', 'auth', 'First action for kindergarten 2');
  `);
  const chainResK2 = await db.query(`
    SELECT id, previous_log_hash, current_log_hash 
    FROM audit_logs 
    WHERE kindergarten_id = '${k2}' 
    LIMIT 1;
  `);
  const k2Genesis = chainResK2.rows[0].previous_log_hash.trim() === '0'.repeat(64);
  console.log(`Kindergarten 2 Genesis previous_log_hash: ${chainResK2.rows[0].previous_log_hash.trim()}`);
  console.log(`TEST C Result: ${k2Genesis ? 'PASS (Kindergarten 2 has independent genesis chain, not dependent on K1)' : 'FAIL'}`);
  if (!k2Genesis) throw new Error('TEST C FAILED: Different kindergarten chains cross-contaminated!');

  console.log('\n--- TEST D & E: HASH CHANGES WHEN REASON OR ACTOR_ROLE CHANGES ---');
  // Baseline JSONB hash calculation comparison
  const hashProbe1 = await db.query(`
    SELECT encode(sha256(jsonb_build_object(
      'id', '11111111-0000-0000-0000-000000000001'::uuid,
      'actor_role', 'ADMIN'::app_role,
      'reason', 'Reason Alpha',
      'previous_log_hash', repeat('0', 64)
    )::text::bytea), 'hex') as h;
  `);
  const hashProbeDiffReason = await db.query(`
    SELECT encode(sha256(jsonb_build_object(
      'id', '11111111-0000-0000-0000-000000000001'::uuid,
      'actor_role', 'ADMIN'::app_role,
      'reason', 'Reason Beta',
      'previous_log_hash', repeat('0', 64)
    )::text::bytea), 'hex') as h;
  `);
  const hashProbeDiffRole = await db.query(`
    SELECT encode(sha256(jsonb_build_object(
      'id', '11111111-0000-0000-0000-000000000001'::uuid,
      'actor_role', 'TEACHER'::app_role,
      'reason', 'Reason Alpha',
      'previous_log_hash', repeat('0', 64)
    )::text::bytea), 'hex') as h;
  `);
  const hBase = hashProbe1.rows[0].h;
  const hDiffReason = hashProbeDiffReason.rows[0].h;
  const hDiffRole = hashProbeDiffRole.rows[0].h;

  console.log(`Base hash:             ${hBase}`);
  console.log(`Different reason hash: ${hDiffReason}`);
  console.log(`Different role hash:   ${hDiffRole}`);
  const reasonDiffPass = hBase !== hDiffReason;
  const roleDiffPass = hBase !== hDiffRole;
  console.log(`TEST D (Reason sensitivity):     ${reasonDiffPass ? 'PASS' : 'FAIL'}`);
  console.log(`TEST E (Actor role sensitivity): ${roleDiffPass ? 'PASS' : 'FAIL'}`);
  if (!reasonDiffPass || !roleDiffPass) throw new Error('TEST D/E FAILED: Cryptographic hash is insensitive to security fields!');

  console.log('\n--- TEST F: HASH CHANGES WHEN PREVIOUS_LOG_HASH CHANGES ---');
  const hashProbeDiffPrev = await db.query(`
    SELECT encode(sha256(jsonb_build_object(
      'id', '11111111-0000-0000-0000-000000000001'::uuid,
      'actor_role', 'ADMIN'::app_role,
      'reason', 'Reason Alpha',
      'previous_log_hash', repeat('f', 64)
    )::text::bytea), 'hex') as h;
  `);
  const hDiffPrev = hashProbeDiffPrev.rows[0].h;
  console.log(`Different prev_hash hash: ${hDiffPrev}`);
  const prevDiffPass = hBase !== hDiffPrev;
  console.log(`TEST F (Prev hash sensitivity):  ${prevDiffPass ? 'PASS' : 'FAIL'}`);
  if (!prevDiffPass) throw new Error('TEST F FAILED: Cryptographic hash does not bind previous_log_hash!');

  console.log('\n--- TEST G & H: CANONICAL STRUCTURED METADATA & DETERMINISM ---');
  const detProbe1 = await db.query(`
    SELECT encode(sha256(jsonb_build_object(
      'action', 'PROBE',
      'metadata', '{"b": 2, "a": 1}'::jsonb
    )::text::bytea), 'hex') as h;
  `);
  const detProbe2 = await db.query(`
    SELECT encode(sha256(jsonb_build_object(
      'action', 'PROBE',
      'metadata', '{"a": 1, "b": 2}'::jsonb
    )::text::bytea), 'hex') as h;
  `);
  const detPass = detProbe1.rows[0].h === detProbe2.rows[0].h;
  console.log(`Metadata Key Order Permutation 1: ${detProbe1.rows[0].h}`);
  console.log(`Metadata Key Order Permutation 2: ${detProbe2.rows[0].h}`);
  console.log(`TEST G/H Result: ${detPass ? 'PASS (PostgreSQL JSONB normalizes keys deterministically before hashing)' : 'FAIL'}`);
  if (!detPass) throw new Error('TEST G/H FAILED: JSONB metadata serialization is non-deterministic!');

  console.log('\n--- TEST I & J: IMMUTABILITY PROTECTION (UPDATE & DELETE BLOCKED) ---');
  let updBlocked = false;
  try {
    await db.query("UPDATE audit_logs SET reason = 'Malicious alteration' WHERE id = 'aa000001-0000-0000-0000-000000000001';");
  } catch (err) {
    updBlocked = err.message.includes('TAMPER_ALERT');
  }
  let delBlocked = false;
  try {
    await db.query("DELETE FROM audit_logs WHERE id = 'aa000001-0000-0000-0000-000000000001';");
  } catch (err) {
    delBlocked = err.message.includes('TAMPER_ALERT');
  }
  console.log(`TEST I (UPDATE Blocked): ${updBlocked ? 'PASS (TAMPER_ALERT raised)' : 'FAIL'}`);
  console.log(`TEST J (DELETE Blocked): ${delBlocked ? 'PASS (TAMPER_ALERT raised)' : 'FAIL'}`);
  if (!updBlocked || !delBlocked) throw new Error('TEST I/J FAILED: Immutability trigger failed!');

  console.log('\n================================================================');
  console.log('ALL AUDIT LOG HASH-CHAIN SECURITY TESTS PASSED (100%)');
  console.log('================================================================');
}

runComprehensiveAuditHashTests().catch(e => {
  console.error('FATAL AUDIT TEST ERROR:', e);
  process.exit(1);
});
