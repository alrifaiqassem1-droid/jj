import fs from 'fs';
import path from 'path';

function runPhase1FoundationTests() {
  console.log('================================================================');
  console.log('PHASE 1 ARCHITECTURAL FOUNDATION & ARABIC-FIRST TEST SUITE');
  console.log('================================================================\n');

  // TEST 1: Check index.html Arabic-first + RTL invariant
  console.log('[TEST 1] Verifying index.html Arabic-first and RTL attributes...');
  const indexHtml = fs.readFileSync('index.html', 'utf-8');
  if (!indexHtml.includes('<html lang="ar" dir="rtl">')) {
    throw new Error('TEST 1 FAILED: index.html is not configured with lang="ar" and dir="rtl"!');
  }
  if (!indexHtml.includes('روضة الأدهم الذكية')) {
    throw new Error('TEST 1 FAILED: index.html title is not localized in Arabic!');
  }
  console.log('✓ TEST 1 PASS: index.html strictly asserts lang="ar" dir="rtl".\n');

  // TEST 2: Check frozen migrations integrity (Files must exist and remain unchanged)
  console.log('[TEST 2] Verifying that migrations 00001, 00002, 00003, and 00004 exist...');
  const frozenMigrations = [
    'supabase/migrations/20260927000001_initial_schema.sql',
    'supabase/migrations/20260927000002_rls_policies.sql',
    'supabase/migrations/20260927000003_invitations_fsm.sql',
    'supabase/migrations/20260927000004_user_profile_provisioning.sql',
  ];

  for (const m of frozenMigrations) {
    if (!fs.existsSync(m)) {
      throw new Error(`TEST 2 FAILED: Frozen migration file ${m} is missing!`);
    }
  }
  console.log('✓ TEST 2 PASS: All 4 frozen migrations exist in their immutable paths.\n');

  // TEST 3: Check i18n files structure and Arabic completeness
  console.log('[TEST 3] Verifying Arabic and English dictionaries...');
  const arPath = 'src/lib/i18n/ar.ts';
  const enPath = 'src/lib/i18n/en.ts';
  const typesPath = 'src/lib/i18n/types.ts';
  const contextPath = 'src/lib/i18n/I18nContext.tsx';

  if (!fs.existsSync(arPath) || !fs.existsSync(enPath) || !fs.existsSync(typesPath) || !fs.existsSync(contextPath)) {
    throw new Error('TEST 3 FAILED: One or more i18n core files are missing!');
  }

  const arContent = fs.readFileSync(arPath, 'utf-8');
  if (!arContent.includes('روضة الأدهم الذكية') || !arContent.includes('common:') || !arContent.includes('auth:')) {
    throw new Error('TEST 3 FAILED: Arabic dictionary is missing core domains or app name!');
  }
  console.log('✓ TEST 3 PASS: Complete Arabic-first dictionary and i18n provider verified.\n');

  // TEST 4: Check AuthContext presence and integration
  console.log('[TEST 4] Verifying AuthContext foundation & RPC signature...');
  const authContextPath = 'src/modules/auth/AuthContext.tsx';
  if (!fs.existsSync(authContextPath)) {
    throw new Error('TEST 4 FAILED: AuthContext.tsx is missing!');
  }
  const authContent = fs.readFileSync(authContextPath, 'utf-8');
  if (!authContent.includes('useAuth') || !authContent.includes('user_profiles') || !authContent.includes('claim_parent_invitation')) {
    throw new Error('TEST 4 FAILED: AuthContext does not integrate user_profiles or invitation RPC!');
  }
  if (!authContent.includes('p_token_hash') || !authContent.includes('p_ip_address') || !authContent.includes('p_user_agent')) {
    throw new Error('TEST 4 FAILED: claim_parent_invitation is missing required parameters (p_token_hash, p_ip_address, p_user_agent)!');
  }
  console.log('✓ TEST 4 PASS: AuthContext properly connects to user_profiles and invitation FSM with exact RPC signature match.\n');

  // TEST 4.5: Check I18n runtime fallback
  console.log('[TEST 4.5] Verifying I18nContext Arabic fallback guard...');
  const i18nContextContent = fs.readFileSync(contextPath, 'utf-8');
  if (!i18nContextContent.includes('dictionaries.ar')) {
    throw new Error('TEST 4.5 FAILED: I18nContext does not contain explicit fallback to dictionaries.ar!');
  }
  console.log('✓ TEST 4.5 PASS: I18nContext contains explicit fallback to dictionaries.ar.\n');

  // TEST 5: Verify PHASE1_BASELINE_ARCHITECTURE.md documentation
  console.log('[TEST 5] Verifying Phase 1 architectural documentation...');
  const docPath = 'PHASE1_BASELINE_ARCHITECTURE.md';
  if (!fs.existsSync(docPath)) {
    throw new Error('TEST 5 FAILED: PHASE1_BASELINE_ARCHITECTURE.md is missing!');
  }
  const docContent = fs.readFileSync(docPath, 'utf-8');
  const requiredHeadings = [
    'طبقات النظام',
    'حدود النظام',
    'طريقة التعامل مع Supabase',
    'دورة حياة المصادقة',
    'تفعيل الملف الشخصي',
    'دورة حياة دعوات أولياء الأمور',
    'الأدوار والعضويات',
    'حدود حماية الكيرنل',
    'بنية التوطين',
    'بنية الاتجاه من اليمين لليسار',
    'استراتيجية الاختبارات'
  ];
  for (const h of requiredHeadings) {
    if (!docContent.includes(h)) {
      throw new Error(`TEST 5 FAILED: Missing required section in architecture doc: ${h}`);
    }
  }
  console.log('✓ TEST 5 PASS: PHASE1_BASELINE_ARCHITECTURE.md contains all 13 required architectural specifications.\n');

  console.log('================================================================');
  console.log('ALL 5 PHASE 1 FOUNDATION TESTS PASSED (100% SUCCESS)');
  console.log('================================================================');
}

try {
  runPhase1FoundationTests();
} catch (err) {
  console.error('\n❌ PHASE 1 FOUNDATION TEST FAILED:', err.message);
  process.exit(1);
}
