import fs from 'fs';
import path from 'path';
import { PGlite } from '@electric-sql/pglite';
import {
  adminPickupExceptionSchema,
  attendanceCorrectionSchema,
  authorizedRelationshipPickupSchema,
  dateStringSchema,
  recordDailyAttendanceSchema,
  recordPickupSchema,
} from '../src/modules/attendance/attendanceValidation';

let passedCount = 0;
let failedCount = 0;
let skippedCount = 0;

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`  ✗ FAIL: ${message}`);
    failedCount++;
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`  ✓ PASS: ${message}`);
  passedCount++;
}

async function runGate6aTestSuite() {
  console.log('===============================================================');
  console.log('GATE 6A TEST SUITE — ATTENDANCE SERVICE, VALIDATION & SECURITY');
  console.log('Engine: PGlite WASM (PostgreSQL 18.3) + Zod Contracts');
  console.log('===============================================================');

  // ===========================================================================
  // GROUP 1: Zod Contracts & Validation Rule Tests
  // ===========================================================================
  console.log('\n--- 1. Validation Rules Execution Tests (Zod Contracts) ---');

  const kgIdFixture = 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11';
  const classIdFixture = 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22';
  const childIdFixture = 'c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33';
  const attIdFixture = 'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380a44';
  const relIdFixture = 'e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a55';

  // Test 1: Valid daily attendance input
  const validDaily = {
    kindergarten_id: kgIdFixture,
    class_id: classIdFixture,
    child_id: childIdFixture,
    date: '2026-10-04',
    status: 'PRESENT' as const,
    notes: 'Arrived on time',
  };
  const r1 = recordDailyAttendanceSchema.safeParse(validDaily);
  assert(r1.success, 'Test 1: Valid daily attendance input passes validation');

  // Test 2: Invalid status rejected
  const invalidStatus = { ...validDaily, status: 'INVALID_STATUS' };
  const r2 = recordDailyAttendanceSchema.safeParse(invalidStatus);
  assert(!r2.success, 'Test 2: Invalid attendance status is rejected');

  // Test 3: Invalid UUID rejected
  const invalidUuid = { ...validDaily, child_id: 'not-a-valid-uuid' };
  const r3 = recordDailyAttendanceSchema.safeParse(invalidUuid);
  assert(!r3.success, 'Test 3: Malformed child_id UUID is rejected');

  // Test 4: Invalid date format rejected
  const invalidDate = { ...validDaily, date: '04-10-2026' };
  const r4 = recordDailyAttendanceSchema.safeParse(invalidDate);
  assert(!r4.success, 'Test 4: Non-ISO date format is rejected');

  // Test 5: Authorized relationship pickup requires relationship_id UUID
  const validPickupRel = {
    pickup_type: 'AUTHORIZED_RELATIONSHIP' as const,
    attendance_id: attIdFixture,
    child_id: childIdFixture,
    kindergarten_id: kgIdFixture,
    relationship_id: relIdFixture,
  };
  const r5 = authorizedRelationshipPickupSchema.safeParse(validPickupRel);
  assert(r5.success, 'Test 5: Authorized relationship pickup input parses successfully');

  // Test 6: Free text arbitrary pickup name is NOT accepted in authorized pickup schema
  const roguePickupAttempt = {
    pickup_type: 'AUTHORIZED_RELATIONSHIP',
    attendance_id: attIdFixture,
    child_id: childIdFixture,
    kindergarten_id: kgIdFixture,
    picked_up_by_name: 'شخص عشوائي غير مصرح له', // Arbitrary text injected
  };
  const r6 = authorizedRelationshipPickupSchema.safeParse(roguePickupAttempt);
  assert(!r6.success, 'Test 6: Free-text pickup name without relationship_id is rejected');

  // Test 7: Admin exception with reason < 10 chars is rejected
  const shortReasonException = {
    pickup_type: 'ADMIN_EXCEPTION' as const,
    attendance_id: attIdFixture,
    child_id: childIdFixture,
    kindergarten_id: kgIdFixture,
    recipient_name: 'فهد محمد الدوسري',
    reason: 'قصير', // Only 4 characters
  };
  const r7 = adminPickupExceptionSchema.safeParse(shortReasonException);
  assert(!r7.success, 'Test 7: Admin exception with reason < 10 chars is rejected by validation');

  // Test 8: Admin exception with valid reason >= 10 chars is accepted
  const validAdminException = {
    ...shortReasonException,
    reason: 'تفويض هاتفي مباشر ومسجل من ولي الأمر لحالة طارئة',
    recipient_id_number: '1098765432',
  };
  const r8 = adminPickupExceptionSchema.safeParse(validAdminException);
  assert(r8.success, 'Test 8: Valid admin pickup exception input is accepted');

  // Test 9: Correction with reason < 10 chars is rejected
  const shortReasonCorrection = {
    attendance_id: attIdFixture,
    kindergarten_id: kgIdFixture,
    child_id: childIdFixture,
    new_status: 'PRESENT' as const,
    reason: 'خطأ رصد', // 7 chars
  };
  const r9 = attendanceCorrectionSchema.safeParse(shortReasonCorrection);
  assert(!r9.success, 'Test 9: Attendance correction with reason < 10 chars is rejected');

  // Test 10: Correction with new_status = 'UNRECORDED' is rejected
  const unrecordedCorrection = {
    ...shortReasonCorrection,
    new_status: 'UNRECORDED' as const,
    reason: 'تصحيح الحالة إلى غير مسجل',
  };
  const r10 = attendanceCorrectionSchema.safeParse(unrecordedCorrection);
  assert(!r10.success, 'Test 10: Setting new_status to UNRECORDED in correction is rejected');

  // Test 11: Valid correction input is accepted
  const validCorrection = {
    ...shortReasonCorrection,
    reason: 'حضور متأخر للطفل برفقة والدته بعذر طبي معتمد',
  };
  const r11 = attendanceCorrectionSchema.safeParse(validCorrection);
  assert(r11.success, 'Test 11: Valid attendance correction input is accepted');

  // ===========================================================================
  // GROUP 2: Architectural & Security Invariants Verification
  // ===========================================================================
  console.log('\n--- 2. Architectural & Security Invariant Tests ---');

  const servicePath = path.join(process.cwd(), 'src/modules/attendance/attendanceService.ts');
  assert(fs.existsSync(servicePath), 'Test 12: attendanceService.ts exists');
  const serviceCode = fs.readFileSync(servicePath, 'utf8');

  // Test 13: Zero physical delete
  const deletesAttendance = /\.from\(['"]attendance['"]\)\s*\.delete\(\)/.test(serviceCode);
  const deletesCorrections = /\.from\(['"]attendance_corrections['"]\)\s*\.delete\(\)/.test(serviceCode);
  assert(!deletesAttendance && !deletesCorrections, 'Test 13: attendanceService.ts contains ZERO physical delete calls');

  // Test 14: Client service NEVER writes directly to audit_logs (preserves cryptographic hash integrity)
  const writesToAuditLogs = /['"]audit_logs['"]\s*\)\s*\.insert/.test(serviceCode);
  assert(!writesToAuditLogs, 'Test 14: attendanceService.ts does NOT perform direct client writes to audit_logs');

  // Test 15: Pickup authorization checks verified_at AND authorized_for_pickup
  const checksAuthorizedForPickup = /authorized_for_pickup/.test(serviceCode);
  const checksVerifiedAt = /verified_at/.test(serviceCode);
  assert(
    checksAuthorizedForPickup && checksVerifiedAt,
    'Test 15: recordPickup strictly verifies both authorized_for_pickup and verified_at'
  );

  // Test 16: Admin pickup exception verifies ADMIN role in kindergarten_memberships
  const checksAdminRole = /eq\(['"]role['"],\s*['"]ADMIN['"]\)/.test(serviceCode);
  assert(checksAdminRole, 'Test 16: Admin pickup exception strictly verifies caller has active ADMIN role');

  // Test 17: Service checks child_id isolation in relationship
  const checksChildIsolation = /rel\.child_id\s*!==\s*input\.child_id/.test(serviceCode);
  assert(checksChildIsolation, 'Test 17: Service strictly prevents cross-child relationship pickup spoofing');

  // ===========================================================================
  // GROUP 3: Actual PostgreSQL Engine (PGlite) Security & RLS Tests
  // ===========================================================================
  console.log('\n--- 3. Actual PostgreSQL Engine Security, Constraints & RLS Tests ---');

  const db = new PGlite();

  // Setup auth schema & functions
  await db.exec(`
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (id UUID PRIMARY KEY, email TEXT UNIQUE);
    CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID AS $$
      SELECT NULLIF(current_setting('request.jwt.claims', true)::jsonb->>'sub', '')::uuid;
    $$ LANGUAGE sql STABLE;
    CREATE OR REPLACE FUNCTION auth.jwt() RETURNS JSONB AS $$
      SELECT COALESCE(current_setting('request.jwt.claims', true)::jsonb, '{}'::jsonb);
    $$ LANGUAGE sql STABLE;
    CREATE ROLE authenticated NOLOGIN;
    CREATE ROLE anon NOLOGIN;
    GRANT USAGE ON SCHEMA public, auth TO authenticated, anon;
  `);

  // Execute canonical schema migrations
  await db.exec(fs.readFileSync('supabase/migrations/20260927000001_initial_schema.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000002_rls_policies.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000003_invitations_fsm.sql', 'utf-8'));

  // Grant privileges to authenticated role
  await db.exec(`
    GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
  `);

  // Fixtures
  const kId = '11111111-1111-1111-1111-111111111111';
  const cId = '22222222-2222-2222-2222-222222222222';
  const child1Id = '33333333-3333-3333-3333-333333333333';
  const child2Id = '33333333-3333-3333-3333-333333333334';
  const adminUid = 'aaaa0001-0000-0000-0000-000000000001';
  const teacherUid = 'bbbb0001-0000-0000-0000-000000000001';
  const teacherOtherUid = 'bbbb0002-0000-0000-0000-000000000002';
  const staffUid = 'cccc0001-0000-0000-0000-000000000001';
  const parent1Uid = 'dddd0001-0000-0000-0000-000000000001';
  const parent2Uid = 'dddd0002-0000-0000-0000-000000000002';
  const superAdminUid = 'eeee0001-0000-0000-0000-000000000001';

  // Seed base entities
  await db.exec(`
    INSERT INTO kindergartens (id, name, license_number, contact_email, contact_phone, address)
    VALUES ('${kId}', 'Rawdaty Smart School', 'LIC-KSA-01', 'info@rawdaty.sa', '0500000001', 'Riyadh');

    INSERT INTO auth.users (id, email) VALUES
      ('${adminUid}', 'admin@rawdaty.sa'),
      ('${teacherUid}', 'teacher@rawdaty.sa'),
      ('${teacherOtherUid}', 'teacher2@rawdaty.sa'),
      ('${staffUid}', 'staff@rawdaty.sa'),
      ('${parent1Uid}', 'parent1@rawdaty.sa'),
      ('${parent2Uid}', 'parent2@rawdaty.sa'),
      ('${superAdminUid}', 'superadmin@rawdaty.sa');

    INSERT INTO user_profiles (id, full_name, phone_number) VALUES
      ('${adminUid}', 'نورة القحطاني - مديرة', '0500000001'),
      ('${teacherUid}', 'سارة الشهري - معلمة', '0500000002'),
      ('${teacherOtherUid}', 'ريم الغامدي - معلمة شعبة أخرى', '0500000003'),
      ('${staffUid}', 'هند العتيبي - موظفة استقبال', '0500000004'),
      ('${parent1Uid}', 'أحمد بن خالد السالم', '0500000005'),
      ('${parent2Uid}', 'مها محمد العبدالله', '0500000006'),
      ('${superAdminUid}', 'مدقق النظام المالي', '0500000007');

    INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role, permissions, is_active) VALUES
      ('${kId}', '${adminUid}', 'ADMIN', '{}', TRUE),
      ('${kId}', '${teacherUid}', 'TEACHER', '{}', TRUE),
      ('${kId}', '${teacherOtherUid}', 'TEACHER', '{}', TRUE),
      ('${kId}', '${staffUid}', 'STAFF', '{"RECORD_ATTENDANCE", "VIEW_ATTENDANCE"}', TRUE),
      ('${kId}', '${parent1Uid}', 'PARENT', '{}', TRUE),
      ('${kId}', '${parent2Uid}', 'PARENT', '{}', TRUE);

    INSERT INTO classes (id, kindergarten_id, name, grade_level, capacity, academic_year)
    VALUES ('${cId}', '${kId}', 'فصل الأمل', 'KG1', 20, '2026-2027');

    INSERT INTO teacher_class_assignments (kindergarten_id, class_id, teacher_id, is_lead_teacher)
    VALUES ('${kId}', '${cId}', '${teacherUid}', TRUE);

    INSERT INTO children (id, kindergarten_id, class_id, first_name, last_name, dob, gender, emergency_contact_name, emergency_contact_phone)
    VALUES
      ('${child1Id}', '${kId}', '${cId}', 'زيد', 'السالم', '2022-05-10', 'MALE', 'أحمد السالم', '0500000005'),
      ('${child2Id}', '${kId}', '${cId}', 'سارة', 'العبدالله', '2022-06-15', 'FEMALE', 'مها العبدالله', '0500000006');
  `);

  // Seed parent relationships
  // Parent 1: Verified + Authorized for pickup
  // Parent 2: Unverified (verified_at IS NULL)
  await db.exec(`
    INSERT INTO parent_child_relationships (id, kindergarten_id, parent_id, child_id, relationship, authorized_for_pickup, verified_at, verified_by_admin_id)
    VALUES
      ('99990001-0000-0000-0000-000000000001', '${kId}', '${parent1Uid}', '${child1Id}', 'FATHER', TRUE, NOW(), '${adminUid}'),
      ('99990002-0000-0000-0000-000000000002', '${kId}', '${parent2Uid}', '${child2Id}', 'MOTHER', FALSE, NULL, NULL);
  `);

  // Helper to run query as a specific user with RLS active inside an isolated transaction
  async function runAs(userId: string, roleName: string, sqlQuery: string) {
    return db.transaction(async (tx) => {
      await tx.exec(`
        SET LOCAL ROLE authenticated;
        SET LOCAL "request.jwt.claims" = '{"sub": "${userId}", "role": "authenticated"}';
      `);
      return tx.query<Record<string, any>>(sqlQuery);
    });
  }

  // Test 18: Admin records attendance successfully
  const att1Id = 'aaaa1111-0000-0000-0000-000000000001';
  await runAs(
    adminUid,
    'ADMIN',
    `INSERT INTO attendance (id, kindergarten_id, class_id, child_id, date, status, recorded_by)
     VALUES ('${att1Id}', '${kId}', '${cId}', '${child1Id}', '2026-10-04', 'PRESENT', '${adminUid}');`
  );
  const q18 = await runAs(adminUid, 'ADMIN', `SELECT status FROM attendance WHERE id = '${att1Id}';`);
  assert(q18.rows[0]?.status === 'PRESENT', 'Test 18: Admin successfully inserts attendance record');

  // Test 19: Unique constraint blocks duplicate attendance for same child on same date
  let dupBlocked = false;
  try {
    await runAs(
      adminUid,
      'ADMIN',
      `INSERT INTO attendance (kindergarten_id, class_id, child_id, date, status, recorded_by)
       VALUES ('${kId}', '${cId}', '${child1Id}', '2026-10-04', 'ABSENT_EXCUSED', '${adminUid}');`
    );
  } catch (err: unknown) {
    const errorMsg = String(err);
    dupBlocked = errorMsg.includes('unique_child_daily_attendance') || errorMsg.includes('23505');
  }
  assert(dupBlocked, 'Test 19: Duplicate (child_id, date) attendance is strictly rejected by UNIQUE constraint');

  // Test 20: Assigned Teacher can view and update attendance for their class
  const q20 = await runAs(
    teacherUid,
    'TEACHER',
    `UPDATE attendance SET notes = 'Updated by assigned teacher' WHERE id = '${att1Id}' RETURNING notes;`
  );
  assert(q20.rows[0]?.notes === 'Updated by assigned teacher', 'Test 20: Assigned teacher can update class attendance');

  // Test 21: Unassigned Teacher CANNOT see or update other class attendance
  let unassignedBlocked = false;
  const q21 = await runAs(
    teacherOtherUid,
    'TEACHER',
    `UPDATE attendance SET notes = 'Hacked by other teacher' WHERE id = '${att1Id}' RETURNING notes;`
  );
  assert(q21.rows.length === 0, 'Test 21: Unassigned teacher CANNOT update other class attendance (0 rows affected by RLS)');

  // Test 22: Staff with RECORD_ATTENDANCE can insert attendance for child 2
  const att2Id = 'aaaa2222-0000-0000-0000-000000000002';
  await runAs(
    staffUid,
    'STAFF',
    `INSERT INTO attendance (id, kindergarten_id, class_id, child_id, date, status, recorded_by)
     VALUES ('${att2Id}', '${kId}', '${cId}', '${child2Id}', '2026-10-04', 'ABSENT_EXCUSED', '${staffUid}');`
  );
  const q22 = await runAs(staffUid, 'STAFF', `SELECT status FROM attendance WHERE id = '${att2Id}';`);
  assert(q22.rows[0]?.status === 'ABSENT_EXCUSED', 'Test 22: Staff with RECORD_ATTENDANCE can insert attendance');

  // Test 23: Staff CANNOT update existing attendance (RLS update restriction)
  const q23 = await runAs(
    staffUid,
    'STAFF',
    `UPDATE attendance SET status = 'PRESENT' WHERE id = '${att2Id}' RETURNING status;`
  );
  assert(q23.rows.length === 0, 'Test 23: Staff is strictly BLOCKED from updating attendance by RLS (0 rows affected)');

  // Test 24: Parent can only view their own child's attendance
  const q24Own = await runAs(parent1Uid, 'PARENT', `SELECT id FROM attendance WHERE child_id = '${child1Id}';`);
  const q24Other = await runAs(parent1Uid, 'PARENT', `SELECT id FROM attendance WHERE child_id = '${child2Id}';`);
  assert(
    q24Own.rows.length === 1 && q24Other.rows.length === 0,
    'Test 24: Parent can strictly SELECT own child attendance and CANNOT see other children'
  );

  // Test 25: Parent CANNOT write attendance
  let parentWriteBlocked = false;
  try {
    await runAs(
      parent1Uid,
      'PARENT',
      `INSERT INTO attendance (kindergarten_id, class_id, child_id, date, status, recorded_by)
       VALUES ('${kId}', '${cId}', '${child1Id}', '2026-10-05', 'PRESENT', '${parent1Uid}');`
    );
  } catch (err: unknown) {
    parentWriteBlocked = true;
  }
  assert(parentWriteBlocked, 'Test 25: Parent writing attendance is strictly BLOCKED by RLS');

  // Test 26: Super Admin without active support session CANNOT read attendance
  const q26NoSession = await runAs(superAdminUid, 'SUPER_ADMIN', `SELECT id FROM attendance WHERE id = '${att1Id}';`);
  assert(q26NoSession.rows.length === 0, 'Test 26: Super Admin without active support session CANNOT read attendance');

  // Test 27: Super Admin with active support session CAN read attendance
  await db.exec(`
    INSERT INTO super_admin_support_sessions (target_kindergarten_id, super_admin_id, reason, scope, is_active, expires_at)
    VALUES ('${kId}', '${superAdminUid}', 'Comprehensive Legal Compliance & Security Audit Verification Session', 'READ_ONLY_ATTENDANCE_INSPECTION', TRUE, NOW() + INTERVAL '1 hour');
  `);
  const q27WithSession = await runAs(superAdminUid, 'SUPER_ADMIN', `SELECT id FROM attendance WHERE id = '${att1Id}';`);
  assert(q27WithSession.rows.length === 1, 'Test 27: Super Admin with active support session CAN read attendance');

  // Test 28: Correction insertion records previous/new status and reason >= 10
  const corr1Id = 'cccc1111-0000-0000-0000-000000000001';
  await runAs(
    adminUid,
    'ADMIN',
    `INSERT INTO attendance_corrections (id, attendance_id, kindergarten_id, child_id, previous_status, new_status, corrected_by_user_id, reason, client_timestamp)
     VALUES ('${corr1Id}', '${att1Id}', '${kId}', '${child1Id}', 'PRESENT', 'CHECKED_OUT', '${adminUid}', 'حضور متأخر وتم استلامه بعذر رسمي', NOW());`
  );
  const q28 = await runAs(adminUid, 'ADMIN', `SELECT reason FROM attendance_corrections WHERE id = '${corr1Id}';`);
  assert(q28.rows.length === 1, 'Test 28: Valid correction record created in attendance_corrections ledger');

  // Test 29: Database CHECK constraint rejects correction reason < 10 characters
  let reasonCheckFailed = false;
  try {
    await runAs(
      adminUid,
      'ADMIN',
      `INSERT INTO attendance_corrections (attendance_id, kindergarten_id, child_id, previous_status, new_status, corrected_by_user_id, reason, client_timestamp)
       VALUES ('${att1Id}', '${kId}', '${child1Id}', 'PRESENT', 'ABSENT_EXCUSED', '${adminUid}', 'قصير', NOW());`
    );
  } catch (err: unknown) {
    const errorMsg = String(err);
    reasonCheckFailed = errorMsg.includes('reason') || errorMsg.includes('check');
  }
  assert(reasonCheckFailed, 'Test 29: Database CHECK constraint strictly rejects correction reason < 10 characters');

  // Test 30: Authenticated role cannot UPDATE corrections (blocked by RLS, 0 rows affected)
  const q30Rls = await runAs(
    adminUid,
    'ADMIN',
    `UPDATE attendance_corrections SET reason = 'محاولة تلاعب عبر مستخدم مصادق' WHERE id = '${corr1Id}' RETURNING reason;`
  );
  assert(q30Rls.rows.length === 0, 'Test 30: Authenticated roles are blocked from UPDATE on corrections by RLS (0 rows affected)');

  // Test 31: Trigger trg_freeze_attendance_corrections strictly blocks UPDATE with TAMPER_ALERT
  let triggerUpdateBlocked = false;
  try {
    await db.query(`UPDATE attendance_corrections SET reason = 'محاولة تلاعب مباشرة' WHERE id = '${corr1Id}';`);
  } catch (err: unknown) {
    const errorMsg = String(err);
    triggerUpdateBlocked = errorMsg.includes('TAMPER_ALERT') || errorMsg.includes('immutable');
  }
  assert(triggerUpdateBlocked, 'Test 31: Trigger trg_freeze_attendance_corrections strictly BLOCKS any UPDATE with TAMPER_ALERT');

  // Test 32: Trigger trg_freeze_attendance_corrections strictly blocks DELETE with TAMPER_ALERT
  let triggerDeleteBlocked = false;
  try {
    await db.query(`DELETE FROM attendance_corrections WHERE id = '${corr1Id}';`);
  } catch (err: unknown) {
    const errorMsg = String(err);
    triggerDeleteBlocked = errorMsg.includes('TAMPER_ALERT') || errorMsg.includes('immutable');
  }
  assert(triggerDeleteBlocked, 'Test 32: Trigger trg_freeze_attendance_corrections strictly BLOCKS any DELETE with TAMPER_ALERT');

  // Test 33: Secure pickup with authorized parent updates status to CHECKED_OUT and sets picked_up_by_name
  const pickupParent1 = 'أحمد بن خالد السالم (FATHER)';
  await runAs(
    teacherUid,
    'TEACHER',
    `UPDATE attendance
     SET status = 'CHECKED_OUT', check_out_time = NOW(), picked_up_by_name = '${pickupParent1}'
     WHERE id = '${att1Id}';`
  );
  const q33 = await runAs(adminUid, 'ADMIN', `SELECT status, picked_up_by_name FROM attendance WHERE id = '${att1Id}';`);
  assert(
    q33.rows[0]?.status === 'CHECKED_OUT' && q33.rows[0]?.picked_up_by_name === pickupParent1,
    'Test 33: Secure pickup successfully records CHECKED_OUT and canonical picked_up_by_name'
  );

  console.log('\n===============================================================');
  console.log(`GATE 6A TEST SUITE SUMMARY: ${passedCount} passed, ${failedCount} failed, ${skippedCount} skipped`);
  console.log('===============================================================');

  if (failedCount > 0) {
    process.exit(1);
  }
}

runGate6aTestSuite().catch((err) => {
  console.error('Fatal execution error:', err);
  process.exit(1);
});
