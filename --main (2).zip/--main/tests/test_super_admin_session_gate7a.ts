import { PGlite } from '@electric-sql/pglite';
import fs from 'fs';
import path from 'path';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    passed++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    failed++;
    console.error(`  ✗ FAIL: ${testName}${detail ? ` - ${detail}` : ''}`);
    throw new Error(`Assertion failed: ${testName}`);
  }
}

async function runGate7aTestSuite() {
  console.log('===============================================================');
  console.log('GATE 7A TEST SUITE — SUPER_ADMIN SUPPORT SESSION SECURITY');
  console.log('Standards: 60-Minute Max Duration, Cryptographic Audit & Kernel Defense');
  console.log('===============================================================\n');

  const db = new PGlite();

  // 1. Setup Auth Schema & Roles
  await db.exec(`
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (
      id UUID PRIMARY KEY,
      email TEXT UNIQUE,
      phone TEXT,
      raw_user_meta_data JSONB,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );

    CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID AS $$
      SELECT NULLIF(current_setting('request.jwt.claims', true)::jsonb->>'sub', '')::uuid;
    $$ LANGUAGE sql STABLE;

    CREATE OR REPLACE FUNCTION auth.jwt() RETURNS JSONB AS $$
      SELECT COALESCE(current_setting('request.jwt.claims', true)::jsonb, '{}'::jsonb);
    $$ LANGUAGE sql STABLE;

    CREATE ROLE authenticated NOLOGIN;
    CREATE ROLE anon NOLOGIN;
    GRANT USAGE ON SCHEMA public, auth TO authenticated, anon;
  `);

  // 2. Load Migrations 1 to 7
  console.log('--- 1. Executing Migrations (1 to 7) ---');
  await db.exec(fs.readFileSync('supabase/migrations/20260927000001_initial_schema.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000002_rls_policies.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000003_invitations_fsm.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000004_user_profile_provisioning.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000005_super_admin_support_sessions.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000006_storage_security_hardening.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000007_super_admin_privilege_hardening.sql', 'utf-8'));
  console.log('  ✓ All 7 migrations loaded successfully into PostgreSQL engine.\n');

  await db.exec(`
    GRANT ALL ON ALL TABLES IN SCHEMA public, storage TO authenticated;
    GRANT ALL ON ALL ROUTINES IN SCHEMA public, storage, auth TO authenticated;
  `);

  // 3. Seed test actors
  const kgId = '11111111-1111-1111-1111-111111111111';
  const otherKgId = '22222222-2222-2222-2222-222222222222';
  const superAdminId = 'ffff0007-0000-0000-0000-000000000007';
  const regularTeacherId = 'ffff0003-0000-0000-0000-000000000003';
  const regularAdminId = 'ffff0001-0000-0000-0000-000000000001';

  await db.exec(`
    INSERT INTO auth.users (id, email) VALUES
      ('${superAdminId}', 'superadmin@system.gov.sa'),
      ('${regularTeacherId}', 'teacher@school.sa'),
      ('${regularAdminId}', 'admin@school.sa');

    INSERT INTO kindergartens (id, name, license_number, contact_email, contact_phone, address)
    VALUES
      ('${kgId}', 'Al-Amal Kindergarten', 'LIC-7A-001', 'amal@school.sa', '0501112233', 'Riyadh'),
      ('${otherKgId}', 'Al-Noor Kindergarten', 'LIC-7A-002', 'noor@school.sa', '0502223344', 'Jeddah');

    INSERT INTO user_profiles (id, full_name, phone_number) VALUES
      ('${superAdminId}', 'System Super Admin', '0577777777'),
      ('${regularTeacherId}', 'Teacher Sarah', '0533333333'),
      ('${regularAdminId}', 'Director Fatima', '0511111111')
    ON CONFLICT (id) DO UPDATE SET full_name = EXCLUDED.full_name, phone_number = EXCLUDED.phone_number;

    INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role)
    VALUES
      ('${kgId}', '${regularAdminId}', 'ADMIN'),
      ('${kgId}', '${regularTeacherId}', 'TEACHER');

    -- Designated Platform Super Admin record in authoritative table
    INSERT INTO platform_super_admins (user_id, notes)
    VALUES ('${superAdminId}', 'Authoritative designated System Operations Super Admin');
  `);

  // Helper function to switch authenticated context
  async function setAuth(userId: string, role: string = 'SUPER_ADMIN') {
    await db.query("SELECT set_config('request.jwt.claims', $1, false);", [JSON.stringify({ sub: userId, role })]);
  }

  // ===========================================================================
  // TEST GROUP 1: Reason Length Validation (29 chars vs 30 chars)
  // ===========================================================================
  console.log('--- 2. Reason Length Validation Tests ---');

  // Set auth identity to superAdminId
  await setAuth(superAdminId, 'SUPER_ADMIN');

  // Test 1: 29 characters -> FAIL
  const reason29 = '12345678901234567890123456789'; // exactly 29 chars
  let failedAsExpected29 = false;
  try {
    await db.query(`
      SELECT rpc_initiate_support_session(
        '${kgId}'::uuid,
        '${reason29}',
        30
      );
    `);
  } catch (err: unknown) {
    failedAsExpected29 = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('SESSION_REASON_TOO_SHORT') || msg.includes('at least 30 characters'), 'Test 1.1: Error message indicates reason too short', msg);
  }
  assert(failedAsExpected29, 'Test 1.2: 29 characters reason is strictly REJECTED');

  // Test 2: 30 characters -> PASS
  const reason30 = '123456789012345678901234567890'; // exactly 30 chars
  const res30 = await db.query(`
    SELECT rpc_initiate_support_session(
      '${kgId}'::uuid,
      '${reason30}',
      30
    ) as session;
  `);
  const sessionData30 = (res30.rows[0] as { session: { success: boolean; duration_minutes: number; session_id: string } }).session;
  assert(sessionData30.success === true, 'Test 2.1: 30 characters reason is ACCEPTED');
  assert(sessionData30.duration_minutes === 30, 'Test 2.2: Session duration set correctly');

  // ===========================================================================
  // TEST GROUP 2: Duration Limits (59m, 60m, 60m+1s, 61m)
  // ===========================================================================
  console.log('\n--- 3. Duration Cap Tests (Max 60 Minutes) ---');

  const validReason = 'Emergency pedagogical review for student records validation'; // > 30 chars

  // Test 3: 59 minutes -> PASS
  const res59 = await db.query(`
    SELECT rpc_initiate_support_session(
      '${kgId}'::uuid,
      '${validReason}',
      59
    ) as session;
  `);
  const s59 = (res59.rows[0] as { session: { success: boolean; duration_minutes: number } }).session;
  assert(s59.success === true && s59.duration_minutes === 59, 'Test 3: 59 minutes duration is ACCEPTED');

  // Test 4: 60 minutes -> PASS
  const res60 = await db.query(`
    SELECT rpc_initiate_support_session(
      '${kgId}'::uuid,
      '${validReason}',
      60
    ) as session;
  `);
  const s60 = (res60.rows[0] as { session: { success: boolean; duration_minutes: number } }).session;
  assert(s60.success === true && s60.duration_minutes === 60, 'Test 4: 60 minutes duration is ACCEPTED (boundary cap)');

  // Test 5: 61 minutes -> FAIL
  let failedAsExpected61 = false;
  try {
    await db.query(`
      SELECT rpc_initiate_support_session(
        '${kgId}'::uuid,
        '${validReason}',
        61
      );
    `);
  } catch (err: unknown) {
    failedAsExpected61 = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('SESSION_DURATION_EXCEEDED') || msg.includes('cannot exceed 60 minutes'), 'Test 5.1: Error message indicates duration exceeded', msg);
  }
  assert(failedAsExpected61, 'Test 5.2: 61 minutes duration is strictly REJECTED');

  // Test 6: 60 minutes + 1 second on database table level -> FAIL
  let failedAsExpected60m1s = false;
  try {
    await db.query(`
      INSERT INTO super_admin_support_sessions (
        super_admin_id,
        target_kindergarten_id,
        reason,
        scope,
        initiated_at,
        expires_at
      ) VALUES (
        '${superAdminId}',
        '${kgId}',
        '${validReason}',
        'BYPASS_TEST',
        NOW(),
        NOW() + INTERVAL '60 minutes 1 second'
      );
    `);
  } catch (err: unknown) {
    failedAsExpected60m1s = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(
      msg.includes('check_support_session_max_duration') || msg.includes('SESSION_DURATION_EXCEEDED'),
      'Test 6.1: Direct DDL check constraint / trigger stops 60m+1s',
      msg
    );
  }
  assert(failedAsExpected60m1s, 'Test 6.2: 60 minutes + 1 second is strictly BLOCKED by DB kernel constraint');

  // ===========================================================================
  // TEST GROUP 3: Expired Session Invalidation
  // ===========================================================================
  console.log('\n--- 4. Active vs Expired Session Validation ---');

  // Create a 10-minute session
  const resAct = await db.query(`
    SELECT rpc_initiate_support_session(
      '${kgId}'::uuid,
      'Testing active session status for child access',
      10
    ) as session;
  `);
  const sAct = (resAct.rows[0] as { session: { session_id: string } }).session;

  // Verify auth.has_active_support_session returns TRUE
  const checkActive = await db.query(`SELECT auth.has_active_support_session('${kgId}'::uuid) as is_active;`);
  assert((checkActive.rows[0] as { is_active: boolean }).is_active === true, 'Test 7.1: Active support session allows has_active_support_session = TRUE');

  // Verify auth.has_active_support_session for another kindergarten returns FALSE (Tenant Scoping)
  const checkOtherActive = await db.query(`SELECT auth.has_active_support_session('${otherKgId}'::uuid) as is_active;`);
  assert((checkOtherActive.rows[0] as { is_active: boolean }).is_active === false, 'Test 7.1b: Active support session for kgId strictly does NOT grant access to other kindergarten');

  // Revoke session via RPC
  const resRevoke = await db.query(`
    SELECT rpc_revoke_support_session(
      '${sAct.session_id}'::uuid,
      'Maintenance operation completed'
    ) as result;
  `);
  const revResult = (resRevoke.rows[0] as { result: { success: boolean; is_active: boolean } }).result;
  assert(revResult.success === true && revResult.is_active === false, 'Test 7.2: rpc_revoke_support_session successfully deactivates session');

  const checkRevoked = await db.query(`SELECT auth.has_active_support_session('${kgId}'::uuid) as is_active;`);
  assert((checkRevoked.rows[0] as { is_active: boolean }).is_active === false, 'Test 7.3: Revoked session yields has_active_support_session = FALSE');

  // Simulate an expired session by setting expires_at in the past
  await db.query(`
    UPDATE super_admin_support_sessions
    SET expires_at = NOW() - INTERVAL '5 minutes'
    WHERE id = '${sAct.session_id}';
  `);
  const checkExpired = await db.query(`SELECT auth.has_active_support_session('${kgId}'::uuid) as is_active;`);
  assert((checkExpired.rows[0] as { is_active: boolean }).is_active === false, 'Test 7.4: Expired session strictly yields has_active_support_session = FALSE');

  // ===========================================================================
  // TEST GROUP 4: Direct Client Mutation Bypasses
  // ===========================================================================
  console.log('\n--- 5. Anti-Tampering & RLS Defense Tests ---');

  // Test 8: Direct client INSERT without RPC is blocked by RLS
  // Switch to unprivileged authenticated role
  await db.exec(`SET ROLE authenticated;`);
  await setAuth(superAdminId, 'SUPER_ADMIN');

  let directInsertBlocked = false;
  try {
    await db.query(`
      INSERT INTO super_admin_support_sessions (
        super_admin_id,
        target_kindergarten_id,
        reason,
        scope,
        initiated_at,
        expires_at
      ) VALUES (
        '${superAdminId}',
        '${kgId}',
        'Direct rogue insertion bypass attempt 12345',
        'ROGUE',
        NOW(),
        NOW() + INTERVAL '30 minutes'
      );
    `);
  } catch (err: unknown) {
    directInsertBlocked = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('violates row-level security policy') || msg.includes('permission denied'), 'Test 8.1: RLS policy denies direct INSERT', msg);
  }
  assert(directInsertBlocked, 'Test 8.2: Direct client INSERT bypass is strictly BLOCKED by RLS');

  // Switch back to test supervisor
  await db.exec(`RESET ROLE;`);
  await setAuth(superAdminId, 'SUPER_ADMIN');

  // Test 9: Direct UPDATE extending expiry -> FAIL (Blocked by trigger)
  // Create a session first via RPC
  const sNew = await db.query(`
    SELECT rpc_initiate_support_session(
      '${kgId}'::uuid,
      'Valid session created for anti-extension test case',
      30
    ) as session;
  `);
  const newSessionId = (sNew.rows[0] as { session: { session_id: string } }).session.session_id;

  let extensionBlocked = false;
  try {
    await db.query(`
      UPDATE super_admin_support_sessions
      SET expires_at = expires_at + INTERVAL '10 minutes'
      WHERE id = '${newSessionId}';
    `);
  } catch (err: unknown) {
    extensionBlocked = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('TAMPER_ALERT') && msg.includes('Extending support session expiry'), 'Test 9.1: Anti-extension trigger fired', msg);
  }
  assert(extensionBlocked, 'Test 9.2: Direct UPDATE extending expiry is strictly BLOCKED');

  // ===========================================================================
  // TEST GROUP 5: Role & Kindergarten Scoping
  // ===========================================================================
  console.log('\n--- 6. Role & Kindergarten Boundary Tests ---');

  // Test 10: Non-SUPER_ADMIN (Teacher) attempting to initiate session -> FAIL
  await setAuth(regularTeacherId, 'TEACHER');
  let teacherBlocked = false;
  try {
    await db.query(`
      SELECT rpc_initiate_support_session(
        '${kgId}'::uuid,
        'Teacher attempting unauthorized support session',
        30
      );
    `);
  } catch (err: unknown) {
    teacherBlocked = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('PERMISSION_DENIED') || msg.includes('SUPER_ADMIN'), 'Test 10.1: Teacher rejected from initiating support session', msg);
  }
  assert(teacherBlocked, 'Test 10.2: Non-SUPER_ADMIN is strictly REJECTED');

  // Test 11: Non-existent / Wrong Kindergarten -> FAIL
  await setAuth(superAdminId, 'SUPER_ADMIN');
  const fakeKgId = '99999999-9999-9999-9999-999999999999';
  let wrongKgBlocked = false;
  try {
    await db.query(`
      SELECT rpc_initiate_support_session(
        '${fakeKgId}'::uuid,
        'Initiating session on non-existent kindergarten',
        30
      );
    `);
  } catch (err: unknown) {
    wrongKgBlocked = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('KINDERGARTEN_NOT_FOUND'), 'Test 11.1: Non-existent kindergarten rejected', msg);
  }
  assert(wrongKgBlocked, 'Test 11.2: Invalid kindergarten is strictly REJECTED');

  // ===========================================================================
  // TEST GROUP 6: Immutable Audit Log Generation
  // ===========================================================================
  console.log('\n--- 7. Audit Log Generation & Immutability Tests ---');

  const auditEvents = await db.query(`
    SELECT action, resource_type, actor_role, reason, metadata, previous_log_hash, current_log_hash
    FROM audit_logs
    WHERE resource_type = 'super_admin_support_sessions'
    ORDER BY created_at ASC;
  `);

  interface AuditRow {
    action: string;
    actor_role: string;
    current_log_hash: string;
  }
  const auditRows = auditEvents.rows as AuditRow[];
  assert(auditRows.length >= 2, 'Test 12.1: Audit records successfully created for support sessions');
  const initAudit = auditRows.find((r) => r.action === 'SUPER_ADMIN_SUPPORT_SESSION_INITIATED');
  assert(initAudit !== undefined, 'Test 12.2: SUPER_ADMIN_SUPPORT_SESSION_INITIATED audit event found');
  assert(initAudit?.actor_role === 'SUPER_ADMIN', 'Test 12.3: Actor role logged as SUPER_ADMIN');
  assert(Boolean(initAudit?.current_log_hash && initAudit.current_log_hash.length === 64), 'Test 12.4: Cryptographic hash chain generated for audit event');

  const revokeAudit = auditRows.find((r) => r.action === 'SUPER_ADMIN_SUPPORT_SESSION_REVOKED');
  assert(revokeAudit !== undefined, 'Test 12.5: SUPER_ADMIN_SUPPORT_SESSION_REVOKED audit event found');

  // Immutability test on audit_logs: UPDATE must fail with TAMPER_ALERT
  let auditUpdateBlocked = false;
  try {
    await db.query(`
      UPDATE audit_logs
      SET reason = 'Altered reason'
      WHERE resource_type = 'super_admin_support_sessions';
    `);
  } catch (err: unknown) {
    auditUpdateBlocked = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('TAMPER_ALERT'), 'Test 12.6: Audit log update blocked by freeze trigger', msg);
  }
  assert(auditUpdateBlocked, 'Test 12.7: Audit logs cannot be modified');

  // ===========================================================================
  // TEST GROUP 7: Gate 7C P0 Hardening — Sole Authority platform_super_admins
  // ===========================================================================
  console.log('\n--- 8. Gate 7C P0 Privilege Escalation Hardening Tests ---');

  const rogueUserId = 'ffff0099-0000-0000-0000-000000000099';
  await db.exec(`
    INSERT INTO auth.users (id, email) VALUES
      ('${rogueUserId}', 'rogue_attacker@test.sa');
    INSERT INTO user_profiles (id, full_name, phone_number) VALUES
      ('${rogueUserId}', 'Attacker Super Admin System Director', '0599999999')
    ON CONFLICT (id) DO UPDATE SET full_name = EXCLUDED.full_name;
  `);

  // Test 13: Name matching does NOT grant Super Admin
  await setAuth(rogueUserId, 'authenticated');
  let rogueNameBlocked = false;
  try {
    await db.query(`
      SELECT rpc_initiate_support_session(
        '${kgId}'::uuid,
        'Rogue attacker attempting session via forged full_name matching',
        30
      );
    `);
  } catch (err: unknown) {
    rogueNameBlocked = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('PERMISSION_DENIED'), 'Test 13.1: Error message indicates permission denied for rogue name', msg);
  }
  assert(rogueNameBlocked, 'Test 13.2: Forged full_name containing Super Admin is strictly REJECTED');

  // Test 14: Forged user_metadata does NOT grant Super Admin
  await db.query("SELECT set_config('request.jwt.claims', $1, false);", [
    JSON.stringify({
      sub: rogueUserId,
      role: 'authenticated',
      user_metadata: { role: 'SUPER_ADMIN' },
    }),
  ]);
  let rogueUserMetaBlocked = false;
  try {
    await db.query(`
      SELECT rpc_initiate_support_session(
        '${kgId}'::uuid,
        'Rogue attacker attempting session via forged user_metadata claim',
        30
      );
    `);
  } catch (err: unknown) {
    rogueUserMetaBlocked = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('PERMISSION_DENIED'), 'Test 14.1: Error message indicates permission denied for forged user_metadata', msg);
  }
  assert(rogueUserMetaBlocked, 'Test 14.2: Forged user_metadata.role = SUPER_ADMIN is strictly REJECTED');

  // Test 15: app_metadata.role alone does NOT grant Super Admin without table record
  await db.query("SELECT set_config('request.jwt.claims', $1, false);", [
    JSON.stringify({
      sub: rogueUserId,
      role: 'authenticated',
      app_metadata: { role: 'SUPER_ADMIN' },
    }),
  ]);
  let appMetaAloneBlocked = false;
  try {
    await db.query(`
      SELECT rpc_initiate_support_session(
        '${kgId}'::uuid,
        'Caller with app_metadata alone attempting session without table record',
        30
      );
    `);
  } catch (err: unknown) {
    appMetaAloneBlocked = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('PERMISSION_DENIED'), 'Test 15.1: Error indicates table authority requirement', msg);
  }
  assert(appMetaAloneBlocked, 'Test 15.2: app_metadata alone without platform_super_admins is strictly REJECTED');

  // Test 16: Local Admin CANNOT insert role = 'SUPER_ADMIN' in kindergarten_memberships
  await db.exec(`SET ROLE authenticated;`);
  await setAuth(regularAdminId, 'ADMIN');
  let adminMembershipEscalationBlocked = false;
  try {
    await db.query(`
      INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role)
      VALUES ('${kgId}', '${regularTeacherId}', 'SUPER_ADMIN');
    `);
  } catch (err: unknown) {
    adminMembershipEscalationBlocked = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('check_membership_no_super_admin') || msg.includes('violates row-level security policy') || msg.includes('check constraint'), 'Test 16.1: DDL/RLS stops local admin membership escalation', msg);
  }
  assert(adminMembershipEscalationBlocked, 'Test 16.2: Local admin inserting SUPER_ADMIN membership is strictly BLOCKED');

  // Test 17: Local Admin CANNOT create invitation with target_role = 'SUPER_ADMIN'
  let adminInviteEscalationBlocked = false;
  try {
    await db.query(`
      INSERT INTO invitations (
        kindergarten_id,
        target_email,
        target_role,
        token_hash,
        expires_at
      ) VALUES (
        '${kgId}',
        'hacker_super@school.sa',
        'SUPER_ADMIN',
        'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
        NOW() + INTERVAL '7 days'
      );
    `);
  } catch (err: unknown) {
    adminInviteEscalationBlocked = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('check_invitation_no_super_admin') || msg.includes('violates row-level security policy') || msg.includes('check constraint'), 'Test 17.1: DDL/RLS stops invitation escalation', msg);
  }
  assert(adminInviteEscalationBlocked, 'Test 17.2: Local admin creating SUPER_ADMIN invitation is strictly BLOCKED');

  // Test 18: Direct client INSERT into platform_super_admins is blocked
  let directPlatformAdminInsertBlocked = false;
  try {
    await db.query(`
      INSERT INTO platform_super_admins (user_id)
      VALUES ('${rogueUserId}');
    `);
  } catch (err: unknown) {
    directPlatformAdminInsertBlocked = true;
    const msg = err instanceof Error ? err.message : String(err);
    assert(msg.includes('violates row-level security policy') || msg.includes('TAMPER_ALERT'), 'Test 18.1: Client insert into platform_super_admins denied', msg);
  }
  assert(directPlatformAdminInsertBlocked, 'Test 18.2: Client direct INSERT into platform_super_admins is strictly BLOCKED');

  // Switch back to test supervisor
  await db.exec(`RESET ROLE;`);
  await setAuth(superAdminId, 'SUPER_ADMIN');

  console.log('\n===============================================================');
  console.log(`GATE 7A / GATE 7C TEST SUITE SUMMARY: ${passed} passed, ${failed} failed`);
  console.log('===============================================================');
}

runGate7aTestSuite().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
