import fs from 'fs';
import path from 'path';
import {
  createChildSchema,
  updateChildSchema,
  GENDER_VALUES,
} from '../src/modules/children/childValidation';

/**
 * Phase 1 — Vertical Slice 2: Implementation Gate 3 Test Suite
 * Covers Domain Validation, Security & Tenant Invariants, UI Integrity, and i18n
 */

let passedTests = 0;
let failedTests = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    passedTests++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    failedTests++;
    console.error(`  ✗ FAIL: ${testName}${detail ? ` - ${detail}` : ''}`);
  }
}

console.log('===============================================================');
console.log('PHASE 1 — VERTICAL SLICE 2: IMPLEMENTATION GATE 3 TEST SUITE');
console.log('===============================================================\n');

// -----------------------------------------------------------------------------
// Group 1: Validation Rules Execution Tests (Zod Schema)
// -----------------------------------------------------------------------------
console.log('--- 1. Validation Rules Execution Tests ---');

const validChildPayload = {
  first_name: 'سارة',
  last_name: 'العتيبي',
  dob: '2022-03-15',
  gender: 'FEMALE' as const,
  class_id: '11111111-2222-4333-8444-555555555555',
  emergency_contact_name: 'محمد العتيبي',
  emergency_contact_phone: '0501234567',
  enrollment_date: '2026-09-01',
};

// Test 1: Valid child input parses successfully
const res1 = createChildSchema.safeParse(validChildPayload);
assert(res1.success === true, 'Test 1: Valid child input parses successfully');

// Test 2: First name < 2 characters is rejected
const res2 = createChildSchema.safeParse({ ...validChildPayload, first_name: 'أ' });
assert(
  res2.success === false && res2.error.issues[0].message.includes('حرفين على الأقل'),
  'Test 2: First name with less than 2 characters is rejected'
);

// Test 3: First name > 100 characters is rejected
const longFirstName = 'س'.repeat(101);
const res3 = createChildSchema.safeParse({ ...validChildPayload, first_name: longFirstName });
assert(
  res3.success === false && res3.error.issues[0].message.includes('100 حرف'),
  'Test 3: First name exceeding 100 characters is rejected'
);

// Test 4: Last name < 2 characters is rejected
const res4 = createChildSchema.safeParse({ ...validChildPayload, last_name: 'ع' });
assert(
  res4.success === false && res4.error.issues[0].message.includes('حرفين على الأقل'),
  'Test 4: Last name with less than 2 characters is rejected'
);

// Test 5: Last name > 100 characters is rejected
const longLastName = 'ع'.repeat(101);
const res5 = createChildSchema.safeParse({ ...validChildPayload, last_name: longLastName });
assert(
  res5.success === false && res5.error.issues[0].message.includes('100 حرف'),
  'Test 5: Last name exceeding 100 characters is rejected'
);

// Test 6: Future date of birth is rejected
const futureDate = new Date();
futureDate.setFullYear(futureDate.getFullYear() + 1);
const futureDobStr = futureDate.toISOString().split('T')[0];
const res6 = createChildSchema.safeParse({ ...validChildPayload, dob: futureDobStr });
assert(
  res6.success === false && res6.error.issues[0].message.includes('المستقبل'),
  'Test 6: Future date of birth is rejected'
);

// Test 7: Valid past date of birth is accepted
const res7 = createChildSchema.safeParse({ ...validChildPayload, dob: '2023-01-10' });
assert(res7.success === true, 'Test 7: Valid past date of birth is accepted');

// Test 8: Gender 'MALE' is accepted
const res8 = createChildSchema.safeParse({ ...validChildPayload, gender: 'MALE' });
assert(res8.success === true && res8.data.gender === 'MALE', "Test 8: Gender 'MALE' is accepted");

// Test 9: Gender 'FEMALE' is accepted
const res9 = createChildSchema.safeParse({ ...validChildPayload, gender: 'FEMALE' });
assert(res9.success === true && res9.data.gender === 'FEMALE', "Test 9: Gender 'FEMALE' is accepted");

// Test 10: Arabic gender 'ذكر' is rejected by technical contract
const res10 = createChildSchema.safeParse({ ...validChildPayload, gender: 'ذكر' });
assert(res10.success === false, "Test 10: Arabic gender 'ذكر' is rejected by technical contract");

// Test 11: Arabic gender 'أنثى' is rejected by technical contract
const res11 = createChildSchema.safeParse({ ...validChildPayload, gender: 'أنثى' });
assert(res11.success === false, "Test 11: Arabic gender 'أنثى' is rejected by technical contract");

// Test 12: Invalid gender string is rejected
const res12 = createChildSchema.safeParse({ ...validChildPayload, gender: 'OTHER' });
assert(res12.success === false, "Test 12: Arbitrary string 'OTHER' is rejected for gender");

// Test 13: Invalid class UUID format is rejected
const res13 = createChildSchema.safeParse({ ...validChildPayload, class_id: 'invalid-not-a-uuid' });
assert(
  res13.success === false && res13.error.issues[0].message.includes('UUID'),
  'Test 13: Non-UUID class_id is rejected'
);

// Test 14: Emergency contact name < 3 characters is rejected
const res14 = createChildSchema.safeParse({ ...validChildPayload, emergency_contact_name: 'أب' });
assert(
  res14.success === false && res14.error.issues[0].message.includes('3 أحرف'),
  'Test 14: Emergency contact name with less than 3 characters is rejected'
);

// Test 15: Empty emergency phone is rejected
const res15 = createChildSchema.safeParse({ ...validChildPayload, emergency_contact_phone: '   ' });
assert(
  res15.success === false,
  'Test 15: Empty emergency phone number is rejected'
);

// Test 16: Default enrollment date is applied if omitted
const { enrollment_date, ...payloadWithoutEnrollment } = validChildPayload;
const res16 = createChildSchema.safeParse(payloadWithoutEnrollment);
assert(
  res16.success === true && typeof res16.data.enrollment_date === 'string' && res16.data.enrollment_date.length > 0,
  'Test 16: Default enrollment date is applied if omitted'
);

// -----------------------------------------------------------------------------
// Group 2: Architectural & Security Invariants
// -----------------------------------------------------------------------------
console.log('\n--- 2. Architectural & Security Invariants ---');

const serviceFilePath = path.join(process.cwd(), 'src/modules/children/childrenService.ts');
const serviceCode = fs.readFileSync(serviceFilePath, 'utf8');

// Test 17: Service contains zero physical `.delete()` calls
const hasPhysicalDeleteInService = /\.delete\s*\(/i.test(serviceCode);
assert(!hasPhysicalDeleteInService, 'Test 17: childrenService.ts contains ZERO physical `.delete()` calls');

// Test 18: Service performs soft delete via `deleted_at = NOW()`
const hasSoftDeleteUpdate = /deleted_at:\s*new\s+Date\(\)\.toISOString\(\)/.test(serviceCode);
assert(hasSoftDeleteUpdate, 'Test 18: archiveChild uses UPDATE soft-delete semantics exclusively');

// Test 19: Service never attempts client-side writes to audit_logs
const hasAuditLogsWrite = /from\(['"]audit_logs['"]\)\s*\.insert/i.test(serviceCode);
assert(!hasAuditLogsWrite, 'Test 19: childrenService.ts does NOT perform direct client writes to audit_logs');

// Test 20: kindergartenId treated strictly as query context, not authorization source
const hasZeroTrustComment = /ZERO TRUST:\s*`kindergartenId`\s*passed by caller is strictly a query context selector/i.test(serviceCode);
assert(hasZeroTrustComment, 'Test 20: kindergartenId is treated strictly as query context, RLS is final authority');

// Test 21: updateChild disallows changing kindergarten_id
const hasTenantChangeProtection = /CANNOT_CHANGE_TENANT/i.test(serviceCode);
assert(hasTenantChangeProtection, 'Test 21: updateChild enforces same-kindergarten tenant boundary');

// Test 22: class assignment verifies that class belongs to the same kindergarten
const hasClassKindergartenCheck = /CLASS_NOT_IN_KINDERGARTEN/i.test(serviceCode);
assert(hasClassKindergartenCheck, 'Test 22: createChild and updateChild verify class belongs to same kindergarten');

// -----------------------------------------------------------------------------
// Group 3: UI Components Presence & Export Integrity
// -----------------------------------------------------------------------------
console.log('\n--- 3. UI Components Presence & Export Integrity ---');

const childrenComponentsDir = path.join(process.cwd(), 'src/modules/children/components');
const requiredChildrenComponents = [
  'ChildCardSkeleton.tsx',
  'ChildCard.tsx',
  'ChildrenToolbar.tsx',
  'CreateChildDrawer.tsx',
  'EditChildDrawer.tsx',
  'ChildDetailsSheet.tsx',
  'ArchiveChildDialog.tsx',
];

requiredChildrenComponents.forEach((filename) => {
  const filePath = path.join(childrenComponentsDir, filename);
  const exists = fs.existsSync(filePath);
  assert(exists, `Test 23+: Component exists: ${filename}`);
});

const mainViewExists = fs.existsSync(path.join(process.cwd(), 'src/modules/children/ChildrenView.tsx'));
assert(mainViewExists, 'Test 30: ChildrenView.tsx exists at module root');

// Test 31: Zero physical delete in all children UI components
let hasPhysicalDeleteInUI = false;
let hasDirectAuditInUI = false;

[...requiredChildrenComponents, '../ChildrenView.tsx'].forEach((filename) => {
  const filePath = path.join(childrenComponentsDir, filename);
  if (fs.existsSync(filePath)) {
    const code = fs.readFileSync(filePath, 'utf8');
    if (/\.delete\s*\(/i.test(code)) {
      hasPhysicalDeleteInUI = true;
    }
    if (/from\(['"]audit_logs['"]\)/i.test(code)) {
      hasDirectAuditInUI = true;
    }
  }
});

assert(!hasPhysicalDeleteInUI, 'Test 31: Zero physical `.delete()` in all children UI components');
assert(!hasDirectAuditInUI, 'Test 32: Zero direct `audit_logs` writes in all children UI components');

// -----------------------------------------------------------------------------
// Group 4: Design System Semantics & Accessibility
// -----------------------------------------------------------------------------
console.log('\n--- 4. Design System Semantics & Accessibility ---');

const createDrawerCode = fs.readFileSync(path.join(childrenComponentsDir, 'CreateChildDrawer.tsx'), 'utf8');
const editDrawerCode = fs.readFileSync(path.join(childrenComponentsDir, 'EditChildDrawer.tsx'), 'utf8');
const detailsSheetCode = fs.readFileSync(path.join(childrenComponentsDir, 'ChildDetailsSheet.tsx'), 'utf8');

// Test 33: Drawer uses logical inline-end positioning and direction-aware animation
const hasInlineEndDrawer = /inset-inline-end-0/i.test(createDrawerCode) && /inset-inline-end-0/i.test(editDrawerCode);
const hasLogicalAnimation =
  createDrawerCode.includes("dir === 'rtl' ? 'slide-in-from-left' : 'slide-in-from-right'") &&
  editDrawerCode.includes("dir === 'rtl' ? 'slide-in-from-left' : 'slide-in-from-right'");
assert(hasInlineEndDrawer && hasLogicalAnimation, 'Test 33: Create & Edit Child Drawers adhere to logical inline-end positioning & direction-aware animation');

// Test 34: Mobile drag handle in ChildDetailsSheet
const hasDragHandle = /rounded-full\s+bg-slate-300/i.test(detailsSheetCode);
assert(hasDragHandle, 'Test 34: ChildDetailsSheet contains mobile drag handle indicator');

// -----------------------------------------------------------------------------
// Group 5: Admin Shell Integration
// -----------------------------------------------------------------------------
console.log('\n--- 5. Admin Shell Integration ---');

const adminShellCode = fs.readFileSync(path.join(process.cwd(), 'src/modules/admin/components/AdminShell.tsx'), 'utf8');
const rendersChildrenView = /<ChildrenView\s*\/>/.test(adminShellCode);
assert(rendersChildrenView, 'Test 35: AdminShell renders <ChildrenView /> for children tab');

// -----------------------------------------------------------------------------
// Group 6: i18n Dictionary Integrity
// -----------------------------------------------------------------------------
console.log('\n--- 6. i18n Dictionary Integrity ---');

const arI18nCode = fs.readFileSync(path.join(process.cwd(), 'src/lib/i18n/ar.ts'), 'utf8');
const enI18nCode = fs.readFileSync(path.join(process.cwd(), 'src/lib/i18n/en.ts'), 'utf8');
const typesI18nCode = fs.readFileSync(path.join(process.cwd(), 'src/lib/i18n/types.ts'), 'utf8');

const arHasChildren = /children:\s*\{/.test(arI18nCode);
const enHasChildren = /children:\s*\{/.test(enI18nCode);
const typesHasChildren = /children:\s*\{/.test(typesI18nCode);

assert(arHasChildren && enHasChildren && typesHasChildren, 'Test 36: Both ar.ts and en.ts and types.ts include children dictionary');

// Test 37: Zero hardcoded Arabic text in children UI components
const arabicCharPattern = /[\u0600-\u06FF]/;
let foundHardcodedArabicInUI = false;

requiredChildrenComponents.forEach((filename) => {
  const filePath = path.join(childrenComponentsDir, filename);
  const code = fs.readFileSync(filePath, 'utf8');
  // Strip comments before checking for Arabic characters
  const strippedCode = code.replace(/\/\*[\s\S]*?\*\/|\/\/.*/g, '');
  if (arabicCharPattern.test(strippedCode)) {
    foundHardcodedArabicInUI = true;
    console.error(`Found hardcoded Arabic in ${filename}`);
  }
});

assert(!foundHardcodedArabicInUI, 'Test 37: Zero hardcoded Arabic text in all children UI components (uses i18n exclusively)');

// Test 38: GENDER_VALUES strictly matches 'MALE' | 'FEMALE'
assert(
  GENDER_VALUES.length === 2 && GENDER_VALUES.includes('MALE') && GENDER_VALUES.includes('FEMALE'),
  "Test 38: Technical gender contract is strictly 'MALE' | 'FEMALE'"
);

console.log('\n===============================================================');
console.log(`TEST SUMMARY: ${passedTests} PASSED, ${failedTests} FAILED`);
console.log('===============================================================');

if (failedTests > 0) {
  process.exit(1);
}
