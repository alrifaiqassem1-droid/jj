import fs from 'fs';
import path from 'path';
import {
  assignTeacherSchema,
  updateAssignmentRoleSchema,
} from '../src/modules/staff/staffValidation';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`  ✗ FAIL: ${message}`);
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`  ✓ PASS: ${message}`);
}

console.log('===============================================================');
console.log('PHASE 1 — VERTICAL SLICE 3: IMPLEMENTATION GATE 4 TEST SUITE');
console.log('Staff & Teacher Class Assignment — Invariants & Quality Verification');
console.log('===============================================================');

// -----------------------------------------------------------------------------
// Group 1: Validation Rules Execution Tests (Zod Contracts)
// -----------------------------------------------------------------------------
console.log('\n--- 1. Validation Rules Execution Tests ---');

// Test 1: Valid assignment input parses successfully
const validAssignment = {
  class_id: 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
  teacher_id: 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22',
  is_lead_teacher: true,
};
const parseResult1 = assignTeacherSchema.safeParse(validAssignment);
assert(parseResult1.success, 'Test 1: Valid assignment input parses successfully');

// Test 2: Default is_lead_teacher to false if omitted
const assignmentWithoutLead = {
  class_id: 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
  teacher_id: 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22',
};
const parseResult2 = assignTeacherSchema.safeParse(assignmentWithoutLead);
assert(
  parseResult2.success && parseResult2.data.is_lead_teacher === false,
  'Test 2: is_lead_teacher defaults to false when omitted'
);

// Test 3: Invalid class_id UUID rejected
const invalidClassUuid = {
  class_id: 'not-a-valid-uuid',
  teacher_id: 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22',
};
const parseResult3 = assignTeacherSchema.safeParse(invalidClassUuid);
assert(!parseResult3.success, 'Test 3: Malformed class_id UUID is rejected');

// Test 4: Invalid teacher_id UUID rejected
const invalidTeacherUuid = {
  class_id: 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
  teacher_id: '12345-invalid',
};
const parseResult4 = assignTeacherSchema.safeParse(invalidTeacherUuid);
assert(!parseResult4.success, 'Test 4: Malformed teacher_id UUID is rejected');

// Test 5: Valid update assignment role input parses
const validRoleUpdate = { is_lead_teacher: true };
const parseResult5 = updateAssignmentRoleSchema.safeParse(validRoleUpdate);
assert(parseResult5.success, 'Test 5: Valid boolean for updateAssignmentRole parses successfully');

// Test 6: Non-boolean update assignment role rejected
const invalidRoleUpdate = { is_lead_teacher: 'yes' };
const parseResult6 = updateAssignmentRoleSchema.safeParse(invalidRoleUpdate);
assert(!parseResult6.success, 'Test 6: Non-boolean updateAssignmentRole input is rejected');

// -----------------------------------------------------------------------------
// Group 2: Architectural & Security Invariant Tests
// -----------------------------------------------------------------------------
console.log('\n--- 2. Architectural & Security Invariants ---');

const staffServicePath = path.join(process.cwd(), 'src/modules/staff/staffService.ts');
assert(fs.existsSync(staffServicePath), 'Test 7: staffService.ts exists');
const staffServiceCode = fs.readFileSync(staffServicePath, 'utf8');

// Test 8: Zero physical delete on primary entities
const deletesClasses = /\.from\(['"]classes['"]\)\s*\.delete\(\)/.test(staffServiceCode);
const deletesMemberships = /\.from\(['"]kindergarten_memberships['"]\)\s*\.delete\(\)/.test(staffServiceCode);
const deletesProfiles = /\.from\(['"]user_profiles['"]\)\s*\.delete\(\)/.test(staffServiceCode);
assert(
  !deletesClasses && !deletesMemberships && !deletesProfiles,
  'Test 8: staffService.ts contains ZERO physical .delete() on classes, memberships, or user_profiles'
);

// Test 9: Zero client-side audit writes
const writesToAuditLogs = /audit_logs/i.test(staffServiceCode);
assert(!writesToAuditLogs, 'Test 9: staffService.ts does NOT perform direct client writes to audit_logs');

// Test 10: Teacher eligibility check verifies role = 'TEACHER', active, and non-deleted
const checksTeacherRole = /eq\(['"]role['"],\s*['"]TEACHER['"]\)/.test(staffServiceCode);
const checksTeacherActive = /eq\(['"]is_active['"],\s*true\)/.test(staffServiceCode);
const checksTeacherNonDeleted = /is\(['"]deleted_at['"],\s*null\)/.test(staffServiceCode);
assert(
  checksTeacherRole && checksTeacherActive && checksTeacherNonDeleted,
  'Test 10: assignTeacherToClass enforces active, non-deleted TEACHER role membership'
);

// Test 11: Cross-kindergarten tenant check
const hasCrossKindergartenCheck = /targetClass\.kindergarten_id\s*!==\s*kindergartenId/.test(staffServiceCode);
const hasCrossTenantErrorCode = /CROSS_KINDERGARTEN_ASSIGNMENT_DENIED/.test(staffServiceCode);
assert(
  hasCrossKindergartenCheck && hasCrossTenantErrorCode,
  'Test 11: assignTeacherToClass strictly blocks cross-kindergarten class assignment'
);

// Test 12: Duplicate assignment error mapping
const mapsDuplicateError = /DUPLICATE_ASSIGNMENT/.test(staffServiceCode) && /23505/.test(staffServiceCode);
assert(mapsDuplicateError, 'Test 12: PostgreSQL 23505 unique violation is mapped to DUPLICATE_ASSIGNMENT');

// Test 13: Permission denied error mapping
const mapsRlsError = /PERMISSION_DENIED_RLS/.test(staffServiceCode) && /42501/.test(staffServiceCode);
assert(mapsRlsError, 'Test 13: PostgreSQL 42501 RLS violation is mapped to PERMISSION_DENIED_RLS');

// -----------------------------------------------------------------------------
// Group 3: UI Components Presence & Export Integrity
// -----------------------------------------------------------------------------
console.log('\n--- 3. UI Components Presence & Export Integrity ---');

const staffComponentsDir = path.join(process.cwd(), 'src/modules/staff/components');
const expectedComponents = [
  'TeacherCardSkeleton.tsx',
  'TeacherCard.tsx',
  'TeachersToolbar.tsx',
  'AssignTeacherDrawer.tsx',
  'UnassignTeacherDialog.tsx',
];

for (const comp of expectedComponents) {
  const compPath = path.join(staffComponentsDir, comp);
  assert(fs.existsSync(compPath), `Test 14+: Component exists: ${comp}`);
}

const teachersViewPath = path.join(process.cwd(), 'src/modules/staff/TeachersView.tsx');
assert(fs.existsSync(teachersViewPath), 'Test 19: TeachersView.tsx exists at module root');

// Test 20: Zero physical delete on primary entities in UI components
for (const comp of expectedComponents) {
  const code = fs.readFileSync(path.join(staffComponentsDir, comp), 'utf8');
  assert(!/\.delete\(/.test(code), `Test 20+: Zero direct .delete() in UI component: ${comp}`);
}

// -----------------------------------------------------------------------------
// Group 4: Design System Semantics & Accessibility
// -----------------------------------------------------------------------------
console.log('\n--- 4. Design System Semantics & Accessibility ---');

const drawerCode = fs.readFileSync(path.join(staffComponentsDir, 'AssignTeacherDrawer.tsx'), 'utf8');
const dialogCode = fs.readFileSync(path.join(staffComponentsDir, 'UnassignTeacherDialog.tsx'), 'utf8');

// Test 25: Drawer uses logical inline-end positioning and direction-aware animation
const hasInlineEndDrawer = /inset-inline-end-0/i.test(drawerCode);
const hasLogicalAnimation = drawerCode.includes("dir === 'rtl' ? 'slide-in-from-left' : 'slide-in-from-right'");
assert(
  hasInlineEndDrawer && hasLogicalAnimation,
  'Test 25: AssignTeacherDrawer adheres to logical inline-end positioning & direction-aware animation'
);

// Test 26: UnassignTeacherDialog uses alertdialog semantics
const hasAlertDialogRole = /role="alertdialog"/i.test(dialogCode);
const hasAriaModal = /aria-modal="true"/i.test(dialogCode);
assert(
  hasAlertDialogRole && hasAriaModal,
  'Test 26: UnassignTeacherDialog adheres to alertdialog accessibility semantics'
);

// -----------------------------------------------------------------------------
// Group 5: Admin Shell Integration
// -----------------------------------------------------------------------------
console.log('\n--- 5. Admin Shell Integration ---');

const adminShellCode = fs.readFileSync(path.join(process.cwd(), 'src/modules/admin/components/AdminShell.tsx'), 'utf8');
const rendersTeachersView = /<TeachersView\s*\/>/.test(adminShellCode);
assert(rendersTeachersView, 'Test 27: AdminShell renders <TeachersView /> for teachers tab');

// -----------------------------------------------------------------------------
// Group 6: i18n Dictionary Integrity
// -----------------------------------------------------------------------------
console.log('\n--- 6. i18n Dictionary Integrity ---');

const typesPath = path.join(process.cwd(), 'src/lib/i18n/types.ts');
const arPath = path.join(process.cwd(), 'src/lib/i18n/ar.ts');
const enPath = path.join(process.cwd(), 'src/lib/i18n/en.ts');

const typesCode = fs.readFileSync(typesPath, 'utf8');
const arCode = fs.readFileSync(arPath, 'utf8');
const enCode = fs.readFileSync(enPath, 'utf8');

assert(/teachers:\s*\{/.test(typesCode), 'Test 28: types.ts defines teachers dictionary');
assert(/teachers:\s*\{/.test(arCode), 'Test 29: ar.ts includes teachers dictionary');
assert(/teachers:\s*\{/.test(enCode), 'Test 30: en.ts includes teachers dictionary');

// Test 31: Zero hardcoded Arabic in staff UI components
for (const comp of expectedComponents) {
  const code = fs.readFileSync(path.join(staffComponentsDir, comp), 'utf8');
  // Strip out comments
  const cleanCode = code.replace(/\/\*[\s\S]*?\*\/|\/\/.*/g, '');
  // Search for literal Arabic strings in JSX
  const hasHardcodedArabic = /[\u0600-\u06FF]/.test(cleanCode);
  assert(!hasHardcodedArabic, `Test 31+: Zero hardcoded Arabic text in ${comp} (uses i18n)`);
}

const teachersViewCode = fs.readFileSync(teachersViewPath, 'utf8');
const cleanTeachersView = teachersViewCode.replace(/\/\*[\s\S]*?\*\/|\/\/.*/g, '');
assert(!/[\u0600-\u06FF]/.test(cleanTeachersView), 'Test 36: Zero hardcoded Arabic text in TeachersView.tsx');

console.log('===============================================================');
console.log('TEST SUMMARY: ALL GATE 4 INVARIANT TESTS PASSED');
console.log('===============================================================');
