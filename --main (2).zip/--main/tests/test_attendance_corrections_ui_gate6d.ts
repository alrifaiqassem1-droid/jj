import fs from 'fs';
import path from 'path';
import { PGlite } from '@electric-sql/pglite';
import { attendanceCorrectionSchema } from '../src/modules/attendance/attendanceValidation';

let passedCount = 0;
let failedCount = 0;

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`  ✗ FAIL: ${message}`);
    failedCount++;
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`  ✓ PASS: ${message}`);
  passedCount++;
}

async function runGate6dTestSuite() {
  console.log('===============================================================');
  console.log('GATE 6D TEST SUITE — CORRECTIONS LEDGER UI & SECURITY VERIFICATION');
  console.log('Target: CorrectionDrawer, i18n, Invariants, and PGlite Engine');
  console.log('===============================================================');

  const rootDir = process.cwd();
  const drawerPath = path.join(rootDir, 'src/modules/attendance/components/CorrectionDrawer.tsx');
  const rowPath = path.join(rootDir, 'src/modules/attendance/components/AttendanceRow.tsx');
  const listPath = path.join(rootDir, 'src/modules/attendance/components/AttendanceList.tsx');
  const viewPath = path.join(rootDir, 'src/modules/attendance/components/AttendanceView.tsx');
  const typesPath = path.join(rootDir, 'src/lib/i18n/types.ts');
  const arPath = path.join(rootDir, 'src/lib/i18n/ar.ts');
  const enPath = path.join(rootDir, 'src/lib/i18n/en.ts');
  const servicePath = path.join(rootDir, 'src/modules/attendance/attendanceService.ts');

  // --- 1. Component Presence & Export Integrity ---
  console.log('\n--- 1. Component Presence & Export Integrity ---');
  assert(fs.existsSync(drawerPath), 'Test 1: CorrectionDrawer.tsx exists in attendance components');
  const drawerContent = fs.readFileSync(drawerPath, 'utf-8');
  assert(
    drawerContent.includes('export const CorrectionDrawer'),
    'Test 2: CorrectionDrawer component is properly exported'
  );

  // --- 2. i18n Dictionary Integrity & Zero Hardcoded Strings ---
  console.log('\n--- 2. i18n Dictionary Integrity & Zero Hardcoded Strings ---');
  const typesContent = fs.readFileSync(typesPath, 'utf-8');
  const arContent = fs.readFileSync(arPath, 'utf-8');
  const enContent = fs.readFileSync(enPath, 'utf-8');

  assert(typesContent.includes('corrections: {'), 'Test 3: types.ts defines corrections namespace');
  assert(arContent.includes('corrections: {'), 'Test 4: ar.ts includes corrections dictionary');
  assert(enContent.includes('corrections: {'), 'Test 5: en.ts includes corrections dictionary');

  // Extract keys and ensure 1:1 match
  const requiredKeys = [
    'title',
    'description',
    'actionCorrection',
    'currentStatusLabel',
    'newStatusLabel',
    'selectStatusPlaceholder',
    'reasonLabel',
    'reasonPlaceholder',
    'reasonMinCharsHint',
    'reasonTooShort',
    'reasonTooLong',
    'sameStatusError',
    'characterCount',
    'historyTitle',
    'noHistory',
    'historyLoading',
    'previousStatusLabel',
    'correctedStatusLabel',
    'correctedByLabel',
    'correctedAtLabel',
    'sourceLabel',
    'submitCorrection',
    'submittingCorrection',
    'cancel',
    'closeDrawerAria',
    'correctionSuccess',
    'correctionError',
    'unrecordedError',
    'immutableNotice',
    'VALIDATION_FAILED',
    'NOT_AUTHORIZED',
    'ATTENDANCE_NOT_FOUND',
    'CORRECTION_REASON_TOO_SHORT',
    'CORRECTION_STATUS_UNCHANGED',
    'CORRECTION_IMMUTABLE',
    'STAFF_UPDATE_FORBIDDEN',
    'SERVICE_NETWORK_ERROR',
  ];

  for (const k of requiredKeys) {
    assert(typesContent.includes(`${k}: string`), `Test 6+: types.ts contains key "${k}"`);
    assert(arContent.includes(`${k}:`), `Test 6+: ar.ts contains key "${k}"`);
    assert(enContent.includes(`${k}:`), `Test 6+: en.ts contains key "${k}"`);
  }

  // Verify Zero Hardcoded Arabic text in CorrectionDrawer.tsx
  const arabicRegex = /[\u0600-\u06FF]/;
  const codeWithoutComments = drawerContent.replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//gm, '');
  assert(
    !arabicRegex.test(codeWithoutComments),
    'Test 7: Zero hardcoded Arabic strings in CorrectionDrawer.tsx (uses i18n exclusively)'
  );

  // --- 3. Validation & Business Rule Compliance ---
  console.log('\n--- 3. Validation & Business Rule Compliance ---');
  const kgId = 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11';
  const childId = 'c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33';
  const attId = 'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380a44';

  const shortReasonInput = {
    attendance_id: attId,
    kindergarten_id: kgId,
    child_id: childId,
    new_status: 'PRESENT' as const,
    reason: '   قصير   ', // 4 characters after trim
  };
  const valShort = attendanceCorrectionSchema.safeParse(shortReasonInput);
  assert(!valShort.success, 'Test 8: Reason with < 10 characters after trimming is rejected');

  const unrecordedTargetInput = {
    attendance_id: attId,
    kindergarten_id: kgId,
    child_id: childId,
    new_status: 'UNRECORDED' as const,
    reason: 'محاولة تعديل السجل إلى غير مرصود',
  };
  const valUnrec = attendanceCorrectionSchema.safeParse(unrecordedTargetInput);
  assert(!valUnrec.success, 'Test 9: Setting new_status to UNRECORDED is strictly rejected');

  const validCorrectionInput = {
    attendance_id: attId,
    kindergarten_id: kgId,
    child_id: childId,
    new_status: 'PRESENT' as const,
    reason: 'حضور متأخر بإذن مسبق وموثق من الإدارة',
  };
  const valValid = attendanceCorrectionSchema.safeParse(validCorrectionInput);
  assert(valValid.success, 'Test 10: Valid correction input passes Zod validation');

  // --- 4. Architectural & Security Invariants ---
  console.log('\n--- 4. Architectural & Security Invariants ---');
  assert(!drawerContent.includes('.delete('), 'Test 11: CorrectionDrawer contains zero .delete() calls');
  const rowContent = fs.readFileSync(rowPath, 'utf-8');
  assert(!rowContent.includes('.delete('), 'Test 12: AttendanceRow contains zero .delete() calls');

  assert(!drawerContent.includes("from('audit_logs')"), 'Test 13: CorrectionDrawer does not write to audit_logs');
  assert(!drawerContent.includes('from("audit_logs")'), 'Test 14: CorrectionDrawer has zero audit_logs references');

  assert(!drawerContent.includes("supabase.from("), 'Test 15: CorrectionDrawer contains zero direct supabase.from() calls');
  assert(
    drawerContent.includes('recordCorrection') && drawerContent.includes('getAttendanceCorrections'),
    'Test 16: CorrectionDrawer invokes service layer recordCorrection & getAttendanceCorrections'
  );

  assert(
    !drawerContent.includes('deleteCorrection') &&
    !drawerContent.includes('updateCorrection') &&
    !drawerContent.includes('onEditHistory'),
    'Test 17: Historical corrections ledger in UI is strictly read-only (no edit/delete)'
  );

  const viewContent = fs.readFileSync(viewPath, 'utf-8');
  assert(
    viewContent.includes('handleCorrectionSuccess') &&
    viewContent.includes('onCorrectionSuccess'),
    'Test 18: AttendanceView executes pessimistic update only upon server confirmation'
  );

  assert(
    rowContent.includes("!item.id.startsWith('unrecorded-')"),
    'Test 19: AttendanceRow renders correction action only for recorded attendance items'
  );
  assert(
    viewContent.includes("child.id.startsWith('unrecorded-')"),
    'Test 20: AttendanceView blocks opening correction drawer for unrecorded items'
  );

  // --- 5. Accessibility, RTL & Design System ---
  console.log('\n--- 5. Accessibility, RTL & Design System ---');
  assert(drawerContent.includes('role="dialog"'), 'Test 21: Semantic role="dialog" is present');
  assert(drawerContent.includes('aria-modal="true"'), 'Test 22: aria-modal="true" is present');
  assert(drawerContent.includes('aria-labelledby="correction-drawer-title"'), 'Test 23: aria-labelledby is properly bound');
  assert(drawerContent.includes('aria-describedby="correction-drawer-subtitle"'), 'Test 24: aria-describedby is properly bound');
  assert(drawerContent.includes("e.key === 'Escape'"), 'Test 25: Escape key closes the drawer');
  assert(drawerContent.includes("e.key === 'Tab'"), 'Test 26: Real Tab/Shift+Tab focus trap is implemented');
  assert(
    drawerContent.includes('previousFocusRef.current.focus()') || drawerContent.includes('previousFocusRef.current'),
    'Test 27: Focus restoration to triggering element is implemented'
  );
  assert(drawerContent.includes('end-0'), 'Test 28: RTL logical positioning uses end-0');
  assert(
    !drawerContent.includes('left-0') && !drawerContent.includes('right-0'),
    'Test 29: No physical left-0 / right-0 positioning in drawer layout'
  );
  assert(drawerContent.includes('min-h-[44px]'), 'Test 30: Touch targets >= 44px on interactive elements');

  // --- 6. Actual PostgreSQL Engine RLS & Trigger Enforcement ---
  console.log('\n--- 6. Actual PostgreSQL Engine RLS & Trigger Enforcement ---');
  const db = new PGlite();

  // Setup auth schema & functions
  await db.exec(`
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (id UUID PRIMARY KEY, email TEXT UNIQUE);
    CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID AS $$
      SELECT NULLIF(current_setting('request.jwt.claims', true)::jsonb->>'sub', '')::uuid;
    $$ LANGUAGE sql STABLE;
    CREATE OR REPLACE FUNCTION auth.jwt() RETURNS JSONB AS $$
      SELECT COALESCE(current_setting('request.jwt.claims', true)::jsonb, '{}'::jsonb);
    $$ LANGUAGE sql STABLE;
    CREATE ROLE authenticated NOLOGIN;
    CREATE ROLE anon NOLOGIN;
    GRANT USAGE ON SCHEMA public, auth TO authenticated, anon;
  `);

  // Execute canonical schema migrations
  await db.exec(fs.readFileSync('supabase/migrations/20260927000001_initial_schema.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000002_rls_policies.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000003_invitations_fsm.sql', 'utf-8'));

  // Grant privileges to authenticated role
  await db.exec(`
    GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
  `);

  // Fixtures
  const kId = '11111111-1111-1111-1111-111111111111';
  const classId = '22222222-2222-2222-2222-222222222222';
  const child1Id = '33333333-3333-3333-3333-333333333333';
  const adminUid = '44444444-4444-4444-4444-444444444444';
  const teacherUid = '55555555-5555-5555-5555-555555555555';
  const staffUid = '66666666-6666-6666-6666-666666666666';
  const parentUid = '77777777-7777-7777-7777-777777777777';

  await db.exec(`
    INSERT INTO kindergartens (id, name, license_number, contact_email, contact_phone, address, timezone)
    VALUES ('${kId}', 'روضة الأدهم', 'LIC-6D-001', 'info@aladham.sa', '0500000001', 'Riyadh', 'Asia/Riyadh');

    INSERT INTO auth.users (id, email) VALUES
      ('${adminUid}', 'admin@rawdaty.sa'),
      ('${teacherUid}', 'teacher@rawdaty.sa'),
      ('${staffUid}', 'staff@rawdaty.sa'),
      ('${parentUid}', 'parent@rawdaty.sa');

    INSERT INTO user_profiles (id, phone_number, full_name) VALUES
      ('${adminUid}', '+966500000001', 'مدير الروضة'),
      ('${teacherUid}', '+966500000002', 'معلم الفصل'),
      ('${staffUid}', '+966500000003', 'موظف استقبال'),
      ('${parentUid}', '+966500000004', 'ولي الأمر');

    INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role, permissions, is_active) VALUES
      ('${kId}', '${adminUid}', 'ADMIN', '{}', TRUE),
      ('${kId}', '${teacherUid}', 'TEACHER', '{}', TRUE),
      ('${kId}', '${staffUid}', 'STAFF', '{"RECORD_ATTENDANCE", "VIEW_ATTENDANCE"}', TRUE),
      ('${kId}', '${parentUid}', 'PARENT', '{}', TRUE);

    INSERT INTO classes (id, kindergarten_id, name, grade_level, capacity, academic_year)
    VALUES ('${classId}', '${kId}', 'فصل النجوم', 'KG1', 20, '2026-2027');

    INSERT INTO teacher_class_assignments (kindergarten_id, class_id, teacher_id)
    VALUES ('${kId}', '${classId}', '${teacherUid}');

    INSERT INTO children (id, kindergarten_id, class_id, first_name, last_name, dob, gender, emergency_contact_name, emergency_contact_phone, enrollment_date)
    VALUES ('${child1Id}', '${kId}', '${classId}', 'عمر', 'الغامدي', '2022-04-10', 'MALE', 'سالم الغامدي', '0500000099', '2026-09-01');
  `);

  const attRowId = '88888888-8888-8888-8888-888888888888';
  await db.exec(`
    INSERT INTO attendance (id, client_attendance_uuid, kindergarten_id, class_id, child_id, date, status, recorded_by)
    VALUES ('${attRowId}', gen_random_uuid(), '${kId}', '${classId}', '${child1Id}', '2026-10-05', 'ABSENT_UNEXCUSED', '${teacherUid}');
  `);

  // Helper to run query as a specific user with RLS active inside an isolated transaction
  async function runAs(userId: string, roleName: string, sqlQuery: string) {
    return db.transaction(async (tx) => {
      await tx.exec(`
        SET LOCAL ROLE authenticated;
        SET LOCAL "request.jwt.claims" = '{"sub": "${userId}", "role": "authenticated"}';
      `);
      return tx.query<Record<string, any>>(sqlQuery);
    });
  }

  // Test 31: Teacher can insert into attendance_corrections for assigned class
  const corrId1 = '99999999-9999-9999-9999-999999999991';
  await runAs(
    teacherUid,
    'TEACHER',
    `INSERT INTO attendance_corrections (id, attendance_id, kindergarten_id, child_id, previous_status, new_status, corrected_by_user_id, reason, client_timestamp)
     VALUES ('${corrId1}', '${attRowId}', '${kId}', '${child1Id}', 'ABSENT_UNEXCUSED', 'PRESENT', '${teacherUid}', 'حضور متأخر بعذر رسمي من ولي الأمر', NOW());`
  );
  const qCorr1 = await runAs(teacherUid, 'TEACHER', `SELECT reason FROM attendance_corrections WHERE id = '${corrId1}';`);
  assert(qCorr1.rows.length === 1, 'Test 31: Assigned teacher successfully inserts correction in ledger');

  // Test 32: Staff is blocked from inserting into attendance_corrections by RLS
  let staffInsertFailed = false;
  try {
    const qStaff = await runAs(
      staffUid,
      'STAFF',
      `INSERT INTO attendance_corrections (attendance_id, kindergarten_id, child_id, previous_status, new_status, corrected_by_user_id, reason, client_timestamp)
       VALUES ('${attRowId}', '${kId}', '${child1Id}', 'ABSENT_UNEXCUSED', 'PRESENT', '${staffUid}', 'محاولة تصحيح من موظف استقبال', NOW());`
    );
    staffInsertFailed = qStaff.rows.length === 0;
  } catch (err: unknown) {
    staffInsertFailed = true;
  }
  assert(staffInsertFailed, 'Test 32: Staff is strictly blocked from inserting corrections by RLS');

  // Test 33: Parent is blocked from reading attendance_corrections
  const qParent = await runAs(parentUid, 'PARENT', `SELECT * FROM attendance_corrections WHERE id = '${corrId1}';`);
  assert(qParent.rows.length === 0, 'Test 33: Parent receives 0 rows when attempting to select from correction ledger');

  // Test 34: Trigger trg_freeze_attendance_corrections blocks any update with TAMPER_ALERT
  let triggerUpdateBlocked = false;
  try {
    await db.exec(`UPDATE attendance_corrections SET reason = 'محاولة تعديل السجل' WHERE id = '${corrId1}';`);
  } catch (err: unknown) {
    triggerUpdateBlocked = String(err).includes('TAMPER_ALERT');
  }
  assert(triggerUpdateBlocked, 'Test 34: Trigger trg_freeze_attendance_corrections strictly blocks UPDATE with TAMPER_ALERT');

  // Test 35: Gate 6A files remain completely untouched
  const gate6aServiceLines = fs.readFileSync(servicePath, 'utf-8').split('\n').length;
  assert(gate6aServiceLines === 684, 'Test 35: attendanceService.ts is untouched (exactly 684 lines)');

  console.log('\n===============================================================');
  console.log(`GATE 6D TEST SUITE SUMMARY: ${passedCount} passed, ${failedCount} failed`);
  console.log('===============================================================');

  if (failedCount > 0) {
    process.exit(1);
  }
}

runGate6dTestSuite().catch((err) => {
  console.error('Fatal test suite failure:', err);
  process.exit(1);
});
