import fs from 'fs';
import path from 'path';
import {
  createClassSchema,
  updateClassSchema,
} from '../src/modules/classes/classValidation';
import {
  createClass,
  updateClass,
  archiveClass,
  getActiveClasses,
} from '../src/modules/classes/classesService';

/**
 * Implementation Gate 1: Class Management & Validation Test Suite
 */

let passedTests = 0;
let failedTests = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    passedTests++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    failedTests++;
    console.error(`  ✗ FAIL: ${testName}${detail ? ` - ${detail}` : ''}`);
  }
}

console.log('===============================================================');
console.log('PHASE 1 — VERTICAL SLICE 1: IMPLEMENTATION GATE 1 TEST SUITE');
console.log('===============================================================\n');

// -----------------------------------------------------------------------------
// Group 1: Validation Rules (Zod Schemas)
// -----------------------------------------------------------------------------
console.log('--- 1. Validation Rules Execution Tests ---');

// Test 1: Valid class input
const validPayload = {
  name: 'شعبة الياسمين',
  grade_level: 'KG1',
  room_number: 'القاعة 101',
  capacity: 22,
  academic_year: '2026-2027',
};
const res1 = createClassSchema.safeParse(validPayload);
assert(res1.success === true, 'Test 1: Valid class input parses successfully');

// Test 2: Empty name
const res2 = createClassSchema.safeParse({ ...validPayload, name: '   ' });
assert(
  res2.success === false && res2.error.issues[0].message.includes('حرفين على الأقل'),
  'Test 2: Empty or whitespace-only name is rejected'
);

// Test 3: Name < 2 characters
const res3 = createClassSchema.safeParse({ ...validPayload, name: 'أ' });
assert(
  res3.success === false && res3.error.issues[0].message.includes('حرفين على الأقل'),
  'Test 3: Name with less than 2 characters is rejected'
);

// Test 4: Name > 100 characters
const longName = 'ش'.repeat(101);
const res4 = createClassSchema.safeParse({ ...validPayload, name: longName });
assert(
  res4.success === false && res4.error.issues[0].message.includes('100 حرف'),
  'Test 4: Name exceeding 100 characters is rejected'
);

// Test 5: Invalid grade_level
const res5 = createClassSchema.safeParse({ ...validPayload, grade_level: 'GRADE_1' });
assert(
  res5.success === false && res5.error.issues[0].message.includes('المرحلة الدراسية'),
  'Test 5: Invalid grade_level (not in KG1, KG2, KG3) is rejected'
);

// Test 6: Room number > 50 characters
const longRoom = 'R'.repeat(51);
const res6 = createClassSchema.safeParse({ ...validPayload, room_number: longRoom });
assert(
  res6.success === false && res6.error.issues[0].message.includes('50 حرفاً'),
  'Test 6: Room number exceeding 50 characters is rejected'
);

// Test 7: Capacity < 1
const res7 = createClassSchema.safeParse({ ...validPayload, capacity: 0 });
assert(
  res7.success === false && res7.error.issues[0].message.includes('طفل واحد'),
  'Test 7: Capacity less than 1 is rejected'
);

// Test 8: Capacity > 40 (Application-level limit)
const res8 = createClassSchema.safeParse({ ...validPayload, capacity: 41 });
assert(
  res8.success === false && res8.error.issues[0].message.includes('40 طفلاً'),
  'Test 8: Capacity exceeding 40 is rejected by business rule'
);

// Test 9: Non-integer capacity
const res9 = createClassSchema.safeParse({ ...validPayload, capacity: 20.5 });
assert(
  res9.success === false && res9.error.issues[0].message.includes('عدداً صحيحاً'),
  'Test 9: Non-integer floating point capacity is rejected'
);

// Test 10: Invalid academic_year format
const res10 = createClassSchema.safeParse({ ...validPayload, academic_year: '2026/2027' });
const res10b = createClassSchema.safeParse({ ...validPayload, academic_year: '2026' });
assert(
  res10.success === false && res10b.success === false,
  'Test 10: Non-compliant academic_year format is rejected'
);

// Test 11: Valid academic_year format
const res11 = createClassSchema.safeParse({ ...validPayload, academic_year: '2026-2027' });
assert(
  res11.success === true && res11.data.academic_year === '2026-2027',
  'Test 11: Valid academic_year (YYYY-YYYY) is accepted'
);

// -----------------------------------------------------------------------------
// Group 2: Error Mapping & Duplicate Constraint Handling
// -----------------------------------------------------------------------------
console.log('\n--- 2. Error Mapping & Constraint Handling Tests ---');

// Test 12: Duplicate constraint handling (PostgreSQL 23505)
// We test that validation rejects invalid payloads before hitting DB,
// and when given an invalid payload, createClass returns a friendly validation error.
async function testServiceValidationHandling() {
  const result = await createClass('dummy-kindergarten-id', { ...validPayload, name: '' });
  assert(
    result.error !== null && result.errorCode === 'VALIDATION_FAILED',
    'Test 12: Service intercepts validation failures with domain error code'
  );
}

// -----------------------------------------------------------------------------
// Group 3: Architecture & Security Invariants Verification
// -----------------------------------------------------------------------------
console.log('\n--- 3. Architectural & Security Invariant Tests ---');

// Test 13: Archive uses UPDATE/soft-delete semantics
// Inspect implementation of archiveClass
async function testArchiveSemantics() {
  const serviceFilePath = path.join(process.cwd(), 'src/modules/classes/classesService.ts');
  const serviceCode = fs.readFileSync(serviceFilePath, 'utf8');

  const hasSoftDeleteUpdate =
    serviceCode.includes('deleted_at: new Date().toISOString()') &&
    serviceCode.includes(".update({") &&
    serviceCode.includes("deleted_at: new Date().toISOString()");

  assert(
    hasSoftDeleteUpdate,
    'Test 13: archiveClass uses UPDATE soft-delete semantics exclusively'
  );

  // Test 14: Absolute absence of `.delete()` in Classes Service
  // Regex to detect any invocation of `.delete(`
  const hasDeleteCall = /\.delete\s*\(/i.test(serviceCode);
  assert(
    !hasDeleteCall,
    'Test 14: classesService.ts contains ZERO physical `.delete()` calls'
  );

  // Test 15: No direct insert to `audit_logs`
  const hasAuditLogsWrite =
    serviceCode.includes("from('audit_logs')") ||
    serviceCode.includes('from("audit_logs")');
  assert(
    !hasAuditLogsWrite,
    'Test 15: classesService.ts does NOT perform direct client writes to audit_logs'
  );

  // Test 16: Zero-Trust Tenant Context
  // Verify kindergarten_id is used only as selector and not as proof of authorization
  const hasSelectorUsage =
    serviceCode.includes("kindergarten_id: kindergartenId") &&
    serviceCode.includes(".eq('kindergarten_id', kindergartenId)");
  assert(
    hasSelectorUsage,
    'Test 16: kindergarten_id is treated strictly as query context, RLS is final authority'
  );
}

async function runAll() {
  await testServiceValidationHandling();
  await testArchiveSemantics();

  console.log('\n===============================================================');
  console.log(`TEST SUMMARY: ${passedTests} PASSED, ${failedTests} FAILED`);
  console.log('===============================================================');

  if (failedTests > 0) {
    process.exit(1);
  }
}

runAll().catch((err) => {
  console.error('Test execution failed:', err);
  process.exit(1);
});
