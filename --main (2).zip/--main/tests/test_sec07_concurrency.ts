import { PGlite } from '@electric-sql/pglite';
import fs from 'fs';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    passed++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    failed++;
    console.error(`  ✗ FAIL: ${testName}${detail ? ` - ${detail}` : ''}`);
    throw new Error(`Assertion failed: ${testName}`);
  }
}

async function runSec07ConcurrencySuite() {
  console.log('===============================================================');
  console.log('SEC-07 CONCURRENCY & MULTI-REQUEST AUDIT & RATE LIMITING SUITE');
  console.log('Engine: PostgreSQL 18.3 (PGlite Clean Isolated Sandbox)');
  console.log('===============================================================\n');

  const db = new PGlite();

  // 1. Auth Infrastructure
  await db.exec(`
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (
      id UUID PRIMARY KEY,
      email TEXT UNIQUE,
      phone TEXT,
      raw_user_meta_data JSONB,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID AS $$
      SELECT NULLIF(current_setting('request.jwt.claims', true)::jsonb->>'sub', '')::uuid;
    $$ LANGUAGE sql STABLE;
    CREATE OR REPLACE FUNCTION auth.jwt() RETURNS JSONB AS $$
      SELECT COALESCE(current_setting('request.jwt.claims', true)::jsonb, '{}'::jsonb);
    $$ LANGUAGE sql STABLE;

    CREATE ROLE authenticated NOLOGIN;
    CREATE ROLE anon NOLOGIN;
    GRANT USAGE ON SCHEMA public, auth TO authenticated, anon;
  `);

  // 2. Load Migrations 1 to 8 in sequential order
  console.log('--- 1. Applying Canonical Migrations (00001 to 00008) ---');
  await db.exec(fs.readFileSync('supabase/migrations/20260927000001_initial_schema.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000002_rls_policies.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000003_invitations_fsm.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000004_user_profile_provisioning.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000005_super_admin_support_sessions.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000006_storage_security_hardening.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000007_super_admin_privilege_hardening.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000008_health_profile_lifecycle_and_audit.sql', 'utf-8'));
  console.log('  ✓ All 8 migrations applied sequentially without error.\n');

  // 3. Seed Fixtures
  const k1 = '11111111-1111-1111-1111-111111111111';
  const c1 = 'cccc1111-cccc-cccc-cccc-cccccccccccc';
  const c2 = 'cccc2222-cccc-cccc-cccc-cccccccccccc';
  const adminId = 'ffff0001-0000-0000-0000-000000000001';
  const superAdminId = 'ffff0007-0000-0000-0000-000000000007';
  const attackerId = 'ffff0099-0000-0000-0000-000000000099';

  await db.exec(`
    INSERT INTO auth.users (id, email) VALUES
      ('${adminId}', 'admin@test.com'),
      ('${superAdminId}', 'superadmin@test.com'),
      ('${attackerId}', 'attacker@test.com')
    ON CONFLICT (id) DO NOTHING;

    INSERT INTO kindergartens (id, name, license_number, contact_email, contact_phone, address)
    VALUES ('${k1}', 'Kindergarten Alpha', 'LIC-CONCUR-1', 'kg1@concur.com', '0500000001', 'Riyadh 1');

    INSERT INTO classes (id, kindergarten_id, name, grade_level)
    VALUES ('aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '${k1}', 'Class 1A', 'KG1');

    INSERT INTO user_profiles (id, full_name, phone_number)
    VALUES 
      ('${adminId}', 'Director Alpha', '0511111199'),
      ('${superAdminId}', 'Super Admin Operative', '0577777799'),
      ('${attackerId}', 'Unauthorized Probe Actor', '0599999999')
    ON CONFLICT (id) DO UPDATE SET full_name = EXCLUDED.full_name, phone_number = EXCLUDED.phone_number;

    INSERT INTO platform_super_admins (user_id)
    VALUES ('${superAdminId}');

    INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role, permissions)
    VALUES 
      ('${k1}', '${adminId}', 'ADMIN', '{}'),
      ('${k1}', '${attackerId}', 'STAFF', '{}');

    INSERT INTO children (id, kindergarten_id, class_id, first_name, last_name, dob, gender, emergency_contact_name, emergency_contact_phone)
    VALUES 
      ('${c1}', '${k1}', 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Child A', 'FamA', '2022-01-01', 'MALE', 'Contact A', '0501111111'),
      ('${c2}', '${k1}', 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Child B', 'FamB', '2022-02-02', 'FEMALE', 'Contact B', '0502222222');

    INSERT INTO child_health_profiles (kindergarten_id, child_id, blood_type, allergies, has_epipen)
    VALUES 
      ('${k1}', '${c1}', 'O+', ARRAY['Peanuts'], TRUE),
      ('${k1}', '${c2}', 'A+', ARRAY['Dairy'], FALSE);
  `);

  // ============================================================================
  // TEST SCENARIO 1: ATOMIC EMERGENCY NOTIFICATION DEDUPLICATION UNDER CONCURRENCY
  // ============================================================================
  console.log('--- TEST SCENARIO 1: Emergency Notification Atomic Deduplication ---');
  
  // Initiate emergency support session
  await db.query("SELECT set_config('request.jwt.claims', $1, false);", [JSON.stringify({ sub: superAdminId })]);
  const sessionRes = await db.query(`
    SELECT rpc_initiate_support_session(
      '${k1}',
      'Emergency health incident investigation requiring child record inspections',
      30,
      'CHILD_HEALTH_EMERGENCY'
    ) AS res;
  `);
  const sessionId = (sessionRes.rows[0] as { res: { id: string } }).res.id;
  assert(sessionId !== undefined, 'Support session successfully initiated with CHILD_HEALTH_EMERGENCY scope');

  // Simulate two concurrent health reads under the same support session
  const readQuery1 = `SELECT rpc_get_child_health_profile('${c1}', 'Emergency check child 1') as res;`;
  const readQuery2 = `SELECT rpc_get_child_health_profile('${c2}', 'Emergency check child 2') as res;`;

  const [res1, res2] = await Promise.all([
    db.query(readQuery1),
    db.query(readQuery2),
  ]);

  const row1 = res1.rows[0] as { res: { success: boolean } };
  const row2 = res2.rows[0] as { res: { success: boolean } };
  assert(row1.res.success === true, 'Read 1 under emergency session succeeded');
  assert(row2.res.success === true, 'Read 2 under emergency session succeeded');

  // Verify notifications table: Exactly ONE notification must exist for this support session
  const notifCountRes = await db.query(`
    SELECT count(*) FROM notifications 
    WHERE metadata->>'support_session_id' = '${sessionId}' AND priority = 'CRITICAL';
  `);
  const notifCount = Number((notifCountRes.rows[0] as { count: string | number }).count);
  assert(notifCount === 1, `Atomic Deduplication Verified: Exactly 1 notification created (got ${notifCount})`);

  // Verify audit logs: Both reads were logged independently
  const auditReadsRes = await db.query(`
    SELECT count(*) FROM audit_logs 
    WHERE request_session_id = '${sessionId}' AND action = 'CHILD_HEALTH_INFO_VIEWED';
  `);
  const auditReadsCount = Number((auditReadsRes.rows[0] as { count: string | number }).count);
  assert(auditReadsCount === 2, `Both independent health reads were recorded in audit_logs (got ${auditReadsCount})`);

  // ============================================================================
  // TEST SCENARIO 2: 15-CONCURRENT PROBES RATE LIMITING & AUDIT INTEGRITY
  // ============================================================================
  console.log('\n--- TEST SCENARIO 2: 15-Concurrent Probes Rate Limiting & Audit Integrity ---');
  await db.query("SELECT set_config('request.jwt.claims', $1, false);", [JSON.stringify({ sub: attackerId })]);

  // Launch 15 concurrent unauthorized health read probes
  const probePromises = Array.from({ length: 15 }, (_, i) => 
    db.query(`SELECT rpc_get_child_health_profile('${c1}', 'Rogue probe attempt ${i + 1}') as res;`)
  );
  const probeResults = await Promise.all(probePromises);

  let deniedWithAuditCount = 0;
  let rateLimitedCount = 0;

  for (const r of probeResults) {
    const data = (r.rows[0] as { res: { error_code?: string; audit_logged?: boolean } }).res;
    if (data.error_code === 'ACCESS_DENIED' && data.audit_logged === true) {
      deniedWithAuditCount++;
    } else if (data.error_code === 'RATE_LIMIT_EXCEEDED' && data.audit_logged === false) {
      rateLimitedCount++;
    }
  }

  console.log(`  Probe Results: ${deniedWithAuditCount} ACCESS_DENIED (audit logged), ${rateLimitedCount} RATE_LIMIT_EXCEEDED (unlogged circuit breaker)`);
  assert(deniedWithAuditCount === 10, `Exactly 10 unauthorized requests recorded audit logs before limit (got ${deniedWithAuditCount})`);
  assert(rateLimitedCount === 5, `Remaining 5 requests were rate limited without consuming audit chain (got ${rateLimitedCount})`);

  // Verify audit logs row count for attacker
  const attackerLogsRes = await db.query(`
    SELECT id, previous_log_hash, current_log_hash 
    FROM audit_logs 
    WHERE actor_id = '${attackerId}' AND action = 'CHILD_HEALTH_INFO_ACCESS_DENIED'
    ORDER BY created_at ASC, id ASC;
  `);
  interface AuditLogRow {
    id: string;
    previous_log_hash: string;
    current_log_hash: string;
  }
  const attackerLogs = attackerLogsRes.rows as AuditLogRow[];
  assert(attackerLogs.length === 10, `Database contains exactly 10 audit rows for attacker (got ${attackerLogs.length})`);

  // Verify Hash Chain Integrity of the 10 denial logs
  let chainIntact = true;
  for (let i = 1; i < attackerLogs.length; i++) {
    const prevRow = attackerLogs[i - 1];
    const currRow = attackerLogs[i];
    if (currRow.previous_log_hash.trim() !== prevRow.current_log_hash.trim()) {
      chainIntact = false;
      break;
    }
  }
  assert(chainIntact, 'Cryptographic hash chain for all 10 committed denial logs is completely continuous and untampered');

  console.log(`\n===============================================================`);
  console.log(`RESULTS: ${passed} PASSED | ${failed} FAILED`);
  console.log(`===============================================================\n`);
}

runSec07ConcurrencySuite().catch(err => {
  console.error('CONCURRENCY SUITE FAILED:', err);
  process.exit(1);
});
