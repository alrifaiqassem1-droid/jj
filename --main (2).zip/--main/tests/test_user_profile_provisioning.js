import { PGlite } from '@electric-sql/pglite';
import fs from 'fs';

async function runUserProfileProvisioningTests() {
  console.log('================================================================');
  console.log('TARGETED TEST SUITE: USER PROFILE PROVISIONING TRIGGER & FSM');
  console.log('Validating Migration 00004 & End-to-End Auth Lifecycle');
  console.log('================================================================\n');

  const db = new PGlite();

  // 1. Setup Auth Mock Schema & Functions
  await db.exec(`
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (
      id UUID PRIMARY KEY,
      email TEXT UNIQUE,
      phone TEXT,
      raw_user_meta_data JSONB,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID AS $$
      SELECT NULLIF(COALESCE(NULLIF(current_setting('request.jwt.claims', true), ''), '{}')::jsonb->>'sub', '')::uuid;
    $$ LANGUAGE sql STABLE;
    CREATE OR REPLACE FUNCTION auth.jwt() RETURNS JSONB AS $$
      SELECT COALESCE(NULLIF(current_setting('request.jwt.claims', true), ''), '{}')::jsonb;
    $$ LANGUAGE sql STABLE;
    CREATE ROLE authenticated NOLOGIN;
    GRANT USAGE ON SCHEMA public, auth TO authenticated;
  `);

  // 2. Execute Migrations 00001 to 00004 sequentially
  console.log('[STEP 1] Applying Migrations 1 to 4 sequentially...');
  await db.exec(fs.readFileSync('supabase/migrations/20260927000001_initial_schema.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000002_rls_policies.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000003_invitations_fsm.sql', 'utf-8'));
  await db.exec(fs.readFileSync('supabase/migrations/20260927000004_user_profile_provisioning.sql', 'utf-8'));
  console.log('✓ All 4 migrations applied cleanly.\n');

  // TEST 1: Auto-provisioning user_profiles on auth.users INSERT
  console.log('[TEST 1] Creating new user in auth.users with metadata...');
  const userId1 = '11111111-2222-3333-4444-555555555551';
  await db.query(`
    INSERT INTO auth.users (id, email, phone, raw_user_meta_data)
    VALUES (
      '${userId1}',
      'parent.ahmed@example.com',
      '+966501112233',
      '{"full_name": "أحمد السعيد", "preferred_language": "ar"}'::jsonb
    );
  `);

  const profileRes1 = await db.query(`SELECT * FROM public.user_profiles WHERE id = '${userId1}';`);
  if (profileRes1.rows.length !== 1) {
    throw new Error('TEST 1 FAILED: user_profiles record was NOT automatically created!');
  }
  const prof1 = profileRes1.rows[0];
  if (prof1.full_name !== 'أحمد السعيد' || prof1.phone_number !== '+966501112233' || prof1.preferred_language !== 'ar') {
    throw new Error(`TEST 1 FAILED: Profile fields mismatch! Got: ${JSON.stringify(prof1)}`);
  }
  console.log('✓ TEST 1 PASS: user_profiles automatically created with correct metadata.\n');

  // TEST 2: Fallback handling when raw_user_meta_data is empty
  console.log('[TEST 2] Creating user with no metadata (testing email fallback)...');
  const userId2 = '11111111-2222-3333-4444-555555555552';
  await db.query(`
    INSERT INTO auth.users (id, email, phone, raw_user_meta_data)
    VALUES ('${userId2}', 'teacher.sara@school.com', NULL, '{}'::jsonb);
  `);

  const profileRes2 = await db.query(`SELECT * FROM public.user_profiles WHERE id = '${userId2}';`);
  const prof2 = profileRes2.rows[0];
  if (prof2.full_name !== 'teacher.sara' || prof2.preferred_language !== 'ar' || prof2.phone_number !== null) {
    throw new Error(`TEST 2 FAILED: Fallback values incorrect! Got: ${JSON.stringify(prof2)}`);
  }
  console.log('✓ TEST 2 PASS: Graceful fallback to email prefix and defaults verified.\n');

  // TEST 3: Idempotency (same user does not produce a second profile or conflict error)
  console.log('[TEST 3] Testing Idempotency on repeated profile insertion...');
  await db.query(`
    INSERT INTO public.user_profiles (id, full_name, phone_number)
    VALUES ('${userId1}', 'أحمد السعيد المحدّث', '+966501112233')
    ON CONFLICT (id) DO UPDATE SET updated_at = NOW();
  `);
  const countRes = await db.query(`SELECT count(*) as count FROM public.user_profiles WHERE id = '${userId1}';`);
  if (parseInt(countRes.rows[0].count) !== 1) {
    throw new Error(`TEST 3 FAILED: Duplicate profile detected! Count: ${countRes.rows[0].count}`);
  }
  console.log('✓ TEST 3 PASS: Idempotency verified. Exactly 1 profile exists for user.\n');

  // TEST 4: claim_parent_invitation succeeds seamlessly with auto-provisioned profile
  console.log('[TEST 4] Testing claim_parent_invitation with auto-provisioned profile...');
  // Setup kindergarten and child fixtures
  const kgId = 'aaaa0001-0000-0000-0000-000000000001';
  const adminId = 'aaaa0002-0000-0000-0000-000000000002';
  const classId = 'aaaa0004-0000-0000-0000-000000000004';
  const childId = 'aaaa0003-0000-0000-0000-000000000003';
  const tokenHash = 'e'.repeat(64); // Exactly 64 chars SHA-256 hash representation

  await db.exec(`
    INSERT INTO kindergartens (id, name, license_number, contact_email, contact_phone, address)
    VALUES ('${kgId}', 'روضة الأمل', 'LIC-999', 'hope@test.com', '0500000099', 'الرياض');
    
    INSERT INTO auth.users (id, email) VALUES ('${adminId}', 'director@hope.com');
    
    INSERT INTO classes (id, kindergarten_id, name, grade_level)
    VALUES ('${classId}', '${kgId}', 'فصل الزهور', 'KG1');

    INSERT INTO children (id, kindergarten_id, class_id, first_name, last_name, dob, gender, emergency_contact_name, emergency_contact_phone)
    VALUES ('${childId}', '${kgId}', '${classId}', 'سعود', 'العتيبي', '2022-01-01', 'MALE', 'أحمد العتيبي', '0501112233');
    
    INSERT INTO invitations (
      kindergarten_id, created_by, target_role, target_email, token_hash, target_child_id, expires_at
    ) VALUES (
      '${kgId}', '${adminId}', 'PARENT', 'parent.auto@example.com', '${tokenHash}', '${childId}', NOW() + INTERVAL '48 hours'
    );
  `);

  // A brand new parent signs up
  const newParentId = 'bbbb0001-0000-0000-0000-000000000001';
  await db.exec(`
    INSERT INTO auth.users (id, email, raw_user_meta_data)
    VALUES ('${newParentId}', 'parent.auto@example.com', '{"full_name": "والد سعود"}'::jsonb);
  `);

  // Assert user_profiles was created by trigger
  const parentProf = await db.query(`SELECT * FROM public.user_profiles WHERE id = '${newParentId}';`);
  if (parentProf.rows.length === 0) {
    throw new Error('TEST 4 PRE-CHECK FAILED: Parent profile was not auto-provisioned!');
  }

  // Simulate authenticated parent context calling claim_parent_invitation
  await db.query("SELECT set_config('request.jwt.claims', $1, false);", [JSON.stringify({ sub: newParentId, role: 'authenticated' })]);
  
  const claimRes = await db.query(`
    SELECT claim_parent_invitation(
      '${tokenHash}',
      '127.0.0.1'::inet,
      'Mozilla/5.0 Test Runner'
    ) AS result;
  `);

  const claimOutput = claimRes.rows[0].result;
  if (!claimOutput.success || claimOutput.status !== 'IDENTITY_VERIFICATION_PENDING') {
    throw new Error(`TEST 4 FAILED: Invitation claim failed! Got: ${JSON.stringify(claimOutput)}`);
  }

  // Verify membership and relationship were inserted with FKs satisfied
  const membershipCheck = await db.query(`SELECT * FROM kindergarten_memberships WHERE user_id = '${newParentId}';`);
  const relationshipCheck = await db.query(`SELECT * FROM parent_child_relationships WHERE parent_id = '${newParentId}';`);

  if (membershipCheck.rows.length !== 1 || relationshipCheck.rows.length !== 1) {
    throw new Error('TEST 4 FAILED: Membership or relationship records missing after claim!');
  }
  console.log('✓ TEST 4 PASS: claim_parent_invitation succeeded seamlessly with zero FK failures.\n');

  // TEST 5: Security Definer Privilege Boundary & search_path
  console.log('[TEST 5] Checking SECURITY DEFINER and search_path hardening...');
  const funcPerms = await db.query(`
    SELECT routine_name, security_type
    FROM information_schema.routines
    WHERE routine_name = 'handle_new_user' AND routine_schema = 'public';
  `);
  if (funcPerms.rows.length === 0 || funcPerms.rows[0].security_type !== 'DEFINER') {
    throw new Error('TEST 5 FAILED: handle_new_user is not configured as SECURITY DEFINER!');
  }

  const proconfigCheck = await db.query(`
    SELECT p.proname, p.proconfig
    FROM pg_proc p
    JOIN pg_namespace n ON p.pronamespace = n.oid
    WHERE n.nspname = 'public' AND p.proname = 'handle_new_user';
  `);
  const config = proconfigCheck.rows[0].proconfig;
  const hasSearchPath = config && config.some(c => c.includes('search_path=public, auth, pg_temp'));
  if (!hasSearchPath) {
    throw new Error(`TEST 5 FAILED: Explicit search_path missing or incorrect! Got: ${JSON.stringify(config)}`);
  }
  console.log('✓ TEST 5 PASS: SECURITY DEFINER and search_path hardening verified.\n');

  // TEST 6: Assert PUBLIC does NOT have EXECUTE privilege
  console.log('[TEST 6] Verifying PUBLIC execution privilege is revoked...');
  const publicPrivCheck = await db.query(`
    SELECT has_function_privilege('public', 'public.handle_new_user()', 'EXECUTE') AS has_priv;
  `);
  if (publicPrivCheck.rows[0].has_priv !== false) {
    throw new Error('TEST 6 FAILED: PUBLIC still has EXECUTE privilege on handle_new_user()!');
  }
  console.log('✓ TEST 6 PASS: PUBLIC EXECUTE privilege is definitively revoked.\n');

  // TEST 7: Role-specific Grants Verification in a multi-role environment
  console.log('[TEST 7] Verifying conditional grants when supabase_auth_admin and service_role exist...');
  const dbMultiRole = new PGlite();
  await dbMultiRole.exec(`
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (
      id UUID PRIMARY KEY,
      email TEXT UNIQUE,
      phone TEXT,
      raw_user_meta_data JSONB,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID AS $$
      SELECT NULLIF(COALESCE(NULLIF(current_setting('request.jwt.claims', true), ''), '{}')::jsonb->>'sub', '')::uuid;
    $$ LANGUAGE sql STABLE;
    CREATE OR REPLACE FUNCTION auth.jwt() RETURNS JSONB AS $$
      SELECT COALESCE(NULLIF(current_setting('request.jwt.claims', true), ''), '{}')::jsonb;
    $$ LANGUAGE sql STABLE;
    CREATE ROLE authenticated NOLOGIN;
    CREATE ROLE supabase_auth_admin NOLOGIN;
    CREATE ROLE service_role NOLOGIN;
    GRANT USAGE ON SCHEMA public, auth TO authenticated;
  `);
  // Run all migrations including 00004
  await dbMultiRole.exec(fs.readFileSync('supabase/migrations/20260927000001_initial_schema.sql', 'utf-8'));
  await dbMultiRole.exec(fs.readFileSync('supabase/migrations/20260927000002_rls_policies.sql', 'utf-8'));
  await dbMultiRole.exec(fs.readFileSync('supabase/migrations/20260927000003_invitations_fsm.sql', 'utf-8'));
  await dbMultiRole.exec(fs.readFileSync('supabase/migrations/20260927000004_user_profile_provisioning.sql', 'utf-8'));

  const authAdminPriv = await dbMultiRole.query(`
    SELECT has_function_privilege('supabase_auth_admin', 'public.handle_new_user()', 'EXECUTE') AS has_priv;
  `);
  const serviceRolePriv = await dbMultiRole.query(`
    SELECT has_function_privilege('service_role', 'public.handle_new_user()', 'EXECUTE') AS has_priv;
  `);
  const publicCheck2 = await dbMultiRole.query(`
    SELECT has_function_privilege('public', 'public.handle_new_user()', 'EXECUTE') AS has_priv;
  `);

  if (authAdminPriv.rows[0].has_priv !== true) {
    throw new Error('TEST 7 FAILED: supabase_auth_admin was NOT granted EXECUTE privilege!');
  }
  if (serviceRolePriv.rows[0].has_priv !== true) {
    throw new Error('TEST 7 FAILED: service_role was NOT granted EXECUTE privilege!');
  }
  if (publicCheck2.rows[0].has_priv !== false) {
    throw new Error('TEST 7 FAILED: PUBLIC has EXECUTE in multi-role environment!');
  }
  console.log('✓ TEST 7 PASS: supabase_auth_admin and service_role receive EXECUTE, PUBLIC is denied.\n');

  console.log('================================================================');
  console.log('ALL 7 USER PROFILE PROVISIONING & SECURITY TESTS PASSED (100%)');
  console.log('================================================================');
}

runUserProfileProvisioningTests().catch(err => {
  console.error('\n❌ FATAL TEST ERROR in User Profile Provisioning Suite:', err);
  process.exit(1);
});
