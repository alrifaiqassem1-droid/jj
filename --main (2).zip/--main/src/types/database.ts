/**
 * Rawdaty Smart (روضتي الذكية) — Canonical Database & Domain Types
 * Exactly 25 Entities as defined in FINAL_ENTITY_REGISTRY.md.
 */

// 1. Roles & Permissions Enums
export type AppRole = 'SUPER_ADMIN' | 'ADMIN' | 'TEACHER' | 'STAFF' | 'PARENT';

export type StaffPermission =
  | 'VIEW_CHILD_BASIC_INFO'
  | 'EDIT_CHILD_BASIC_INFO'
  | 'VIEW_CHILD_HEALTH_INFO'
  | 'EDIT_CHILD_HEALTH_INFO'
  | 'PERFORM_CLINICAL_REVIEW'
  | 'RECORD_ATTENDANCE'
  | 'VIEW_ATTENDANCE'
  | 'MANAGE_MEDIA'
  | 'VIEW_INVOICES';

export type InvitationLifecycleStatus =
  | 'CREATED'
  | 'OPENED'
  | 'ACCOUNT_CREATED'
  | 'IDENTITY_VERIFICATION_PENDING'
  | 'CLAIMED'
  | 'REVOKED'
  | 'EXPIRED';

export type AttendanceStatus =
  | 'UNRECORDED'
  | 'PRESENT'
  | 'ABSENT_UNEXCUSED'
  | 'ABSENT_EXCUSED'
  | 'CHECKED_OUT'
  | 'CORRECTED';

export type DevelopmentalDomain =
  | 'COGNITIVE'
  | 'LANGUAGE_COMMUNICATION'
  | 'SOCIAL_EMOTIONAL'
  | 'FINE_MOTOR'
  | 'GROSS_MOTOR'
  | 'SELF_CARE_INDEPENDENCE';

export type RelationshipType =
  | 'MOTHER'
  | 'FATHER'
  | 'LEGAL_GUARDIAN'
  | 'GRANDPARENT'
  | 'AUTHORIZED_RELATIVE';

export type AiApprovalStatus =
  | 'PENDING_REVIEW'
  | 'APPROVED'
  | 'REJECTED'
  | 'MODIFIED';

export type InvoiceStatus =
  | 'DRAFT'
  | 'ISSUED'
  | 'PAID'
  | 'OVERDUE'
  | 'VOID';

export type NotificationChannel = 'IN_APP' | 'WEB_PUSH' | 'EMAIL';
export type NotificationPriority = 'LOW' | 'NORMAL' | 'URGENT' | 'CRITICAL';

// 2. Interfaces for all 25 Entities
export interface Kindergarten {
  id: string;
  name: string;
  license_number: string;
  contact_email: string;
  contact_phone: string;
  address: string;
  city: string;
  country_code: string;
  timezone: string;
  settings: Record<string, unknown>;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  deleted_by: string | null;
}

export interface UserProfile {
  id: string;
  full_name: string;
  phone_number: string | null;
  national_id_hash: string | null;
  preferred_language: string;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

export interface KindergartenMembership {
  id: string;
  kindergarten_id: string;
  user_id: string;
  role: AppRole;
  permissions: StaffPermission[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

export interface SuperAdminSupportSession {
  id: string;
  super_admin_id: string;
  target_kindergarten_id: string;
  reason: string;
  scope: string;
  is_active: boolean;
  initiated_at: string;
  expires_at: string;
  revoked_at: string | null;
  revoked_by: string | null;
  created_at: string;
}

export interface PlatformSuperAdmin {
  user_id: string;
  created_at: string;
  created_by: string | null;
  is_active: boolean;
  notes: string | null;
}

export interface ClassRoom {
  id: string;
  kindergarten_id: string;
  name: string;
  grade_level: string;
  room_number: string | null;
  capacity: number;
  academic_year: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

export interface TeacherClassAssignment {
  id: string;
  kindergarten_id: string;
  class_id: string;
  teacher_id: string;
  is_lead_teacher: boolean;
  assigned_at: string;
  created_at: string;
}

export interface Child {
  id: string;
  kindergarten_id: string;
  class_id: string;
  first_name: string;
  last_name: string;
  dob: string;
  gender: 'MALE' | 'FEMALE';
  emergency_contact_name: string;
  emergency_contact_phone: string;
  enrollment_date: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  deleted_by: string | null;
}

export interface ChildHealthProfile {
  id: string;
  kindergarten_id: string;
  child_id: string;
  blood_type: string | null;
  allergies: string[];
  has_epipen: boolean;
  epipen_location: string | null;
  chronic_conditions: string[];
  emergency_medications: string | null;
  dietary_restrictions: string | null;
  pediatrician_name: string | null;
  pediatrician_phone: string | null;
  clinical_notes: string | null;
  last_reviewed_at: string;
  last_reviewed_by: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

export interface ParentChildRelationship {
  id: string;
  kindergarten_id: string;
  parent_id: string;
  child_id: string;
  relationship: RelationshipType;
  is_primary_contact: boolean;
  authorized_for_pickup: boolean;
  verified_at: string | null; // CRITICAL: Legal Custody Gate
  verified_by_admin_id: string | null;
  verification_notes: string | null;
  created_at: string;
  deleted_at: string | null;
}

export interface Invitation {
  id: string;
  kindergarten_id: string;
  created_by: string;
  target_role: AppRole;
  target_email: string;
  target_phone: string | null;
  token_hash: string;
  target_child_id: string | null;
  target_relationship: RelationshipType | null;
  target_class_id: string | null;
  status: InvitationLifecycleStatus;
  max_uses: number;
  uses_count: number;
  opened_at: string | null;
  account_created_at: string | null;
  claimed_at: string | null;
  claimed_by_user_id: string | null;
  expires_at: string;
  revoked_at: string | null;
  revoked_by: string | null;
  created_at: string;
}

export interface InvitationRedemption {
  id: string;
  invitation_id: string;
  redeemed_by: string;
  ip_address: string | null;
  user_agent: string | null;
  redeemed_at: string;
}

export interface Attendance {
  id: string;
  client_attendance_uuid: string | null;
  kindergarten_id: string;
  class_id: string;
  child_id: string;
  date: string;
  status: AttendanceStatus;
  check_in_time: string | null;
  check_out_time: string | null;
  recorded_by: string;
  picked_up_by_name: string | null;
  notes: string | null;
  client_recorded_at: string;
  server_synced_at: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  deleted_by: string | null;
}

export interface AttendanceCorrection {
  id: string;
  attendance_id: string;
  kindergarten_id: string;
  child_id: string;
  previous_status: AttendanceStatus;
  new_status: AttendanceStatus;
  corrected_by_user_id: string;
  reason: string;
  source: string;
  request_session_id: string | null;
  client_timestamp: string;
  server_synced_at: string;
  created_at: string;
}

export interface TeacherObservation {
  id: string;
  kindergarten_id: string;
  class_id: string;
  child_id: string;
  teacher_id: string;
  activity_context: string;
  observed_behavior: string;
  primary_domain: DevelopmentalDomain;
  secondary_domains: DevelopmentalDomain[];
  media_ids: string[];
  observed_at: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

export interface ParentObservation {
  id: string;
  kindergarten_id: string;
  child_id: string;
  parent_id: string;
  play_context: string;
  parent_reflection: string;
  domain_hint: DevelopmentalDomain | null;
  media_ids: string[];
  observed_at: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

export interface AiAnalysis {
  id: string;
  kindergarten_id: string;
  child_id: string;
  model_version: string;
  prompt_tokens: number;
  completion_tokens: number;
  latency_ms: number;
  raw_response_hash: string;
  status: string;
  created_at: string;
}

export interface AiEvidence {
  id: string;
  kindergarten_id: string;
  analysis_id: string;
  source_table: 'teacher_observations' | 'parent_observations';
  source_record_id: string;
  evidence_quote: string;
  relevance_score: number;
  created_at: string;
}

export interface AiInsight {
  id: string;
  kindergarten_id: string;
  child_id: string;
  analysis_id: string;
  domain: DevelopmentalDomain;
  synthesized_summary: string;
  observed_strengths: string[];
  growth_opportunities: string[];
  is_signed_off_by_teacher: boolean;
  signed_off_teacher_id: string | null;
  signed_off_at: string | null;
  created_at: string;
}

export interface AiRecommendation {
  id: string;
  kindergarten_id: string;
  child_id: string;
  insight_id: string;
  activity_title: string;
  activity_duration_minutes: number;
  materials_needed: string[];
  step_by_step_instructions: string[];
  purpose_description: string;
  parent_tips: string | null;
  approval_status: AiApprovalStatus;
  approved_by_teacher_id: string | null;
  approved_at: string | null;
  rejection_reason: string | null;
  created_at: string;
}

export interface AiFollowup {
  id: string;
  kindergarten_id: string;
  recommendation_id: string;
  child_id: string;
  logged_by_user_id: string;
  activity_completed: boolean;
  child_engagement_rating: number | null;
  parent_feedback_notes: string | null;
  teacher_notes: string | null;
  created_at: string;
}

export interface MediaVault {
  id: string;
  kindergarten_id: string;
  storage_path: string;
  mime_type: string;
  file_size_bytes: number;
  sha256_checksum: string;
  uploaded_by: string;
  created_at: string;
  deleted_at: string | null;
}

export interface MediaChildTag {
  id: string;
  kindergarten_id: string;
  media_id: string;
  child_id: string;
  tagged_by: string;
  tagged_at: string;
}

export interface TuitionInvoice {
  id: string;
  kindergarten_id: string;
  child_id: string;
  parent_id: string;
  invoice_number: string;
  amount_sar: number;
  vat_sar: number;
  total_sar: number;
  status: InvoiceStatus;
  due_date: string;
  paid_at: string | null;
  payment_reference: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

export interface Notification {
  id: string;
  kindergarten_id: string;
  recipient_user_id: string;
  channel: NotificationChannel;
  priority: NotificationPriority;
  title: string;
  body: string;
  action_url: string | null;
  metadata: Record<string, unknown>;
  read_at: string | null;
  created_at: string;
}

export interface AuditLog {
  id: string;
  kindergarten_id: string | null;
  actor_id: string | null;
  actor_role: AppRole | null;
  action: string;
  resource_type: string;
  resource_id: string | null;
  request_session_id: string | null;
  ip_address: string | null;
  user_agent: string | null;
  reason: string | null;
  metadata: Record<string, unknown>;
  previous_log_hash: string | null;
  current_log_hash: string;
  created_at: string;
}

export interface HealthProfileParentView {
  child_id: string;
  blood_type: string | null;
  allergies: string[];
  has_epipen: boolean;
  epipen_location: string | null;
  chronic_conditions: string[];
  emergency_medications: string | null;
  dietary_restrictions: string | null;
  pediatrician_name: string | null;
  pediatrician_phone: string | null;
  clinical_notes: string | null;
  last_reviewed_at: string;
}

export type HealthProfileReadResult =
  | { success: true; role: 'PARENT'; data: HealthProfileParentView }
  | { success: true; role: 'ADMIN' | 'STAFF' | 'SUPER_ADMIN'; data: ChildHealthProfile }
  | { success: false; error_code: string; message: string; audit_logged?: boolean };

