import React, { useState } from 'react';
import {
  Shield,
  Database,
  Lock,
  UserCheck,
  CheckCircle2,
  FileText,
  KeyRound,
  LogOut,
  LogIn,
  Languages,
  Sparkles,
  Info,
  Building2,
  Camera
} from 'lucide-react';
import { useI18n } from './lib/i18n/I18nContext';
import { useAuth } from './modules/auth/AuthContext';
import { AdminShell } from './modules/admin/components/AdminShell';
import { ParentInstagramShell } from './modules/parent-portal/ParentInstagramShell';

import { AppLogo } from './components/ui/AppLogo';

export default function App() {
  const { t, locale, setLocale } = useI18n();
  const { user, profile, signIn, signUp, signOut, error } = useAuth();

  const [currentView, setCurrentView] = useState<'admin' | 'parent' | 'baseline'>('admin');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [fullNameInput, setFullNameInput] = useState('');
  const [phoneInput, setPhoneInput] = useState('');
  const [authSubmitting, setAuthSubmitting] = useState(false);
  const [activeSection, setActiveSection] = useState<'overview' | 'layers' | 'security' | 'database'>('overview');

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthSubmitting(true);
    if (authMode === 'signin') {
      const res = await signIn(emailInput, passwordInput);
      if (res.success) {
        setShowAuthModal(false);
      }
    } else {
      const res = await signUp(emailInput, passwordInput, fullNameInput, phoneInput);
      if (res.success) {
        setShowAuthModal(false);
      }
    }
    setAuthSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Universal Preview Switcher Bar */}
      <nav
        aria-label="شريط التبديل السريع للمعاينة"
        className="bg-slate-900/95 backdrop-blur-md border-b border-emerald-500/30 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 sticky top-0 z-50 shadow-lg"
      >
        <AppLogo size="md" variant="dark" showText={true} />

        {/* View Switcher Controls */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => setCurrentView('admin')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              currentView === 'admin'
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>لوحة المديرة 🏢</span>
          </button>

          <button
            type="button"
            onClick={() => setCurrentView('parent')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              currentView === 'parent'
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>تطبيق الأهالي (إنستغرام) 📸</span>
          </button>

          <button
            type="button"
            onClick={() => setCurrentView('baseline')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              currentView === 'baseline'
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>المعمارية والأمان 🏛️</span>
          </button>
        </div>

        {/* Right side Language & Quick User Status */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setLocale(locale === 'ar' ? 'en' : 'ar')}
            className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white px-2.5 py-1.5 rounded-lg border border-slate-700 bg-slate-800/80 transition cursor-pointer"
          >
            <Languages className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-semibold">{t.common.languageToggle}</span>
          </button>

          {user ? (
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-300 hidden sm:inline">
                {profile?.full_name || user.email}
              </span>
              <button
                type="button"
                onClick={() => signOut()}
                className="text-xs text-rose-400 hover:text-rose-300 px-2 py-1 rounded bg-rose-500/10 border border-rose-500/20"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setShowAuthModal(true)}
              className="text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 px-3 py-1.5 rounded-lg transition"
            >
              {t.auth.signIn}
            </button>
          )}
        </div>
      </nav>

      {/* Main View Render */}
      {currentView === 'admin' ? (
        <AdminShell
          onBackToHome={() => setCurrentView('baseline')}
          onOpenSignIn={() => setShowAuthModal(true)}
        />
      ) : currentView === 'parent' ? (
        <ParentInstagramShell
          onBackToAdmin={() => setCurrentView('admin')}
        />
      ) : (
        <>
          {/* Main Container for Baseline Architecture */}
          <main className="flex-1 max-w-7xl mx-auto w-full p-6 space-y-6">
            {/* Phase 1 Baseline Hero Card */}
            <section className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl relative overflow-hidden">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="space-y-3 max-w-3xl">
                  <div className="inline-flex items-center gap-2 text-xs font-bold text-emerald-400">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>{t.baseline.phase1Title}</span>
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight leading-snug">
                    {t.common.appName} — {t.dashboard.heroTitle}
                  </h1>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    {t.dashboard.heroDescription}
                  </p>
                </div>

                {/* Architecture Invariant Card */}
                <div className="p-5 rounded-xl bg-slate-950/90 border border-emerald-500/30 min-w-[280px] space-y-3 text-xs shadow-lg">
                  <div className="font-bold text-emerald-400 border-b border-slate-800 pb-2 flex items-center justify-between">
                    <span>{t.dashboard.statusCardTitle}</span>
                    <span className="font-mono text-[10px] text-slate-400">{t.dashboard.statusCardBadge}</span>
                  </div>
                  <ul className="space-y-2 text-slate-300">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{t.dashboard.itemRlsStrict}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{t.dashboard.itemProfileProvisioned}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{t.dashboard.itemChildProtection}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{t.dashboard.itemArabicFirstRtl}</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Sub-navigation Tabs */}
              <div className="pt-4 border-t border-slate-800/80 flex flex-wrap gap-2 text-xs">
                <button
                  onClick={() => setActiveSection('overview')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                    activeSection === 'overview'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {t.dashboard.tabOverview}
                </button>
                <button
                  onClick={() => setActiveSection('layers')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                    activeSection === 'layers'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {t.dashboard.tabLayers}
                </button>
                <button
                  onClick={() => setActiveSection('security')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                    activeSection === 'security'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {t.dashboard.tabSecurity}
                </button>
                <button
                  onClick={() => setActiveSection('database')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                    activeSection === 'database'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {t.dashboard.tabDatabase}
                </button>
              </div>
            </section>

            {/* SECTION 1: OVERVIEW */}
            {activeSection === 'overview' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-5 space-y-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
                    <UserCheck className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-white">{t.dashboard.identityTitle}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {t.dashboard.identityDesc}
                  </p>
                </div>

                <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-5 space-y-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                    <Lock className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-white">{t.dashboard.kernelRlsTitle}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {t.dashboard.kernelRlsDesc}
                  </p>
                </div>

                <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-5 space-y-3">
                  <div className="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-white">{t.dashboard.invitationsFsmTitle}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {t.dashboard.invitationsFsmDesc}
                  </p>
                </div>
              </div>
            )}

            {/* SECTION 2: LAYERS & ARCHITECTURE */}
            {activeSection === 'layers' && (
              <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-6 space-y-5">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-400" />
                  {t.dashboard.layersSectionTitle}
                </h3>

                <div className="space-y-3 text-xs">
                  <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between text-white font-bold">
                      <span>{t.dashboard.layerPresentationTitle}</span>
                      <span className="font-mono text-emerald-400 text-[10px]">{t.dashboard.layerPresentationBadge}</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      {t.dashboard.layerPresentationDesc}
                    </p>
                  </div>

                  <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between text-white font-bold">
                      <span>{t.dashboard.layerDomainTitle}</span>
                      <span className="font-mono text-blue-400 text-[10px]">{t.dashboard.layerDomainBadge}</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      {t.dashboard.layerDomainDesc}
                    </p>
                  </div>

                  <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between text-white font-bold">
                      <span>{t.dashboard.layerKernelTitle}</span>
                      <span className="font-mono text-amber-400 text-[10px]">{t.dashboard.layerKernelBadge}</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      {t.dashboard.layerKernelDesc}
                    </p>
                  </div>

                  <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between text-white font-bold">
                      <span>{t.dashboard.layerPersistenceTitle}</span>
                      <span className="font-mono text-purple-400 text-[10px]">{t.dashboard.layerPersistenceBadge}</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      {t.dashboard.layerPersistenceDesc}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* SECTION 3: SECURITY & PROVISIONING */}
            {activeSection === 'security' && (
              <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-6 space-y-5">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-400" />
                  {t.dashboard.securitySectionTitle}
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
                    <span className="font-bold text-emerald-400">{t.dashboard.triggerTitle}</span>
                    <p className="text-slate-300 leading-relaxed">
                      {t.dashboard.triggerDesc1}
                    </p>
                    <p className="text-slate-400 leading-relaxed">
                      {t.dashboard.triggerDesc2}
                    </p>
                  </div>

                  <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
                    <span className="font-bold text-emerald-400">{t.dashboard.parentVerificationTitle}</span>
                    <p className="text-slate-300 leading-relaxed">
                      {t.dashboard.parentVerificationDesc1}
                    </p>
                    <p className="text-slate-400 leading-relaxed">
                      {t.dashboard.parentVerificationDesc2}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* SECTION 4: FROZEN DATABASE ENTITIES */}
            {activeSection === 'database' && (
              <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <Database className="w-4 h-4 text-emerald-400" />
                      {t.dashboard.entitiesTitle}
                    </h3>
                    <p className="text-xs text-slate-400">{t.dashboard.entitiesSubtitle}</p>
                  </div>
                  <span className="text-xs text-emerald-400 font-mono font-bold bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/20">
                    {t.dashboard.entitiesBadge}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5 text-[11px] font-mono">
                  {[
                    'kindergartens',
                    'user_profiles',
                    'kindergarten_memberships',
                    'super_admin_support_sessions',
                    'classes',
                    'teacher_class_assignments',
                    'children',
                    'child_health_profiles',
                    'parent_child_relationships',
                    'invitations',
                    'invitation_redemptions',
                    'attendance',
                    'attendance_corrections',
                    'teacher_observations',
                    'parent_observations',
                    'ai_analysis',
                    'ai_evidence',
                    'ai_insights',
                    'ai_recommendations',
                    'ai_followups',
                    'media_vault',
                    'media_child_tags',
                    'tuition_invoices',
                    'notifications',
                    'audit_logs',
                  ].map((name) => (
                    <div key={name} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 text-slate-300 flex items-center justify-between">
                      <span className="truncate">{name}</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Documentation Reference Footer */}
            <footer className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-400" />
                <span>{t.dashboard.footerDocStored} <code className="text-emerald-300 font-mono text-[11px]">PHASE1_BASELINE_ARCHITECTURE.md</code></span>
              </div>
              <div className="flex items-center gap-2 text-[11px]">
                <span>{t.dashboard.footerIdentity}</span>
                <span>·</span>
                <span>{t.dashboard.footerSecurity}</span>
                <span>·</span>
                <span className="text-emerald-400 font-semibold">{t.dashboard.footerPhase1Ready}</span>
              </div>
            </footer>
          </main>
        </>
      )}

      {/* Authentication Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <LogIn className="w-4 h-4 text-emerald-400" />
                <span>{authMode === 'signin' ? t.auth.signIn : t.auth.signUp}</span>
              </h3>
              <button
                onClick={() => setShowAuthModal(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                <Info className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleAuthSubmit} className="space-y-4 text-xs">
              {authMode === 'signup' && (
                <>
                  <div className="space-y-1">
                    <label className="text-slate-300 font-semibold">{t.auth.fullName}</label>
                    <input
                      type="text"
                      required
                      value={fullNameInput}
                      onChange={(e) => setFullNameInput(e.target.value)}
                      placeholder={t.auth.fullNamePlaceholder}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-slate-300 font-semibold">{t.auth.phoneNumber}</label>
                    <input
                      type="tel"
                      value={phoneInput}
                      onChange={(e) => setPhoneInput(e.target.value)}
                      placeholder={t.auth.phonePlaceholder}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </>
              )}

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">{t.auth.email}</label>
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 text-start"
                  dir="ltr"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">{t.auth.password}</label>
                <input
                  type="password"
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                type="submit"
                disabled={authSubmitting}
                className="w-full py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold rounded-lg transition shadow-md shadow-emerald-500/20 cursor-pointer flex items-center justify-center gap-2"
              >
                {authSubmitting ? t.common.loading : (authMode === 'signin' ? t.auth.signIn : t.auth.signUp)}
              </button>
            </form>

            <div className="pt-3 border-t border-slate-800 text-center text-[11px] text-slate-400">
              {authMode === 'signin' ? (
                <p>
                  {t.auth.noAccount}{' '}
                  <button
                    onClick={() => setAuthMode('signup')}
                    className="text-emerald-400 hover:underline font-semibold cursor-pointer"
                  >
                    {t.auth.signUp}
                  </button>
                </p>
              ) : (
                <p>
                  {t.auth.alreadyHaveAccount}{' '}
                  <button
                    onClick={() => setAuthMode('signin')}
                    className="text-emerald-400 hover:underline font-semibold cursor-pointer"
                  >
                    {t.auth.signIn}
                  </button>
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
