import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { env } from '../config/env';

/**
 * Server-Side Supabase Client (Protected API Routes / Server Middlewares)
 * Can be initialized with a user's Bearer token to execute queries under the user's exact RLS identity.
 */
export function createServerUserClient(bearerToken: string): SupabaseClient {
  return createClient(env.VITE_SUPABASE_URL, env.VITE_SUPABASE_ANON_KEY, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
    global: {
      headers: {
        Authorization: `Bearer ${bearerToken}`,
      },
    },
  });
}

/**
 * Server-Side Audited Service Role Client
 * PROHIBITED for normal business operations or bypassing RLS.
 * Exclusively permitted for background system jobs (e.g. cleaning expired sessions, automated db maintenance).
 */
export function createAuditedAdminClient(): SupabaseClient {
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceRoleKey) {
    throw new Error('CONFIG_ERROR: SUPABASE_SERVICE_ROLE_KEY is not defined in server environment.');
  }

  return createClient(env.VITE_SUPABASE_URL, serviceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}
