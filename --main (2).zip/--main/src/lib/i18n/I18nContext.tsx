import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import type { SupportedLocale, TextDirection, TranslationDictionary } from './types';
import { arTranslations } from './ar';
import { enTranslations } from './en';

interface I18nContextValue {
  locale: SupportedLocale;
  dir: TextDirection;
  setLocale: (locale: SupportedLocale) => void;
  t: TranslationDictionary;
}

const dictionaries: Record<SupportedLocale, TranslationDictionary> = {
  ar: arTranslations,
  en: enTranslations,
};

const I18nContext = createContext<I18nContextValue | null>(null);

export function I18nProvider({ children }: { children: React.ReactNode }) {
  // Strict Invariant: Arabic-first as non-negotiable default
  const [locale, setLocale] = useState<SupportedLocale>('ar');

  const dir: TextDirection = useMemo(() => (locale === 'en' ? 'ltr' : 'rtl'), [locale]);

  useEffect(() => {
    // Keep DOM document root perfectly synchronized
    document.documentElement.lang = locale;
    document.documentElement.dir = dir;
  }, [locale, dir]);

  const handleSetLocale = (newLocale: SupportedLocale) => {
    if (newLocale === 'en') {
      setLocale('en');
    } else {
      setLocale('ar');
    }
  };

  const value = useMemo<I18nContextValue>(
    () => ({
      locale,
      dir,
      setLocale: handleSetLocale,
      t: (dictionaries[locale] as TranslationDictionary) || dictionaries.ar,
    }),
    [locale, dir]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
}
