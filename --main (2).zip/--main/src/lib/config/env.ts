import { z } from 'zod';

/**
 * Server and Client Environment Schema Definition.
 * Validates configuration at application boot without crashing during early prototyping.
 */
const envSchema = z.object({
  VITE_APP_ENV: z.enum(['development', 'staging', 'production']).default('development'),
  VITE_SUPABASE_URL: z.string().url().default('https://placeholder-project.supabase.co'),
  VITE_SUPABASE_ANON_KEY: z.string().min(10).default('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.placeholder-anon-key'),
});

export type EnvConfig = z.infer<typeof envSchema>;

export function getClientEnv(): EnvConfig {
  const metaEnv = typeof import.meta !== 'undefined' && (import.meta as unknown as { env?: Record<string, string> }).env
    ? (import.meta as unknown as { env: Record<string, string> }).env
    : {};

  const parsed = envSchema.safeParse({
    VITE_APP_ENV: metaEnv.VITE_APP_ENV || process.env.VITE_APP_ENV || 'development',
    VITE_SUPABASE_URL: metaEnv.VITE_SUPABASE_URL || process.env.VITE_SUPABASE_URL || 'https://placeholder-project.supabase.co',
    VITE_SUPABASE_ANON_KEY: metaEnv.VITE_SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.placeholder-anon-key',
  });

  if (!parsed.success) {
    console.warn('⚠️ Environment configuration fallback engaged:', parsed.error.format());
    return {
      VITE_APP_ENV: 'development',
      VITE_SUPABASE_URL: 'https://placeholder-project.supabase.co',
      VITE_SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.placeholder-anon-key',
    };
  }

  return parsed.data;
}

export const env = getClientEnv();
