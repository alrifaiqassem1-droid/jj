/**
 * Al-Adham Smart Kindergarten — Pedagogical AI Engine (Home-School Bridge)
 * Translates daily classroom field observations into tailored pedagogical setups
 * for teachers and 10-minute playful home integration for parents.
 *
 * Implements strict Human-in-the-Loop AI Principles:
 * - Attribution: [اقتراح من الذكاء الاصطناعي — يتطلب مراجعة بشرية واعتمادًا]
 * - Strictly Non-Diagnostic, Strengths-Based Developmental Language.
 */

export interface DailyObservationInput {
  childId: string;
  childName: string;
  className: string;
  domain: 'FINE_MOTOR' | 'SPATIAL_COGNITIVE' | 'SOCIAL_EMOTIONAL' | 'LANGUAGE';
  observationText: string;
  observedAt: string;
  teacherName: string;
}

export interface HomeSchoolBridgePlan {
  id: string;
  childId: string;
  childName: string;
  domainLabel: string;
  date: string;
  // Pedagogical Reflection (Human-in-the-Loop AI Summary)
  developmentalFocus: string;
  rationale: string;
  // For Teacher
  teacherPlan: {
    targetCorner: string; // e.g. ركن منتسوري والاكتشاف
    actionStep: string;
    materialsToPrepare: string[];
    suggestedPeerPairing?: string;
  };
  // For Parent
  parentBridge: {
    headline: string;
    durationMinutes: number; // e.g. 10
    homeMicroActivity: string;
    conversationStarter: string; // سؤال مفتاح الحديث الودود مع الطفل
    funCheer: string;
  };
  status: 'PENDING_REVIEW' | 'APPROVED' | 'COMPLETED';
}

const PRESET_PLANS: Record<string, HomeSchoolBridgePlan> = {
  adham: {
    id: 'bridge-adham-01',
    childId: 'cccc1111-cccc-cccc-cccc-cccccccccccc',
    childName: 'أدهم الرفاعي',
    domainLabel: 'النمو الحركي الدقيق والتعبير الفني',
    date: 'اليوم',
    developmentalFocus: 'تطور السيطرة الثلاثية على الأصابع وزيادة التركيز أثناء التلوين والتنسيق',
    rationale: 'استجابة لملاحظة المعلمة حول استمتاع أدهم بمزج الألوان المائية واختيار درجات الأزرق والبرتقالي بحرية.',
    teacherPlan: {
      targetCorner: 'ركن الفنون والحرف اليدوية',
      actionStep: 'تجهيز ورق مقوى داكن وألوان أصابع طبيعية، وتشجيعه على رسم خطوط متعرجة ومنحنيات لتقوية عضلة الإبهام.',
      materialsToPrepare: ['ورق مقوى ذو ملمس خشن', 'ألوان مائية عضوية آمنة', 'ملاقط خشبية وكرات صوف'],
      suggestedPeerPairing: 'المشاركة مع زميله فهد في مشروع تلوين لوحة جدارية مصغرة مشتركة.',
    },
    parentBridge: {
      headline: 'نشاط المساء: لعبة البحث عن الظلال والألوان في المنزل 🎨',
      durationMinutes: 10,
      homeMicroActivity: 'أحضروا ملعقتين وورقة بيضاء، وضعوا لعبة صغيرة تحت إضاءة المصباح واطلبوا من أدهم تتبع ظلها بالقلم الرصاص على الورقة مع الثناء على دقته.',
      conversationStarter: '«يا بطل، شفت ألوانك الجميلة بالروضة اليوم.. ما هو اللون اللي حسيت إنه يخليك فرحان أكثر شي اليوم؟»',
      funCheer: 'أدهم مهندس الألوان الصغير! 🌟',
    },
    status: 'APPROVED',
  },
  sara: {
    id: 'bridge-sara-01',
    childId: 'cccc2222-cccc-cccc-cccc-cccccccccccc',
    childName: 'سارة الرفاعي',
    domainLabel: 'الطلاقة اللغوية والتفاعل الاجتماعي',
    date: 'اليوم',
    developmentalFocus: 'توسيع المخزون اللفظي ومشاركة التعبير العاطفي أثناء الحوار الصفي',
    rationale: 'استناداً إلى تفاعل سارة اللطيف في حلقة الصباح والاستماع لقصة اليوم وإعادة سرد أجزاء منها بثقة.',
    teacherPlan: {
      targetCorner: 'ركن القراءة والمسرح الدموي',
      actionStep: 'استخدام دمى الأصابع لتمثيل شخصيات قصة اليوم ودعوة سارة لاختيار نهاية مبتكرة للقصة بصوتها.',
      materialsToPrepare: ['دمى أصابع قماشية', 'كتاب القصة المصور بأحجام كبيرة'],
      suggestedPeerPairing: 'التمثيل المشترك مع زميلتها نورة في حلقة المسرح.',
    },
    parentBridge: {
      headline: 'نشاط المساء: قصة ما قبل النوم التفاعلية (أنتِ البطلة) 📖',
      durationMinutes: 10,
      homeMicroActivity: 'اقرؤوا صفحتين من قصة قصيرة، وتوقفوا فجأة واسألوا سارة: «لو كنتِ مكان الفراشة الصغيرة، وين كنتِ تحبي تطيري الحين؟» واستمعوا لإجابتها بمحبة.',
      conversationStarter: '«حبيبتي سارة، سمعت إنك سمعتِ قصة جميلة بالروضة اليوم، تقدرين تحكي لي مين كانت أحلى شخصية حبيتيها؟»',
      funCheer: 'سارة الفراشة الذكية والراوية المبدعة! ✨',
    },
    status: 'APPROVED',
  },
};

export const pedagogicalAiEngine = {
  /**
   * Retrieves the personalized Home-School Bridge plan for a given child.
   */
  getBridgePlan(childKey: 'adham' | 'sara' = 'adham'): HomeSchoolBridgePlan {
    return PRESET_PLANS[childKey] || PRESET_PLANS.adham;
  },

  /**
   * Dynamically constructs a pedagogical bridge plan based on an arbitrary field observation.
   */
  generateBridgeFromObservation(input: DailyObservationInput): HomeSchoolBridgePlan {
    return {
      id: `bridge-${input.childId}-${Date.now()}`,
      childId: input.childId,
      childName: input.childName,
      domainLabel: input.domain,
      date: 'اليوم',
      developmentalFocus: `دعم المهارات المستهدفة استناداً لملاحظة: ${input.observationText.slice(0, 45)}...`,
      rationale: `ملاحظة ميدانية مسجلة بواسطة ${input.teacherName}.`,
      teacherPlan: {
        targetCorner: 'ركن منتسوري والتفكير الرياضي',
        actionStep: 'تطبيق تمرين تفاعلي يثري الملاحظة المرصودة ويعزز استقلالية الطفل.',
        materialsToPrepare: ['أدوات خشبية آمنة', 'بطاقات مطابقة مصورة'],
      },
      parentBridge: {
        headline: `نشاط الدقائق العشر التفاعلي مع ${input.childName} 🏡`,
        durationMinutes: 10,
        homeMicroActivity: 'نشاط منزلي هادئ لمدة 10 دقائق لترسيخ المفاهيم المكتسبة في الروضة.',
        conversationStarter: `«كيف كان يومك يا ${input.childName}؟ ما هو أكثر نشاط أسعدك اليوم مع أصدقائك؟»`,
        funCheer: 'خطوة تنموية مميزة كل يوم! 🌟',
      },
      status: 'PENDING_REVIEW',
    };
  },
};
