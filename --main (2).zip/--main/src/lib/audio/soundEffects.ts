/**
 * Al-Adham Smart Kindergarten Web Audio Chime Service
 * Generates pleasant, cheerful Do-Mi-Sol chord chimes using the standard browser Web Audio API.
 * Pure mathematical synthesis - no external audio files or network requests required.
 */

class SoundService {
  private audioCtx: AudioContext | null = null;

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;

    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }

    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {
        // User interaction might still be pending
      });
    }

    return this.audioCtx;
  }

  /**
   * Plays a cheerful Do-Mi-Sol ascending chime (C6, E6, G6, C7)
   * Designed for pleasant positive feedback (confirmations, approval, pickup alerts).
   */
  public playCheerfulChime(): void {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      // Do-Mi-Sol-Do chord notes: C6 (1046.5 Hz), E6 (1318.5 Hz), G6 (1567.98 Hz), C7 (2093 Hz)
      const notes = [
        { freq: 1046.5, delay: 0.0, duration: 0.35, gain: 0.14 },
        { freq: 1318.51, delay: 0.06, duration: 0.4, gain: 0.16 },
        { freq: 1567.98, delay: 0.12, duration: 0.45, gain: 0.18 },
        { freq: 2093.0, delay: 0.18, duration: 0.55, gain: 0.2 },
      ];

      notes.forEach(({ freq, delay, duration, gain }) => {
        const osc = ctx.createOscillator();
        const gainNode = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + delay);

        // Smooth volume envelope with quick soft attack and exponential decay
        gainNode.gain.setValueAtTime(0.0001, now + delay);
        gainNode.gain.exponentialRampToValueAtTime(gain, now + delay + 0.015);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, now + delay + duration);

        osc.connect(gainNode);
        gainNode.connect(ctx.destination);

        osc.start(now + delay);
        osc.stop(now + delay + duration + 0.05);
      });
    } catch {
      // Audio playback fails gracefully if blocked by system/browser
    }
  }

  /**
   * Plays a subtle notification ping for alerts
   */
  public playNotification(): void {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(1174.66, now); // D6
      osc.frequency.exponentialRampToValueAtTime(1760.0, now + 0.08); // A6

      gainNode.gain.setValueAtTime(0.0001, now);
      gainNode.gain.exponentialRampToValueAtTime(0.12, now + 0.02);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);

      osc.connect(gainNode);
      gainNode.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.3);
    } catch {
      // Audio playback fails gracefully
    }
  }
}

export const soundService = new SoundService();
