import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Sparkles,
  CheckCircle2,
  Brain,
  Volume2,
  Check,
  ChevronDown,
  ChevronUp,
  FileText,
  Lightbulb,
  Heart
} from 'lucide-react';
import { soundService } from '../../lib/audio/soundEffects';
import { DynamicButton, type ButtonState } from '../ui/DynamicButton';

export interface RecommendationItem {
  id: string;
  title: string;
  category: string;
  skillTarget: string;
  evidence: string;
  suggestedAction: string;
  homeExtension: string;
  approved: boolean;
}

const DEFAULT_RECOMMENDATIONS: RecommendationItem[] = [
  {
    id: 'rec-1',
    title: 'تحدي المتاهة الملونة والتوازن بالأصابع',
    category: 'النمو الحركي الدقيق',
    skillTarget: 'تعزيز قوة عضلات الأنامل والتآزر البصري الحركي',
    evidence: 'استناداً إلى ملاحظة ورشة الرسم وتفضيل أدهم لمسك الفرشاة الثلاثي ومزج الألوان اليوم.',
    suggestedAction: 'تجهيز مسار خيوط ملونة يتبعها الطفل بنقل خرزات خشبية بالملقط الخفيف في ركن الفنون.',
    homeExtension: 'نشاط منزلي: تشكيل أشكال هندسية بالصلصال الطبيعي مع الوالدين لمدة 10 دقائق.',
    approved: false,
  },
  {
    id: 'rec-2',
    title: 'هندسة الجسور الخشبية المشتركة',
    category: 'الذكاء المكاني والتعاون',
    skillTarget: 'تطوير التخطيط المكاني والمشاركة الاجتماعية مع الزملاء',
    evidence: 'استناداً إلى نجاح أدهم في بناء البرج الخشبي بعد 3 محاولات ورغبته في مشاركة الإنجاز مع أقرانه.',
    suggestedAction: 'دعوة أدهم ليكون قائد مجموعة صغيرة لتصميم "جسر الروضة الذكي" من المكعبات المتوازنة.',
    homeExtension: 'نشاط منزلي: إشراك الطفل في ترتيب أواني المطبخ الخفيفة أو الألعاب بالتسلسل الحجمي.',
    approved: false,
  },
];

export interface AIRecommendationsCardProps {
  childName?: string;
  className?: string;
  compact?: boolean;
}

export const AIRecommendationsCard: React.FC<AIRecommendationsCardProps> = ({
  childName = 'أدهم الرفاعي',
  className = '',
  compact = false,
}) => {
  const [recommendations, setRecommendations] = useState<RecommendationItem[]>(DEFAULT_RECOMMENDATIONS);
  const [expandedId, setExpandedId] = useState<string | null>('rec-1');
  const [approvingState, setApprovingState] = useState<Record<string, ButtonState>>({});
  const [parentNotes, setParentNotes] = useState<Record<string, string>>({});

  const handleApprove = (rec: RecommendationItem) => {
    setApprovingState((prev) => ({ ...prev, [rec.id]: 'loading' }));

    setTimeout(() => {
      // Play cheerful Web Audio chime!
      soundService.playCheerfulChime();

      setRecommendations((prev) =>
        prev.map((r) => (r.id === rec.id ? { ...r, approved: true } : r))
      );
      setApprovingState((prev) => ({ ...prev, [rec.id]: 'success' }));

      setTimeout(() => {
        setApprovingState((prev) => ({ ...prev, [rec.id]: 'idle' }));
      }, 2500);
    }, 600);
  };

  const handlePlaySoundTest = () => {
    soundService.playCheerfulChime();
  };

  return (
    <div
      className={`rounded-3xl border border-emerald-500/30 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 p-4 sm:p-6 shadow-xl relative overflow-hidden ${className}`}
      aria-labelledby="ai-card-title"
    >
      {/* Decorative ambient aura */}
      <div className="absolute top-0 end-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 flex items-center justify-center shrink-0 shadow-sm">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 id="ai-card-title" className="text-sm sm:text-base font-bold text-white tracking-tight">
                التوصيات التنموية الذكية المخصصة
              </h3>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-500/30">
                {childName}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              تحليل تربوي آلي مستند إلى ملاحظات اليوم ودفتر المتابعة
            </p>
          </div>
        </div>

        {/* AI Disclaimer & Audio Preview Badge */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handlePlaySoundTest}
            title="معاينة نغمة الإشعار المبهجة (Do-Mi-Sol)"
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-emerald-300 text-[11px] font-medium border border-slate-700 transition cursor-pointer"
          >
            <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">نغمة النجاح</span>
          </button>

          <span className="text-[10px] text-emerald-300/90 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-xl font-medium">
            مساعد ذكي خاضع للمراجعة
          </span>
        </div>
      </div>

      {/* Mandatory Human-In-The-Loop Attribution Notice */}
      <div className="mt-3.5 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
        <span className="leading-relaxed">
          <strong className="text-emerald-300 font-semibold">[اقتراح من الذكاء الاصطناعي]:</strong> يُعرض للاسترشاد التربوي ويتطلب اعتماد المعلمة أو ولي الأمر لتثبيته في خطة الطفل النمائية.
        </span>
      </div>

      {/* Recommendations List */}
      <div className="mt-4 space-y-3">
        {recommendations.map((rec) => {
          const isExpanded = expandedId === rec.id;
          const currentBtnState = approvingState[rec.id] || 'idle';

          return (
            <div
              key={rec.id}
              className={`rounded-2xl border transition-all ${
                rec.approved
                  ? 'bg-emerald-950/30 border-emerald-500/40 shadow-sm'
                  : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Card Summary Header */}
              <div
                onClick={() => setExpandedId(isExpanded ? null : rec.id)}
                className="p-3.5 sm:p-4 flex items-center justify-between gap-3 cursor-pointer select-none"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                      rec.approved
                        ? 'bg-emerald-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {rec.approved ? <Check className="w-4 h-4 stroke-[3]" /> : <Lightbulb className="w-4 h-4 text-emerald-400" />}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs sm:text-sm font-bold text-white truncate">
                        {rec.title}
                      </h4>
                      {rec.approved && (
                        <span className="text-[10px] text-emerald-300 font-bold bg-emerald-950 px-2 py-0.5 rounded-md border border-emerald-500/30">
                          معتمد في الخطة ✓
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 truncate pt-0.5">
                      {rec.category} · {rec.skillTarget}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-slate-400">
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </span>
                </div>
              </div>

              {/* Expanded Details Body */}
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.18 }}
                    className="px-4 pb-4 pt-1 space-y-3 border-t border-slate-800/80 text-xs"
                  >
                    {/* Evidence & Context */}
                    <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
                      <div className="flex items-center gap-1.5 font-bold text-slate-300 text-[11px]">
                        <FileText className="w-3.5 h-3.5 text-emerald-400" />
                        <span>سياق الملاحظة الميدانية (Evidence):</span>
                      </div>
                      <p className="text-slate-400 text-xs leading-relaxed">{rec.evidence}</p>
                    </div>

                    {/* Classroom Activity */}
                    <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
                      <div className="flex items-center gap-1.5 font-bold text-emerald-300 text-[11px]">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                        <span>النشاط المقترح داخل الروضة:</span>
                      </div>
                      <p className="text-slate-200 text-xs leading-relaxed">{rec.suggestedAction}</p>
                    </div>

                    {/* Home Extension */}
                    {!compact && (
                      <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
                        <div className="flex items-center gap-1.5 font-bold text-teal-300 text-[11px]">
                          <Heart className="w-3.5 h-3.5 text-teal-400" />
                          <span>التكامل الأسري المقترح (في المنزل):</span>
                        </div>
                        <p className="text-slate-300 text-xs leading-relaxed">{rec.homeExtension}</p>
                      </div>
                    )}

                    {/* Optional Note field */}
                    <div>
                      <input
                        type="text"
                        value={parentNotes[rec.id] || ''}
                        onChange={(e) =>
                          setParentNotes((prev) => ({ ...prev, [rec.id]: e.target.value }))
                        }
                        placeholder="ملاحظة أو تعديل المعلمة قبل الاعتماد..."
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                      />
                    </div>

                    {/* Action Approval Button */}
                    <div className="pt-2 flex items-center justify-end gap-2">
                      <DynamicButton
                        type="button"
                        state={currentBtnState}
                        variant={rec.approved ? 'secondary' : 'emerald'}
                        size="md"
                        onClick={() => handleApprove(rec)}
                        loadingText="جارٍ الاعتماد والتسجيل..."
                        successText="تم الاعتماد وسماع نغمة الإنجاز! 🔔"
                        icon={<CheckCircle2 className="w-4 h-4 stroke-[2.2]" />}
                      >
                        {rec.approved ? 'إعادة اعتماد التوصية' : 'اعتماد التوصية وإدراجها بالخطة'}
                      </DynamicButton>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  );
};
