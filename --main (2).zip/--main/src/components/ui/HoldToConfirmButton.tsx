import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, CheckCircle2, ShieldAlert } from 'lucide-react';

export interface HoldToConfirmButtonProps {
  onConfirm: () => void;
  holdDuration?: number; // duration in ms, default 2000ms
  idleText?: string;
  holdingText?: string;
  confirmedText?: string;
  hintText?: string;
  variant?: 'danger' | 'warning' | 'primary' | 'emerald';
  icon?: React.ReactNode;
  disabled?: boolean;
  className?: string;
  fullWidth?: boolean;
}

export const HoldToConfirmButton: React.FC<HoldToConfirmButtonProps> = ({
  onConfirm,
  holdDuration = 2000,
  idleText = 'اضغط باستمرار للتأكيد',
  holdingText = 'تابع الضغط...',
  confirmedText = 'تم التأكيد بنجاح!',
  hintText = 'اضغط باستمرار لمدة ثانيتين',
  variant = 'danger',
  icon,
  disabled = false,
  className = '',
  fullWidth = false,
}) => {
  const [progress, setProgress] = useState<number>(0);
  const [isHolding, setIsHolding] = useState<boolean>(false);
  const [isConfirmed, setIsConfirmed] = useState<boolean>(false);

  const timerRef = useRef<number | null>(null);
  const startTimeRef = useRef<number | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const resetHold = useCallback(() => {
    if (timerRef.current) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (animationFrameRef.current) {
      window.cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    setIsHolding(false);
    setProgress(0);
    startTimeRef.current = null;
  }, []);

  const handleComplete = useCallback(() => {
    setIsConfirmed(true);
    setProgress(100);
    setIsHolding(false);
    onConfirm();

    // Reset back after 1.8s
    setTimeout(() => {
      setIsConfirmed(false);
      setProgress(0);
    }, 1800);
  }, [onConfirm]);

  const updateProgress = useCallback(() => {
    if (!startTimeRef.current) return;
    const elapsed = Date.now() - startTimeRef.current;
    const currentProgress = Math.min((elapsed / holdDuration) * 100, 100);
    setProgress(currentProgress);

    if (elapsed < holdDuration) {
      animationFrameRef.current = window.requestAnimationFrame(updateProgress);
    } else {
      handleComplete();
    }
  }, [holdDuration, handleComplete]);

  const startHold = useCallback(
    (e?: React.SyntheticEvent) => {
      if (disabled || isConfirmed) return;
      if (e) {
        // Prevent default text selection or context menu on mobile touch
        if (e.type === 'touchstart') {
          // keep touch handling smooth
        }
      }
      setIsHolding(true);
      startTimeRef.current = Date.now();
      animationFrameRef.current = window.requestAnimationFrame(updateProgress);
    },
    [disabled, isConfirmed, updateProgress]
  );

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
      if (animationFrameRef.current) window.cancelAnimationFrame(animationFrameRef.current);
    };
  }, []);

  // Keyboard accessibility: hold Space or Enter
  const handleKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if ((e.key === ' ' || e.key === 'Enter') && !isHolding && !disabled && !isConfirmed) {
      e.preventDefault();
      startHold();
    }
  };

  const handleKeyUp = (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if ((e.key === ' ' || e.key === 'Enter') && isHolding) {
      e.preventDefault();
      resetHold();
    }
  };

  const colorConfig = {
    danger: {
      bg: 'bg-rose-950/70 hover:bg-rose-950/90 border border-rose-500/40 text-rose-200',
      fill: 'bg-gradient-to-r from-rose-600 to-rose-500',
      ring: 'focus-visible:ring-rose-500',
      glow: 'shadow-lg shadow-rose-950/50',
    },
    warning: {
      bg: 'bg-amber-950/70 hover:bg-amber-950/90 border border-amber-500/40 text-amber-200',
      fill: 'bg-gradient-to-r from-amber-600 to-amber-500',
      ring: 'focus-visible:ring-amber-500',
      glow: 'shadow-lg shadow-amber-950/50',
    },
    primary: {
      bg: 'bg-teal-950/70 hover:bg-teal-950/90 border border-teal-500/40 text-teal-200',
      fill: 'bg-gradient-to-r from-teal-600 to-teal-500',
      ring: 'focus-visible:ring-teal-500',
      glow: 'shadow-lg shadow-teal-950/50',
    },
    emerald: {
      bg: 'bg-emerald-950/70 hover:bg-emerald-950/90 border border-emerald-500/40 text-emerald-200',
      fill: 'bg-gradient-to-r from-emerald-600 to-emerald-500',
      ring: 'focus-visible:ring-emerald-500',
      glow: 'shadow-lg shadow-emerald-950/50',
    },
  }[variant];

  return (
    <div className={`relative flex flex-col items-center gap-1 ${fullWidth ? 'w-full' : 'inline-flex'}`}>
      <motion.button
        type="button"
        onMouseDown={startHold}
        onMouseUp={resetHold}
        onMouseLeave={resetHold}
        onTouchStart={startHold}
        onTouchEnd={resetHold}
        onTouchCancel={resetHold}
        onKeyDown={handleKeyDown}
        onKeyUp={handleKeyUp}
        disabled={disabled}
        aria-label={`${idleText}. ${hintText}`}
        aria-valuenow={Math.round(progress)}
        aria-valuemin={0}
        aria-valuemax={100}
        role="button"
        animate={isHolding ? { scale: 0.98 } : { scale: 1 }}
        transition={{ duration: 0.1 }}
        className={`relative overflow-hidden h-12 px-5 min-h-[44px] rounded-xl font-bold text-xs sm:text-sm select-none cursor-pointer transition-colors outline-none focus-visible:ring-2 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-950 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center ${
          colorConfig.bg
        } ${colorConfig.ring} ${colorConfig.glow} ${fullWidth ? 'w-full' : ''} ${className}`}
      >
        {/* Animated Progress Fill Bar (RTL right-to-left) */}
        <motion.div
          className={`absolute inset-0 start-0 ${colorConfig.fill} pointer-events-none opacity-90`}
          style={{
            width: `${progress}%`,
            transition: isHolding ? 'none' : 'width 0.25s ease-out',
          }}
        />

        {/* Shimmer pulse effect when holding */}
        {isHolding && (
          <div className="absolute inset-0 bg-white/10 animate-pulse pointer-events-none" />
        )}

        {/* Content text & status */}
        <div className="relative z-10 flex items-center gap-2.5">
          <AnimatePresence mode="wait">
            {isConfirmed ? (
              <motion.span
                key="confirmed"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-2 text-white font-extrabold"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                <span>{confirmedText}</span>
              </motion.span>
            ) : isHolding ? (
              <motion.span
                key="holding"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-2 text-white font-bold"
              >
                <AlertCircle className="w-4 h-4 animate-spin" />
                <span>{holdingText}</span>
                <span className="font-mono text-xs text-white/90 font-black">
                  {Math.round(progress)}%
                </span>
              </motion.span>
            ) : (
              <motion.span
                key="idle"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-2 text-inherit"
              >
                {icon || <ShieldAlert className="w-4 h-4 shrink-0 text-inherit" />}
                <span>{idleText}</span>
              </motion.span>
            )}
          </AnimatePresence>
        </div>
      </motion.button>

      {/* Subtle Hint Text */}
      <span className="text-[11px] text-slate-400 font-medium">
        {isHolding ? 'استمر بالضغط حتى يكتمل الشريط' : hintText}
      </span>
    </div>
  );
};
