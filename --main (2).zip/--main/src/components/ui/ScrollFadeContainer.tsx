import React, { useRef, useState, useEffect, useCallback } from 'react';

export interface ScrollFadeContainerProps {
  children: React.ReactNode;
  orientation?: 'horizontal' | 'vertical' | 'both';
  fadeSize?: number; // Size in px for the fade mask/gradient
  fadeColor?: string; // Hex or CSS color to match parent surface, default slate-950 #020617
  className?: string;
  contentClassName?: string;
}

export const ScrollFadeContainer: React.FC<ScrollFadeContainerProps> = ({
  children,
  orientation = 'horizontal',
  fadeSize = 32,
  fadeColor = '#020617', // slate-950 default
  className = '',
  contentClassName = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  const [canScrollStart, setCanScrollStart] = useState<boolean>(false);
  const [canScrollEnd, setCanScrollEnd] = useState<boolean>(false);
  const [canScrollTop, setCanScrollTop] = useState<boolean>(false);
  const [canScrollBottom, setCanScrollBottom] = useState<boolean>(false);

  const updateScrollIndicators = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;

    if (orientation === 'horizontal' || orientation === 'both') {
      const scrollWidth = el.scrollWidth;
      const clientWidth = el.clientWidth;
      const scrollLeft = Math.abs(el.scrollLeft);
      const maxScroll = scrollWidth - clientWidth;

      // In RTL or LTR, account for threshold
      const hasHorizontalScroll = maxScroll > 4;
      setCanScrollStart(hasHorizontalScroll && scrollLeft > 5);
      setCanScrollEnd(hasHorizontalScroll && scrollLeft < maxScroll - 5);
    }

    if (orientation === 'vertical' || orientation === 'both') {
      const scrollHeight = el.scrollHeight;
      const clientHeight = el.clientHeight;
      const scrollTop = el.scrollTop;
      const maxScrollY = scrollHeight - clientHeight;

      const hasVerticalScroll = maxScrollY > 4;
      setCanScrollTop(hasVerticalScroll && scrollTop > 5);
      setCanScrollBottom(hasVerticalScroll && scrollTop < maxScrollY - 5);
    }
  }, [orientation]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    updateScrollIndicators();

    const handleScroll = () => {
      updateScrollIndicators();
    };

    el.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', updateScrollIndicators);

    // Mutation observer to handle dynamic content additions
    const observer = new MutationObserver(() => {
      updateScrollIndicators();
    });
    observer.observe(el, { childList: true, subtree: true });

    return () => {
      el.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', updateScrollIndicators);
      observer.disconnect();
    };
  }, [updateScrollIndicators]);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Horizontal Start Edge Fade (Right edge in RTL) */}
      {(orientation === 'horizontal' || orientation === 'both') && canScrollStart && (
        <div
          aria-hidden="true"
          className="absolute inset-y-0 start-0 z-20 pointer-events-none transition-opacity duration-200"
          style={{
            width: `${fadeSize}px`,
            background: `linear-gradient(to right, ${fadeColor}, transparent)`,
          }}
        />
      )}

      {/* Horizontal End Edge Fade (Left edge in RTL) */}
      {(orientation === 'horizontal' || orientation === 'both') && canScrollEnd && (
        <div
          aria-hidden="true"
          className="absolute inset-y-0 end-0 z-20 pointer-events-none transition-opacity duration-200"
          style={{
            width: `${fadeSize}px`,
            background: `linear-gradient(to left, ${fadeColor}, transparent)`,
          }}
        />
      )}

      {/* Vertical Top Edge Fade */}
      {(orientation === 'vertical' || orientation === 'both') && canScrollTop && (
        <div
          aria-hidden="true"
          className="absolute inset-x-0 top-0 z-20 pointer-events-none transition-opacity duration-200"
          style={{
            height: `${fadeSize}px`,
            background: `linear-gradient(to bottom, ${fadeColor}, transparent)`,
          }}
        />
      )}

      {/* Vertical Bottom Edge Fade */}
      {(orientation === 'vertical' || orientation === 'both') && canScrollBottom && (
        <div
          aria-hidden="true"
          className="absolute inset-x-0 bottom-0 z-20 pointer-events-none transition-opacity duration-200"
          style={{
            height: `${fadeSize}px`,
            background: `linear-gradient(to top, ${fadeColor}, transparent)`,
          }}
        />
      )}

      {/* Actual Scrollable Content Area */}
      <div
        ref={containerRef}
        className={`w-full h-full no-scrollbar overflow-auto ${
          orientation === 'horizontal'
            ? 'overflow-x-auto overflow-y-hidden'
            : orientation === 'vertical'
            ? 'overflow-y-auto overflow-x-hidden'
            : 'overflow-auto'
        } ${contentClassName}`}
      >
        {children}
      </div>
    </div>
  );
};
