import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UploadCloud, Image as ImageIcon, X, Check, AlertCircle, Sparkles } from 'lucide-react';
import { DynamicButton } from './DynamicButton';

export interface UploadedFileItem {
  id: string;
  file: File;
  previewUrl: string;
  name: string;
  sizeMb: string;
}

export interface MagneticDropZoneProps {
  onFilesAccepted?: (files: File[]) => void;
  maxFiles?: number;
  maxSizeMb?: number;
  allowedTypes?: string[];
  title?: string;
  subtitle?: string;
  className?: string;
}

export const MagneticDropZone: React.FC<MagneticDropZoneProps> = ({
  onFilesAccepted,
  maxFiles = 5,
  maxSizeMb = 10,
  allowedTypes = ['image/jpeg', 'image/png', 'image/webp'],
  title = 'اسحب صور الأنشطة اليومية وأفلتها هنا',
  subtitle = 'أو انقر لاختيار الصور من جهازك (PNG, JPG, WEBP حتى 10MB)',
  className = '',
}) => {
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [filesList, setFilesList] = useState<UploadedFileItem[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [uploadState, setUploadState] = useState<'idle' | 'loading' | 'success'>('idle');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateAndAddFiles = (incomingFiles: FileList | File[]) => {
    setErrorMessage(null);
    const validItems: UploadedFileItem[] = [];

    const fileArray = Array.from(incomingFiles);

    if (filesList.length + fileArray.length > maxFiles) {
      setErrorMessage(`الحد الأقصى المسموح به هو ${maxFiles} صور دفعة واحدة.`);
      return;
    }

    for (const file of fileArray) {
      if (!allowedTypes.includes(file.type)) {
        setErrorMessage(`نوع الملف غير مدعوم (${file.name}). يرجى رفع صور JPG أو PNG أو WEBP.`);
        continue;
      }
      if (file.size > maxSizeMb * 1024 * 1024) {
        setErrorMessage(`حجم الصورة كبير جداً (${(file.size / (1024 * 1024)).toFixed(1)}MB). الحد الأقصى هو ${maxSizeMb}MB.`);
        continue;
      }

      const previewUrl = URL.createObjectURL(file);
      validItems.push({
        id: `${file.name}-${Date.now()}-${Math.random()}`,
        file,
        previewUrl,
        name: file.name,
        sizeMb: (file.size / (1024 * 1024)).toFixed(2),
      });
    }

    if (validItems.length > 0) {
      setFilesList((prev) => [...prev, ...validItems]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      validateAndAddFiles(e.dataTransfer.files);
    }
  };

  const removeFile = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFilesList((prev) => {
      const target = prev.find((item) => item.id === id);
      if (target) URL.revokeObjectURL(target.previewUrl);
      return prev.filter((item) => item.id !== id);
    });
  };

  const handleUploadSubmit = () => {
    if (filesList.length === 0) return;
    setUploadState('loading');

    setTimeout(() => {
      setUploadState('success');
      if (onFilesAccepted) {
        onFilesAccepted(filesList.map((f) => f.file));
      }

      setTimeout(() => {
        setUploadState('idle');
        setFilesList([]);
      }, 1500);
    }, 1200);
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Drop Zone Box */}
      <motion.div
        animate={{
          scale: isDragging ? 1.015 : 1,
          borderColor: isDragging ? '#10b981' : '#334155',
          backgroundColor: isDragging ? 'rgba(6, 78, 59, 0.25)' : 'rgba(15, 23, 42, 0.8)',
        }}
        transition={{ type: 'spring', stiffness: 350, damping: 25 }}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className="relative border-2 border-dashed rounded-2xl p-6 sm:p-8 text-center cursor-pointer overflow-hidden transition-shadow shadow-lg hover:shadow-emerald-950/40 group backdrop-blur-sm"
      >
        <input
          ref={fileInputRef}
          type="file"
          accept={allowedTypes.join(',')}
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files) {
              validateAndAddFiles(e.target.files);
              e.target.value = '';
            }
          }}
        />

        {/* Ambient subtle glow when dragging */}
        {isDragging && (
          <div className="absolute inset-0 bg-radial from-emerald-500/20 to-transparent pointer-events-none animate-pulse" />
        )}

        <div className="relative z-10 flex flex-col items-center gap-3">
          <motion.div
            animate={isDragging ? { y: -4, scale: 1.1 } : { y: 0, scale: 1 }}
            className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-colors shadow-md ${
              isDragging
                ? 'bg-emerald-500 text-slate-950'
                : 'bg-emerald-950/70 text-emerald-400 border border-emerald-500/30 group-hover:border-emerald-500/60'
            }`}
          >
            {isDragging ? (
              <Sparkles className="w-7 h-7" />
            ) : (
              <UploadCloud className="w-7 h-7 stroke-[2]" />
            )}
          </motion.div>

          <div className="space-y-1">
            <h4 className="text-sm sm:text-base font-bold text-white tracking-tight">
              {isDragging ? 'أفلت الصور هنا فوراً!' : title}
            </h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
              {subtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            <span className="text-[11px] bg-slate-900/90 text-slate-300 px-2.5 py-1 rounded-md border border-slate-800">
              🖼️ الحد الأقصى: {maxFiles} صور
            </span>
            <span className="text-[11px] bg-slate-900/90 text-slate-300 px-2.5 py-1 rounded-md border border-slate-800">
              🔒 تشفير وحفظ في الخزينة المعتمدة
            </span>
          </div>
        </div>
      </motion.div>

      {/* Error Message */}
      {errorMessage && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Queued Photos Preview Grid */}
      <AnimatePresence>
        {filesList.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="space-y-3 pt-2"
          >
            <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
              <span className="flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
                <span>الصور المحددة للرفع ({filesList.length})</span>
              </span>
              <button
                type="button"
                onClick={() => setFilesList([])}
                className="text-[11px] text-slate-400 hover:text-rose-400 transition-colors"
              >
                مسح الكل
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {filesList.map((item) => (
                <div
                  key={item.id}
                  className="group relative rounded-xl overflow-hidden border border-slate-800 bg-slate-900 shadow-sm"
                >
                  <img
                    src={item.previewUrl}
                    alt={item.name}
                    className="w-full h-24 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end justify-between p-2">
                    <span className="text-[10px] text-white truncate max-w-[80%] font-medium">
                      {item.name}
                    </span>
                    <button
                      type="button"
                      onClick={(e) => removeFile(item.id, e)}
                      aria-label="حذف الصورة"
                      className="w-6 h-6 rounded-full bg-slate-900/90 hover:bg-rose-600 text-white flex items-center justify-center transition-colors"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2">
              <DynamicButton
                state={uploadState}
                variant="emerald"
                size="md"
                fullWidth
                onClick={handleUploadSubmit}
                loadingText="جارٍ تشفير وحفظ الصور في الخزينة..."
                successText="تم حفظ الصور بنجاح في ملف الطفل!"
                icon={<Check className="w-4 h-4 stroke-[2.5]" />}
              >
                حفظ ونشر الصور المحددة ({filesList.length})
              </DynamicButton>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
