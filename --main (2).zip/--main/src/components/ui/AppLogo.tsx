import React from 'react';

export type LogoSize = 'sm' | 'md' | 'lg' | 'xl';
export type LogoVariant = 'dark' | 'light' | 'emerald';

export interface AppLogoProps {
  size?: LogoSize;
  variant?: LogoVariant;
  showText?: boolean;
  textPosition?: 'right' | 'bottom';
  className?: string;
  onClick?: () => void;
}

export const AppLogo: React.FC<AppLogoProps> = ({
  size = 'md',
  variant = 'dark',
  showText = true,
  textPosition = 'right',
  className = '',
  onClick,
}) => {
  // Dimensions map
  const sizeMap: Record<LogoSize, { badge: string; svg: number; title: string; subtitle: string }> = {
    sm: {
      badge: 'w-7 h-7 rounded-lg',
      svg: 28,
      title: 'text-xs',
      subtitle: 'text-[9px]',
    },
    md: {
      badge: 'w-9 h-9 rounded-xl',
      svg: 36,
      title: 'text-sm font-bold',
      subtitle: 'text-[10px]',
    },
    lg: {
      badge: 'w-11 h-11 rounded-2xl',
      svg: 44,
      title: 'text-base font-extrabold',
      subtitle: 'text-xs',
    },
    xl: {
      badge: 'w-14 h-14 rounded-2xl',
      svg: 56,
      title: 'text-lg font-black',
      subtitle: 'text-xs',
    },
  };

  const currentSize = sizeMap[size];

  // Theme styles for text
  const textColor = {
    dark: {
      title: 'text-white',
      subtitle: 'text-emerald-400',
    },
    light: {
      title: 'text-slate-900',
      subtitle: 'text-teal-700',
    },
    emerald: {
      title: 'text-emerald-300',
      subtitle: 'text-teal-400',
    },
  }[variant];

  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center gap-2.5 select-none ${onClick ? 'cursor-pointer' : ''} ${
        textPosition === 'bottom' ? 'flex-col items-center text-center' : 'flex-row'
      } ${className}`}
      role="img"
      aria-label="شعار روضة الأدهم الذكية — درع الأمان ورأس الأدهم ونجمة الذكاء"
    >
      {/* Official Emblem Badge Container */}
      <div
        className={`relative ${currentSize.badge} bg-gradient-to-br from-slate-900 via-emerald-950 to-teal-900 border border-emerald-500/40 p-1 flex items-center justify-center shrink-0 shadow-md shadow-emerald-950/50 overflow-hidden group`}
      >
        {/* Subtle Ambient Radial Highlight */}
        <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/15 via-transparent to-teal-400/20 pointer-events-none" />

        {/* Master SVG Emblem */}
        <svg
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-sm transition-transform duration-300 group-hover:scale-105"
        >
          <defs>
            {/* Outer Shield Gradient */}
            <linearGradient id="shieldGrad" x1="12" y1="8" x2="88" y2="92" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#34d399" />
              <stop offset="50%" stopColor="#059669" />
              <stop offset="100%" stopColor="#047857" />
            </linearGradient>

            {/* Inner Shield Fill Gradient */}
            <linearGradient id="shieldInnerGrad" x1="50" y1="12" x2="50" y2="88" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#064e3b" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#022c22" stopOpacity="0.95" />
            </linearGradient>

            {/* Adham Stallion Metallic Gold/Emerald Accent Gradient */}
            <linearGradient id="horseGrad" x1="30" y1="20" x2="75" y2="76" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="40%" stopColor="#a7f3d0" />
              <stop offset="100%" stopColor="#34d399" />
            </linearGradient>

            {/* Star Sparkle Gradient */}
            <linearGradient id="starGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="100%" stopColor="#34d399" />
            </linearGradient>
          </defs>

          {/* 1. Shield Boundary (حماية وأمان الروضة) */}
          <path
            d="M50 7 C68 7, 85 13, 87 27 C89 55, 72 77, 50 93 C28 77, 11 55, 13 27 C15 13, 32 7, 50 7 Z"
            fill="url(#shieldInnerGrad)"
            stroke="url(#shieldGrad)"
            strokeWidth="3.5"
            strokeLinejoin="round"
          />

          {/* Hairline Inner Shield Security Inset */}
          <path
            d="M50 14 C64 14, 78 19, 80 30 C82 52, 67 71, 50 84 C33 71, 18 52, 20 30 C22 19, 36 14, 50 14 Z"
            fill="none"
            stroke="#10b981"
            strokeWidth="1"
            strokeOpacity="0.35"
          />

          {/* 2. Adham Stallion Profile Silhouette (الحصان الأدهم - أصالة، كبرياء، قوة وذكاء) */}
          {/* Head & Arched Neck Profile */}
          <path
            d="M33 76 C35 62, 38 50, 44 42 C46 39, 45 31, 48 24 C49.5 20.5, 53.5 21, 54.5 25.5 C55.5 30, 56.5 31.5, 61 33 C66 34.5, 72 38, 73 43 C74 46.5, 70 49, 66 50 C61 51, 58 48.5, 55 52 C52 55.5, 50 63, 51.5 76 C45.5 76, 39 76, 33 76 Z"
            fill="url(#horseGrad)"
          />

          {/* Mane Accent Flow Lines (شعر العرف الرشيق) */}
          <path
            d="M44 32 C41 36, 39 42, 38 48"
            stroke="#10b981"
            strokeWidth="2"
            strokeLinecap="round"
          />
          <path
            d="M47 26 C43 32, 40 40, 39 46"
            stroke="#a7f3d0"
            strokeWidth="1.5"
            strokeLinecap="round"
          />

          {/* Stallion Eye (عين أدهم الذكية) */}
          <circle cx="58" cy="40" r="2.2" fill="#064e3b" />
          <circle cx="58.6" cy="39.4" r="0.8" fill="#ffffff" />

          {/* Muzzle Detail */}
          <path
            d="M68 47 C66 48, 64 47.5, 63 46"
            stroke="#064e3b"
            strokeWidth="1.2"
            strokeLinecap="round"
          />

          {/* 3. Shining Smart Star (نجمة الذكاء المتألقة) */}
          <path
            d="M74 20 Q74 26, 80 26 Q74 26, 74 32 Q74 26, 68 26 Q74 26, 74 20 Z"
            fill="url(#starGrad)"
          />
          <circle cx="74" cy="26" r="1.5" fill="#ffffff" />

          {/* Secondary Mini Smart Sparkle */}
          <path
            d="M30 32 Q30 35, 33 35 Q30 35, 30 38 Q30 35, 27 35 Q30 35, 30 32 Z"
            fill="#a7f3d0"
            opacity="0.8"
          />
        </svg>
      </div>

      {/* Official Typography Label */}
      {showText && (
        <div className="flex flex-col text-start leading-tight">
          <span className={`tracking-tight font-extrabold ${currentSize.title} ${textColor.title}`}>
            روضة الأدهم الذكية
          </span>
          <span className={`font-medium ${currentSize.subtitle} ${textColor.subtitle} tracking-normal`}>
            Rawdaty Smart · منظومة الرعاية والذكاء التربوي
          </span>
        </div>
      )}
    </div>
  );
};
