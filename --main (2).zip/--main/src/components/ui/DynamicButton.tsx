import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, CheckCircle2 } from 'lucide-react';

export type ButtonState = 'idle' | 'loading' | 'success';
export type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'outline' | 'ghost' | 'emerald';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface DynamicButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  state?: ButtonState;
  variant?: ButtonVariant;
  size?: ButtonSize;
  loadingText?: string;
  successText?: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
  fullWidth?: boolean;
}

const variantStyles: Record<ButtonVariant, string> = {
  primary: 'bg-teal-700 hover:bg-teal-800 active:bg-teal-900 text-white shadow-xs focus-visible:ring-teal-600',
  emerald: 'bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-slate-950 font-bold shadow-md shadow-emerald-500/20 focus-visible:ring-emerald-400',
  secondary: 'bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-slate-100 border border-slate-700 focus-visible:ring-slate-500',
  danger: 'bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white shadow-xs focus-visible:ring-rose-500',
  outline: 'border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 focus-visible:ring-teal-600',
  ghost: 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 focus-visible:ring-teal-600',
};

const sizeStyles: Record<ButtonSize, string> = {
  sm: 'h-9 px-3 text-xs gap-1.5 rounded-lg',
  md: 'h-11 px-4 text-xs sm:text-sm gap-2 rounded-xl min-h-[44px]',
  lg: 'h-12 px-6 text-sm sm:text-base gap-2.5 rounded-xl min-h-[48px]',
};

export const DynamicButton: React.FC<DynamicButtonProps> = ({
  state = 'idle',
  variant = 'emerald',
  size = 'md',
  loadingText = 'جارٍ المعالجة...',
  successText = 'تمت العملية بنجاح!',
  icon,
  children,
  fullWidth = false,
  disabled,
  className = '',
  onClick,
  ...props
}) => {
  const isInteractive = state === 'idle' && !disabled;

  return (
    <motion.button
      whileTap={isInteractive ? { scale: 0.98 } : undefined}
      transition={{ duration: 0.12, ease: [0.16, 1, 0.3, 1] }}
      disabled={!isInteractive}
      onClick={isInteractive ? onClick : undefined}
      aria-busy={state === 'loading'}
      aria-live="polite"
      className={`relative inline-flex items-center justify-center font-semibold overflow-hidden transition-colors outline-none focus-visible:ring-2 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-950 disabled:opacity-60 disabled:cursor-not-allowed select-none ${
        variantStyles[variant]
      } ${sizeStyles[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...props}
    >
      <AnimatePresence mode="wait" initial={false}>
        {state === 'idle' && (
          <motion.span
            key="idle"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.15 }}
            className="inline-flex items-center gap-2 whitespace-nowrap"
          >
            {icon && <span className="shrink-0">{icon}</span>}
            <span>{children}</span>
          </motion.span>
        )}

        {state === 'loading' && (
          <motion.span
            key="loading"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.15 }}
            className="inline-flex items-center gap-2 whitespace-nowrap"
          >
            <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
            <span>{loadingText}</span>
          </motion.span>
        )}

        {state === 'success' && (
          <motion.span
            key="success"
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.85 }}
            transition={{ duration: 0.2, type: 'spring', stiffness: 400, damping: 25 }}
            className="inline-flex items-center gap-2 whitespace-nowrap text-white font-bold"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" aria-hidden="true" />
            <span>{successText}</span>
          </motion.span>
        )}
      </AnimatePresence>
    </motion.button>
  );
};
