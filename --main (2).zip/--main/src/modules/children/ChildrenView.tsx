import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Plus, Users, AlertCircle, RefreshCw, CheckCircle2 } from 'lucide-react';
import { useI18n } from '../../lib/i18n/I18nContext';
import { useAuth } from '../auth/AuthContext';
import { getKindergartenProfile } from '../kindergarten/kindergartenService';
import { getActiveClasses } from '../classes/classesService';
import { getActiveChildren } from './childrenService';
import type { Kindergarten, ClassRoom, Child } from '../../types/database';

import { KindergartenContextBanner } from '../classes/components/KindergartenContextBanner';
import { ChildrenToolbar } from './components/ChildrenToolbar';
import { ChildCard } from './components/ChildCard';
import { ChildCardSkeleton } from './components/ChildCardSkeleton';
import { CreateChildDrawer } from './components/CreateChildDrawer';
import { EditChildDrawer } from './components/EditChildDrawer';
import { ChildDetailsSheet } from './components/ChildDetailsSheet';
import { ArchiveChildDialog } from './components/ArchiveChildDialog';

export const ChildrenView: React.FC = () => {
  const { t } = useI18n();
  const { activeMembership } = useAuth();

  // Primary data states
  const [kindergarten, setKindergarten] = useState<Kindergarten | null>(null);
  const [classesList, setClassesList] = useState<ClassRoom[]>([]);
  const [childrenList, setChildrenList] = useState<Child[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Search & Filter local states
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedClassId, setSelectedClassId] = useState<string>('ALL');

  // Modal / Drawer / Sheet states
  const [createDrawerOpen, setCreateDrawerOpen] = useState<boolean>(false);
  const [editDrawerOpen, setEditDrawerOpen] = useState<boolean>(false);
  const [detailsSheetOpen, setDetailsSheetOpen] = useState<boolean>(false);
  const [archiveDialogOpen, setArchiveDialogOpen] = useState<boolean>(false);
  const [selectedChild, setSelectedChild] = useState<Child | null>(null);

  // Focus Restoration Tracking
  const lastActiveElementRef = useRef<HTMLElement | null>(null);
  const createButtonRef = useRef<HTMLButtonElement>(null);

  const activeKindergartenId = activeMembership?.kindergarten_id;

  // Load verified context, active classes, and enrolled children
  const loadData = useCallback(async () => {
    if (!activeKindergartenId) {
      setLoading(false);
      return;
    }

    setLoading(true);
    setErrorMessage(null);

    try {
      const [kResult, cResult, chResult] = await Promise.all([
        getKindergartenProfile(activeKindergartenId),
        getActiveClasses(activeKindergartenId),
        getActiveChildren(activeKindergartenId),
      ]);

      if (kResult.error) {
        setErrorMessage(kResult.error.message);
      } else {
        setKindergarten(kResult.data);
      }

      if (cResult.error) {
        setErrorMessage(cResult.error.message);
      } else {
        setClassesList(cResult.data || []);
      }

      if (chResult.error) {
        setErrorMessage(chResult.error.message);
      } else {
        setChildrenList(chResult.data || []);
      }
    } catch {
      setErrorMessage(t.children.errorNetworkOrServer);
    } finally {
      setLoading(false);
    }
  }, [activeKindergartenId, t.children.errorNetworkOrServer]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Display transient success notification
  const triggerSuccessToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => {
      setSuccessToast(null);
    }, 4000);
  };

  // Open Handlers with Focus Tracking
  const handleOpenCreateDrawer = () => {
    lastActiveElementRef.current = document.activeElement as HTMLElement;
    setCreateDrawerOpen(true);
  };

  const handleCloseCreateDrawer = () => {
    setCreateDrawerOpen(false);
    if (lastActiveElementRef.current) {
      lastActiveElementRef.current.focus();
    } else {
      createButtonRef.current?.focus();
    }
  };

  const handleOpenEditDrawer = (child: Child) => {
    lastActiveElementRef.current = document.activeElement as HTMLElement;
    setSelectedChild(child);
    setEditDrawerOpen(true);
  };

  const handleCloseEditDrawer = () => {
    setEditDrawerOpen(false);
    setSelectedChild(null);
    if (lastActiveElementRef.current) {
      lastActiveElementRef.current.focus();
    }
  };

  const handleOpenDetailsSheet = (child: Child) => {
    lastActiveElementRef.current = document.activeElement as HTMLElement;
    setSelectedChild(child);
    setDetailsSheetOpen(true);
  };

  const handleCloseDetailsSheet = () => {
    setDetailsSheetOpen(false);
    setSelectedChild(null);
    if (lastActiveElementRef.current) {
      lastActiveElementRef.current.focus();
    }
  };

  const handleOpenArchiveDialog = (child: Child) => {
    lastActiveElementRef.current = document.activeElement as HTMLElement;
    setSelectedChild(child);
    setArchiveDialogOpen(true);
  };

  const handleCloseArchiveDialog = () => {
    setArchiveDialogOpen(false);
    setSelectedChild(null);
    if (lastActiveElementRef.current) {
      lastActiveElementRef.current.focus();
    }
  };

  // Action Success Callbacks
  const handleCreateSuccess = (newChild: Child) => {
    handleCloseCreateDrawer();
    setChildrenList((prev) => [newChild, ...prev]);
    triggerSuccessToast(t.children.createSuccessMessage);
  };

  const handleEditSuccess = (updatedChild: Child) => {
    handleCloseEditDrawer();
    setChildrenList((prev) =>
      prev.map((c) => (c.id === updatedChild.id ? updatedChild : c))
    );
    triggerSuccessToast(t.children.editSuccessMessage);
  };

  const handleArchiveSuccess = (archivedChildId: string) => {
    handleCloseArchiveDialog();
    setChildrenList((prev) => prev.filter((c) => c.id !== archivedChildId));
    triggerSuccessToast(t.children.archiveSuccessMessage);
  };

  // Classes map for fast lookup
  const classesMap = new Map<string, ClassRoom>();
  classesList.forEach((c) => classesMap.set(c.id, c));

  // Client-side filtering
  const filteredChildren = childrenList.filter((child) => {
    // 1. Class filter
    if (selectedClassId !== 'ALL' && child.class_id !== selectedClassId) {
      return false;
    }

    // 2. Search query filter
    if (searchQuery.trim().length > 0) {
      const q = searchQuery.toLowerCase().trim();
      const fullName = `${child.first_name} ${child.last_name}`.toLowerCase();
      const emergencyName = child.emergency_contact_name.toLowerCase();
      const emergencyPhone = child.emergency_contact_phone.toLowerCase();

      return (
        fullName.includes(q) ||
        emergencyName.includes(q) ||
        emergencyPhone.includes(q)
      );
    }

    return true;
  });

  return (
    <div className="space-y-6">
      {/* Institutional Context Banner */}
      <KindergartenContextBanner kindergarten={kindergarten} loading={loading} />

      {/* Main Header with Primary Action Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200/80 pb-5">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            {t.children.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {t.children.subtitle}
          </p>
        </div>

        <button
          ref={createButtonRef}
          type="button"
          onClick={handleOpenCreateDrawer}
          disabled={loading || classesList.length === 0}
          className="h-11 px-4 sm:px-5 bg-teal-700 hover:bg-teal-800 active:bg-teal-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs hover:shadow-sm transition-all flex items-center justify-center gap-2 focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2 outline-none self-start sm:self-auto disabled:opacity-50 disabled:pointer-events-none min-h-[44px]"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" aria-hidden="true" />
          <span>{t.children.createChildAction}</span>
        </button>
      </div>

      {/* Transient Success Notification Toast */}
      {successToast && (
        <div
          className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl p-4 flex items-center justify-between shadow-xs animate-in fade-in slide-in-from-top-2 duration-200"
          role="status"
          aria-live="polite"
        >
          <div className="flex items-center gap-2.5 text-xs sm:text-sm font-semibold">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" aria-hidden="true" />
            <span>{successToast}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessToast(null)}
            className="text-emerald-700 hover:text-emerald-900 text-xs font-bold"
          >
            {t.classes.cancelAction}
          </button>
        </div>
      )}

      {/* Error State Banner */}
      {errorMessage && !loading && (
        <div
          className="bg-rose-50 border border-rose-200 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-rose-800"
          role="alert"
        >
          <div className="flex items-center gap-2.5 text-xs sm:text-sm font-medium">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" aria-hidden="true" />
            <span>{errorMessage}</span>
          </div>
          <button
            type="button"
            onClick={loadData}
            className="h-9 px-3.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 focus-visible:ring-2 focus-visible:ring-rose-500 outline-none shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{t.children.retryAction}</span>
          </button>
        </div>
      )}

      {/* Toolbar Controls */}
      <ChildrenToolbar
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedClassId={selectedClassId}
        onSelectClassId={setSelectedClassId}
        classesList={classesList}
        totalChildrenCount={childrenList.length}
        filteredChildrenCount={filteredChildren.length}
        onClearFilters={() => {
          setSearchQuery('');
          setSelectedClassId('ALL');
        }}
      />

      {/* Main Grid Content */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" aria-busy="true">
          {Array.from({ length: 6 }).map((_, idx) => (
            <ChildCardSkeleton key={idx} />
          ))}
        </div>
      ) : childrenList.length === 0 ? (
        /* Empty State: Zero Children */
        <div className="bg-white border border-slate-200 rounded-2xl p-8 sm:p-12 text-center max-w-lg mx-auto shadow-xs space-y-4">
          <div className="w-14 h-14 bg-teal-50 text-teal-700 rounded-2xl flex items-center justify-center mx-auto border border-teal-200/60 shadow-xs">
            <Users className="w-7 h-7" aria-hidden="true" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900">
              {t.children.noChildrenYetTitle}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-sm mx-auto">
              {t.children.noChildrenYetDesc}
            </p>
          </div>
          <button
            type="button"
            onClick={handleOpenCreateDrawer}
            disabled={classesList.length === 0}
            className="h-11 px-5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors inline-flex items-center gap-2 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none disabled:opacity-50"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" aria-hidden="true" />
            <span>{t.children.createChildAction}</span>
          </button>
        </div>
      ) : filteredChildren.length === 0 ? (
        /* Search/Filter No Results State */
        <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-8 text-center max-w-md mx-auto space-y-3">
          <p className="text-sm font-bold text-slate-800">
            {t.children.noSearchResults}
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setSelectedClassId('ALL');
            }}
            className="h-10 px-4 text-xs font-semibold text-teal-700 hover:text-teal-800 hover:bg-teal-50 rounded-lg transition-colors border border-teal-200 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none"
          >
            {t.children.clearFilters}
          </button>
        </div>
      ) : (
        /* Cards Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredChildren.map((child) => (
            <ChildCard
              key={child.id}
              child={child}
              classRoom={classesMap.get(child.class_id) || null}
              onViewDetails={handleOpenDetailsSheet}
              onEdit={handleOpenEditDrawer}
              onArchive={handleOpenArchiveDialog}
            />
          ))}
        </div>
      )}

      {/* Create Child Slide-over Drawer */}
      <CreateChildDrawer
        isOpen={createDrawerOpen}
        kindergartenId={activeKindergartenId || ''}
        classesList={classesList}
        onClose={handleCloseCreateDrawer}
        onSuccess={handleCreateSuccess}
      />

      {/* Edit Child Slide-over Drawer */}
      <EditChildDrawer
        isOpen={editDrawerOpen}
        child={selectedChild}
        classesList={classesList}
        onClose={handleCloseEditDrawer}
        onSuccess={handleEditSuccess}
      />

      {/* Child Details Modal / Bottom Sheet */}
      <ChildDetailsSheet
        isOpen={detailsSheetOpen}
        child={selectedChild}
        classRoom={selectedChild ? classesMap.get(selectedChild.class_id) || null : null}
        onClose={handleCloseDetailsSheet}
        onEdit={(child) => {
          handleCloseDetailsSheet();
          handleOpenEditDrawer(child);
        }}
        onArchive={(child) => {
          handleCloseDetailsSheet();
          handleOpenArchiveDialog(child);
        }}
      />

      {/* Soft Archive Confirmation Dialog */}
      <ArchiveChildDialog
        isOpen={archiveDialogOpen}
        child={selectedChild}
        onClose={handleCloseArchiveDialog}
        onSuccess={handleArchiveSuccess}
      />
    </div>
  );
};
