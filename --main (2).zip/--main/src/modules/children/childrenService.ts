import { supabase } from '../../lib/supabase/client';
import type { Child } from '../../types/database';
import {
  createChildSchema,
  updateChildSchema,
  type CreateChildInput,
  type UpdateChildInput,
} from './childValidation';

/**
 * Children Domain & Data Service
 *
 * Architecture & Security Invariants:
 * 1. ZERO TRUST: `kindergartenId` passed by caller is strictly a query context selector.
 *    True authorization is governed by the database RLS policies ("Children: Basic Info Tiered Read", "Children: Admin Manage")
 *    using the cryptographic session `auth.uid()`.
 * 2. SOFT DELETE ONLY: Physical deletion (`DELETE FROM children`) is STRICTLY PROHIBITED.
 *    Archiving is implemented strictly via `UPDATE children SET deleted_at = NOW(), updated_at = NOW()`.
 * 3. NO CLIENT AUDIT INSERTS: Direct insertion into `audit_logs` from the browser client is blocked
 *    by database RLS (default deny, no insert policy). The service NEVER attempts client-side audit writes.
 *    (AUDIT INFRASTRUCTURE GAP — NOT IMPLEMENTED).
 * 4. TENANT BOUNDARY INTEGRITY: Cross-kindergarten class assignment is strictly forbidden.
 *    When creating or transferring a child, `class_id` must belong to the active kindergarten.
 *    The child's `kindergarten_id` can NEVER be modified.
 * 5. VALIDATION CONTRACT: All mutations are pre-validated via Zod schemas before hitting PostgREST.
 *    Technical gender values are strictly 'MALE' | 'FEMALE'.
 */

export interface ServiceResult<T> {
  data: T | null;
  error: Error | null;
  errorCode?: string;
}

/**
 * Maps PostgreSQL and Supabase errors to domain-specific Arabic messages.
 */
function mapPostgresError(error: { code?: string; message: string }): { message: string; code?: string } {
  // PostgreSQL 42501: insufficient_privilege (RLS rejection)
  if (error.code === '42501' || error.message.includes('row-level security')) {
    return {
      message: 'غير مصرح لك بإجراء هذه العملية على أطفال هذه الروضة',
      code: 'PERMISSION_DENIED_RLS',
    };
  }

  // PostgreSQL 23503: foreign_key_violation
  if (error.code === '23503') {
    return {
      message: 'تعذر ربط السجل، الشعبة الدراسية المحددة أو الروضة غير موجودة أو مقيدة',
      code: 'FOREIGN_KEY_VIOLATION',
    };
  }

  // PostgreSQL 23514: check_constraint_violation
  if (error.code === '23514') {
    return {
      message: 'فشلت العملية، إحدى القيم المدخلة تنتهك القيود المعتمدة للنظام',
      code: 'CHECK_CONSTRAINT_VIOLATION',
    };
  }

  // PostgreSQL 23505: unique_violation
  if (error.code === '23505') {
    return {
      message: 'توجد بيانات مطابقة مسجلة مسبقاً في النظام',
      code: 'DUPLICATE_ENTRY',
    };
  }

  return {
    message: error.message || 'حدث خطأ غير متوقع أثناء معالجة بيانات الطفل',
    code: error.code,
  };
}

/**
 * Retrieve active children belonging to a kindergarten.
 * Automatically filtered by `deleted_at IS NULL` and protected by RLS.
 * Optionally filtered by `filterClassId`.
 */
export async function getActiveChildren(
  kindergartenId: string,
  filterClassId?: string
): Promise<ServiceResult<Child[]>> {
  try {
    if (!kindergartenId || typeof kindergartenId !== 'string') {
      return {
        data: null,
        error: new Error('معرف الروضة غير محدد أو غير صالح'),
        errorCode: 'INVALID_KINDERGARTEN_ID',
      };
    }

    let query = supabase
      .from('children')
      .select('*')
      .eq('kindergarten_id', kindergartenId)
      .is('deleted_at', null)
      .order('first_name', { ascending: true })
      .order('last_name', { ascending: true });

    if (filterClassId && filterClassId !== 'ALL') {
      query = query.eq('class_id', filterClassId);
    }

    const { data, error } = await query;

    if (error) {
      const mapped = mapPostgresError(error);
      return { data: null, error: new Error(mapped.message), errorCode: mapped.code };
    }

    return { data: (data as Child[]) || [], error: null };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'خطأ أثناء جلب قائمة الأطفال';
    return { data: null, error: new Error(msg), errorCode: 'UNEXPECTED_ERROR' };
  }
}

/**
 * Retrieve a single child by ID.
 * Returns null if archived or non-existent.
 */
export async function getChildById(childId: string): Promise<ServiceResult<Child>> {
  try {
    if (!childId || typeof childId !== 'string') {
      return {
        data: null,
        error: new Error('معرف الطفل غير محدد'),
        errorCode: 'INVALID_CHILD_ID',
      };
    }

    const { data, error } = await supabase
      .from('children')
      .select('*')
      .eq('id', childId)
      .is('deleted_at', null)
      .maybeSingle();

    if (error) {
      const mapped = mapPostgresError(error);
      return { data: null, error: new Error(mapped.message), errorCode: mapped.code };
    }

    return { data: data as Child | null, error: null };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'خطأ أثناء استرجاع بيانات الطفل';
    return { data: null, error: new Error(msg), errorCode: 'UNEXPECTED_ERROR' };
  }
}

/**
 * Register a new child in a class cohort.
 * Enforces Zod validation and ensures class belongs to the kindergarten.
 */
export async function createChild(
  kindergartenId: string,
  rawInput: unknown
): Promise<ServiceResult<Child>> {
  try {
    if (!kindergartenId || typeof kindergartenId !== 'string') {
      return {
        data: null,
        error: new Error('معرف الروضة مطلوب لتسجيل طفل جديد'),
        errorCode: 'INVALID_KINDERGARTEN_ID',
      };
    }

    // 1. Zod Validation
    const validationResult = createChildSchema.safeParse(rawInput);
    if (!validationResult.success) {
      const firstIssue = validationResult.error.issues[0];
      const errorMessage = firstIssue ? firstIssue.message : 'بيانات الطفل غير صالحة';
      return { data: null, error: new Error(errorMessage), errorCode: 'VALIDATION_FAILED' };
    }

    const validated: CreateChildInput = validationResult.data;

    // 2. Verify target class exists, is not archived, and belongs to the same kindergarten
    const { data: classRecord, error: classError } = await supabase
      .from('classes')
      .select('id, kindergarten_id')
      .eq('id', validated.class_id)
      .eq('kindergarten_id', kindergartenId)
      .is('deleted_at', null)
      .maybeSingle();

    if (classError || !classRecord) {
      return {
        data: null,
        error: new Error('الشعبة الدراسية المحددة لا تنتمي لنفس الروضة أو أنها غير موجودة'),
        errorCode: 'CLASS_NOT_IN_KINDERGARTEN',
      };
    }

    // 3. PostgREST Insert (Subject to RLS "Children: Admin Manage")
    const { data, error } = await supabase
      .from('children')
      .insert({
        kindergarten_id: kindergartenId,
        class_id: validated.class_id,
        first_name: validated.first_name,
        last_name: validated.last_name,
        dob: validated.dob,
        gender: validated.gender,
        emergency_contact_name: validated.emergency_contact_name,
        emergency_contact_phone: validated.emergency_contact_phone,
        enrollment_date: validated.enrollment_date,
      })
      .select('*')
      .single();

    if (error) {
      const mapped = mapPostgresError(error);
      return { data: null, error: new Error(mapped.message), errorCode: mapped.code };
    }

    return { data: data as Child, error: null };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'خطأ غير متوقع أثناء تسجيل الطفل';
    return { data: null, error: new Error(msg), errorCode: 'UNEXPECTED_ERROR' };
  }
}

/**
 * Update an existing child's demographic information or transfer them to another class cohort.
 * Strictly prevents changing kindergarten_id.
 * Validates that any new class_id belongs to the same kindergarten.
 */
export async function updateChild(
  childId: string,
  rawInput: unknown
): Promise<ServiceResult<Child>> {
  try {
    if (!childId || typeof childId !== 'string') {
      return {
        data: null,
        error: new Error('معرف الطفل مطلوب لتحديث البيانات'),
        errorCode: 'INVALID_CHILD_ID',
      };
    }

    // Reject attempt to modify kindergarten_id
    if (typeof rawInput === 'object' && rawInput !== null && 'kindergarten_id' in rawInput) {
      return {
        data: null,
        error: new Error('لا يمكن تغيير الروضة التي ينتمي إليها الطفل'),
        errorCode: 'CANNOT_CHANGE_TENANT',
      };
    }

    // 1. Zod Validation
    const validationResult = updateChildSchema.safeParse(rawInput);
    if (!validationResult.success) {
      const firstIssue = validationResult.error.issues[0];
      const errorMessage = firstIssue ? firstIssue.message : 'بيانات التحديث غير صالحة';
      return { data: null, error: new Error(errorMessage), errorCode: 'VALIDATION_FAILED' };
    }

    const validated: UpdateChildInput = validationResult.data;

    // Fetch existing child to know current kindergarten_id
    const { data: existingChild, error: fetchError } = await supabase
      .from('children')
      .select('id, kindergarten_id, class_id')
      .eq('id', childId)
      .is('deleted_at', null)
      .maybeSingle();

    if (fetchError || !existingChild) {
      return {
        data: null,
        error: new Error('لم يتم العثور على سجل الطفل المحدد أو قد تم أرشفته مسبقاً'),
        errorCode: 'CHILD_NOT_FOUND',
      };
    }

    // 2. If class_id is changing, verify target class belongs to the SAME kindergarten
    if (validated.class_id && validated.class_id !== existingChild.class_id) {
      const { data: targetClass, error: classLookupError } = await supabase
        .from('classes')
        .select('id, kindergarten_id')
        .eq('id', validated.class_id)
        .eq('kindergarten_id', existingChild.kindergarten_id)
        .is('deleted_at', null)
        .maybeSingle();

      if (classLookupError || !targetClass) {
        return {
          data: null,
          error: new Error('الشعبة الدراسية المستهدفة لا تنتمي لنفس الروضة أو أنها مؤرشفة'),
          errorCode: 'CLASS_NOT_IN_KINDERGARTEN',
        };
      }
    }

    // Build clean update payload
    const updatePayload: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };

    if (validated.first_name !== undefined) updatePayload.first_name = validated.first_name;
    if (validated.last_name !== undefined) updatePayload.last_name = validated.last_name;
    if (validated.dob !== undefined) updatePayload.dob = validated.dob;
    if (validated.gender !== undefined) updatePayload.gender = validated.gender;
    if (validated.class_id !== undefined) updatePayload.class_id = validated.class_id;
    if (validated.emergency_contact_name !== undefined) updatePayload.emergency_contact_name = validated.emergency_contact_name;
    if (validated.emergency_contact_phone !== undefined) updatePayload.emergency_contact_phone = validated.emergency_contact_phone;
    if (validated.enrollment_date !== undefined) updatePayload.enrollment_date = validated.enrollment_date;

    // 3. PostgREST Update (Subject to RLS "Children: Admin Manage")
    const { data, error } = await supabase
      .from('children')
      .update(updatePayload)
      .eq('id', childId)
      .is('deleted_at', null)
      .select('*')
      .single();

    if (error) {
      const mapped = mapPostgresError(error);
      return { data: null, error: new Error(mapped.message), errorCode: mapped.code };
    }

    return { data: data as Child, error: null };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'خطأ غير متوقع أثناء تحديث بيانات الطفل';
    return { data: null, error: new Error(msg), errorCode: 'UNEXPECTED_ERROR' };
  }
}

/**
 * Archive a child profile (SOFT-DELETE ONLY).
 *
 * CRITICAL ARCHITECTURAL GUARANTEE:
 * This method sets `deleted_at = NOW()`.
 * It NEVER performs a physical DELETE on the table.
 */
export async function archiveChild(childId: string): Promise<ServiceResult<{ archived: boolean }>> {
  try {
    if (!childId || typeof childId !== 'string') {
      return {
        data: null,
        error: new Error('معرف الطفل مطلوب للأرشفة'),
        errorCode: 'INVALID_CHILD_ID',
      };
    }

    // SOFT-DELETE via UPDATE only
    const { data, error } = await supabase
      .from('children')
      .update({
        deleted_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq('id', childId)
      .is('deleted_at', null)
      .select('id')
      .maybeSingle();

    if (error) {
      const mapped = mapPostgresError(error);
      return { data: null, error: new Error(mapped.message), errorCode: mapped.code };
    }

    if (!data) {
      return {
        data: null,
        error: new Error('لم يتم العثور على سجل الطفل المحدد، أو قد تمت أرشفته مسبقاً'),
        errorCode: 'CHILD_NOT_FOUND',
      };
    }

    return { data: { archived: true }, error: null };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'خطأ غير متوقع أثناء أرشفة سجل الطفل';
    return { data: null, error: new Error(msg), errorCode: 'UNEXPECTED_ERROR' };
  }
}
