import React from 'react';
import { Search, X, Filter } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { ClassRoom } from '../../../types/database';

interface ChildrenToolbarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedClassId: string;
  onSelectClassId: (classId: string) => void;
  classesList: ClassRoom[];
  totalChildrenCount: number;
  filteredChildrenCount: number;
  onClearFilters: () => void;
}

export const ChildrenToolbar: React.FC<ChildrenToolbarProps> = ({
  searchQuery,
  onSearchChange,
  selectedClassId,
  onSelectClassId,
  classesList,
  totalChildrenCount,
  filteredChildrenCount,
  onClearFilters,
}) => {
  const { t } = useI18n();

  const isFiltered = searchQuery.trim().length > 0 || selectedClassId !== 'ALL';

  return (
    <div className="w-full bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Search Input Box */}
        <div className="relative flex-1 max-w-md">
          <div className="absolute inset-y-0 inset-inline-start-0 ps-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" aria-hidden="true" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={t.children.searchPlaceholder}
            className="w-full h-11 ps-10 pe-10 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:border-teal-700 focus-visible:ring-2 focus-visible:ring-teal-700/20 outline-none transition-all"
            aria-label={t.children.searchPlaceholder}
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => onSearchChange('')}
              className="absolute inset-y-0 inset-inline-end-0 pe-3 flex items-center text-slate-400 hover:text-slate-700 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none min-h-[44px]"
              aria-label={t.children.clearSearchAria}
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Class Filter Dropdown */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <div className="absolute inset-y-0 inset-inline-start-0 ps-3 flex items-center pointer-events-none text-slate-400">
              <Filter className="w-4 h-4" aria-hidden="true" />
            </div>
            <select
              value={selectedClassId}
              onChange={(e) => onSelectClassId(e.target.value)}
              className="h-11 ps-9 pe-8 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 font-medium focus:bg-white focus:border-teal-700 focus-visible:ring-2 focus-visible:ring-teal-700/20 outline-none transition-all cursor-pointer"
              aria-label={t.children.filterClassAria}
            >
              <option value="ALL">{t.children.filterAllClasses}</option>
              {classesList.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.grade_level})
                </option>
              ))}
            </select>
          </div>

          {isFiltered && (
            <button
              type="button"
              onClick={onClearFilters}
              className="h-11 px-3 text-xs font-semibold text-teal-700 hover:text-teal-800 hover:bg-teal-50 rounded-lg transition-colors flex items-center gap-1.5 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none"
            >
              <X className="w-3.5 h-3.5" />
              <span>{t.children.clearFilters}</span>
            </button>
          )}
        </div>
      </div>

      {/* Live status count bar */}
      <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
        <div className="flex items-center gap-1.5 font-medium" aria-live="polite">
          <span>{t.children.activeChildrenCount}</span>
          <span className="font-bold text-slate-900">{filteredChildrenCount}</span>
          {totalChildrenCount !== filteredChildrenCount && (
            <span className="text-slate-400">
              ({t.children.totalCountOutOf} {totalChildrenCount})
            </span>
          )}
        </div>
        <span className="text-[11px] text-teal-700 font-semibold bg-teal-50 px-2 py-0.5 rounded">
          {t.children.phaseTag}
        </span>
      </div>
    </div>
  );
};
