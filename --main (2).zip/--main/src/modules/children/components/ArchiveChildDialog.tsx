import React, { useState, useEffect, useRef } from 'react';
import { AlertTriangle } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { Child } from '../../../types/database';
import { archiveChild } from '../childrenService';
import { HoldToConfirmButton } from '../../../components/ui/HoldToConfirmButton';

interface ArchiveChildDialogProps {
  isOpen: boolean;
  child: Child | null;
  onClose: () => void;
  onSuccess: (archivedChildId: string) => void;
}

export const ArchiveChildDialog: React.FC<ArchiveChildDialogProps> = ({
  isOpen,
  child,
  onClose,
  onSuccess,
}) => {
  const { t } = useI18n();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setIsSubmitting(false);
      setErrorMessage(null);
    }
  }, [isOpen]);

  // Focus trap & Escape listener
  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape' && !isSubmitting) {
        e.preventDefault();
        onClose();
      }

      if (e.key === 'Tab' && dialogRef.current) {
        const focusableElements = dialogRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        if (e.shiftKey) {
          if (document.activeElement === firstElement) {
            e.preventDefault();
            lastElement?.focus();
          }
        } else {
          if (document.activeElement === lastElement) {
            e.preventDefault();
            firstElement?.focus();
          }
        }
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, isSubmitting, onClose]);

  const handleConfirm = async () => {
    if (!child || isSubmitting) return;
    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const result = await archiveChild(child.id);

      if (result.error) {
        setErrorMessage(result.error.message);
        setIsSubmitting(false);
      } else {
        onSuccess(child.id);
      }
    } catch {
      setErrorMessage(t.children.errorNetworkOrServer);
      setIsSubmitting(false);
    }
  };

  if (!isOpen || !child) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="archive-child-dialog-title"
      aria-describedby="archive-child-dialog-desc"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={() => !isSubmitting && onClose()}
        aria-hidden="true"
      />

      {/* Dialog Box */}
      <div
        ref={dialogRef}
        className="relative bg-white rounded-2xl shadow-xl border border-slate-200 p-6 max-w-md w-full z-10 animate-in zoom-in-95 duration-200 space-y-4"
      >
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0 border border-amber-200">
            <AlertTriangle className="w-6 h-6" aria-hidden="true" />
          </div>

          <div className="flex-1 min-w-0">
            <h3 id="archive-child-dialog-title" className="text-base font-bold text-slate-900">
              {t.children.archiveDialogTitle}
            </h3>
            <p className="text-sm font-semibold text-slate-700 mt-1">
              {child.first_name} {child.last_name}
            </p>
          </div>
        </div>

        <p id="archive-child-dialog-desc" className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
          {t.children.archiveDialogDesc}
        </p>

        {errorMessage && (
          <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 text-xs text-rose-800 font-medium">
            {errorMessage}
          </div>
        )}

        <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="w-full sm:w-auto h-11 px-4 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 outline-none disabled:opacity-50"
          >
            {t.children.cancelAction}
          </button>

          <HoldToConfirmButton
            onConfirm={handleConfirm}
            holdDuration={2000}
            idleText={t.children.confirmArchiveAction}
            holdingText="جارٍ التحقق وتأكيد الأرشفة..."
            confirmedText="تمت أرشفة الطفل بنجاح"
            hintText="اضغط باستمرار لمدة ثانيتين لمنع الأرشفة العرضية"
            variant="danger"
            disabled={isSubmitting}
          />
        </div>
      </div>
    </div>
  );
};
