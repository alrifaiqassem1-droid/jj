import React, { useEffect, useRef } from 'react';
import { X, Calendar, User, Phone, School, Edit2, Archive } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { Child, ClassRoom } from '../../../types/database';

interface ChildDetailsSheetProps {
  isOpen: boolean;
  child: Child | null;
  classRoom?: ClassRoom | null;
  onClose: () => void;
  onEdit: (child: Child) => void;
  onArchive: (child: Child) => void;
}

export const ChildDetailsSheet: React.FC<ChildDetailsSheetProps> = ({
  isOpen,
  child,
  classRoom,
  onClose,
  onEdit,
  onArchive,
}) => {
  const { t, locale } = useI18n();
  const sheetRef = useRef<HTMLDivElement>(null);

  // Focus trap & Escape listener
  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  if (!isOpen || !child) return null;

  const dateLocale = locale === 'ar' ? 'ar-SA' : 'en-US';
  const formattedDob = new Date(child.dob).toLocaleDateString(dateLocale, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const formattedEnrollment = new Date(child.enrollment_date).toLocaleDateString(dateLocale, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const genderLabel = child.gender === 'MALE' ? t.children.genderMale : t.children.genderFemale;
  const classNameDisplay = classRoom ? classRoom.name : t.children.unassignedClass;
  const gradeLevelDisplay = classRoom ? classRoom.grade_level : '';

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="child-details-sheet-title"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Sheet Container */}
      <div
        ref={sheetRef}
        className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl shadow-xl z-10 flex flex-col max-h-[90vh] sm:max-h-[85vh] animate-in slide-in-from-bottom duration-250 border border-slate-200 focus:outline-none overflow-hidden"
      >
        {/* Mobile Drag Handle Indicator */}
        <div className="w-full flex justify-center pt-3 pb-1 sm:hidden">
          <div className="w-9 h-1 rounded-full bg-slate-300" aria-hidden="true" />
        </div>

        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 id="child-details-sheet-title" className="text-base sm:text-lg font-bold text-slate-900 truncate">
              {child.first_name} {child.last_name}
            </h2>
            <div className="mt-1 flex items-center gap-2">
              <span className="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-semibold bg-teal-50 text-teal-800 border border-teal-200/80">
                {genderLabel}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                {classNameDisplay} {gradeLevelDisplay && `(${gradeLevelDisplay})`}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-11 h-11 flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none transition-colors"
            aria-label={t.children.closeDetailsAction}
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-sm text-slate-700">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* Classroom */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center shrink-0 text-slate-500">
                <School className="w-4 h-4" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-500 block">{t.children.classSelectLabel}</span>
                <span className="text-xs font-bold text-slate-900 truncate block mt-0.5">
                  {classNameDisplay}
                </span>
              </div>
            </div>

            {/* Date of Birth */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center shrink-0 text-slate-500">
                <Calendar className="w-4 h-4" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-500 block">{t.children.dobLabel}</span>
                <span className="text-xs font-bold text-slate-900 truncate block mt-0.5">
                  {formattedDob}
                </span>
              </div>
            </div>

            {/* Emergency Contact Name */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center shrink-0 text-slate-500">
                <User className="w-4 h-4" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-500 block">{t.children.emergencyNameLabel}</span>
                <span className="text-xs font-bold text-slate-900 truncate block mt-0.5">
                  {child.emergency_contact_name}
                </span>
              </div>
            </div>

            {/* Emergency Contact Phone */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center shrink-0 text-slate-500">
                <Phone className="w-4 h-4" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-500 block">{t.children.emergencyPhoneLabel}</span>
                <span className="text-xs font-mono font-bold text-slate-900 truncate block mt-0.5" dir="ltr">
                  <bdi>{child.emergency_contact_phone}</bdi>
                </span>
              </div>
            </div>
          </div>

          {/* Enrollment Date */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 flex items-center justify-between text-xs">
            <span className="text-slate-500">{t.children.enrollmentDateLabel}</span>
            <span className="font-semibold text-slate-900">{formattedEnrollment}</span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-slate-100 bg-slate-50/60 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              onClose();
              onArchive(child);
            }}
            className="h-11 px-3.5 text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors flex items-center gap-1.5 focus-visible:ring-2 focus-visible:ring-rose-500 outline-none"
          >
            <Archive className="w-4 h-4" />
            <span>{t.children.archiveAction}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onEdit(child);
              }}
              className="h-11 px-4 bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none"
            >
              <Edit2 className="w-4 h-4" />
              <span>{t.children.editAction}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
