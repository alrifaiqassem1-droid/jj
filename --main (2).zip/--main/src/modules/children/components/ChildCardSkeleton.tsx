import React from 'react';

/**
 * ChildCardSkeleton
 * Smooth, accessible skeleton loader honoring prefers-reduced-motion.
 */
export const ChildCardSkeleton: React.FC = () => {
  return (
    <div
      className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between h-[210px] animate-pulse"
      aria-hidden="true"
    >
      <div>
        <div className="flex items-center justify-between gap-3 mb-3">
          <div className="h-5 bg-slate-200 rounded-md w-36" />
          <div className="h-6 bg-slate-100 rounded-md w-16" />
        </div>

        <div className="space-y-2 mt-4">
          <div className="h-4 bg-slate-100 rounded w-2/3" />
          <div className="h-4 bg-slate-100 rounded w-3/4" />
          <div className="h-4 bg-slate-100 rounded w-1/2" />
        </div>
      </div>

      <div className="border-t border-slate-100 pt-3 flex items-center justify-between">
        <div className="h-4 bg-slate-100 rounded w-24" />
        <div className="h-8 bg-slate-100 rounded-lg w-20" />
      </div>
    </div>
  );
};
