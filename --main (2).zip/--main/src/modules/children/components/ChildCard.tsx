import React, { useState, useRef, useEffect } from 'react';
import { MoreVertical, Eye, Edit2, Archive, Phone, Calendar, User, School } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { Child, ClassRoom } from '../../../types/database';

interface ChildCardProps {
  child: Child;
  classRoom?: ClassRoom | null;
  onViewDetails: (child: Child) => void;
  onEdit: (child: Child) => void;
  onArchive: (child: Child) => void;
}

export const ChildCard: React.FC<ChildCardProps> = ({
  child,
  classRoom,
  onViewDetails,
  onEdit,
  onArchive,
}) => {
  const { t, locale } = useI18n();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);

  // Close dropdown on outside click or Escape
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    }

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape' && menuOpen) {
        setMenuOpen(false);
        menuButtonRef.current?.focus();
      }
    }

    if (menuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [menuOpen]);

  // Date formatting by locale
  const dateLocale = locale === 'ar' ? 'ar-SA' : 'en-US';
  const formattedEnrollmentDate = new Date(child.enrollment_date).toLocaleDateString(dateLocale, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  const genderLabel = child.gender === 'MALE' ? t.children.genderMale : t.children.genderFemale;
  const classNameDisplay = classRoom ? classRoom.name : t.children.unassignedClass;

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs hover:shadow-md hover:border-slate-300 transition-all flex flex-col justify-between h-full relative group">
      <div>
        {/* Header row: Name, Gender badge, and menu button */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0 flex-1">
            <h3 className="font-bold text-base text-slate-900 truncate">
              {child.first_name} {child.last_name}
            </h3>
            <div className="flex items-center gap-2 mt-1">
              <span className="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-semibold bg-teal-50 text-teal-800 border border-teal-200/80">
                {genderLabel}
              </span>
              <span className="inline-flex items-center gap-1 text-xs text-slate-600 font-medium truncate">
                <School className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
                <span className="truncate">{classNameDisplay}</span>
              </span>
            </div>
          </div>

          {/* More options menu */}
          <div className="relative shrink-0" ref={menuRef}>
            <button
              ref={menuButtonRef}
              type="button"
              onClick={() => setMenuOpen(!menuOpen)}
              className="w-9 h-9 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none transition-colors"
              aria-label={`${t.children.moreActionsAria} ${child.first_name}`}
              aria-haspopup="true"
              aria-expanded={menuOpen}
            >
              <MoreVertical className="w-5 h-5" aria-hidden="true" />
            </button>

            {menuOpen && (
              <div
                className="absolute end-0 top-full mt-1 w-44 bg-white border border-slate-200 rounded-xl shadow-lg py-1 z-20 animate-in fade-in zoom-in-95 duration-100"
                role="menu"
                aria-orientation="vertical"
              >
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onViewDetails(child);
                  }}
                  className="w-full text-start px-3.5 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-2 transition-colors min-h-[44px]"
                  role="menuitem"
                >
                  <Eye className="w-4 h-4 text-slate-500" aria-hidden="true" />
                  <span>{t.children.viewDetailsAction}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onEdit(child);
                  }}
                  className="w-full text-start px-3.5 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-2 transition-colors min-h-[44px]"
                  role="menuitem"
                >
                  <Edit2 className="w-4 h-4 text-slate-500" aria-hidden="true" />
                  <span>{t.children.editAction}</span>
                </button>

                <div className="my-1 border-t border-slate-100" />

                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onArchive(child);
                  }}
                  className="w-full text-start px-3.5 py-2.5 text-xs font-semibold text-rose-600 hover:bg-rose-50 flex items-center gap-2 transition-colors min-h-[44px]"
                  role="menuitem"
                >
                  <Archive className="w-4 h-4 text-rose-500" aria-hidden="true" />
                  <span>{t.children.archiveAction}</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Emergency & Demographic Info */}
        <div className="space-y-2 mt-4 text-xs text-slate-600 border-t border-slate-100 pt-3">
          <div className="flex items-center gap-2 truncate">
            <User className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
            <span className="text-slate-500 shrink-0">{t.children.emergencyNameLabel}:</span>
            <span className="font-medium text-slate-800 truncate">{child.emergency_contact_name}</span>
          </div>

          <div className="flex items-center gap-2 truncate">
            <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
            <span className="text-slate-500 shrink-0">{t.children.emergencyPhoneLabel}:</span>
            <span className="font-mono text-slate-800 truncate" dir="ltr">
              <bdi>{child.emergency_contact_phone}</bdi>
            </span>
          </div>
        </div>
      </div>

      {/* Footer: Enrollment Date & Quick Details Button */}
      <div className="border-t border-slate-100 pt-3 mt-3 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 text-slate-500">
          <Calendar className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span className="truncate">{formattedEnrollmentDate}</span>
        </div>

        <button
          type="button"
          onClick={() => onViewDetails(child)}
          className="text-teal-700 hover:text-teal-800 font-semibold px-2 py-1 rounded-md hover:bg-teal-50 transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 outline-none min-h-[44px] flex items-center"
        >
          {t.children.viewDetailsAction}
        </button>
      </div>
    </div>
  );
};
