import React, { useState, useEffect, useRef } from 'react';
import { X, Loader2, AlertCircle } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import {
  createChildSchema,
  type Gender,
} from '../childValidation';
import { createChild } from '../childrenService';
import type { Child, ClassRoom } from '../../../types/database';

interface CreateChildDrawerProps {
  isOpen: boolean;
  kindergartenId: string;
  classesList: ClassRoom[];
  onClose: () => void;
  onSuccess: (newChild: Child) => void;
}

interface FormState {
  first_name: string;
  last_name: string;
  dob: string;
  gender: Gender;
  class_id: string;
  emergency_contact_name: string;
  emergency_contact_phone: string;
  enrollment_date: string;
}

const getInitialFormState = (firstClassId?: string): FormState => ({
  first_name: '',
  last_name: '',
  dob: '',
  gender: 'MALE',
  class_id: firstClassId || '',
  emergency_contact_name: '',
  emergency_contact_phone: '',
  enrollment_date: new Date().toISOString().split('T')[0],
});

export const CreateChildDrawer: React.FC<CreateChildDrawerProps> = ({
  isOpen,
  kindergartenId,
  classesList,
  onClose,
  onSuccess,
}) => {
  const { t, dir } = useI18n();

  const [form, setForm] = useState<FormState>(() => getInitialFormState(classesList[0]?.id));
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showUnsavedConfirm, setShowUnsavedConfirm] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const firstInputRef = useRef<HTMLInputElement>(null);

  const isDirty =
    form.first_name.trim() !== '' ||
    form.last_name.trim() !== '' ||
    form.dob.trim() !== '' ||
    form.emergency_contact_name.trim() !== '' ||
    form.emergency_contact_phone.trim() !== '';

  useEffect(() => {
    if (isOpen) {
      setForm(getInitialFormState(classesList[0]?.id));
      setFieldErrors({});
      setServerError(null);
      setShowUnsavedConfirm(false);
      setTimeout(() => {
        firstInputRef.current?.focus();
      }, 100);
    }
  }, [isOpen, classesList]);

  const handleRequestClose = () => {
    if (isSubmitting) return;
    if (isDirty) {
      setShowUnsavedConfirm(true);
    } else {
      onClose();
    }
  };

  const handleConfirmDiscard = () => {
    setShowUnsavedConfirm(false);
    onClose();
  };

  const handleCancelDiscard = () => {
    setShowUnsavedConfirm(false);
  };

  // Keyboard navigation & Focus Trap
  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        e.preventDefault();
        if (showUnsavedConfirm) {
          setShowUnsavedConfirm(false);
        } else {
          handleRequestClose();
        }
        return;
      }

      if (e.key === 'Tab' && containerRef.current) {
        const focusableElements = containerRef.current.querySelectorAll<HTMLElement>(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        if (e.shiftKey) {
          if (document.activeElement === firstElement) {
            e.preventDefault();
            lastElement?.focus();
          }
        } else {
          if (document.activeElement === lastElement) {
            e.preventDefault();
            firstElement?.focus();
          }
        }
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, showUnsavedConfirm, isDirty, isSubmitting]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setServerError(null);
    setFieldErrors({});

    // Client-side schema parse
    const parseResult = createChildSchema.safeParse(form);
    if (!parseResult.success) {
      const errors: Record<string, string> = {};
      parseResult.error.issues.forEach((issue) => {
        const path = issue.path[0];
        if (path) {
          errors[path.toString()] = issue.message;
        }
      });
      setFieldErrors(errors);
      return;
    }

    setIsSubmitting(true);

    try {
      const result = await createChild(kindergartenId, form);

      if (result.error) {
        setServerError(result.error.message);
      } else if (result.data) {
        onSuccess(result.data);
      }
    } catch {
      setServerError(t.children.errorNetworkOrServer);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden"
      role="dialog"
      aria-modal="true"
      aria-labelledby="create-child-drawer-title"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={handleRequestClose}
        aria-hidden="true"
      />

      {/* Drawer Container (Side-panel positioned at logical inline-end) */}
      <div className="fixed inset-y-0 inset-inline-end-0 flex max-w-full">
        <div
          ref={containerRef}
          className={`w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between border-inline-start border-slate-200 animate-in ${
            dir === 'rtl' ? 'slide-in-from-left' : 'slide-in-from-right'
          } duration-300 focus:outline-none`}
        >
          {/* Header */}
          <div className="p-6 border-b border-slate-100 flex items-start justify-between gap-4">
            <div>
              <h2 id="create-child-drawer-title" className="text-lg font-bold text-slate-900">
                {t.children.createDrawerTitle}
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                {t.children.createDrawerSubtitle}
              </p>
            </div>

            <button
              type="button"
              onClick={handleRequestClose}
              className="w-10 h-10 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none transition-colors"
              aria-label={t.children.closeCreateDrawerAria}
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>

          {/* Body / Form */}
          <form id="create-child-form" onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-start">
            {/* Server Error Alert */}
            {serverError && (
              <div
                className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 text-xs text-rose-800 flex items-start gap-2.5"
                role="alert"
              >
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" aria-hidden="true" />
                <span className="font-medium">{serverError}</span>
              </div>
            )}

            {/* First Name & Last Name (Grid) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label htmlFor="child-first-name" className="block text-xs font-bold text-slate-700 mb-1">
                  {t.children.firstNameLabel} <span className="text-rose-500">*</span>
                </label>
                <input
                  ref={firstInputRef}
                  id="child-first-name"
                  type="text"
                  value={form.first_name}
                  onChange={(e) => setForm({ ...form, first_name: e.target.value })}
                  placeholder={t.children.firstNamePlaceholder}
                  className={`w-full h-11 px-3 bg-slate-50 border rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none transition-colors ${
                    fieldErrors.first_name ? 'border-rose-400 focus:ring-2 focus:ring-rose-200' : 'border-slate-200 focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20'
                  }`}
                  aria-invalid={!!fieldErrors.first_name}
                  aria-describedby={fieldErrors.first_name ? 'child-first-name-error' : undefined}
                />
                {fieldErrors.first_name && (
                  <p id="child-first-name-error" className="text-xs text-rose-600 mt-1 font-medium">
                    {fieldErrors.first_name}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="child-last-name" className="block text-xs font-bold text-slate-700 mb-1">
                  {t.children.lastNameLabel} <span className="text-rose-500">*</span>
                </label>
                <input
                  id="child-last-name"
                  type="text"
                  value={form.last_name}
                  onChange={(e) => setForm({ ...form, last_name: e.target.value })}
                  placeholder={t.children.lastNamePlaceholder}
                  className={`w-full h-11 px-3 bg-slate-50 border rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none transition-colors ${
                    fieldErrors.last_name ? 'border-rose-400 focus:ring-2 focus:ring-rose-200' : 'border-slate-200 focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20'
                  }`}
                  aria-invalid={!!fieldErrors.last_name}
                  aria-describedby={fieldErrors.last_name ? 'child-last-name-error' : undefined}
                />
                {fieldErrors.last_name && (
                  <p id="child-last-name-error" className="text-xs text-rose-600 mt-1 font-medium">
                    {fieldErrors.last_name}
                  </p>
                )}
              </div>
            </div>

            {/* Date of Birth & Gender (Grid) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label htmlFor="child-dob" className="block text-xs font-bold text-slate-700 mb-1">
                  {t.children.dobLabel} <span className="text-rose-500">*</span>
                </label>
                <input
                  id="child-dob"
                  type="date"
                  value={form.dob}
                  max={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setForm({ ...form, dob: e.target.value })}
                  className={`w-full h-11 px-3 bg-slate-50 border rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none transition-colors ${
                    fieldErrors.dob ? 'border-rose-400 focus:ring-2 focus:ring-rose-200' : 'border-slate-200 focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20'
                  }`}
                  aria-invalid={!!fieldErrors.dob}
                  aria-describedby={fieldErrors.dob ? 'child-dob-error' : undefined}
                />
                {fieldErrors.dob && (
                  <p id="child-dob-error" className="text-xs text-rose-600 mt-1 font-medium">
                    {fieldErrors.dob}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t.children.genderLabel} <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2 h-11">
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, gender: 'MALE' })}
                    className={`h-full border rounded-lg text-xs font-bold transition-all focus-visible:ring-2 focus-visible:ring-teal-700 outline-none flex items-center justify-center ${
                      form.gender === 'MALE'
                        ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {t.children.genderMale}
                  </button>

                  <button
                    type="button"
                    onClick={() => setForm({ ...form, gender: 'FEMALE' })}
                    className={`h-full border rounded-lg text-xs font-bold transition-all focus-visible:ring-2 focus-visible:ring-teal-700 outline-none flex items-center justify-center ${
                      form.gender === 'FEMALE'
                        ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {t.children.genderFemale}
                  </button>
                </div>
              </div>
            </div>

            {/* Class Cohort Assignment */}
            <div>
              <label htmlFor="child-class-id" className="block text-xs font-bold text-slate-700 mb-1">
                {t.children.classSelectLabel} <span className="text-rose-500">*</span>
              </label>
              <select
                id="child-class-id"
                value={form.class_id}
                onChange={(e) => setForm({ ...form, class_id: e.target.value })}
                className={`w-full h-11 px-3 bg-slate-50 border rounded-lg text-sm text-slate-900 focus:bg-white focus:outline-none transition-colors ${
                  fieldErrors.class_id ? 'border-rose-400 focus:ring-2 focus:ring-rose-200' : 'border-slate-200 focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20'
                }`}
                aria-invalid={!!fieldErrors.class_id}
                aria-describedby={fieldErrors.class_id ? 'child-class-id-error' : undefined}
              >
                <option value="" disabled>
                  {t.children.classSelectPlaceholder}
                </option>
                {classesList.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.grade_level})
                  </option>
                ))}
              </select>
              {fieldErrors.class_id && (
                <p id="child-class-id-error" className="text-xs text-rose-600 mt-1 font-medium">
                  {fieldErrors.class_id}
                </p>
              )}
            </div>

            {/* Emergency Contact Name */}
            <div>
              <label htmlFor="child-emergency-name" className="block text-xs font-bold text-slate-700 mb-1">
                {t.children.emergencyNameLabel} <span className="text-rose-500">*</span>
              </label>
              <input
                id="child-emergency-name"
                type="text"
                value={form.emergency_contact_name}
                onChange={(e) => setForm({ ...form, emergency_contact_name: e.target.value })}
                placeholder={t.children.emergencyNamePlaceholder}
                className={`w-full h-11 px-3 bg-slate-50 border rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none transition-colors ${
                  fieldErrors.emergency_contact_name ? 'border-rose-400 focus:ring-2 focus:ring-rose-200' : 'border-slate-200 focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20'
                }`}
                aria-invalid={!!fieldErrors.emergency_contact_name}
                aria-describedby={fieldErrors.emergency_contact_name ? 'child-emergency-name-error' : undefined}
              />
              {fieldErrors.emergency_contact_name && (
                <p id="child-emergency-name-error" className="text-xs text-rose-600 mt-1 font-medium">
                  {fieldErrors.emergency_contact_name}
                </p>
              )}
            </div>

            {/* Emergency Contact Phone */}
            <div>
              <label htmlFor="child-emergency-phone" className="block text-xs font-bold text-slate-700 mb-1">
                {t.children.emergencyPhoneLabel} <span className="text-rose-500">*</span>
              </label>
              <input
                id="child-emergency-phone"
                type="tel"
                value={form.emergency_contact_phone}
                onChange={(e) => setForm({ ...form, emergency_contact_phone: e.target.value })}
                placeholder={t.children.emergencyPhonePlaceholder}
                className={`w-full h-11 px-3 bg-slate-50 border rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none transition-colors ${
                  fieldErrors.emergency_contact_phone ? 'border-rose-400 focus:ring-2 focus:ring-rose-200' : 'border-slate-200 focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20'
                }`}
                aria-invalid={!!fieldErrors.emergency_contact_phone}
                aria-describedby={fieldErrors.emergency_contact_phone ? 'child-emergency-phone-error' : undefined}
              />
              {fieldErrors.emergency_contact_phone && (
                <p id="child-emergency-phone-error" className="text-xs text-rose-600 mt-1 font-medium">
                  {fieldErrors.emergency_contact_phone}
                </p>
              )}
            </div>

            {/* Enrollment Date */}
            <div>
              <label htmlFor="child-enrollment-date" className="block text-xs font-bold text-slate-700 mb-1">
                {t.children.enrollmentDateLabel}
              </label>
              <input
                id="child-enrollment-date"
                type="date"
                value={form.enrollment_date}
                onChange={(e) => setForm({ ...form, enrollment_date: e.target.value })}
                className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 focus:outline-none transition-colors"
              />
            </div>
          </form>

          {/* Footer Actions */}
          <div className="p-4 sm:p-6 border-t border-slate-100 flex items-center justify-end gap-3 bg-slate-50/50">
            <button
              type="button"
              onClick={handleRequestClose}
              disabled={isSubmitting}
              className="h-11 px-4 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 outline-none min-h-[44px]"
            >
              {t.classes.cancelAction}
            </button>

            <button
              type="submit"
              form="create-child-form"
              disabled={isSubmitting}
              className="h-11 px-5 bg-teal-700 hover:bg-teal-800 active:bg-teal-900 text-white text-xs font-bold rounded-lg shadow-xs hover:shadow-sm transition-all focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2 outline-none flex items-center gap-2 disabled:opacity-50 disabled:pointer-events-none min-h-[44px]"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                  <span>{t.children.submittingCreateAction}</span>
                </>
              ) : (
                <span>{t.children.submitCreateAction}</span>
              )}
            </button>
          </div>

          {/* Unsaved Changes Confirmation Dialog */}
          {showUnsavedConfirm && (
            <div
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150"
              role="alertdialog"
              aria-labelledby="confirm-discard-title"
              aria-describedby="confirm-discard-desc"
            >
              <div className="bg-white rounded-xl p-5 max-w-sm w-full shadow-xl border border-slate-200 space-y-4">
                <h3 id="confirm-discard-title" className="text-sm font-bold text-slate-900">
                  {t.classes.unsavedChangesWarning}
                </h3>
                <p id="confirm-discard-desc" className="text-xs text-slate-600">
                  {t.children.unsavedChangesWarning}
                </p>
                <div className="flex items-center justify-end gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={handleCancelDiscard}
                    className="h-10 px-3.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors min-h-[44px]"
                  >
                    {t.children.keepEditingAction}
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmDiscard}
                    className="h-10 px-3.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-lg shadow-xs transition-colors min-h-[44px]"
                  >
                    {t.children.discardChangesAction}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
