import { z } from 'zod';

/**
 * Technical Gender Contract:
 * Database, TypeScript, Zod values: 'MALE' | 'FEMALE' exclusively.
 * Display labels are localized via i18n only (MALE -> ذكر, FEMALE -> أنثى).
 * Arabic labels are NEVER stored in the database.
 */
export const GENDER_VALUES = ['MALE', 'FEMALE'] as const;
export type Gender = (typeof GENDER_VALUES)[number];

/**
 * Calendar ISO date validator (YYYY-MM-DD).
 * Validates actual calendar existence and rejects future dates.
 * AGE POLICY: NOT YET SPECIFIED / PENDING PROJECT REQUIREMENT.
 * No min/max age rules are enforced.
 */
function isValidPastDate(val: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(val)) return false;
  const dateObj = new Date(val + 'T00:00:00Z');
  if (isNaN(dateObj.getTime())) return false;

  // Strict check that the parsed date components match input
  const [year, month, day] = val.split('-').map(Number);
  if (
    dateObj.getUTCFullYear() !== year ||
    dateObj.getUTCMonth() + 1 !== month ||
    dateObj.getUTCDate() !== day
  ) {
    return false;
  }

  // Reject future dates (comparing calendar date in UTC)
  const today = new Date();
  const todayIso = today.toISOString().split('T')[0];
  return val <= todayIso;
}

function isValidCalendarDate(val: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(val)) return false;
  const dateObj = new Date(val + 'T00:00:00Z');
  if (isNaN(dateObj.getTime())) return false;
  const [year, month, day] = val.split('-').map(Number);
  return (
    dateObj.getUTCFullYear() !== year ||
    dateObj.getUTCMonth() + 1 !== month ||
    dateObj.getUTCDate() !== day
  ) ? false : true;
}

/**
 * Zod validation schema for creating a new child.
 */
export const createChildSchema = z.object({
  first_name: z
    .string({
      error: 'الاسم الأول للطفل مطلوب',
    })
    .trim()
    .min(2, 'يجب أن يتكون الاسم الأول من حرفين على الأقل')
    .max(100, 'الاسم الأول لا يمكن أن يتجاوز 100 حرف'),

  last_name: z
    .string({
      error: 'اسم العائلة مطلوب',
    })
    .trim()
    .min(2, 'يجب أن يتكون اسم العائلة من حرفين على الأقل')
    .max(100, 'اسم العائلة لا يمكن أن يتجاوز 100 حرف'),

  dob: z
    .string({
      error: 'تاريخ الميلاد مطلوب',
    })
    .trim()
    .refine((val) => isValidPastDate(val), {
      message: 'تاريخ الميلاد غير صالح، ويجب ألا يكون في المستقبل',
    }),

  gender: z.enum(GENDER_VALUES, {
    error: 'يجب تحديد الجنس (MALE أو FEMALE)',
  }),

  class_id: z
    .string({
      error: 'معرف الشعبة الدراسية مطلوب',
    })
    .uuid('معرف الشعبة الدراسية يجب أن يكون بصيغة UUID صالحة'),

  emergency_contact_name: z
    .string({
      error: 'اسم مسؤول الطوارئ مطلوب',
    })
    .trim()
    .min(3, 'اسم مسؤول الطوارئ يجب أن يتكون من 3 أحرف على الأقل')
    .max(255, 'اسم مسؤول الطوارئ لا يمكن أن يتجاوز 255 حرفًا'),

  emergency_contact_phone: z
    .string({
      error: 'رقم هاتف مسؤول الطوارئ مطلوب',
    })
    .trim()
    .min(1, 'رقم هاتف مسؤول الطوارئ مطلوب')
    .max(50, 'رقم هاتف مسؤول الطوارئ لا يمكن أن يتجاوز 50 حرفًا'),

  enrollment_date: z
    .string()
    .trim()
    .refine((val) => isValidCalendarDate(val), {
      message: 'تاريخ الالتحاق يجب أن يكون بصيغة تاريخ صالحة (YYYY-MM-DD)',
    })
    .default(() => new Date().toISOString().split('T')[0]),
});

export type CreateChildInput = z.infer<typeof createChildSchema>;

/**
 * Zod validation schema for updating an existing child.
 * Disallows kindergarten_id modification (enforces same-tenant boundary).
 */
export const updateChildSchema = z.object({
  first_name: z
    .string()
    .trim()
    .min(2, 'يجب أن يتكون الاسم الأول من حرفين على الأقل')
    .max(100, 'الاسم الأول لا يمكن أن يتجاوز 100 حرف')
    .optional(),

  last_name: z
    .string()
    .trim()
    .min(2, 'يجب أن يتكون اسم العائلة من حرفين على الأقل')
    .max(100, 'اسم العائلة لا يمكن أن يتجاوز 100 حرف')
    .optional(),

  dob: z
    .string()
    .trim()
    .refine((val) => isValidPastDate(val), {
      message: 'تاريخ الميلاد غير صالح، ويجب ألا يكون في المستقبل',
    })
    .optional(),

  gender: z
    .enum(GENDER_VALUES, {
      error: 'يجب تحديد الجنس (MALE أو FEMALE)',
    })
    .optional(),

  class_id: z
    .string()
    .uuid('معرف الشعبة الدراسية يجب أن يكون بصيغة UUID صالحة')
    .optional(),

  emergency_contact_name: z
    .string()
    .trim()
    .min(3, 'اسم مسؤول الطوارئ يجب أن يتكون من 3 أحرف على الأقل')
    .max(255, 'اسم مسؤول الطوارئ لا يمكن أن يتجاوز 255 حرفًا')
    .optional(),

  emergency_contact_phone: z
    .string()
    .trim()
    .min(1, 'رقم هاتف مسؤول الطوارئ مطلوب')
    .max(50, 'رقم هاتف مسؤول الطوارئ لا يمكن أن يتجاوز 50 حرفًا')
    .optional(),

  enrollment_date: z
    .string()
    .trim()
    .refine((val) => isValidCalendarDate(val), {
      message: 'تاريخ الالتحاق يجب أن يكون بصيغة تاريخ صالحة (YYYY-MM-DD)',
    })
    .optional(),
});

export type UpdateChildInput = z.infer<typeof updateChildSchema>;
