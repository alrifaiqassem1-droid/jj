import { z } from 'zod';

/**
 * Class Validation Schemas (Zod Contracts)
 *
 * Enforces business rules and constraints defined in Phase 1 Vertical Slice 1.
 *
 * Distinctions:
 * - `grade_level`: Allowed values ('KG1' | 'KG2' | 'KG3') are enforced at application level.
 *   The database schema defines VARCHAR(50), so this is an Application-level validation.
 * - `capacity <= 40`: Enforced at application level.
 *   The database schema enforces only `CHECK (capacity > 0)`.
 * - `name`: Trimmed, 2 to 100 characters.
 * - `academic_year`: Enforces `YYYY-YYYY` pattern.
 */

export const ALLOWED_GRADE_LEVELS = ['KG1', 'KG2', 'KG3'] as const;
export type GradeLevel = (typeof ALLOWED_GRADE_LEVELS)[number];

export const createClassSchema = z.object({
  name: z
    .string({
      message: 'اسم الشعبة مطلوب',
    })
    .transform((val) => val.trim())
    .pipe(
      z
        .string()
        .min(2, 'يجب أن يتكون اسم الشعبة من حرفين على الأقل')
        .max(100, 'يجب ألا يتجاوز اسم الشعبة 100 حرف')
    ),

  grade_level: z.enum(ALLOWED_GRADE_LEVELS, {
    message: 'المرحلة الدراسية المحددة غير صالحة. الخيارات المتاحة: KG1 (روضة 1)، KG2 (روضة 2)، KG3 (تمهيدي)',
  }),

  room_number: z
    .string()
    .transform((val) => val.trim())
    .pipe(z.string().max(50, 'رقم أو مسمى القاعة يجب ألا يتجاوز 50 حرفاً'))
    .nullable()
    .optional()
    .transform((val) => (val && val.length > 0 ? val : null)),

  capacity: z
    .number({
      message: 'السعة الاستيعابية مطلوبة ويجب أن تكون رقماً',
    })
    .int('السعة الاستيعابية يجب أن تكون عدداً صحيحاً بدون كسور')
    .min(1, 'السعة الاستيعابية يجب ألا تقل عن طفل واحد')
    .max(40, 'الحد الأقصى للسعة الاستيعابية المسموح بها في النظام هو 40 طفلاً'),

  academic_year: z
    .string({
      message: 'العام الدراسي مطلوب',
    })
    .transform((val) => val.trim())
    .pipe(
      z
        .string()
        .regex(
          /^\d{4}-\d{4}$/,
          'صيغة العام الدراسي غير صالحة. الصيغة المطلوبة: YYYY-YYYY (مثال: 2026-2027)'
        )
    ),
});

export const updateClassSchema = z.object({
  name: z
    .string()
    .transform((val) => val.trim())
    .pipe(
      z
        .string()
        .min(2, 'يجب أن يتكون اسم الشعبة من حرفين على الأقل')
        .max(100, 'يجب ألا يتجاوز اسم الشعبة 100 حرف')
    )
    .optional(),

  grade_level: z
    .enum(ALLOWED_GRADE_LEVELS, {
      message: 'المرحلة الدراسية المحددة غير صالحة. الخيارات المتاحة: KG1، KG2، KG3',
    })
    .optional(),

  room_number: z
    .string()
    .transform((val) => val.trim())
    .pipe(z.string().max(50, 'رقم أو مسمى القاعة يجب ألا يتجاوز 50 حرفاً'))
    .nullable()
    .optional()
    .transform((val) => (val && val.length > 0 ? val : null)),

  capacity: z
    .number({
      message: 'السعة الاستيعابية يجب أن تكون رقماً',
    })
    .int('السعة الاستيعابية يجب أن تكون عدداً صحيحاً بدون كسور')
    .min(1, 'السعة الاستيعابية يجب ألا تقل عن طفل واحد')
    .max(40, 'الحد الأقصى للسعة الاستيعابية المسموح بها في النظام هو 40 طفلاً')
    .optional(),

  academic_year: z
    .string()
    .transform((val) => val.trim())
    .pipe(
      z
        .string()
        .regex(
          /^\d{4}-\d{4}$/,
          'صيغة العام الدراسي غير صالحة. الصيغة المطلوبة: YYYY-YYYY (مثال: 2026-2027)'
        )
    )
    .optional(),
});

export type CreateClassInput = z.infer<typeof createClassSchema>;
export type UpdateClassInput = z.infer<typeof updateClassSchema>;
