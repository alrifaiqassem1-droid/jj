import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Plus, School, AlertCircle, RefreshCw, CheckCircle2 } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import { useAuth } from '../../auth/AuthContext';
import { getKindergartenProfile } from '../../kindergarten/kindergartenService';
import { getActiveClasses } from '../classesService';
import type { Kindergarten, ClassRoom } from '../../../types/database';
import type { GradeLevel } from '../classValidation';

import { KindergartenContextBanner } from './KindergartenContextBanner';
import { ClassesToolbar } from './ClassesToolbar';
import { ClassCard } from './ClassCard';
import { ClassCardSkeleton } from './ClassCardSkeleton';
import { CreateClassDrawer } from './CreateClassDrawer';
import { EditClassDrawer } from './EditClassDrawer';
import { ClassDetailsSheet } from './ClassDetailsSheet';
import { ArchiveClassDialog } from './ArchiveClassDialog';

/**
 * ClassesView Component
 * Phase 1 Vertical Slice 1 Master Screen.
 * Orchestrates Kindergarten Context and Class Management strictly according to Design System v1.4.
 */
export const ClassesView: React.FC = () => {
  const { t } = useI18n();
  const { activeMembership } = useAuth();

  // Primary data states
  const [kindergarten, setKindergarten] = useState<Kindergarten | null>(null);
  const [classesList, setClassesList] = useState<ClassRoom[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Search & Filter local states
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedGrade, setSelectedGrade] = useState<'ALL' | GradeLevel>('ALL');

  // Modal / Drawer / Sheet states
  const [createDrawerOpen, setCreateDrawerOpen] = useState<boolean>(false);
  const [editDrawerOpen, setEditDrawerOpen] = useState<boolean>(false);
  const [detailsSheetOpen, setDetailsSheetOpen] = useState<boolean>(false);
  const [archiveDialogOpen, setArchiveDialogOpen] = useState<boolean>(false);
  const [selectedClass, setSelectedClass] = useState<ClassRoom | null>(null);

  // Focus Restoration Tracking
  const lastActiveElementRef = useRef<HTMLElement | null>(null);
  const createButtonRef = useRef<HTMLButtonElement>(null);

  const activeKindergartenId = activeMembership?.kindergarten_id;

  // Load verified context and active classes
  const loadData = useCallback(async () => {
    if (!activeKindergartenId) {
      setLoading(false);
      return;
    }

    setLoading(true);
    setErrorMessage(null);

    try {
      // 1. Fetch kindergarten profile
      const [kResult, cResult] = await Promise.all([
        getKindergartenProfile(activeKindergartenId),
        getActiveClasses(activeKindergartenId),
      ]);

      if (kResult.error) {
        setErrorMessage(kResult.error.message);
      } else {
        setKindergarten(kResult.data);
      }

      if (cResult.error) {
        setErrorMessage(cResult.error.message);
      } else {
        setClassesList(cResult.data || []);
      }
    } catch {
      setErrorMessage(t.classes.errorNetworkOrServer);
    } finally {
      setLoading(false);
    }
  }, [activeKindergartenId, t.classes.errorNetworkOrServer]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Display transient success notification
  const triggerSuccessToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => {
      setSuccessToast(null);
    }, 4000);
  };

  // Open Handlers with Focus Tracking
  const handleOpenCreateDrawer = () => {
    lastActiveElementRef.current = document.activeElement as HTMLElement;
    setCreateDrawerOpen(true);
  };

  const handleCloseCreateDrawer = () => {
    setCreateDrawerOpen(false);
    // Restore focus
    if (lastActiveElementRef.current) {
      lastActiveElementRef.current.focus();
    } else {
      createButtonRef.current?.focus();
    }
  };

  const handleOpenEditDrawer = (classRoom: ClassRoom) => {
    lastActiveElementRef.current = document.activeElement as HTMLElement;
    setSelectedClass(classRoom);
    setEditDrawerOpen(true);
  };

  const handleCloseEditDrawer = () => {
    setEditDrawerOpen(false);
    if (lastActiveElementRef.current) {
      lastActiveElementRef.current.focus();
    }
  };

  const handleOpenDetailsSheet = (classRoom: ClassRoom) => {
    lastActiveElementRef.current = document.activeElement as HTMLElement;
    setSelectedClass(classRoom);
    setDetailsSheetOpen(true);
  };

  const handleCloseDetailsSheet = () => {
    setDetailsSheetOpen(false);
    if (lastActiveElementRef.current) {
      lastActiveElementRef.current.focus();
    }
  };

  const handleOpenArchiveDialog = (classRoom: ClassRoom) => {
    lastActiveElementRef.current = document.activeElement as HTMLElement;
    setSelectedClass(classRoom);
    setArchiveDialogOpen(true);
  };

  const handleCloseArchiveDialog = () => {
    setArchiveDialogOpen(false);
    if (lastActiveElementRef.current) {
      lastActiveElementRef.current.focus();
    }
  };

  // Mutation Handlers
  const handleCreateSuccess = (newClass: ClassRoom) => {
    setClassesList((prev) => [newClass, ...prev]);
    triggerSuccessToast(t.classes.createSuccessMessage);
  };

  const handleUpdateSuccess = (updatedClass: ClassRoom) => {
    setClassesList((prev) =>
      prev.map((c) => (c.id === updatedClass.id ? updatedClass : c))
    );
    triggerSuccessToast(t.classes.editSuccessMessage);
  };

  const handleArchiveSuccess = (archivedClassId: string) => {
    setClassesList((prev) => prev.filter((c) => c.id !== archivedClassId));
    triggerSuccessToast(t.classes.archiveSuccessMessage);
  };

  // Client-Side Local Search and Filter
  const filteredClasses = classesList.filter((classRoom) => {
    // 1. Grade filter
    if (selectedGrade !== 'ALL' && classRoom.grade_level !== selectedGrade) {
      return false;
    }

    // 2. Search query filter
    const query = searchQuery.trim().toLowerCase();
    if (query) {
      const matchName = classRoom.name.toLowerCase().includes(query);
      const matchRoom = classRoom.room_number?.toLowerCase().includes(query) || false;
      const matchYear = classRoom.academic_year.toLowerCase().includes(query);
      return matchName || matchRoom || matchYear;
    }

    return true;
  });

  return (
    <div className="space-y-6">
      {/* 1. Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200/80 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              {t.classes.title}
            </h1>
            <span className="px-2 py-0.5 rounded text-xs font-semibold bg-teal-50 text-teal-800 border border-teal-200/80">
              {t.classes.phaseTag}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            {t.classes.subtitle}
          </p>
        </div>

        {/* Primary Action Button */}
        <button
          ref={createButtonRef}
          type="button"
          onClick={handleOpenCreateDrawer}
          className="min-h-[44px] px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-xl shadow-xs hover:shadow transition-all duration-150 flex items-center justify-center gap-2 text-sm font-semibold focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2 outline-none shrink-0"
        >
          <Plus className="w-5 h-5 stroke-[2.5]" aria-hidden="true" />
          <span>{t.classes.createClassAction}</span>
        </button>
      </div>

      {/* Floating Success Feedback Toast */}
      {successToast && (
        <div
          className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-xl flex items-center gap-2.5 text-xs sm:text-sm font-medium shadow-xs animate-in fade-in duration-200"
          role="status"
          aria-live="polite"
        >
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" aria-hidden="true" />
          <span>{successToast}</span>
        </div>
      )}

      {/* 2. Kindergarten Context Banner */}
      <KindergartenContextBanner
        kindergarten={kindergarten}
        loading={loading && !kindergarten}
      />

      {/* 3. Search & Filter Toolbar */}
      {!loading && !errorMessage && (
        <ClassesToolbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedGrade={selectedGrade}
          onSelectGrade={setSelectedGrade}
          totalClassesCount={classesList.length}
          filteredClassesCount={filteredClasses.length}
          onClearFilters={() => {
            setSearchQuery('');
            setSelectedGrade('ALL');
          }}
        />
      )}

      {/* 4. Content Area with States */}
      <div>
        {/* Loading State: Skeletons */}
        {loading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            <ClassCardSkeleton />
            <ClassCardSkeleton />
            <ClassCardSkeleton />
            <ClassCardSkeleton />
            <ClassCardSkeleton />
            <ClassCardSkeleton />
          </div>
        )}

        {/* Error State with Safe Message & Retry */}
        {!loading && errorMessage && (
          <div
            className="bg-white border border-red-200 rounded-2xl p-8 text-center max-w-md mx-auto space-y-4 shadow-xs"
            role="alert"
          >
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6 stroke-[2]" aria-hidden="true" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">{t.common.error}</h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">{errorMessage}</p>
            </div>
            <button
              type="button"
              onClick={loadData}
              className="min-h-[44px] px-5 py-2 text-xs font-semibold text-teal-800 bg-teal-50 hover:bg-teal-100 rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 outline-none inline-flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" aria-hidden="true" />
              <span>{t.classes.retryAction}</span>
            </button>
          </div>
        )}

        {/* Empty State: Zero classes registered in kindergarten */}
        {!loading && !errorMessage && classesList.length === 0 && (
          <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center max-w-md mx-auto space-y-4 shadow-xs">
            <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mx-auto">
              <School className="w-7 h-7 stroke-[1.75]" aria-hidden="true" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">{t.classes.noClassesYetTitle}</h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                {t.classes.noClassesYetDesc}
              </p>
            </div>
            <button
              type="button"
              onClick={handleOpenCreateDrawer}
              className="min-h-[44px] px-5 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg shadow-xs transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 outline-none inline-flex items-center gap-2"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>{t.classes.createClassAction}</span>
            </button>
          </div>
        )}

        {/* Search Empty State: Classes exist, but search filter yielded 0 results */}
        {!loading && !errorMessage && classesList.length > 0 && filteredClasses.length === 0 && (
          <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center max-w-md mx-auto space-y-3 shadow-xs">
            <p className="text-sm font-semibold text-slate-800">
              {t.classes.noSearchResults}
            </p>
            <p className="text-xs text-slate-500">
              {t.classes.searchNoResultsHint}
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedGrade('ALL');
              }}
              className="min-h-[44px] px-4 py-2 text-xs font-semibold text-teal-700 hover:text-teal-800 hover:bg-teal-50 rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 outline-none"
            >
              {t.classes.clearFilters}
            </button>
          </div>
        )}

        {/* Populated State: Grid of Class Cards */}
        {!loading && !errorMessage && filteredClasses.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {filteredClasses.map((classRoom) => (
              <ClassCard
                key={classRoom.id}
                classRoom={classRoom}
                onViewDetails={handleOpenDetailsSheet}
                onEdit={handleOpenEditDrawer}
                onArchive={handleOpenArchiveDialog}
              />
            ))}
          </div>
        )}
      </div>

      {/* 5. Drawers / Sheets / Dialogs */}
      {activeKindergartenId && (
        <CreateClassDrawer
          isOpen={createDrawerOpen}
          kindergartenId={activeKindergartenId}
          onClose={handleCloseCreateDrawer}
          onSuccess={handleCreateSuccess}
        />
      )}

      <EditClassDrawer
        isOpen={editDrawerOpen}
        classRoom={selectedClass}
        onClose={handleCloseEditDrawer}
        onSuccess={handleUpdateSuccess}
      />

      <ClassDetailsSheet
        isOpen={detailsSheetOpen}
        classRoom={selectedClass}
        onClose={handleCloseDetailsSheet}
        onEdit={handleOpenEditDrawer}
        onArchive={handleOpenArchiveDialog}
      />

      <ArchiveClassDialog
        isOpen={archiveDialogOpen}
        classRoom={selectedClass}
        onClose={handleCloseArchiveDialog}
        onSuccess={handleArchiveSuccess}
      />
    </div>
  );
};
