import React from 'react';
import { Search, X, Filter } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { GradeLevel } from '../classValidation';

interface ClassesToolbarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedGrade: 'ALL' | GradeLevel;
  onSelectGrade: (grade: 'ALL' | GradeLevel) => void;
  totalClassesCount: number;
  filteredClassesCount: number;
  onClearFilters: () => void;
}

/**
 * ClassesToolbar
 * In-memory client-side filter and search controls.
 * Accessible with live announcements for screen readers.
 */
export const ClassesToolbar: React.FC<ClassesToolbarProps> = ({
  searchQuery,
  onSearchChange,
  selectedGrade,
  onSelectGrade,
  totalClassesCount,
  filteredClassesCount,
  onClearFilters,
}) => {
  const { t } = useI18n();

  const isFiltered = searchQuery.trim().length > 0 || selectedGrade !== 'ALL';

  return (
    <div className="w-full bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Search Input Box */}
        <div className="relative flex-1 max-w-md">
          <div className="absolute inset-y-0 inset-inline-start-0 ps-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" aria-hidden="true" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={t.classes.searchPlaceholder}
            className="w-full h-11 ps-10 pe-10 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:border-teal-700 focus-visible:ring-2 focus-visible:ring-teal-700/20 outline-none transition-all"
            aria-label={t.classes.searchPlaceholder}
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => onSearchChange('')}
              className="absolute inset-y-0 inset-inline-end-0 pe-3 flex items-center text-slate-400 hover:text-slate-700 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none"
              aria-label={t.classes.clearSearchAria}
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Pills (All / KG1 / KG2 / KG3) */}
        <div className="flex items-center gap-1.5 flex-wrap" role="group" aria-label={t.classes.filterGradeAria}>
          <span className="text-xs text-slate-500 font-medium me-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
            <span>{t.common.filter}:</span>
          </span>

          <button
            type="button"
            onClick={() => onSelectGrade('ALL')}
            className={`min-h-[44px] px-3.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2 outline-none ${
              selectedGrade === 'ALL'
                ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            aria-pressed={selectedGrade === 'ALL'}
          >
            {t.classes.filterAll}
          </button>

          <button
            type="button"
            onClick={() => onSelectGrade('KG1')}
            className={`min-h-[44px] px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2 outline-none ${
              selectedGrade === 'KG1'
                ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            aria-pressed={selectedGrade === 'KG1'}
          >
            {t.classes.filterKG1}
          </button>

          <button
            type="button"
            onClick={() => onSelectGrade('KG2')}
            className={`min-h-[44px] px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2 outline-none ${
              selectedGrade === 'KG2'
                ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            aria-pressed={selectedGrade === 'KG2'}
          >
            {t.classes.filterKG2}
          </button>

          <button
            type="button"
            onClick={() => onSelectGrade('KG3')}
            className={`min-h-[44px] px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2 outline-none ${
              selectedGrade === 'KG3'
                ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            aria-pressed={selectedGrade === 'KG3'}
          >
            {t.classes.filterKG3}
          </button>

          {isFiltered && (
            <button
              type="button"
              onClick={onClearFilters}
              className="min-h-[44px] px-2.5 py-1.5 text-xs text-slate-500 hover:text-slate-800 underline focus-visible:ring-2 focus-visible:ring-teal-700 outline-none"
            >
              {t.classes.clearFilters}
            </button>
          )}
        </div>
      </div>

      {/* Screen Reader Live Count & Status Line */}
      <div
        className="flex items-center justify-between text-xs text-slate-500 border-t border-slate-100 pt-2"
        aria-live="polite"
      >
        <span>
          {t.classes.activeClassesCount}{' '}
          <strong className="text-slate-900 font-semibold">{filteredClassesCount}</strong>
          {totalClassesCount !== filteredClassesCount && (
            <span className="text-slate-400 ms-1">({t.classes.totalCountOutOf} {totalClassesCount})</span>
          )}
        </span>
      </div>
    </div>
  );
};
