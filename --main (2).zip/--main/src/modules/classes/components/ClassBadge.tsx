import React from 'react';
import type { GradeLevel } from '../classValidation';
import { useI18n } from '../../../lib/i18n/I18nContext';

interface ClassBadgeProps {
  gradeLevel: GradeLevel | string;
  className?: string;
}

/**
 * ClassBadge Component
 * Displays calm, accessible badges for educational grade levels (KG1, KG2, KG3).
 * Meets WCAG 2.1 AA contrast requirements (> 4.5:1).
 */
export const ClassBadge: React.FC<ClassBadgeProps> = ({ gradeLevel, className = '' }) => {
  const { t } = useI18n();

  const getBadgeConfig = (level: string) => {
    switch (level) {
      case 'KG1':
        return {
          label: t.classes.badgeKG1,
          style: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        };
      case 'KG2':
        return {
          label: t.classes.badgeKG2,
          style: 'bg-teal-50 text-teal-800 border-teal-200',
        };
      case 'KG3':
        return {
          label: t.classes.badgeKG3,
          style: 'bg-sky-50 text-sky-800 border-sky-200',
        };
      default:
        return {
          label: level,
          style: 'bg-slate-100 text-slate-800 border-slate-200',
        };
    }
  };

  const config = getBadgeConfig(gradeLevel);

  return (
    <span
      className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold border ${config.style} ${className}`}
    >
      {config.label}
    </span>
  );
};
