import React, { useEffect, useRef } from 'react';
import { X, Calendar, DoorClosed, Users, Edit2, Archive, Clock } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { ClassRoom } from '../../../types/database';
import { ClassBadge } from './ClassBadge';

interface ClassDetailsSheetProps {
  isOpen: boolean;
  classRoom: ClassRoom | null;
  onClose: () => void;
  onEdit: (classRoom: ClassRoom) => void;
  onArchive: (classRoom: ClassRoom) => void;
}

/**
 * ClassDetailsSheet Component
 * Implements Sheet per Section 14.3 of DESIGN_SYSTEM.md v1.4.
 * Bottom sheet on mobile with drag handle, centered modal/sheet on desktop.
 * Strictly excludes raw internal technical UUIDs.
 */
export const ClassDetailsSheet: React.FC<ClassDetailsSheetProps> = ({
  isOpen,
  classRoom,
  onClose,
  onEdit,
  onArchive,
}) => {
  const { t, locale } = useI18n();
  const sheetRef = useRef<HTMLDivElement>(null);

  // Focus trap & Escape listener
  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  if (!isOpen || !classRoom) return null;

  // Format creation timestamp according to active system locale
  const dateLocale = locale === 'ar' ? 'ar-SA' : 'en-US';
  const formattedCreationDate = new Date(classRoom.created_at).toLocaleDateString(dateLocale, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="details-sheet-title"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Sheet Container */}
      <div
        ref={sheetRef}
        className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl shadow-xl z-10 flex flex-col max-h-[90vh] sm:max-h-[85vh] animate-in slide-in-from-bottom duration-250 border border-slate-200 focus:outline-none overflow-hidden"
      >
        {/* Mobile Drag Handle Indicator (Section 14.3) */}
        <div className="w-full flex justify-center pt-3 pb-1 sm:hidden">
          <div className="w-9 h-1 rounded-full bg-slate-300" aria-hidden="true" />
        </div>

        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 id="details-sheet-title" className="text-base sm:text-lg font-bold text-slate-900 truncate">
              {classRoom.name}
            </h2>
            <div className="mt-1 flex items-center gap-2">
              <ClassBadge gradeLevel={classRoom.grade_level} />
              <span className="text-xs text-slate-500 font-mono">
                <bdi>{classRoom.academic_year}</bdi>
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-11 h-11 flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none transition-colors"
            aria-label={t.classes.closeDetailsAction}
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-sm text-slate-700">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* Classroom */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center shrink-0 text-slate-500">
                <DoorClosed className="w-4 h-4" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-500 block">{t.classes.roomLabel}</span>
                <span className="text-xs font-bold text-slate-900 truncate block mt-0.5">
                  {classRoom.room_number || t.classes.unassignedRoom}
                </span>
              </div>
            </div>

            {/* Capacity */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center shrink-0 text-teal-700">
                <Users className="w-4 h-4" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-500 block">{t.classes.capacityLabel}</span>
                <span className="text-xs font-bold text-slate-900 truncate block mt-0.5">
                  {classRoom.capacity} {t.classes.capacityValue}
                </span>
              </div>
            </div>

            {/* Academic Year */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center shrink-0 text-slate-500">
                <Calendar className="w-4 h-4" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-500 block">{t.classes.academicYearLabel}</span>
                <bdi className="text-xs font-bold text-slate-900 font-mono block mt-0.5">
                  {classRoom.academic_year}
                </bdi>
              </div>
            </div>

            {/* Creation Date */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center shrink-0 text-slate-500">
                <Clock className="w-4 h-4" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-500 block">{t.classes.createdDateLabel}</span>
                <span className="text-xs font-semibold text-slate-800 block mt-0.5">
                  {formattedCreationDate}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              onClose();
              onArchive(classRoom);
            }}
            className="min-h-[44px] px-3.5 py-2 text-xs font-semibold text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-red-600 outline-none flex items-center gap-1.5"
          >
            <Archive className="w-4 h-4" aria-hidden="true" />
            <span>{t.classes.archiveAction}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200/70 border border-slate-300 rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 outline-none"
            >
              {t.common.cancel}
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onEdit(classRoom);
              }}
              className="min-h-[44px] px-4 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg shadow-xs transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 outline-none flex items-center gap-1.5"
            >
              <Edit2 className="w-4 h-4" aria-hidden="true" />
              <span>{t.classes.editAction}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
