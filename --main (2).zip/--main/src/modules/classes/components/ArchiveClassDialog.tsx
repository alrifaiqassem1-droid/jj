import React, { useState, useEffect, useRef } from 'react';
import { AlertTriangle, Loader2 } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { ClassRoom } from '../../../types/database';
import { archiveClass } from '../classesService';

interface ArchiveClassDialogProps {
  isOpen: boolean;
  classRoom: ClassRoom | null;
  onClose: () => void;
  onSuccess: (archivedClassId: string) => void;
}

/**
 * ArchiveClassDialog Component
 * Confirms soft archival of a class cohort.
 * Strictly guarantees ZERO physical deletion, only calling archiveClass().
 */
export const ArchiveClassDialog: React.FC<ArchiveClassDialogProps> = ({
  isOpen,
  classRoom,
  onClose,
  onSuccess,
}) => {
  const { t } = useI18n();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const dialogRef = useRef<HTMLDivElement>(null);
  const confirmButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (isOpen) {
      setIsSubmitting(false);
      setErrorMessage(null);
      setTimeout(() => {
        confirmButtonRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  // Focus trap & Escape listener
  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape' && !isSubmitting) {
        e.preventDefault();
        onClose();
      }

      if (e.key === 'Tab' && dialogRef.current) {
        const focusableElements = dialogRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        if (e.shiftKey) {
          if (document.activeElement === firstElement) {
            e.preventDefault();
            lastElement?.focus();
          }
        } else {
          if (document.activeElement === lastElement) {
            e.preventDefault();
            firstElement?.focus();
          }
        }
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, isSubmitting, onClose]);

  const handleConfirmArchive = async () => {
    if (!classRoom || isSubmitting) return;

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const result = await archiveClass(classRoom.id);

      if (result.error) {
        setErrorMessage(result.error.message);
        return;
      }

      if (result.data?.archived) {
        onSuccess(classRoom.id);
        onClose();
      }
    } catch {
      setErrorMessage(t.classes.errorNetworkOrServer);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen || !classRoom) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="archive-dialog-title"
      aria-describedby="archive-dialog-desc"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={() => {
          if (!isSubmitting) onClose();
        }}
        aria-hidden="true"
      />

      {/* Dialog Container */}
      <div
        ref={dialogRef}
        className="relative w-full max-w-md bg-white rounded-2xl shadow-xl z-10 p-6 animate-in zoom-in-95 duration-200 border border-slate-200 focus:outline-none space-y-4"
      >
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 border border-amber-200 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-5 h-5 stroke-[2]" aria-hidden="true" />
          </div>

          <div className="min-w-0 flex-1">
            <h3 id="archive-dialog-title" className="text-base font-bold text-slate-900 leading-snug">
              {t.classes.archiveDialogTitle}
            </h3>
            <p className="text-xs font-semibold text-teal-800 mt-1">
              «{classRoom.name}» — {classRoom.grade_level} ({classRoom.academic_year})
            </p>
          </div>
        </div>

        <p id="archive-dialog-desc" className="text-xs text-slate-600 leading-relaxed">
          {t.classes.archiveDialogDescription}
        </p>

        <p className="text-xs font-semibold text-slate-800">
          {t.classes.archiveDialogConfirmNotice}
        </p>

        {errorMessage && (
          <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700 font-medium leading-relaxed">
            {errorMessage}
          </div>
        )}

        {/* Footer Actions */}
        <div className="pt-2 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="min-h-[44px] px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 outline-none disabled:opacity-50"
          >
            {t.classes.cancelAction}
          </button>

          <button
            ref={confirmButtonRef}
            type="button"
            onClick={handleConfirmArchive}
            disabled={isSubmitting}
            className="min-h-[44px] px-5 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors focus-visible:ring-2 focus-visible:ring-red-600 focus-visible:ring-offset-2 outline-none flex items-center gap-2 disabled:opacity-70"
          >
            {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />}
            <span>
              {isSubmitting ? t.classes.archivingAction : t.classes.confirmArchiveAction}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
