import React, { useState, useRef, useEffect } from 'react';
import { MoreVertical, Eye, Edit2, Archive, DoorClosed, Users, Calendar } from 'lucide-react';
import type { ClassRoom } from '../../../types/database';
import { useI18n } from '../../../lib/i18n/I18nContext';
import { ClassBadge } from './ClassBadge';

interface ClassCardProps {
  classRoom: ClassRoom;
  onViewDetails: (classRoom: ClassRoom) => void;
  onEdit: (classRoom: ClassRoom) => void;
  onArchive: (classRoom: ClassRoom) => void;
}

/**
 * ClassCard Component
 * Displays a single educational class cohort with clear hierarchy and accessible actions.
 */
export const ClassCard: React.FC<ClassCardProps> = ({
  classRoom,
  onViewDetails,
  onEdit,
  onArchive,
}) => {
  const { t } = useI18n();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click or Escape key
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    }

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape' && menuOpen) {
        setMenuOpen(false);
      }
    }

    if (menuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [menuOpen]);

  return (
    <div className="bg-white border border-slate-200/90 hover:border-slate-300 rounded-xl p-5 shadow-xs hover:shadow-sm transition-all duration-150 flex flex-col justify-between relative group">
      <div>
        {/* Card Header: Title & Actions Menu */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0 flex-1">
            <h3 className="text-base font-bold text-slate-900 truncate" title={classRoom.name}>
              {classRoom.name}
            </h3>
            <div className="mt-1.5 flex items-center gap-2">
              <ClassBadge gradeLevel={classRoom.grade_level} />
            </div>
          </div>

          {/* Accessible Action Menu */}
          <div className="relative" ref={menuRef}>
            <button
              type="button"
              onClick={() => setMenuOpen(!menuOpen)}
              className="w-11 h-11 flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2 outline-none transition-colors"
              aria-label={`${t.classes.moreActionsAria} ${classRoom.name}`}
              aria-expanded={menuOpen}
              aria-haspopup="true"
            >
              <MoreVertical className="w-5 h-5" aria-hidden="true" />
            </button>

            {menuOpen && (
              <div
                className="absolute inset-inline-end-0 mt-1 w-48 bg-white border border-slate-200 rounded-xl shadow-lg z-20 py-1.5 focus:outline-none animate-in fade-in duration-100"
                role="menu"
                aria-orientation="vertical"
              >
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onViewDetails(classRoom);
                  }}
                  className="w-full text-start px-3.5 py-2.5 text-xs text-slate-700 hover:bg-slate-50 hover:text-slate-900 flex items-center gap-2.5 transition-colors focus-visible:bg-slate-50 outline-none"
                  role="menuitem"
                >
                  <Eye className="w-4 h-4 text-slate-500" aria-hidden="true" />
                  <span>{t.classes.viewDetailsAction}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onEdit(classRoom);
                  }}
                  className="w-full text-start px-3.5 py-2.5 text-xs text-slate-700 hover:bg-slate-50 hover:text-slate-900 flex items-center gap-2.5 transition-colors focus-visible:bg-slate-50 outline-none"
                  role="menuitem"
                >
                  <Edit2 className="w-4 h-4 text-teal-700" aria-hidden="true" />
                  <span>{t.classes.editAction}</span>
                </button>

                <div className="my-1 border-t border-slate-100" />

                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onArchive(classRoom);
                  }}
                  className="w-full text-start px-3.5 py-2.5 text-xs text-red-600 hover:bg-red-50 hover:text-red-700 flex items-center gap-2.5 transition-colors focus-visible:bg-red-50 outline-none"
                  role="menuitem"
                >
                  <Archive className="w-4 h-4" aria-hidden="true" />
                  <span>{t.classes.archiveAction}</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Card Body: Details */}
        <div className="space-y-2 mt-2 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <DoorClosed className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
            <span className="text-slate-500">{t.classes.roomLabel}</span>
            <span className="font-medium text-slate-800 truncate">
              {classRoom.room_number || t.classes.unassignedRoom}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
            <span className="text-slate-500">{t.classes.capacityLabel}</span>
            <span className="font-semibold text-slate-800">
              {classRoom.capacity} {t.classes.capacityValue}
            </span>
          </div>
        </div>
      </div>

      {/* Card Footer: Academic Year & Direct View Action */}
      <div className="border-t border-slate-100 pt-3 mt-4 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 text-slate-500 font-mono text-[11px]">
          <Calendar className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
          <bdi>{classRoom.academic_year}</bdi>
        </div>

        <button
          type="button"
          onClick={() => onViewDetails(classRoom)}
          className="text-teal-700 hover:text-teal-800 font-semibold px-2 py-1 rounded hover:bg-teal-50 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none transition-colors"
        >
          {t.classes.viewDetailsAction}
        </button>
      </div>
    </div>
  );
};
