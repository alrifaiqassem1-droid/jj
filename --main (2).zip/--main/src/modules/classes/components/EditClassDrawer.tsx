import React, { useState, useEffect, useRef } from 'react';
import { X, Loader2, AlertCircle } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import {
  updateClassSchema,
  ALLOWED_GRADE_LEVELS,
  type GradeLevel,
} from '../classValidation';
import { updateClass } from '../classesService';
import type { ClassRoom } from '../../../types/database';

interface EditClassDrawerProps {
  isOpen: boolean;
  classRoom: ClassRoom | null;
  onClose: () => void;
  onSuccess: (updatedClass: ClassRoom) => void;
}

interface FormState {
  name: string;
  grade_level: GradeLevel;
  room_number: string;
  capacity: number;
  academic_year: string;
}

/**
 * EditClassDrawer
 * Slide-out panel from logical inline-end for updating educational class cohorts.
 * Strictly hides technical IDs (UUID, tenant ID).
 */
export const EditClassDrawer: React.FC<EditClassDrawerProps> = ({
  isOpen,
  classRoom,
  onClose,
  onSuccess,
}) => {
  const { t, dir } = useI18n();

  const [form, setForm] = useState<FormState>({
    name: '',
    grade_level: 'KG1',
    room_number: '',
    capacity: 20,
    academic_year: '2026-2027',
  });
  const [initialForm, setInitialForm] = useState<FormState>({
    name: '',
    grade_level: 'KG1',
    room_number: '',
    capacity: 20,
    academic_year: '2026-2027',
  });

  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showUnsavedConfirm, setShowUnsavedConfirm] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const firstInputRef = useRef<HTMLInputElement>(null);

  // Populate form with existing class attributes on open
  useEffect(() => {
    if (isOpen && classRoom) {
      const state: FormState = {
        name: classRoom.name,
        grade_level: (classRoom.grade_level as GradeLevel) || 'KG1',
        room_number: classRoom.room_number || '',
        capacity: classRoom.capacity,
        academic_year: classRoom.academic_year,
      };
      setForm(state);
      setInitialForm(state);
      setFieldErrors({});
      setServerError(null);
      setShowUnsavedConfirm(false);
      setTimeout(() => {
        firstInputRef.current?.focus();
      }, 100);
    }
  }, [isOpen, classRoom]);

  // Check if form was modified
  const isDirty =
    form.name !== initialForm.name ||
    form.grade_level !== initialForm.grade_level ||
    form.room_number !== initialForm.room_number ||
    form.capacity !== initialForm.capacity ||
    form.academic_year !== initialForm.academic_year;

  const handleRequestClose = () => {
    if (isSubmitting) return;
    if (isDirty) {
      setShowUnsavedConfirm(true);
    } else {
      onClose();
    }
  };

  // Keyboard navigation & Focus Trap
  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        e.preventDefault();
        if (showUnsavedConfirm) {
          setShowUnsavedConfirm(false);
        } else {
          handleRequestClose();
        }
      }

      if (e.key === 'Tab' && containerRef.current) {
        const focusableElements = containerRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        if (e.shiftKey) {
          if (document.activeElement === firstElement) {
            e.preventDefault();
            lastElement?.focus();
          }
        } else {
          if (document.activeElement === lastElement) {
            e.preventDefault();
            firstElement?.focus();
          }
        }
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, showUnsavedConfirm, isDirty, isSubmitting]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!classRoom) return;

    setServerError(null);
    setFieldErrors({});

    // 1. Zod Validation
    const validationResult = updateClassSchema.safeParse({
      name: form.name,
      grade_level: form.grade_level,
      room_number: form.room_number || null,
      capacity: Number(form.capacity),
      academic_year: form.academic_year,
    });

    if (!validationResult.success) {
      const errors: Record<string, string> = {};
      for (const issue of validationResult.error.issues) {
        const fieldName = issue.path[0] as string;
        if (!errors[fieldName]) {
          errors[fieldName] = issue.message;
        }
      }
      setFieldErrors(errors);
      return;
    }

    // 2. Submit to Data Layer Service
    setIsSubmitting(true);
    try {
      const result = await updateClass(classRoom.id, validationResult.data);

      if (result.error) {
        setServerError(result.error.message);
        return;
      }

      if (result.data) {
        onSuccess(result.data);
        onClose();
      }
    } catch {
      setServerError(t.classes.errorNetworkOrServer);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen || !classRoom) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-labelledby="edit-drawer-title"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={handleRequestClose}
        aria-hidden="true"
      />

      {/* Drawer Container at logical inline-end */}
      <div
        ref={containerRef}
        className={`relative w-full sm:w-[460px] h-full bg-white shadow-xl flex flex-col justify-between z-10 animate-in ${
          dir === 'rtl' ? 'slide-in-from-left' : 'slide-in-from-right'
        } duration-250 border-s border-slate-200 focus:outline-none`}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 id="edit-drawer-title" className="text-base font-bold text-slate-900">
              {t.classes.editDrawerTitle}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {t.classes.editDrawerSubtitle}
            </p>
          </div>

          <button
            type="button"
            onClick={handleRequestClose}
            disabled={isSubmitting}
            className="w-11 h-11 flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none transition-colors disabled:opacity-50"
            aria-label={t.classes.closeEditDrawerAria}
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Unsaved Changes Confirmation Banner */}
        {showUnsavedConfirm && (
          <div className="bg-amber-50 border-b border-amber-200 p-4 space-y-3">
            <p className="text-xs text-amber-900 font-medium leading-relaxed">
              {t.classes.unsavedChangesWarning}
            </p>
            <div className="flex items-center gap-2 justify-end">
              <button
                type="button"
                onClick={() => setShowUnsavedConfirm(false)}
                className="min-h-[44px] px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 focus-visible:ring-2 focus-visible:ring-teal-700 outline-none"
              >
                {t.classes.keepEditingAction}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowUnsavedConfirm(false);
                  onClose();
                }}
                className="min-h-[44px] px-3 py-1.5 text-xs font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 focus-visible:ring-2 focus-visible:ring-red-600 outline-none"
              >
                {t.classes.discardChangesAction}
              </button>
            </div>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {/* Server Error Alert */}
          {serverError && (
            <div
              className="bg-red-50 border border-red-200 rounded-xl p-3.5 flex items-start gap-2.5 text-red-800 text-xs"
              role="alert"
            >
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
              <div className="flex-1 font-medium leading-relaxed">{serverError}</div>
            </div>
          )}

          {/* 1. Name */}
          <div className="space-y-1.5">
            <label htmlFor="edit-class-name" className="block text-xs font-semibold text-slate-800">
              {t.classes.nameLabel} <span className="text-red-500">*</span>
            </label>
            <input
              ref={firstInputRef}
              id="edit-class-name"
              type="text"
              value={form.name}
              onChange={(e) => {
                setForm({ ...form, name: e.target.value });
                if (fieldErrors.name) setFieldErrors({ ...fieldErrors, name: '' });
              }}
              disabled={isSubmitting}
              className={`w-full h-11 px-3.5 bg-white border rounded-lg text-sm text-slate-900 focus:border-teal-700 focus-visible:ring-2 focus-visible:ring-teal-700/20 outline-none transition-all ${
                fieldErrors.name ? 'border-red-500 bg-red-50/20' : 'border-slate-300'
              }`}
              aria-invalid={!!fieldErrors.name}
            />
            {fieldErrors.name && (
              <p className="text-xs text-red-600 font-medium">{fieldErrors.name}</p>
            )}
          </div>

          {/* 2. Grade Level */}
          <div className="space-y-1.5">
            <label htmlFor="edit-class-grade" className="block text-xs font-semibold text-slate-800">
              {t.classes.gradeLabel} <span className="text-red-500">*</span>
            </label>
            <select
              id="edit-class-grade"
              value={form.grade_level}
              onChange={(e) => {
                setForm({ ...form, grade_level: e.target.value as GradeLevel });
                if (fieldErrors.grade_level) setFieldErrors({ ...fieldErrors, grade_level: '' });
              }}
              disabled={isSubmitting}
              className="w-full h-11 px-3 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:border-teal-700 focus-visible:ring-2 focus-visible:ring-teal-700/20 outline-none transition-all"
            >
              {ALLOWED_GRADE_LEVELS.map((level) => (
                <option key={level} value={level}>
                  {level === 'KG1' && t.classes.gradeOptionKG1}
                  {level === 'KG2' && t.classes.gradeOptionKG2}
                  {level === 'KG3' && t.classes.gradeOptionKG3}
                </option>
              ))}
            </select>
          </div>

          {/* 3. Room Number */}
          <div className="space-y-1.5">
            <label htmlFor="edit-class-room" className="block text-xs font-semibold text-slate-800">
              {t.classes.roomNumberLabel}{' '}
              <span className="text-[11px] text-slate-400 font-normal">{t.classes.optionalLabel}</span>
            </label>
            <input
              id="edit-class-room"
              type="text"
              value={form.room_number}
              onChange={(e) => {
                setForm({ ...form, room_number: e.target.value });
                if (fieldErrors.room_number) setFieldErrors({ ...fieldErrors, room_number: '' });
              }}
              disabled={isSubmitting}
              className={`w-full h-11 px-3.5 bg-white border rounded-lg text-sm text-slate-900 focus:border-teal-700 focus-visible:ring-2 focus-visible:ring-teal-700/20 outline-none transition-all ${
                fieldErrors.room_number ? 'border-red-500' : 'border-slate-300'
              }`}
              aria-invalid={!!fieldErrors.room_number}
            />
            {fieldErrors.room_number && (
              <p className="text-xs text-red-600 font-medium">{fieldErrors.room_number}</p>
            )}
          </div>

          {/* 4. Capacity */}
          <div className="space-y-1.5">
            <label htmlFor="edit-class-capacity" className="block text-xs font-semibold text-slate-800">
              {t.classes.capacityInputLabel} <span className="text-red-500">*</span>
            </label>
            <input
              id="edit-class-capacity"
              type="number"
              min={1}
              max={40}
              value={form.capacity}
              onChange={(e) => {
                setForm({ ...form, capacity: Number(e.target.value) });
                if (fieldErrors.capacity) setFieldErrors({ ...fieldErrors, capacity: '' });
              }}
              disabled={isSubmitting}
              className={`w-full h-11 px-3.5 bg-white border rounded-lg text-sm text-slate-900 focus:border-teal-700 focus-visible:ring-2 focus-visible:ring-teal-700/20 outline-none transition-all ${
                fieldErrors.capacity ? 'border-red-500' : 'border-slate-300'
              }`}
              aria-invalid={!!fieldErrors.capacity}
            />
            {fieldErrors.capacity && (
              <p className="text-xs text-red-600 font-medium">{fieldErrors.capacity}</p>
            )}
          </div>

          {/* 5. Academic Year */}
          <div className="space-y-1.5">
            <label htmlFor="edit-class-year" className="block text-xs font-semibold text-slate-800">
              {t.classes.academicYearInputLabel} <span className="text-red-500">*</span>
            </label>
            <input
              id="edit-class-year"
              type="text"
              value={form.academic_year}
              onChange={(e) => {
                setForm({ ...form, academic_year: e.target.value });
                if (fieldErrors.academic_year) setFieldErrors({ ...fieldErrors, academic_year: '' });
              }}
              disabled={isSubmitting}
              className={`w-full h-11 px-3.5 bg-white border rounded-lg text-sm text-slate-900 font-mono focus:border-teal-700 focus-visible:ring-2 focus-visible:ring-teal-700/20 outline-none transition-all ${
                fieldErrors.academic_year ? 'border-red-500' : 'border-slate-300'
              }`}
              aria-invalid={!!fieldErrors.academic_year}
            />
            {fieldErrors.academic_year && (
              <p className="text-xs text-red-600 font-medium">{fieldErrors.academic_year}</p>
            )}
          </div>
        </form>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={handleRequestClose}
            disabled={isSubmitting}
            className="min-h-[44px] px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200/70 border border-slate-300 rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 outline-none disabled:opacity-50"
          >
            {t.common.cancel}
          </button>

          <button
            type="button"
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="min-h-[44px] px-5 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg shadow-xs transition-colors focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2 outline-none flex items-center gap-2 disabled:opacity-70"
          >
            {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />}
            <span>
              {isSubmitting ? t.classes.submittingEditAction : t.classes.submitEditAction}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
