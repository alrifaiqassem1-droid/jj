import React from 'react';
import { Building2, ShieldCheck, MapPin } from 'lucide-react';
import type { Kindergarten } from '../../../types/database';
import { useI18n } from '../../../lib/i18n/I18nContext';

interface KindergartenContextBannerProps {
  kindergarten: Kindergarten | null;
  loading: boolean;
}

/**
 * KindergartenContextBanner
 * Renders verified institutional context (name, license number, city)
 * Strictly adheres to verified Gate 1 schema without invented stats.
 */
export const KindergartenContextBanner: React.FC<KindergartenContextBannerProps> = ({
  kindergarten,
  loading,
}) => {
  const { t } = useI18n();

  if (loading) {
    return (
      <div className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5 animate-pulse">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-slate-200 rounded-lg shrink-0" />
          <div className="space-y-2 flex-1">
            <div className="h-4 bg-slate-200 rounded w-1/3" />
            <div className="h-3 bg-slate-200 rounded w-1/4" />
          </div>
        </div>
      </div>
    );
  }

  if (!kindergarten) {
    return null;
  }

  return (
    <div className="w-full bg-teal-50/70 border border-teal-200/80 rounded-xl p-4 sm:p-5 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Kindergarten Identity */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-11 h-11 rounded-xl bg-teal-700 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Building2 className="w-5 h-5 stroke-[2]" aria-hidden="true" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 truncate">
                {kindergarten.name}
              </h2>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-teal-100 text-teal-800">
                <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t.classes.institutionalBannerTitle}</span>
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              {t.classes.subtitle}
            </p>
          </div>
        </div>

        {/* Verified Attributes (License & City only) */}
        <div className="flex items-center gap-4 text-xs text-slate-700 flex-wrap sm:justify-end border-t sm:border-t-0 border-teal-200/50 pt-2 sm:pt-0">
          {kindergarten.license_number && (
            <div className="flex items-center gap-1.5 bg-white/80 px-2.5 py-1 rounded-md border border-teal-100 shadow-2xs">
              <span className="text-slate-500 font-medium">{t.classes.licenseLabel}</span>
              <bdi className="font-semibold text-slate-900 font-mono text-[11px]">
                {kindergarten.license_number}
              </bdi>
            </div>
          )}

          {kindergarten.city && (
            <div className="flex items-center gap-1.5 bg-white/80 px-2.5 py-1 rounded-md border border-teal-100 shadow-2xs">
              <MapPin className="w-3.5 h-3.5 text-teal-700" aria-hidden="true" />
              <span className="text-slate-500 font-medium">{t.classes.cityLabel}</span>
              <span className="font-semibold text-slate-900">{kindergarten.city}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
