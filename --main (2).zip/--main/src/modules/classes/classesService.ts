import { supabase } from '../../lib/supabase/client';
import type { ClassRoom } from '../../types/database';
import {
  createClassSchema,
  updateClassSchema,
  type CreateClassInput,
  type UpdateClassInput,
} from './classValidation';

/**
 * Classes Domain & Data Service
 *
 * Architecture & Security Invariants:
 * 1. ZERO TRUST: `kindergartenId` passed by caller is strictly a query context selector.
 *    True authorization is governed by the database RLS policies ("Classes: Read", "Classes: Admin Manage")
 *    using the cryptographic session `auth.uid()`.
 * 2. SOFT DELETE ONLY: Physical deletion (`DELETE FROM classes`) is STRICTLY PROHIBITED.
 *    Archiving is implemented strictly via `UPDATE classes SET deleted_at = NOW()`.
 * 3. NO CLIENT AUDIT INSERTS: Direct insertion into `audit_logs` from the browser client is blocked
 *    by database RLS (default deny, no insert policy). The service NEVER attempts client-side audit writes.
 * 4. VALIDATION CONTRACT: All mutations are pre-validated via Zod schemas before hitting PostgREST.
 *    Database-level uniqueness constraint `(kindergarten_id, name, academic_year)` is gracefully handled.
 */

export interface ServiceResult<T> {
  data: T | null;
  error: Error | null;
  errorCode?: string;
}

/**
 * Maps PostgreSQL and Supabase errors to domain-specific Arabic messages.
 */
function mapPostgresError(error: { code?: string; message: string }): { message: string; code?: string } {
  // PostgreSQL 23505: unique_violation (unique_class_name_per_year)
  if (error.code === '23505' || error.message.includes('unique_class_name_per_year')) {
    return {
      message: 'توجد شعبة مسجلة مسبقاً بهذا الاسم لنفس العام الدراسي في هذه الروضة',
      code: 'DUPLICATE_CLASS_NAME_YEAR',
    };
  }

  // PostgreSQL 42501: insufficient_privilege (RLS rejection)
  if (error.code === '42501' || error.message.includes('row-level security')) {
    return {
      message: 'غير مصرح لك بإجراء هذه العملية على شعب هذه الروضة',
      code: 'PERMISSION_DENIED_RLS',
    };
  }

  // PostgreSQL 23503: foreign_key_violation
  if (error.code === '23503') {
    return {
      message: 'فشل في ربط السجل، الروضة المحددة غير موجودة أو مقيدة',
      code: 'FOREIGN_KEY_VIOLATION',
    };
  }

  // Check constraint violation
  if (error.code === '23514') {
    return {
      message: 'فشلت العملية، إحدى القيم المدخلة تنتهك قيود النظام الأساسية',
      code: 'CHECK_CONSTRAINT_VIOLATION',
    };
  }

  return {
    message: error.message || 'حدث خطأ غير متوقع أثناء معالجة بيانات الشعبة',
    code: error.code,
  };
}

/**
 * Retrieve active classes belonging to a kindergarten.
 * Automatically filtered by `deleted_at IS NULL` and protected by RLS.
 */
export async function getActiveClasses(kindergartenId: string): Promise<ServiceResult<ClassRoom[]>> {
  try {
    if (!kindergartenId || typeof kindergartenId !== 'string') {
      return { data: null, error: new Error('معرف الروضة غير محدد أو غير صالح'), errorCode: 'INVALID_KINDERGARTEN_ID' };
    }

    const { data, error } = await supabase
      .from('classes')
      .select('*')
      .eq('kindergarten_id', kindergartenId)
      .is('deleted_at', null)
      .order('grade_level', { ascending: true })
      .order('name', { ascending: true });

    if (error) {
      const mapped = mapPostgresError(error);
      return { data: null, error: new Error(mapped.message), errorCode: mapped.code };
    }

    return { data: (data as ClassRoom[]) || [], error: null };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'خطأ أثناء جلب قائمة الشعب الدراسية';
    return { data: null, error: new Error(msg), errorCode: 'UNEXPECTED_ERROR' };
  }
}

/**
 * Retrieve a single class by ID.
 * Returns null if archived or non-existent.
 */
export async function getClassById(classId: string): Promise<ServiceResult<ClassRoom>> {
  try {
    if (!classId || typeof classId !== 'string') {
      return { data: null, error: new Error('معرف الشعبة غير محدد'), errorCode: 'INVALID_CLASS_ID' };
    }

    const { data, error } = await supabase
      .from('classes')
      .select('*')
      .eq('id', classId)
      .is('deleted_at', null)
      .maybeSingle();

    if (error) {
      const mapped = mapPostgresError(error);
      return { data: null, error: new Error(mapped.message), errorCode: mapped.code };
    }

    return { data: data as ClassRoom | null, error: null };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'خطأ أثناء استرجاع بيانات الشعبة';
    return { data: null, error: new Error(msg), errorCode: 'UNEXPECTED_ERROR' };
  }
}

/**
 * Create a new class cohort for a kindergarten.
 * Validates inputs against `createClassSchema` before calling PostgREST.
 */
export async function createClass(
  kindergartenId: string,
  rawInput: unknown
): Promise<ServiceResult<ClassRoom>> {
  try {
    if (!kindergartenId || typeof kindergartenId !== 'string') {
      return { data: null, error: new Error('معرف الروضة مطلوب لإنشاء شعبة'), errorCode: 'INVALID_KINDERGARTEN_ID' };
    }

    // 1. Zod Validation
    const validationResult = createClassSchema.safeParse(rawInput);
    if (!validationResult.success) {
      const firstIssue = validationResult.error.issues[0];
      const errorMessage = firstIssue ? firstIssue.message : 'بيانات الشعبة غير صالحة';
      return { data: null, error: new Error(errorMessage), errorCode: 'VALIDATION_FAILED' };
    }

    const validated: CreateClassInput = validationResult.data;

    // 2. PostgREST Insert (Subject to RLS "Classes: Admin Manage")
    const { data, error } = await supabase
      .from('classes')
      .insert({
        kindergarten_id: kindergartenId,
        name: validated.name,
        grade_level: validated.grade_level,
        room_number: validated.room_number ?? null,
        capacity: validated.capacity,
        academic_year: validated.academic_year,
      })
      .select('*')
      .single();

    if (error) {
      const mapped = mapPostgresError(error);
      return { data: null, error: new Error(mapped.message), errorCode: mapped.code };
    }

    return { data: data as ClassRoom, error: null };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'خطأ غير متوقع أثناء إنشاء الشعبة';
    return { data: null, error: new Error(msg), errorCode: 'UNEXPECTED_ERROR' };
  }
}

/**
 * Update an existing class cohort.
 * Validates inputs against `updateClassSchema` before calling PostgREST.
 */
export async function updateClass(
  classId: string,
  rawInput: unknown
): Promise<ServiceResult<ClassRoom>> {
  try {
    if (!classId || typeof classId !== 'string') {
      return { data: null, error: new Error('معرف الشعبة مطلوب لتحديث البيانات'), errorCode: 'INVALID_CLASS_ID' };
    }

    // 1. Zod Validation
    const validationResult = updateClassSchema.safeParse(rawInput);
    if (!validationResult.success) {
      const firstIssue = validationResult.error.issues[0];
      const errorMessage = firstIssue ? firstIssue.message : 'بيانات التحديث غير صالحة';
      return { data: null, error: new Error(errorMessage), errorCode: 'VALIDATION_FAILED' };
    }

    const validated: UpdateClassInput = validationResult.data;

    // Check if there are any fields to update
    const updatePayload: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };

    if (validated.name !== undefined) updatePayload.name = validated.name;
    if (validated.grade_level !== undefined) updatePayload.grade_level = validated.grade_level;
    if (validated.room_number !== undefined) updatePayload.room_number = validated.room_number;
    if (validated.capacity !== undefined) updatePayload.capacity = validated.capacity;
    if (validated.academic_year !== undefined) updatePayload.academic_year = validated.academic_year;

    // 2. PostgREST Update (Subject to RLS "Classes: Admin Manage")
    const { data, error } = await supabase
      .from('classes')
      .update(updatePayload)
      .eq('id', classId)
      .is('deleted_at', null)
      .select('*')
      .single();

    if (error) {
      const mapped = mapPostgresError(error);
      return { data: null, error: new Error(mapped.message), errorCode: mapped.code };
    }

    return { data: data as ClassRoom, error: null };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'خطأ غير متوقع أثناء تحديث الشعبة';
    return { data: null, error: new Error(msg), errorCode: 'UNEXPECTED_ERROR' };
  }
}

/**
 * Archive a class cohort (SOFT-DELETE ONLY).
 *
 * CRITICAL ARCHITECTURAL GUARANTEE:
 * This method sets `deleted_at = NOW()`.
 * It NEVER performs a physical DELETE on the table.
 */
export async function archiveClass(classId: string): Promise<ServiceResult<{ archived: boolean }>> {
  try {
    if (!classId || typeof classId !== 'string') {
      return { data: null, error: new Error('معرف الشعبة مطلوب للأرشفة'), errorCode: 'INVALID_CLASS_ID' };
    }

    // SOFT-DELETE via UPDATE only
    const { data, error } = await supabase
      .from('classes')
      .update({
        deleted_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq('id', classId)
      .is('deleted_at', null)
      .select('id')
      .maybeSingle();

    if (error) {
      const mapped = mapPostgresError(error);
      return { data: null, error: new Error(mapped.message), errorCode: mapped.code };
    }

    if (!data) {
      return {
        data: null,
        error: new Error('لم يتم العثور على الشعبة المحددة، أو قد تم أرشفتها مسبقاً'),
        errorCode: 'CLASS_NOT_FOUND',
      };
    }

    return { data: { archived: true }, error: null };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'خطأ غير متوقع أثناء أرشفة الشعبة';
    return { data: null, error: new Error(msg), errorCode: 'UNEXPECTED_ERROR' };
  }
}
