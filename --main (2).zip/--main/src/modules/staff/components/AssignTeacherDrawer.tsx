import React, { useState, useEffect, useRef } from 'react';
import { X, Loader2, UserCheck } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { TeacherWithAssignments } from '../staffTypes';
import type { ClassOption } from './TeachersToolbar';
import { assignTeacherToClass } from '../staffService';

interface AssignTeacherDrawerProps {
  isOpen: boolean;
  kindergartenId: string;
  teachersList: TeacherWithAssignments[];
  classesList: ClassOption[];
  preSelectedTeacher: TeacherWithAssignments | null;
  onClose: () => void;
  onSuccess: () => void;
}

export const AssignTeacherDrawer: React.FC<AssignTeacherDrawerProps> = ({
  isOpen,
  kindergartenId,
  teachersList,
  classesList,
  preSelectedTeacher,
  onClose,
  onSuccess,
}) => {
  const { t, dir } = useI18n();
  const containerRef = useRef<HTMLDivElement>(null);
  const previouslyFocusedElementRef = useRef<HTMLElement | null>(null);

  const [selectedTeacherId, setSelectedTeacherId] = useState<string>('');
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [isLeadTeacher, setIsLeadTeacher] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync state when drawer opens or preSelectedTeacher changes
  useEffect(() => {
    if (isOpen) {
      previouslyFocusedElementRef.current = document.activeElement as HTMLElement | null;
      setSelectedTeacherId(preSelectedTeacher ? preSelectedTeacher.userId : (teachersList[0]?.userId ?? ''));
      setSelectedClassId(classesList[0]?.id ?? '');
      setIsLeadTeacher(false);
      setErrorMessage(null);

      // Focus drawer container
      setTimeout(() => {
        containerRef.current?.focus();
      }, 50);
    } else {
      previouslyFocusedElementRef.current?.focus();
    }
  }, [isOpen, preSelectedTeacher, teachersList, classesList]);

  // Focus trap & Escape listener
  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape' && !isSubmitting) {
        onClose();
        return;
      }

      if (event.key === 'Tab' && containerRef.current) {
        const focusable = containerRef.current.querySelectorAll<HTMLElement>(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (focusable.length === 0) return;

        const firstElement = focusable[0];
        const lastElement = focusable[focusable.length - 1];

        if (event.shiftKey) {
          if (document.activeElement === firstElement) {
            lastElement.focus();
            event.preventDefault();
          }
        } else {
          if (document.activeElement === lastElement) {
            firstElement.focus();
            event.preventDefault();
          }
        }
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, isSubmitting, onClose]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTeacherId || !selectedClassId || isSubmitting) return;

    setIsSubmitting(true);
    setErrorMessage(null);

    const result = await assignTeacherToClass(kindergartenId, {
      teacher_id: selectedTeacherId,
      class_id: selectedClassId,
      is_lead_teacher: isLeadTeacher,
    });

    setIsSubmitting(false);

    if (result.error) {
      const code = result.errorCode;
      if (code && t.teachers[code]) {
        setErrorMessage(t.teachers[code]);
      } else {
        setErrorMessage(t.teachers.SERVICE_NETWORK_ERROR);
      }
      return;
    }

    onSuccess();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden"
      role="dialog"
      aria-modal="true"
      aria-labelledby="assign-drawer-title"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={!isSubmitting ? onClose : undefined}
        aria-hidden="true"
      />

      {/* Logical Inline-End Drawer Container */}
      <div className="fixed inset-y-0 inset-inline-end-0 flex max-w-full">
        <div
          ref={containerRef}
          tabIndex={-1}
          className={`w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between border-inline-start border-slate-200 animate-in ${
            dir === 'rtl' ? 'slide-in-from-left' : 'slide-in-from-right'
          } duration-300 focus:outline-none`}
        >
          {/* Header */}
          <div className="p-6 border-b border-slate-100 flex items-start justify-between gap-4">
            <div>
              <h2 id="assign-drawer-title" className="text-lg font-bold text-slate-900">
                {t.teachers.assignDrawerTitle}
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                {t.teachers.assignDrawerSubtitle}
              </p>
            </div>

            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="w-11 h-11 flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors disabled:opacity-50"
              aria-label={t.teachers.closeDrawerAria}
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>

          {/* Body / Form */}
          <form id="assign-teacher-form" onSubmit={handleSubmit} className="flex-1 p-6 space-y-5 overflow-y-auto">
            {errorMessage && (
              <div className="p-3.5 bg-red-50 border border-red-200 rounded-lg text-xs font-medium text-red-800 animate-in fade-in">
                {errorMessage}
              </div>
            )}

            {/* Select Teacher */}
            <div>
              <label htmlFor="assign-teacher-select" className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t.teachers.selectTeacherLabel} <span className="text-red-700">*</span>
              </label>
              <select
                id="assign-teacher-select"
                value={selectedTeacherId}
                onChange={(e) => setSelectedTeacherId(e.target.value)}
                disabled={isSubmitting || !!preSelectedTeacher}
                className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none transition-all disabled:opacity-60 disabled:cursor-not-allowed"
                required
              >
                {teachersList.map((teacher) => (
                  <option key={teacher.userId} value={teacher.userId}>
                    {teacher.fullName}
                  </option>
                ))}
              </select>
            </div>

            {/* Select Class */}
            <div>
              <label htmlFor="assign-class-select" className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t.teachers.selectClassLabel} <span className="text-red-700">*</span>
              </label>
              <select
                id="assign-class-select"
                value={selectedClassId}
                onChange={(e) => setSelectedClassId(e.target.value)}
                disabled={isSubmitting}
                className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none transition-all"
                required
              >
                {classesList.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Is Lead Teacher Checkbox */}
            <div className="pt-2">
              <label className="flex items-start gap-3 p-3.5 bg-teal-50/50 border border-teal-200/60 rounded-xl cursor-pointer hover:bg-teal-50 transition-colors">
                <input
                  type="checkbox"
                  checked={isLeadTeacher}
                  onChange={(e) => setIsLeadTeacher(e.target.checked)}
                  disabled={isSubmitting}
                  className="mt-0.5 w-4 h-4 text-teal-700 rounded border-slate-300 focus:ring-teal-700 cursor-pointer"
                />
                <div>
                  <span className="text-xs font-bold text-slate-900 block">
                    {t.teachers.isLeadCheckboxLabel}
                  </span>
                  <span className="text-[11px] text-slate-500 block mt-0.5">
                    {t.teachers.isLeadCheckboxHelp}
                  </span>
                </div>
              </label>
            </div>
          </form>

          {/* Footer */}
          <div className="p-6 border-t border-slate-100 flex items-center justify-end gap-3 bg-slate-50/50">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 h-11 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-200/70 transition-colors disabled:opacity-50"
            >
              {t.common.cancel}
            </button>

            <button
              type="submit"
              form="assign-teacher-form"
              disabled={isSubmitting || !selectedTeacherId || !selectedClassId}
              className="inline-flex items-center justify-center gap-2 px-5 h-11 rounded-lg text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 transition-colors disabled:opacity-50 shadow-xs"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                  <span>{t.teachers.submittingAssignAction}</span>
                </>
              ) : (
                <>
                  <UserCheck className="w-4 h-4" aria-hidden="true" />
                  <span>{t.teachers.submitAssignAction}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
