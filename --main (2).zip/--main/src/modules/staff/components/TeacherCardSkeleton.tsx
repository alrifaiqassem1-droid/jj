import React from 'react';

export const TeacherCardSkeleton: React.FC = () => {
  return (
    <div
      aria-hidden="true"
      className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs flex flex-col justify-between animate-pulse"
    >
      <div>
        {/* Header with avatar skeleton and name skeleton */}
        <div className="flex items-center gap-3.5 mb-4">
          <div className="w-12 h-12 rounded-full bg-slate-200 shrink-0" />
          <div className="flex-1 space-y-2">
            <div className="h-4 bg-slate-200 rounded-md w-3/4" />
            <div className="h-3 bg-slate-200 rounded-md w-1/2" />
          </div>
        </div>

        {/* Section title skeleton */}
        <div className="h-3 bg-slate-200 rounded-md w-1/3 mb-2" />

        {/* Assignment tags skeleton */}
        <div className="space-y-2 mt-3">
          <div className="h-7 bg-slate-100 rounded-lg w-full" />
          <div className="h-7 bg-slate-100 rounded-lg w-5/6" />
        </div>
      </div>

      {/* Footer action button skeleton */}
      <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
        <div className="h-9 bg-slate-200 rounded-lg w-28" />
        <div className="h-4 bg-slate-200 rounded-md w-16" />
      </div>
    </div>
  );
};
