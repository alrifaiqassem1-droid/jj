import React from 'react';
import { User, Phone, Plus, Crown, Award, Trash2 } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { TeacherWithAssignments, TeacherAssignmentSummary } from '../staffTypes';

interface TeacherCardProps {
  teacher: TeacherWithAssignments;
  onOpenAssign: (teacher: TeacherWithAssignments) => void;
  onToggleLead: (assignment: TeacherAssignmentSummary) => void;
  onOpenUnassign: (teacher: TeacherWithAssignments, assignment: TeacherAssignmentSummary) => void;
  isActionDisabled?: boolean;
}

export const TeacherCard: React.FC<TeacherCardProps> = ({
  teacher,
  onOpenAssign,
  onToggleLead,
  onOpenUnassign,
  isActionDisabled = false,
}) => {
  const { t } = useI18n();

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between">
      <div>
        {/* Header: Avatar, Name, Phone */}
        <div className="flex items-start gap-3.5 mb-4">
          <div className="w-12 h-12 rounded-full bg-teal-100 border border-teal-200/80 text-teal-800 font-bold flex items-center justify-center shrink-0">
            {teacher.avatarUrl ? (
              <img
                src={teacher.avatarUrl}
                alt={teacher.fullName}
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <User className="w-6 h-6 text-teal-800" aria-hidden="true" />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <h3 className="text-base font-bold text-slate-900 truncate">
              {teacher.fullName}
            </h3>
            {teacher.phoneNumber ? (
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
                <bdi className="font-mono text-slate-600">{teacher.phoneNumber}</bdi>
              </div>
            ) : (
              <p className="text-xs text-slate-400 mt-1">{t.common.active}</p>
            )}
          </div>
        </div>

        {/* Assignments section */}
        <div className="mt-3">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 mb-2">
            <span>{t.teachers.assignedClassesCount}</span>
            <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full font-mono text-[11px]">
              {teacher.assignments.length}
            </span>
          </div>

          {teacher.assignments.length === 0 ? (
            <div className="p-3 bg-amber-50/60 border border-amber-200/60 rounded-lg text-xs text-amber-800 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
              <span>{t.teachers.unassignedBadge}</span>
            </div>
          ) : (
            <div className="space-y-2">
              {teacher.assignments.map((assignment) => (
                <div
                  key={assignment.id}
                  className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/70 flex items-center justify-between gap-2"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-slate-800 truncate">
                        {assignment.className}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 text-slate-700 font-medium">
                        {assignment.gradeLevel}
                      </span>
                    </div>

                    <div className="mt-1 flex items-center gap-1.5">
                      {assignment.isLeadTeacher ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200/60">
                          <Crown className="w-3 h-3 text-teal-700" aria-hidden="true" />
                          {t.teachers.leadTeacherBadge}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] text-slate-500 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                          <Award className="w-3 h-3 text-slate-400" aria-hidden="true" />
                          {t.teachers.assistantTeacherBadge}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions for this specific assignment */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => onToggleLead(assignment)}
                      disabled={isActionDisabled}
                      className="p-1.5 rounded-md text-slate-500 hover:text-teal-800 hover:bg-teal-50 transition-colors disabled:opacity-40"
                      title={assignment.isLeadTeacher ? t.teachers.removeLeadAction : t.teachers.makeLeadAction}
                      aria-label={assignment.isLeadTeacher ? t.teachers.removeLeadAction : t.teachers.makeLeadAction}
                    >
                      <Crown className={`w-4 h-4 ${assignment.isLeadTeacher ? 'text-teal-700 fill-teal-100' : ''}`} />
                    </button>

                    <button
                      type="button"
                      onClick={() => onOpenUnassign(teacher, assignment)}
                      disabled={isActionDisabled}
                      className="p-1.5 rounded-md text-slate-400 hover:text-red-700 hover:bg-red-50 transition-colors disabled:opacity-40"
                      title={t.teachers.unassignAction}
                      aria-label={t.teachers.unassignAction}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Footer: Quick Assign Button */}
      <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-end">
        <button
          type="button"
          onClick={() => onOpenAssign(teacher)}
          disabled={isActionDisabled}
          className="inline-flex items-center gap-1.5 px-3.5 h-9 rounded-lg text-xs font-semibold text-teal-800 bg-teal-50 hover:bg-teal-100 border border-teal-200 transition-colors disabled:opacity-50"
        >
          <Plus className="w-3.5 h-3.5" aria-hidden="true" />
          <span>{t.teachers.assignToClassAction}</span>
        </button>
      </div>
    </div>
  );
};
