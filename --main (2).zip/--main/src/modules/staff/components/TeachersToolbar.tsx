import React from 'react';
import { Search, X, Filter } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';

export interface ClassOption {
  id: string;
  name: string;
}

export type StatusFilter = 'ALL' | 'ASSIGNED' | 'UNASSIGNED';

interface TeachersToolbarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedClassId: string;
  onClassChange: (classId: string) => void;
  selectedStatus: StatusFilter;
  onStatusChange: (status: StatusFilter) => void;
  classesList: ClassOption[];
  totalCount: number;
}

export const TeachersToolbar: React.FC<TeachersToolbarProps> = ({
  searchQuery,
  onSearchChange,
  selectedClassId,
  onClassChange,
  selectedStatus,
  onStatusChange,
  classesList,
  totalCount,
}) => {
  const { t } = useI18n();

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 p-4 mb-6 shadow-xs flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
      {/* Search Input */}
      <div className="relative flex-1 min-w-[240px]">
        <div className="absolute inset-y-0 inset-inline-start-0 ps-3.5 flex items-center pointer-events-none text-slate-400">
          <Search className="w-4 h-4" aria-hidden="true" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={t.teachers.searchPlaceholder}
          className="w-full h-11 ps-10 pe-10 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none transition-all"
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => onSearchChange('')}
            className="absolute inset-y-0 inset-inline-end-0 pe-3 flex items-center text-slate-400 hover:text-slate-600 focus:outline-none"
            aria-label={t.children.clearSearchAria}
          >
            <X className="w-4 h-4" aria-hidden="true" />
          </button>
        )}
      </div>

      {/* Filters: Class Cohort & Assignment Status */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Class Filter */}
        <div className="relative min-w-[160px]">
          <select
            value={selectedClassId}
            onChange={(e) => onClassChange(e.target.value)}
            className="w-full h-11 ps-3 pe-8 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 font-medium focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none cursor-pointer transition-all"
            aria-label={t.children.filterClassAria}
          >
            <option value="ALL">{t.teachers.filterAllClasses}</option>
            {classesList.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div className="relative min-w-[140px]">
          <select
            value={selectedStatus}
            onChange={(e) => onStatusChange(e.target.value as StatusFilter)}
            className="w-full h-11 ps-3 pe-8 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 font-medium focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none cursor-pointer transition-all"
          >
            <option value="ALL">{t.teachers.filterStatusAll}</option>
            <option value="ASSIGNED">{t.teachers.filterStatusAssigned}</option>
            <option value="UNASSIGNED">{t.teachers.filterStatusUnassigned}</option>
          </select>
        </div>

        {/* Total Count Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 h-11 bg-teal-50 border border-teal-200/60 rounded-lg text-xs font-semibold text-teal-800">
          <Filter className="w-3.5 h-3.5 text-teal-700" aria-hidden="true" />
          <span>
            {totalCount} {t.teachers.totalTeachersCount}
          </span>
        </div>
      </div>
    </div>
  );
};
