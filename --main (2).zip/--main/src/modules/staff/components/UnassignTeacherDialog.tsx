import React, { useEffect, useRef } from 'react';
import { AlertTriangle, Loader2 } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { TeacherAssignmentSummary, TeacherWithAssignments } from '../staffTypes';

interface UnassignTeacherDialogProps {
  isOpen: boolean;
  teacher: TeacherWithAssignments | null;
  assignment: TeacherAssignmentSummary | null;
  isSubmitting: boolean;
  onConfirm: () => void;
  onClose: () => void;
}

export const UnassignTeacherDialog: React.FC<UnassignTeacherDialogProps> = ({
  isOpen,
  teacher,
  assignment,
  isSubmitting,
  onConfirm,
  onClose,
}) => {
  const { t } = useI18n();
  const previouslyFocusedElementRef = useRef<HTMLElement | null>(null);
  const confirmButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (isOpen) {
      previouslyFocusedElementRef.current = document.activeElement as HTMLElement | null;
      setTimeout(() => {
        confirmButtonRef.current?.focus();
      }, 50);
    } else {
      previouslyFocusedElementRef.current?.focus();
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape' && !isSubmitting) {
        onClose();
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, isSubmitting, onClose]);

  if (!isOpen || !teacher || !assignment) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs"
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="unassign-dialog-title"
      aria-describedby="unassign-dialog-desc"
    >
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 animate-in zoom-in-95 duration-200">
        <div className="flex items-start gap-4">
          <div className="w-11 h-11 rounded-xl bg-red-50 text-red-700 flex items-center justify-center shrink-0 border border-red-100">
            <AlertTriangle className="w-5 h-5" aria-hidden="true" />
          </div>

          <div className="flex-1">
            <h3 id="unassign-dialog-title" className="text-base font-bold text-slate-900">
              {t.teachers.unassignDialogTitle}
            </h3>
            <p id="unassign-dialog-desc" className="text-xs text-slate-500 mt-1 leading-relaxed">
              {t.teachers.unassignDialogDesc}
            </p>

            {/* Target Details Badge */}
            <div className="mt-3.5 p-3 bg-slate-50 rounded-lg border border-slate-200/80 text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">{t.teachers.selectTeacherLabel}:</span>
                <span className="font-bold text-slate-900">{teacher.fullName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">{t.teachers.selectClassLabel}:</span>
                <span className="font-bold text-teal-800">{assignment.className}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-6 flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 h-11 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors disabled:opacity-50"
          >
            {t.common.cancel}
          </button>

          <button
            ref={confirmButtonRef}
            type="button"
            onClick={onConfirm}
            disabled={isSubmitting}
            className="inline-flex items-center justify-center gap-2 px-4 h-11 rounded-lg text-xs font-semibold text-white bg-red-600 hover:bg-red-700 transition-colors disabled:opacity-50 shadow-xs"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                <span>{t.teachers.unassigningAction}</span>
              </>
            ) : (
              <span>{t.teachers.confirmUnassignAction}</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
