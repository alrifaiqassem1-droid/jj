import type { TeacherClassAssignment } from '../../types/database';

export interface TeacherAssignmentSummary {
  id: string;
  classId: string;
  className: string;
  gradeLevel: string;
  isLeadTeacher: boolean;
  assignedAt: string;
}

export interface TeacherWithAssignments {
  membershipId: string;
  userId: string;
  fullName: string;
  phoneNumber: string | null;
  avatarUrl: string | null;
  isActive: boolean;
  assignments: TeacherAssignmentSummary[];
}

export type StaffErrorCode =
  | 'DUPLICATE_ASSIGNMENT'
  | 'TEACHER_NOT_ELIGIBLE'
  | 'CLASS_NOT_FOUND_OR_ARCHIVED'
  | 'CROSS_KINDERGARTEN_ASSIGNMENT_DENIED'
  | 'PERMISSION_DENIED_RLS'
  | 'VALIDATION_FAILED'
  | 'SERVICE_NETWORK_ERROR';

export interface ServiceResult<T> {
  data: T | null;
  error: Error | null;
  errorCode?: StaffErrorCode;
}

export interface AssignTeacherInput {
  class_id: string;
  teacher_id: string;
  is_lead_teacher?: boolean;
}

export interface UpdateAssignmentRoleInput {
  is_lead_teacher: boolean;
}

export type { TeacherClassAssignment };
