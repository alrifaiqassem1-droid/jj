import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  GraduationCap,
  Plus,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { useI18n } from '../../lib/i18n/I18nContext';
import { useAuth } from '../auth/AuthContext';
import { supabase } from '../../lib/supabase/client';
import type { TeacherWithAssignments, TeacherAssignmentSummary } from './staffTypes';
import {
  getTeachersWithAssignments,
  updateAssignmentRole,
  removeTeacherAssignment,
} from './staffService';
import { TeachersToolbar, type ClassOption, type StatusFilter } from './components/TeachersToolbar';
import { TeacherCard } from './components/TeacherCard';
import { TeacherCardSkeleton } from './components/TeacherCardSkeleton';
import { AssignTeacherDrawer } from './components/AssignTeacherDrawer';
import { UnassignTeacherDialog } from './components/UnassignTeacherDialog';

export const TeachersView: React.FC = () => {
  const { t } = useI18n();
  const { activeMembership } = useAuth();
  const activeKindergartenId = activeMembership?.kindergarten_id;

  // Primary State
  const [teachers, setTeachers] = useState<TeacherWithAssignments[]>([]);
  const [classesList, setClassesList] = useState<ClassOption[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [serverError, setServerError] = useState<string | null>(null);

  // Filters State
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedClassId, setSelectedClassId] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<StatusFilter>('ALL');

  // Drawer & Dialog State
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [drawerPreSelectedTeacher, setDrawerPreSelectedTeacher] = useState<TeacherWithAssignments | null>(null);

  const [unassignTarget, setUnassignTarget] = useState<{
    teacher: TeacherWithAssignments;
    assignment: TeacherAssignmentSummary;
  } | null>(null);
  const [isUnassigning, setIsUnassigning] = useState<boolean>(false);

  // Success Feedback Toast
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const showToast = useCallback((message: string) => {
    setSuccessToast(message);
    const timer = setTimeout(() => {
      setSuccessToast(null);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  // Central Data Loader (Single Source of Truth)
  const loadData = useCallback(async () => {
    if (!activeKindergartenId) return;

    setIsLoading(true);
    setServerError(null);

    try {
      // 1. Fetch active classes for the toolbar and drawer dropdowns
      const { data: classesData, error: classesError } = await supabase
        .from('classes')
        .select('id, name')
        .eq('kindergarten_id', activeKindergartenId)
        .is('deleted_at', null)
        .order('name');

      if (classesError) {
        setServerError(t.teachers.SERVICE_NETWORK_ERROR);
        setIsLoading(false);
        return;
      }

      setClassesList(classesData ?? []);

      // 2. Fetch teachers with assignments via domain service
      const teachersResult = await getTeachersWithAssignments(activeKindergartenId);

      if (teachersResult.error) {
        const code = teachersResult.errorCode;
        setServerError(code && t.teachers[code] ? t.teachers[code] : t.teachers.SERVICE_NETWORK_ERROR);
      } else {
        setTeachers(teachersResult.data ?? []);
      }
    } catch {
      setServerError(t.teachers.SERVICE_NETWORK_ERROR);
    } finally {
      setIsLoading(false);
    }
  }, [activeKindergartenId, t]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Filtered Teachers
  const filteredTeachers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    return teachers.filter((teacher) => {
      // Search filter (name or phone)
      const matchesSearch =
        !q ||
        teacher.fullName.toLowerCase().includes(q) ||
        (teacher.phoneNumber && teacher.phoneNumber.includes(q));

      // Class filter
      const matchesClass =
        selectedClassId === 'ALL' ||
        teacher.assignments.some((a) => a.classId === selectedClassId);

      // Status filter
      const matchesStatus =
        selectedStatus === 'ALL' ||
        (selectedStatus === 'ASSIGNED' && teacher.assignments.length > 0) ||
        (selectedStatus === 'UNASSIGNED' && teacher.assignments.length === 0);

      return matchesSearch && matchesClass && matchesStatus;
    });
  }, [teachers, searchQuery, selectedClassId, selectedStatus]);

  // Handle open drawer for a specific teacher
  const handleOpenAssignForTeacher = (teacher: TeacherWithAssignments) => {
    setDrawerPreSelectedTeacher(teacher);
    setIsDrawerOpen(true);
  };

  // Handle open general assign drawer
  const handleOpenGeneralAssign = () => {
    setDrawerPreSelectedTeacher(null);
    setIsDrawerOpen(true);
  };

  // Handle Toggle Lead Teacher Role
  const handleToggleLead = async (assignment: TeacherAssignmentSummary) => {
    const newLeadStatus = !assignment.isLeadTeacher;
    const result = await updateAssignmentRole(assignment.id, newLeadStatus);

    if (result.error) {
      const code = result.errorCode;
      showToast(code && t.teachers[code] ? t.teachers[code] : t.teachers.SERVICE_NETWORK_ERROR);
    } else {
      showToast(t.teachers.updateRoleSuccessMessage);
      loadData();
    }
  };

  // Handle Unassign Confirm
  const handleConfirmUnassign = async () => {
    if (!unassignTarget || isUnassigning) return;

    setIsUnassigning(true);
    const result = await removeTeacherAssignment(unassignTarget.assignment.id);
    setIsUnassigning(false);

    if (result.error) {
      const code = result.errorCode;
      showToast(code && t.teachers[code] ? t.teachers[code] : t.teachers.SERVICE_NETWORK_ERROR);
    } else {
      showToast(t.teachers.unassignSuccessMessage);
      setUnassignTarget(null);
      loadData();
    }
  };

  return (
    <div className="w-full">
      {/* Toast Notification */}
      {successToast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed top-6 inset-inline-end-6 z-50 flex items-center gap-2.5 px-4 py-3 bg-teal-900 text-white text-xs font-semibold rounded-xl shadow-xl border border-teal-700 animate-in slide-in-from-top-2 duration-200"
        >
          <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" aria-hidden="true" />
          <span>{successToast}</span>
        </div>
      )}

      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl font-bold text-slate-900">
              {t.teachers.title}
            </h1>
            <span className="text-[11px] font-semibold text-teal-800 bg-teal-50 border border-teal-200/60 px-2 py-0.5 rounded-full">
              {t.teachers.phaseTag}
            </span>
          </div>
          <p className="text-xs text-slate-500">
            {t.teachers.subtitle}
          </p>
        </div>

        <button
          type="button"
          onClick={handleOpenGeneralAssign}
          disabled={isLoading || teachers.length === 0 || classesList.length === 0}
          className="inline-flex items-center justify-center gap-2 px-4 h-11 rounded-lg text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 transition-colors disabled:opacity-50 shadow-xs shrink-0"
        >
          <Plus className="w-4 h-4" aria-hidden="true" />
          <span>{t.teachers.assignTeacherAction}</span>
        </button>
      </div>

      {/* Toolbar (Search & Filters) */}
      <TeachersToolbar
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedClassId={selectedClassId}
        onClassChange={setSelectedClassId}
        selectedStatus={selectedStatus}
        onStatusChange={setSelectedStatus}
        classesList={classesList}
        totalCount={filteredTeachers.length}
      />

      {/* Main Content Area */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          <TeacherCardSkeleton />
          <TeacherCardSkeleton />
          <TeacherCardSkeleton />
          <TeacherCardSkeleton />
        </div>
      ) : serverError ? (
        <div className="bg-red-50/70 border border-red-200 rounded-2xl p-8 text-center max-w-lg mx-auto my-12">
          <AlertCircle className="w-10 h-10 text-red-600 mx-auto mb-3" aria-hidden="true" />
          <h2 className="text-sm font-bold text-red-900 mb-1">
            {t.common.error}
          </h2>
          <p className="text-xs text-red-700 mb-4">
            {serverError}
          </p>
          <button
            type="button"
            onClick={loadData}
            className="inline-flex items-center gap-2 px-4 h-9 bg-white border border-red-200 rounded-lg text-xs font-semibold text-red-800 hover:bg-red-50 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{t.teachers.retryAction}</span>
          </button>
        </div>
      ) : teachers.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-12 text-center max-w-md mx-auto my-12 shadow-xs">
          <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mx-auto mb-4 border border-teal-100">
            <GraduationCap className="w-7 h-7" aria-hidden="true" />
          </div>
          <h2 className="text-base font-bold text-slate-900 mb-1.5">
            {t.teachers.noTeachersTitle}
          </h2>
          <p className="text-xs text-slate-500 leading-relaxed">
            {t.teachers.noTeachersDesc}
          </p>
        </div>
      ) : filteredTeachers.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-10 text-center max-w-md mx-auto my-10 shadow-xs">
          <p className="text-sm font-semibold text-slate-700 mb-2">
            {t.teachers.noSearchResults}
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setSelectedClassId('ALL');
              setSelectedStatus('ALL');
            }}
            className="text-xs font-bold text-teal-800 hover:underline"
          >
            {t.teachers.clearFilters}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredTeachers.map((teacher) => (
            <TeacherCard
              key={teacher.userId}
              teacher={teacher}
              onOpenAssign={handleOpenAssignForTeacher}
              onToggleLead={handleToggleLead}
              onOpenUnassign={(tItem, aItem) => setUnassignTarget({ teacher: tItem, assignment: aItem })}
              isActionDisabled={isUnassigning}
            />
          ))}
        </div>
      )}

      {/* Assign Teacher Drawer */}
      {activeKindergartenId && (
        <AssignTeacherDrawer
          isOpen={isDrawerOpen}
          kindergartenId={activeKindergartenId}
          teachersList={teachers}
          classesList={classesList}
          preSelectedTeacher={drawerPreSelectedTeacher}
          onClose={() => setIsDrawerOpen(false)}
          onSuccess={() => {
            showToast(t.teachers.assignSuccessMessage);
            loadData();
          }}
        />
      )}

      {/* Unassign Confirmation Dialog */}
      <UnassignTeacherDialog
        isOpen={!!unassignTarget}
        teacher={unassignTarget?.teacher ?? null}
        assignment={unassignTarget?.assignment ?? null}
        isSubmitting={isUnassigning}
        onConfirm={handleConfirmUnassign}
        onClose={() => setUnassignTarget(null)}
      />
    </div>
  );
};
