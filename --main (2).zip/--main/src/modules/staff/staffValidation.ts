import { z } from 'zod';

export const assignTeacherSchema = z.object({
  class_id: z.string().uuid({ message: 'INVALID_CLASS_ID' }),
  teacher_id: z.string().uuid({ message: 'INVALID_TEACHER_ID' }),
  is_lead_teacher: z.boolean().default(false),
});

export const updateAssignmentRoleSchema = z.object({
  is_lead_teacher: z.boolean({
    message: 'IS_LEAD_TEACHER_REQUIRED',
  }),
});

export type ValidatedAssignTeacherInput = z.infer<typeof assignTeacherSchema>;
export type ValidatedUpdateAssignmentRoleInput = z.infer<typeof updateAssignmentRoleSchema>;
