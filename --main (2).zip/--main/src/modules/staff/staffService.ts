import { supabase } from '../../lib/supabase/client';
import type {
  AssignTeacherInput,
  ServiceResult,
  TeacherAssignmentSummary,
  TeacherClassAssignment,
  TeacherWithAssignments,
  StaffErrorCode,
} from './staffTypes';
import {
  assignTeacherSchema,
  updateAssignmentRoleSchema,
} from './staffValidation';

/**
 * Normalizes PostgreSQL and Supabase errors to domain-specific error codes.
 * Returns ONLY abstract codes; all localization and UI strings remain in i18n dictionaries.
 */
function normalizePostgresError(error: { code?: string; message: string }): StaffErrorCode {
  if (error.code === '23505' || error.message.includes('unique_teacher_class_assignment')) {
    return 'DUPLICATE_ASSIGNMENT';
  }
  if (error.code === '42501' || error.message.includes('row-level security')) {
    return 'PERMISSION_DENIED_RLS';
  }
  return 'SERVICE_NETWORK_ERROR';
}

/**
 * Fetches all active teachers for the specified kindergarten, alongside their active class assignments.
 *
 * Security Invariant:
 * Caller-supplied `kindergartenId` acts strictly as query context. True tenant boundary is
 * enforced by PostgreSQL RLS ("Memberships: Read", "Teacher Assignments: Read").
 */
export async function getTeachersWithAssignments(
  kindergartenId: string
): Promise<ServiceResult<TeacherWithAssignments[]>> {
  try {
    // 1. Fetch teacher memberships for the kindergarten
    const { data: memberships, error: membershipError } = await supabase
      .from('kindergarten_memberships')
      .select('id, user_id, is_active, role')
      .eq('kindergarten_id', kindergartenId)
      .eq('role', 'TEACHER')
      .eq('is_active', true)
      .is('deleted_at', null);

    if (membershipError) {
      return {
        data: null,
        error: new Error(membershipError.message),
        errorCode: normalizePostgresError(membershipError),
      };
    }

    if (!memberships || memberships.length === 0) {
      return { data: [], error: null };
    }

    const userIds = memberships.map((m) => m.user_id);

    // 2. Fetch user profiles for these teachers
    const { data: profiles, error: profileError } = await supabase
      .from('user_profiles')
      .select('id, full_name, phone_number, avatar_url')
      .in('id', userIds)
      .is('deleted_at', null);

    if (profileError) {
      return {
        data: null,
        error: new Error(profileError.message),
        errorCode: normalizePostgresError(profileError),
      };
    }

    const profileMap = new Map(
      (profiles ?? []).map((p) => [p.id, p])
    );

    // 3. Fetch current class assignments in this kindergarten
    const { data: assignments, error: assignmentError } = await supabase
      .from('teacher_class_assignments')
      .select('id, class_id, teacher_id, is_lead_teacher, assigned_at')
      .eq('kindergarten_id', kindergartenId);

    if (assignmentError) {
      return {
        data: null,
        error: new Error(assignmentError.message),
        errorCode: normalizePostgresError(assignmentError),
      };
    }

    // 4. Fetch class details for assigned classes
    const classIds = Array.from(new Set((assignments ?? []).map((a) => a.class_id)));
    const classMap = new Map<string, { name: string; grade_level: string }>();

    if (classIds.length > 0) {
      const { data: classesData, error: classesError } = await supabase
        .from('classes')
        .select('id, name, grade_level')
        .in('id', classIds)
        .is('deleted_at', null);

      if (classesError) {
        return {
          data: null,
          error: new Error(classesError.message),
          errorCode: normalizePostgresError(classesError),
        };
      }

      (classesData ?? []).forEach((c) => {
        classMap.set(c.id, { name: c.name, grade_level: c.grade_level });
      });
    }

    // Group assignments by teacher_id
    const assignmentsByTeacher = new Map<string, TeacherAssignmentSummary[]>();
    (assignments ?? []).forEach((a) => {
      const classInfo = classMap.get(a.class_id);
      if (classInfo) {
        const list = assignmentsByTeacher.get(a.teacher_id) ?? [];
        list.push({
          id: a.id,
          classId: a.class_id,
          className: classInfo.name,
          gradeLevel: classInfo.grade_level,
          isLeadTeacher: a.is_lead_teacher,
          assignedAt: a.assigned_at,
        });
        assignmentsByTeacher.set(a.teacher_id, list);
      }
    });

    // 5. Transform into unified domain view model
    const result: TeacherWithAssignments[] = memberships.map((m) => {
      const profile = profileMap.get(m.user_id);
      return {
        membershipId: m.id,
        userId: m.user_id,
        fullName: profile?.full_name ?? 'معلمة غير مسماة',
        phoneNumber: profile?.phone_number ?? null,
        avatarUrl: profile?.avatar_url ?? null,
        isActive: m.is_active,
        assignments: assignmentsByTeacher.get(m.user_id) ?? [],
      };
    });

    return { data: result, error: null };
  } catch (err) {
    const errorObj = err instanceof Error ? err : new Error(String(err));
    return {
      data: null,
      error: errorObj,
      errorCode: 'SERVICE_NETWORK_ERROR',
    };
  }
}

/**
 * Assigns a verified teacher to an active class within the same kindergarten.
 *
 * Security Invariants:
 * - Teacher must belong to the active kindergarten with role 'TEACHER', active, and not deleted.
 * - Class must belong to the active kindergarten and not deleted.
 * - Cross-kindergarten assignment is strictly rejected.
 * - Enforces database unique constraint on (class_id, teacher_id).
 */
export async function assignTeacherToClass(
  kindergartenId: string,
  input: AssignTeacherInput
): Promise<ServiceResult<TeacherClassAssignment>> {
  // 1. Client-side schema validation
  const parseResult = assignTeacherSchema.safeParse(input);
  if (!parseResult.success) {
    return {
      data: null,
      error: new Error(parseResult.error.message),
      errorCode: 'VALIDATION_FAILED',
    };
  }

  const { class_id, teacher_id, is_lead_teacher } = parseResult.data;

  try {
    // 2. Domain verification: Teacher eligibility within this kindergarten
    const { data: teacherMembership, error: membershipError } = await supabase
      .from('kindergarten_memberships')
      .select('id, kindergarten_id, role, is_active, deleted_at')
      .eq('kindergarten_id', kindergartenId)
      .eq('user_id', teacher_id)
      .eq('role', 'TEACHER')
      .eq('is_active', true)
      .is('deleted_at', null)
      .maybeSingle();

    if (membershipError || !teacherMembership) {
      return {
        data: null,
        error: new Error('TEACHER_NOT_ELIGIBLE'),
        errorCode: 'TEACHER_NOT_ELIGIBLE',
      };
    }

    // 3. Domain verification: Class eligibility & tenant match
    const { data: targetClass, error: classError } = await supabase
      .from('classes')
      .select('id, kindergarten_id, deleted_at')
      .eq('id', class_id)
      .is('deleted_at', null)
      .maybeSingle();

    if (classError || !targetClass) {
      return {
        data: null,
        error: new Error('CLASS_NOT_FOUND_OR_ARCHIVED'),
        errorCode: 'CLASS_NOT_FOUND_OR_ARCHIVED',
      };
    }

    if (targetClass.kindergarten_id !== kindergartenId) {
      return {
        data: null,
        error: new Error('CROSS_KINDERGARTEN_ASSIGNMENT_DENIED'),
        errorCode: 'CROSS_KINDERGARTEN_ASSIGNMENT_DENIED',
      };
    }

    // 4. Domain rule: if setting as lead teacher, unmark any previous lead teacher for this class
    if (is_lead_teacher) {
      await supabase
        .from('teacher_class_assignments')
        .update({ is_lead_teacher: false })
        .eq('class_id', class_id)
        .eq('is_lead_teacher', true);
    }

    // 5. Insert assignment into join table
    const { data: inserted, error: insertError } = await supabase
      .from('teacher_class_assignments')
      .insert({
        kindergarten_id: kindergartenId,
        class_id,
        teacher_id,
        is_lead_teacher,
      })
      .select()
      .single();

    if (insertError) {
      return {
        data: null,
        error: new Error(insertError.message),
        errorCode: normalizePostgresError(insertError),
      };
    }

    return {
      data: inserted as TeacherClassAssignment,
      error: null,
    };
  } catch (err) {
    const errorObj = err instanceof Error ? err : new Error(String(err));
    return {
      data: null,
      error: errorObj,
      errorCode: 'SERVICE_NETWORK_ERROR',
    };
  }
}

/**
 * Updates an assignment's role (e.g. promoting or demoting lead teacher).
 *
 * Security Invariant:
 * RLS policy "Teacher Assignments: Admin Manage" protects the record based on kindergarten_id.
 */
export async function updateAssignmentRole(
  assignmentId: string,
  isLeadTeacher: boolean
): Promise<ServiceResult<TeacherClassAssignment>> {
  const parseResult = updateAssignmentRoleSchema.safeParse({ is_lead_teacher: isLeadTeacher });
  if (!parseResult.success) {
    return {
      data: null,
      error: new Error(parseResult.error.message),
      errorCode: 'VALIDATION_FAILED',
    };
  }

  try {
    // If promoting to lead teacher, find the class_id to unmark previous lead teacher
    if (isLeadTeacher) {
      const { data: currentAssignment } = await supabase
        .from('teacher_class_assignments')
        .select('class_id')
        .eq('id', assignmentId)
        .maybeSingle();

      if (currentAssignment?.class_id) {
        await supabase
          .from('teacher_class_assignments')
          .update({ is_lead_teacher: false })
          .eq('class_id', currentAssignment.class_id)
          .eq('is_lead_teacher', true);
      }
    }

    const { data: updated, error: updateError } = await supabase
      .from('teacher_class_assignments')
      .update({ is_lead_teacher: isLeadTeacher })
      .eq('id', assignmentId)
      .select()
      .single();

    if (updateError) {
      return {
        data: null,
        error: new Error(updateError.message),
        errorCode: normalizePostgresError(updateError),
      };
    }

    return {
      data: updated as TeacherClassAssignment,
      error: null,
    };
  } catch (err) {
    const errorObj = err instanceof Error ? err : new Error(String(err));
    return {
      data: null,
      error: errorObj,
      errorCode: 'SERVICE_NETWORK_ERROR',
    };
  }
}

/**
 * Unassigns a teacher from a class by removing the join record.
 *
 * Security & Architectural Invariant:
 * ONLY the join record in `teacher_class_assignments` is deleted.
 * Physical deletion of classes, memberships, or user profiles is STRICTLY PROHIBITED.
 */
export async function removeTeacherAssignment(
  assignmentId: string
): Promise<ServiceResult<{ unassigned: boolean }>> {
  try {
    const { error: deleteError } = await supabase
      .from('teacher_class_assignments')
      .delete()
      .eq('id', assignmentId);

    if (deleteError) {
      return {
        data: null,
        error: new Error(deleteError.message),
        errorCode: normalizePostgresError(deleteError),
      };
    }

    return {
      data: { unassigned: true },
      error: null,
    };
  } catch (err) {
    const errorObj = err instanceof Error ? err : new Error(String(err));
    return {
      data: null,
      error: errorObj,
      errorCode: 'SERVICE_NETWORK_ERROR',
    };
  }
}
