import { supabase } from '../../lib/supabase/client';
import type {
  Attendance,
  AttendanceCorrection,
  AttendanceCorrectionInput,
  AttendanceErrorCode,
  AttendanceListItem,
  AuthorizedPickupPerson,
  RecordDailyAttendanceInput,
  RecordPickupInput,
  ServiceResult,
} from './attendanceTypes';
import {
  attendanceCorrectionSchema,
  recordDailyAttendanceSchema,
  recordPickupSchema,
} from './attendanceValidation';

/**
 * Normalizes PostgreSQL and Supabase errors to domain-specific error codes.
 */
function normalizePostgresError(error: { code?: string; message: string }): AttendanceErrorCode {
  const msg = error.message || '';
  if (error.code === '23505' || msg.includes('unique_child_daily_attendance')) {
    return 'ATTENDANCE_ALREADY_EXISTS';
  }
  if (error.code === '42501' || msg.includes('row-level security') || msg.includes('permission denied')) {
    return 'NOT_AUTHORIZED';
  }
  if (msg.includes('TAMPER_ALERT') || msg.includes('immutable')) {
    return 'CORRECTION_IMMUTABLE';
  }
  if (msg.includes('length(reason) >= 10') || msg.includes('REASON_MIN_10_CHARS')) {
    return 'CORRECTION_REASON_TOO_SHORT';
  }
  return 'SERVICE_NETWORK_ERROR';
}

/**
 * Fetches all daily attendance records for a class on a specific date,
 * joined with the active enrolled children of that class.
 */
export async function getDailyClassAttendance(
  kindergartenId: string,
  classId: string,
  date: string
): Promise<ServiceResult<AttendanceListItem[]>> {
  try {
    // 1. Fetch all non-deleted enrolled children in this class
    const { data: children, error: childError } = await supabase
      .from('children')
      .select('id, first_name, last_name, class_id')
      .eq('kindergarten_id', kindergartenId)
      .eq('class_id', classId)
      .is('deleted_at', null)
      .order('first_name', { ascending: true });

    if (childError) {
      return {
        data: null,
        error: new Error(childError.message),
        errorCode: normalizePostgresError(childError),
      };
    }

    if (!children || children.length === 0) {
      return { data: [], error: null };
    }

    // 2. Fetch existing daily attendance records for this class on date
    const { data: attendanceRecords, error: attError } = await supabase
      .from('attendance')
      .select('*')
      .eq('kindergarten_id', kindergartenId)
      .eq('class_id', classId)
      .eq('date', date)
      .is('deleted_at', null);

    if (attError) {
      return {
        data: null,
        error: new Error(attError.message),
        errorCode: normalizePostgresError(attError),
      };
    }

    const attendanceMap = new Map((attendanceRecords ?? []).map((r) => [r.child_id, r]));

    // 3. Map children to attendance items
    const items: AttendanceListItem[] = children.map((child) => {
      const existing = attendanceMap.get(child.id);
      if (existing) {
        return {
          id: existing.id,
          child_id: child.id,
          child_name: `${child.first_name} ${child.last_name}`,
          class_id: classId,
          date: existing.date,
          status: existing.status,
          check_in_time: existing.check_in_time,
          check_out_time: existing.check_out_time,
          picked_up_by_name: existing.picked_up_by_name,
          recorded_by: existing.recorded_by,
          notes: existing.notes,
        };
      }

      // Default representation for unrecorded children
      return {
        id: `unrecorded-${child.id}`,
        child_id: child.id,
        child_name: `${child.first_name} ${child.last_name}`,
        class_id: classId,
        date: date,
        status: 'UNRECORDED',
        check_in_time: null,
        check_out_time: null,
        picked_up_by_name: null,
        recorded_by: '',
        notes: null,
      };
    });

    return { data: items, error: null };
  } catch (err: unknown) {
    const error = err instanceof Error ? err : new Error(String(err));
    return { data: null, error, errorCode: 'SERVICE_NETWORK_ERROR' };
  }
}

/**
 * Records or updates the daily attendance status of a child.
 * RLS ensures that:
 * - ADMIN can insert/update
 * - TEACHER assigned to class can insert/update
 * - STAFF with RECORD_ATTENDANCE can insert, but cannot update existing rows
 */
export async function recordDailyStatus(
  input: RecordDailyAttendanceInput
): Promise<ServiceResult<Attendance>> {
  try {
    // 1. Zod schema validation
    const valResult = recordDailyAttendanceSchema.safeParse(input);
    if (!valResult.success) {
      return {
        data: null,
        error: new Error(valResult.error.issues?.[0]?.message || valResult.error.message || 'Validation failed'),
        errorCode: 'VALIDATION_FAILED',
      };
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return {
        data: null,
        error: new Error('User must be authenticated to record attendance'),
        errorCode: 'NOT_AUTHORIZED',
      };
    }

    // 2. Check if a daily record already exists for (child_id, date)
    const { data: existing, error: findError } = await supabase
      .from('attendance')
      .select('id, status, check_in_time, notes')
      .eq('child_id', input.child_id)
      .eq('date', input.date)
      .is('deleted_at', null)
      .maybeSingle();

    if (findError) {
      return {
        data: null,
        error: new Error(findError.message),
        errorCode: normalizePostgresError(findError),
      };
    }

    const nowIso = new Date().toISOString();

    if (existing) {
      // Record exists -> UPDATE
      const checkIn =
        input.status === 'PRESENT' && !existing.check_in_time
          ? input.check_in_time || nowIso
          : existing.check_in_time;

      const { data: updated, error: updateError } = await supabase
        .from('attendance')
        .update({
          status: input.status,
          check_in_time: checkIn,
          notes: input.notes !== undefined ? input.notes : existing.notes,
          updated_at: nowIso,
        })
        .eq('id', existing.id)
        .select()
        .single();

      if (updateError) {
        return {
          data: null,
          error: new Error(updateError.message),
          errorCode: normalizePostgresError(updateError),
        };
      }

      return { data: updated, error: null };
    }

    // Record does not exist -> INSERT
    const checkIn = input.status === 'PRESENT' ? input.check_in_time || nowIso : null;

    const { data: inserted, error: insertError } = await supabase
      .from('attendance')
      .insert({
        client_attendance_uuid: crypto.randomUUID(),
        kindergarten_id: input.kindergarten_id,
        class_id: input.class_id,
        child_id: input.child_id,
        date: input.date,
        status: input.status,
        check_in_time: checkIn,
        recorded_by: user.id,
        notes: input.notes || null,
        client_recorded_at: nowIso,
        server_synced_at: nowIso,
      })
      .select()
      .single();

    if (insertError) {
      return {
        data: null,
        error: new Error(insertError.message),
        errorCode: normalizePostgresError(insertError),
      };
    }

    return { data: inserted, error: null };
  } catch (err: unknown) {
    const error = err instanceof Error ? err : new Error(String(err));
    return { data: null, error, errorCode: 'SERVICE_NETWORK_ERROR' };
  }
}

/**
 * Retrieves legally verified and authorized pickup persons for a child.
 * Strictly checks:
 * - authorized_for_pickup = TRUE
 * - verified_at IS NOT NULL (Legal Custody Gate)
 * - deleted_at IS NULL
 */
export async function getAuthorizedPickupPersons(
  childId: string,
  kindergartenId: string
): Promise<ServiceResult<AuthorizedPickupPerson[]>> {
  try {
    const { data: relationships, error: relError } = await supabase
      .from('parent_child_relationships')
      .select('id, parent_id, relationship, is_primary_contact, authorized_for_pickup, verified_at')
      .eq('child_id', childId)
      .eq('kindergarten_id', kindergartenId)
      .eq('authorized_for_pickup', true)
      .not('verified_at', 'is', null)
      .is('deleted_at', null);

    if (relError) {
      return {
        data: null,
        error: new Error(relError.message),
        errorCode: normalizePostgresError(relError),
      };
    }

    if (!relationships || relationships.length === 0) {
      return { data: [], error: null };
    }

    const parentIds = relationships.map((r) => r.parent_id);
    const { data: profiles, error: profError } = await supabase
      .from('user_profiles')
      .select('id, full_name, phone_number')
      .in('id', parentIds);

    if (profError) {
      return {
        data: null,
        error: new Error(profError.message),
        errorCode: normalizePostgresError(profError),
      };
    }

    const profileMap = new Map((profiles ?? []).map((p) => [p.id, p]));

    const result: AuthorizedPickupPerson[] = relationships.map((rel) => {
      const prof = profileMap.get(rel.parent_id);
      return {
        relationship_id: rel.id,
        parent_id: rel.parent_id,
        parent_name: prof?.full_name || 'ولي أمر معتمد',
        parent_phone: prof?.phone_number || null,
        relationship: rel.relationship,
        is_primary_contact: rel.is_primary_contact,
        authorized_for_pickup: rel.authorized_for_pickup,
        verified_at: rel.verified_at as string,
      };
    });

    return { data: result, error: null };
  } catch (err: unknown) {
    const error = err instanceof Error ? err : new Error(String(err));
    return { data: null, error, errorCode: 'SERVICE_NETWORK_ERROR' };
  }
}

/**
 * Records checkout/pickup of a child.
 *
 * Enforces strict authorization:
 * 1. For AUTHORIZED_RELATIONSHIP:
 *    - Relationship MUST exist in parent_child_relationships
 *    - Must match target child_id and kindergarten_id
 *    - Must have authorized_for_pickup = TRUE
 *    - Must have verified_at IS NOT NULL
 *    - Must have deleted_at IS NULL
 *    - Canonical name is generated server-side from user_profiles.
 * 2. For ADMIN_EXCEPTION:
 *    - Actor MUST be verified as ADMIN in kindergarten_memberships
 *    - Reason MUST be >= 10 characters
 *    - Explicitly formatted into picked_up_by_name and audit notes.
 */
export async function recordPickup(
  input: RecordPickupInput
): Promise<ServiceResult<Attendance>> {
  try {
    // 1. Zod contract validation
    const valResult = recordPickupSchema.safeParse(input);
    if (!valResult.success) {
      return {
        data: null,
        error: new Error(valResult.error.issues?.[0]?.message || valResult.error.message || 'Validation failed'),
        errorCode: 'VALIDATION_FAILED',
      };
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return {
        data: null,
        error: new Error('User must be authenticated to record pickup'),
        errorCode: 'NOT_AUTHORIZED',
      };
    }

    // 2. Fetch target attendance row
    const { data: attendance, error: attError } = await supabase
      .from('attendance')
      .select('id, kindergarten_id, child_id, status, notes')
      .eq('id', input.attendance_id)
      .is('deleted_at', null)
      .single();

    if (attError || !attendance) {
      return {
        data: null,
        error: new Error('Attendance record not found'),
        errorCode: 'ATTENDANCE_NOT_FOUND',
      };
    }

    if (attendance.child_id !== input.child_id || attendance.kindergarten_id !== input.kindergarten_id) {
      return {
        data: null,
        error: new Error('Attendance record does not match child or kindergarten'),
        errorCode: 'NOT_AUTHORIZED',
      };
    }

    const nowIso = new Date().toISOString();
    let canonicalPickupName = '';
    let updatedNotes = attendance.notes || '';

    if (input.pickup_type === 'AUTHORIZED_RELATIONSHIP') {
      // 3A. Secure Authorized Relationship Verification
      const { data: rel, error: relError } = await supabase
        .from('parent_child_relationships')
        .select('id, kindergarten_id, child_id, parent_id, relationship, authorized_for_pickup, verified_at, deleted_at')
        .eq('id', input.relationship_id)
        .single();

      if (relError || !rel) {
        return {
          data: null,
          error: new Error('Parent relationship record not found'),
          errorCode: 'PICKUP_RELATIONSHIP_NOT_FOUND',
        };
      }

      if (rel.deleted_at !== null) {
        return {
          data: null,
          error: new Error('Parent relationship is archived and no longer active'),
          errorCode: 'RELATIONSHIP_ARCHIVED',
        };
      }

      if (rel.child_id !== input.child_id) {
        return {
          data: null,
          error: new Error('Relationship does not belong to the target child'),
          errorCode: 'CROSS_CHILD_RELATIONSHIP',
        };
      }

      if (rel.kindergarten_id !== input.kindergarten_id) {
        return {
          data: null,
          error: new Error('Relationship belongs to a different kindergarten tenant'),
          errorCode: 'NOT_AUTHORIZED',
        };
      }

      if (!rel.authorized_for_pickup) {
        return {
          data: null,
          error: new Error('This parent/guardian is not authorized for pickup'),
          errorCode: 'PICKUP_NOT_AUTHORIZED',
        };
      }

      if (!rel.verified_at) {
        return {
          data: null,
          error: new Error('Parent custody has not been verified by administration'),
          errorCode: 'CUSTODY_NOT_VERIFIED',
        };
      }

      // Fetch parent profile name
      const { data: parentProfile } = await supabase
        .from('user_profiles')
        .select('full_name')
        .eq('id', rel.parent_id)
        .single();

      const parentName = parentProfile?.full_name ? parentProfile.full_name.trim() : 'ولي أمر معتمد';
      canonicalPickupName = `${parentName} (${rel.relationship})`.slice(0, 255);
    } else {
      // 3B. Admin Pickup Exception Gateway
      // Strictly verify that current actor has active ADMIN membership in this kindergarten
      const { data: adminMembership, error: memError } = await supabase
        .from('kindergarten_memberships')
        .select('role, is_active, deleted_at')
        .eq('kindergarten_id', input.kindergarten_id)
        .eq('user_id', user.id)
        .eq('role', 'ADMIN')
        .eq('is_active', true)
        .is('deleted_at', null)
        .maybeSingle();

      if (memError || !adminMembership) {
        return {
          data: null,
          error: new Error('Administrative pickup exceptions are strictly restricted to kindergarten ADMIN'),
          errorCode: 'ADMIN_ONLY_EXCEPTION',
        };
      }

      const trimmedName = input.recipient_name.trim();
      const trimmedReason = input.reason.trim();

      if (trimmedReason.length < 10) {
        return {
          data: null,
          error: new Error('Exception justification reason must be at least 10 characters'),
          errorCode: 'ADMIN_EXCEPTION_REASON_TOO_SHORT',
        };
      }

      canonicalPickupName = `[استثناء إداري] ${trimmedName}`.slice(0, 255);
      const idPart = input.recipient_id_number ? ` | رقم الإثبات: ${input.recipient_id_number.trim()}` : '';
      const auditLogLine = `[استثناء تسليم إداري] المستلم: ${trimmedName}${idPart} | السبب: ${trimmedReason} | المسؤول: ${user.id} | التوقيت: ${nowIso}`;
      updatedNotes = updatedNotes ? `${updatedNotes}\n${auditLogLine}` : auditLogLine;
    }

    // 4. Update attendance to CHECKED_OUT with verified pickup details
    const { data: updated, error: updateError } = await supabase
      .from('attendance')
      .update({
        status: 'CHECKED_OUT',
        check_out_time: nowIso,
        picked_up_by_name: canonicalPickupName,
        notes: updatedNotes,
        updated_at: nowIso,
      })
      .eq('id', input.attendance_id)
      .select()
      .single();

    if (updateError) {
      return {
        data: null,
        error: new Error(updateError.message),
        errorCode: normalizePostgresError(updateError),
      };
    }

    return { data: updated, error: null };
  } catch (err: unknown) {
    const error = err instanceof Error ? err : new Error(String(err));
    return { data: null, error, errorCode: 'SERVICE_NETWORK_ERROR' };
  }
}

/**
 * Submits an audited attendance correction.
 *
 * CRITICAL ARCHITECTURAL CONSTRAINTS:
 * 1. Supabase client SDK does not support multi-table atomic transactions without a server-side RPC.
 *    In accordance with Gate 6A constraints (no migrations or DB changes permitted),
 *    Step 1 inserts the immutable audit record into attendance_corrections.
 *    Step 2 updates the attendance table to the target new_status.
 * 2. Database constraint CHECK (length(reason) >= 10) is strictly enforced.
 * 3. PostgreSQL trigger trg_freeze_attendance_corrections ensures the correction ledger is strictly append-only.
 * 4. Final attendance status is set to the actual new_status (e.g. PRESENT), preserving historical ledger.
 */
export async function recordCorrection(
  input: AttendanceCorrectionInput
): Promise<ServiceResult<{ attendance: Attendance; correction: AttendanceCorrection }>> {
  try {
    // 1. Zod schema validation
    const valResult = attendanceCorrectionSchema.safeParse(input);
    if (!valResult.success) {
      return {
        data: null,
        error: new Error(valResult.error.issues?.[0]?.message || valResult.error.message || 'Validation failed'),
        errorCode: 'VALIDATION_FAILED',
      };
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return {
        data: null,
        error: new Error('User must be authenticated to submit attendance corrections'),
        errorCode: 'NOT_AUTHORIZED',
      };
    }

    // 2. Fetch current attendance record
    const { data: current, error: findError } = await supabase
      .from('attendance')
      .select('*')
      .eq('id', input.attendance_id)
      .is('deleted_at', null)
      .single();

    if (findError || !current) {
      return {
        data: null,
        error: new Error('Target attendance record not found'),
        errorCode: 'ATTENDANCE_NOT_FOUND',
      };
    }

    if (current.child_id !== input.child_id || current.kindergarten_id !== input.kindergarten_id) {
      return {
        data: null,
        error: new Error('Attendance record does not match child or kindergarten'),
        errorCode: 'NOT_AUTHORIZED',
      };
    }

    if (current.status === input.new_status) {
      return {
        data: null,
        error: new Error('Correction new status must be different from current status'),
        errorCode: 'CORRECTION_STATUS_UNCHANGED',
      };
    }

    const trimmedReason = input.reason.trim();
    if (trimmedReason.length < 10) {
      return {
        data: null,
        error: new Error('Correction reason must be at least 10 characters'),
        errorCode: 'CORRECTION_REASON_TOO_SHORT',
      };
    }

    const nowIso = new Date().toISOString();

    // 3. Step 1: Insert into immutable attendance_corrections ledger
    const { data: correction, error: corrError } = await supabase
      .from('attendance_corrections')
      .insert({
        attendance_id: input.attendance_id,
        kindergarten_id: input.kindergarten_id,
        child_id: input.child_id,
        previous_status: current.status,
        new_status: input.new_status,
        corrected_by_user_id: user.id,
        reason: trimmedReason,
        source: input.source || 'TEACHER_WEB_MANUAL',
        request_session_id: input.request_session_id || null,
        client_timestamp: nowIso,
        server_synced_at: nowIso,
      })
      .select()
      .single();

    if (corrError) {
      return {
        data: null,
        error: new Error(corrError.message),
        errorCode: normalizePostgresError(corrError),
      };
    }

    // 4. Step 2: Update attendance status to new_status
    const updatedNotes = current.notes
      ? `${current.notes}\n[تصحيح]: ${trimmedReason}`
      : `[تصحيح]: ${trimmedReason}`;

    const { data: updatedAttendance, error: attError } = await supabase
      .from('attendance')
      .update({
        status: input.new_status,
        updated_at: nowIso,
        notes: updatedNotes,
      })
      .eq('id', input.attendance_id)
      .select()
      .single();

    if (attError) {
      return {
        data: null,
        error: new Error(attError.message),
        errorCode: normalizePostgresError(attError),
      };
    }

    return {
      data: {
        attendance: updatedAttendance,
        correction: correction,
      },
      error: null,
    };
  } catch (err: unknown) {
    const error = err instanceof Error ? err : new Error(String(err));
    return { data: null, error, errorCode: 'SERVICE_NETWORK_ERROR' };
  }
}

/**
 * Fetches the immutable audit history of corrections for an attendance record.
 */
export async function getAttendanceCorrections(
  attendanceId: string
): Promise<ServiceResult<AttendanceCorrection[]>> {
  try {
    const { data, error } = await supabase
      .from('attendance_corrections')
      .select('*')
      .eq('attendance_id', attendanceId)
      .order('created_at', { ascending: false });

    if (error) {
      return {
        data: null,
        error: new Error(error.message),
        errorCode: normalizePostgresError(error),
      };
    }

    return { data: data ?? [], error: null };
  } catch (err: unknown) {
    const error = err instanceof Error ? err : new Error(String(err));
    return { data: null, error, errorCode: 'SERVICE_NETWORK_ERROR' };
  }
}
