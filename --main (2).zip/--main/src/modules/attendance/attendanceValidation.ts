import { z } from 'zod';

export const attendanceStatusSchema = z.enum([
  'UNRECORDED',
  'PRESENT',
  'ABSENT_UNEXCUSED',
  'ABSENT_EXCUSED',
  'CHECKED_OUT',
  'CORRECTED',
]);

export const dateStringSchema = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, { message: 'INVALID_DATE_FORMAT_EXPECTED_YYYY_MM_DD' });

export const recordDailyAttendanceSchema = z.object({
  kindergarten_id: z.string().uuid({ message: 'INVALID_KINDERGARTEN_ID' }),
  class_id: z.string().uuid({ message: 'INVALID_CLASS_ID' }),
  child_id: z.string().uuid({ message: 'INVALID_CHILD_ID' }),
  date: dateStringSchema,
  status: attendanceStatusSchema,
  notes: z.string().max(1000).optional(),
  check_in_time: z.string().datetime().optional(),
});

export const authorizedRelationshipPickupSchema = z.object({
  pickup_type: z.literal('AUTHORIZED_RELATIONSHIP'),
  attendance_id: z.string().uuid({ message: 'INVALID_ATTENDANCE_ID' }),
  child_id: z.string().uuid({ message: 'INVALID_CHILD_ID' }),
  kindergarten_id: z.string().uuid({ message: 'INVALID_KINDERGARTEN_ID' }),
  relationship_id: z.string().uuid({ message: 'INVALID_RELATIONSHIP_ID' }),
});

export const adminPickupExceptionSchema = z.object({
  pickup_type: z.literal('ADMIN_EXCEPTION'),
  attendance_id: z.string().uuid({ message: 'INVALID_ATTENDANCE_ID' }),
  child_id: z.string().uuid({ message: 'INVALID_CHILD_ID' }),
  kindergarten_id: z.string().uuid({ message: 'INVALID_KINDERGARTEN_ID' }),
  recipient_name: z
    .string()
    .trim()
    .min(3, { message: 'RECIPIENT_NAME_TOO_SHORT' })
    .max(150, { message: 'RECIPIENT_NAME_TOO_LONG' }),
  recipient_id_number: z.string().trim().max(50).optional(),
  reason: z
    .string()
    .trim()
    .min(10, { message: 'ADMIN_EXCEPTION_REASON_MIN_10_CHARS' })
    .max(500, { message: 'ADMIN_EXCEPTION_REASON_TOO_LONG' }),
});

export const recordPickupSchema = z.discriminatedUnion('pickup_type', [
  authorizedRelationshipPickupSchema,
  adminPickupExceptionSchema,
]);

export const attendanceCorrectionSchema = z.object({
  attendance_id: z.string().uuid({ message: 'INVALID_ATTENDANCE_ID' }),
  kindergarten_id: z.string().uuid({ message: 'INVALID_KINDERGARTEN_ID' }),
  child_id: z.string().uuid({ message: 'INVALID_CHILD_ID' }),
  new_status: attendanceStatusSchema.refine((val) => val !== 'UNRECORDED', {
    message: 'CORRECTION_TARGET_CANNOT_BE_UNRECORDED',
  }),
  reason: z
    .string()
    .trim()
    .min(10, { message: 'CORRECTION_REASON_MIN_10_CHARS' })
    .max(1000, { message: 'CORRECTION_REASON_TOO_LONG' }),
  source: z.string().max(50).default('TEACHER_WEB_MANUAL'),
  request_session_id: z.string().max(100).optional(),
});

export const attendanceFilterSchema = z.object({
  kindergarten_id: z.string().uuid({ message: 'INVALID_KINDERGARTEN_ID' }),
  class_id: z.string().uuid({ message: 'INVALID_CLASS_ID' }),
  date: dateStringSchema,
});

export type ValidatedRecordDailyAttendanceInput = z.infer<typeof recordDailyAttendanceSchema>;
export type ValidatedAuthorizedPickupInput = z.infer<typeof authorizedRelationshipPickupSchema>;
export type ValidatedAdminPickupExceptionInput = z.infer<typeof adminPickupExceptionSchema>;
export type ValidatedRecordPickupInput = z.infer<typeof recordPickupSchema>;
export type ValidatedAttendanceCorrectionInput = z.infer<typeof attendanceCorrectionSchema>;
export type ValidatedAttendanceFilterInput = z.infer<typeof attendanceFilterSchema>;
