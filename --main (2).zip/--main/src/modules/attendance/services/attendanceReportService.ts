import { supabase } from '../../../lib/supabase/client';
import type {
  AttendanceReportFilter,
  AttendanceReportData,
  AttendanceSummaryMetrics,
  DailyAttendanceBreakdown,
  ClassAttendanceBreakdown,
  AttendanceDetailRow,
  CutoffCheckResult,
} from '../types/attendanceReportTypes';

export const SCHEMA_DEFAULT_TIMEZONE = 'Asia/Riyadh';
export const SCHEMA_DEFAULT_CUTOFF_TIME = '14:00';

export interface CutoffCheckOptions {
  cutoffTimeStr?: string | null;
  timezone?: string | null;
  now?: Date;
  isProfileLoaded?: boolean;
}

export interface ExtendedCutoffCheckResult extends CutoffCheckResult {
  isReady?: boolean;
}

/**
 * Validates whether an IANA timezone string is supported by the runtime.
 */
export function isValidTimeZone(tz: string): boolean {
  try {
    Intl.DateTimeFormat(undefined, { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

/**
 * Extracts the calendar date (YYYY-MM-DD) and 24-hour time (HH:mm) for a specific instant
 * within the kindergarten's configured IANA timezone using standard Intl.DateTimeFormat.
 */
export function getZonedDateAndTime(
  now: Date,
  timeZone: string
): { dateStr: string; timeStr: string; hour: number; minute: number } {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  });

  const parts = formatter.formatToParts(now);
  let year = '';
  let month = '';
  let day = '';
  let hour = '';
  let minute = '';

  for (const part of parts) {
    if (part.type === 'year') year = part.value;
    else if (part.type === 'month') month = part.value;
    else if (part.type === 'day') day = part.value;
    else if (part.type === 'hour') hour = part.value;
    else if (part.type === 'minute') minute = part.value;
  }

  if (hour === '24') hour = '00';

  const dateStr = `${year}-${month}-${day}`;
  const timeStr = `${hour.padStart(2, '0')}:${minute.padStart(2, '0')}`;

  return {
    dateStr,
    timeStr,
    hour: parseInt(hour, 10),
    minute: parseInt(minute, 10),
  };
}

/**
 * Calculates attendance metrics with strict child-day mathematical rules:
 * - Attendance Rate = (PRESENT + CHECKED_OUT) / (PRESENT + CHECKED_OUT + ABSENT_EXCUSED + ABSENT_UNEXCUSED)
 * - UNRECORDED is strictly excluded from the rate denominator.
 * - CHECKED_OUT is included in both numerator and denominator.
 * - If denominator === 0, rate is null (represented as N/A in UI, never artificial 0%).
 */
export function calculateAttendanceMetrics(
  present: number,
  checkedOut: number,
  absentExcused: number,
  absentUnexcused: number,
  unrecorded: number
): AttendanceSummaryMetrics {
  const totalRecorded = present + checkedOut + absentExcused + absentUnexcused;
  const totalExpected = totalRecorded + unrecorded;

  let attendanceRate: number | null = null;
  if (totalRecorded > 0) {
    const attended = present + checkedOut;
    attendanceRate = Math.round(((attended / totalRecorded) * 100) * 100) / 100;
  }

  let coverageRate: number | null = null;
  if (totalExpected > 0) {
    coverageRate = Math.round(((totalRecorded / totalExpected) * 100) * 100) / 100;
  }

  return {
    presentChildDays: present,
    checkedOutChildDays: checkedOut,
    absentExcusedChildDays: absentExcused,
    absentUnexcusedChildDays: absentUnexcused,
    unrecordedChildDays: unrecorded,
    totalRecordedChildDays: totalRecorded,
    totalExpectedChildDays: totalExpected,
    attendanceRate,
    coverageRate,
  };
}

/**
 * Gate 6E Daily Cutoff Controller Guard:
 * Pure deterministic controller-level check to determine if normal recording is blocked.
 * Resolves:
 * 1. Kindergarten-configured IANA timezone (defaults to schema 'Asia/Riyadh').
 * 2. Kindergarten-configured cutoff time HH:mm (defaults to schema '14:00').
 * 3. Never uses client device clock/timezone.
 * 4. Rejects silent decisions if profile was not loaded (isProfileLoaded === false).
 */
export function checkDailyCutoff(
  selectedDateStr: string,
  options?: CutoffCheckOptions
): ExtendedCutoffCheckResult {
  // If kindergarten profile is explicitly marked as not loaded or failed, do not assume cutoff decision
  if (options?.isProfileLoaded === false) {
    return {
      isCutoffPassed: false,
      reason: 'NOT_PASSED',
      cutoffTime: '',
      isReady: false,
    };
  }

  // Resolve timezone (must be valid IANA string; schema default is 'Asia/Riyadh')
  const tz = options?.timezone && isValidTimeZone(options.timezone)
    ? options.timezone
    : SCHEMA_DEFAULT_TIMEZONE;

  // Resolve daily_cutoff_time (must match HH:mm format; schema default is '14:00')
  const CUTOFF_REGEX = /^([01]\d|2[0-3]):([0-5]\d)$/;
  const rawCutoff = options?.cutoffTimeStr?.trim();
  const effectiveCutoff = rawCutoff && CUTOFF_REGEX.test(rawCutoff)
    ? rawCutoff
    : SCHEMA_DEFAULT_CUTOFF_TIME;

  // Compute current date and time in kindergarten's timezone
  const now = options?.now ?? new Date();
  const { dateStr: todayZoned, timeStr: timeZoned } = getZonedDateAndTime(now, tz);

  // 1. Past date in kindergarten timezone
  if (selectedDateStr < todayZoned) {
    return { isCutoffPassed: true, reason: 'PAST_DATE', cutoffTime: effectiveCutoff, isReady: true };
  }

  // 2. Future date in kindergarten timezone
  if (selectedDateStr > todayZoned) {
    return { isCutoffPassed: false, reason: 'FUTURE_DATE', cutoffTime: effectiveCutoff, isReady: true };
  }

  // 3. Same day (Today): compare current time in kindergarten timezone against effectiveCutoff
  if (timeZoned >= effectiveCutoff) {
    return { isCutoffPassed: true, reason: 'TIME_PASSED', cutoffTime: effectiveCutoff, isReady: true };
  }

  return { isCutoffPassed: false, reason: 'NOT_PASSED', cutoffTime: effectiveCutoff, isReady: true };
}

/**
 * Generates an inclusive array of ISO date strings [YYYY-MM-DD] between startDate and endDate.
 * Throws error if startDate > endDate.
 */
export function generateDateRange(startDateStr: string, endDateStr: string): string[] {
  if (startDateStr > endDateStr) {
    throw new Error('Invalid date range: startDate must not be after endDate');
  }

  const dates: string[] = [];
  const [sYear, sMonth, sDay] = startDateStr.split('-').map(Number);
  const [eYear, eMonth, eDay] = endDateStr.split('-').map(Number);

  const current = new Date(Date.UTC(sYear, sMonth - 1, sDay));
  const end = new Date(Date.UTC(eYear, eMonth - 1, eDay));

  while (current <= end) {
    const y = current.getUTCFullYear();
    const m = String(current.getUTCMonth() + 1).padStart(2, '0');
    const d = String(current.getUTCDate()).padStart(2, '0');
    dates.push(`${y}-${m}-${d}`);
    current.setUTCDate(current.getUTCDate() + 1);
  }

  return dates;
}

/**
 * Escapes a single CSV field according to RFC 4180 standards.
 */
export function escapeCsvField(value: unknown): string {
  if (value === null || value === undefined) {
    return '';
  }
  const str = String(value);
  // If string contains comma, double-quote, or newline, wrap in quotes and escape quotes
  if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Sanitizes a filename to prevent path traversal or unsafe characters.
 */
export function sanitizeFilename(name: string): string {
  return name.replace(/[^a-zA-Z0-9_-]/g, '_').replace(/_+/g, '_');
}

/**
 * Generates RFC 4180-compliant CSV content with UTF-8 BOM.
 */
export function generateCsvContent(
  headers: string[],
  rows: Array<Array<unknown>>
): string {
  const UTF8_BOM = '\uFEFF';
  const headerLine = headers.map(escapeCsvField).join(',');
  const rowLines = rows.map((row) => row.map(escapeCsvField).join(','));
  return UTF8_BOM + [headerLine, ...rowLines].join('\r\n');
}

/**
 * Role-aware Attendance Report query and aggregation engine.
 */
export async function getAttendanceReport(params: {
  kindergartenId: string;
  userRole: string;
  userId: string;
  filter: AttendanceReportFilter;
}): Promise<{ data: AttendanceReportData | null; error: string | null; detailRows: AttendanceDetailRow[] }> {
  const { kindergartenId, userRole, userId, filter } = params;

  if (!kindergartenId) {
    return { data: null, error: 'Kindergarten ID is required', detailRows: [] };
  }

  if (filter.startDate > filter.endDate) {
    return { data: null, error: 'Start date cannot be after end date', detailRows: [] };
  }

  try {
    // 1. Determine permitted classes based on Role & Tenant isolation
    let permittedClassIds: string[] = [];
    if (userRole === 'ADMIN') {
      const { data: classesData, error: classesErr } = await supabase
        .from('classes')
        .select('id, name')
        .eq('kindergarten_id', kindergartenId)
        .is('deleted_at', null)
        .order('name');

      if (classesErr) throw classesErr;
      permittedClassIds = (classesData ?? []).map((c) => c.id);
    } else if (userRole === 'TEACHER') {
      const { data: assignments, error: assignErr } = await supabase
        .from('teacher_class_assignments')
        .select('class_id')
        .eq('kindergarten_id', kindergartenId)
        .eq('teacher_id', userId);

      if (assignErr) throw assignErr;
      permittedClassIds = (assignments ?? []).map((a) => a.class_id);
    } else {
      // Other roles or unassigned
      permittedClassIds = [];
    }

    // Apply class filter if provided and permitted
    let targetClassIds = permittedClassIds;
    if (filter.classId && filter.classId !== 'ALL') {
      if (permittedClassIds.includes(filter.classId)) {
        targetClassIds = [filter.classId];
      } else {
        // Teacher attempting to filter a non-assigned class: block by restricting to empty
        targetClassIds = [];
      }
    }

    if (targetClassIds.length === 0) {
      const emptyMetrics = calculateAttendanceMetrics(0, 0, 0, 0, 0);
      return {
        data: {
          filter,
          overview: emptyMetrics,
          byDay: [],
          byClass: [],
          permittedClassIds,
        },
        error: null,
        detailRows: [],
      };
    }

    // 2. Fetch class info
    const { data: classRows, error: classInfoErr } = await supabase
      .from('classes')
      .select('id, name')
      .in('id', targetClassIds);

    if (classInfoErr) throw classInfoErr;
    const classNameMap = new Map<string, string>();
    (classRows ?? []).forEach((c) => classNameMap.set(c.id, c.name));

    // 3. Fetch children in target classes
    // Note: To respect historical eligibility without inventing schema:
    // A child is eligible on date D if child.created_at <= end of date D.
    const { data: childrenRows, error: childErr } = await supabase
      .from('children')
      .select('id, first_name, last_name, class_id, created_at')
      .in('class_id', targetClassIds)
      .eq('kindergarten_id', kindergartenId)
      .is('deleted_at', null);

    if (childErr) throw childErr;
    const childrenList = childrenRows ?? [];

    // 4. Fetch attendance records in target range and classes
    const { data: attendanceRows, error: attErr } = await supabase
      .from('attendance')
      .select('id, class_id, child_id, date, status, check_in_time, check_out_time')
      .eq('kindergarten_id', kindergartenId)
      .in('class_id', targetClassIds)
      .gte('date', filter.startDate)
      .lte('date', filter.endDate);

    if (attErr) throw attErr;

    // Fetch associated corrections to determine which attendance records have corrections
    const attendanceIds = (attendanceRows ?? []).map((rec) => rec.id);
    let correctedAttendanceIdSet = new Set<string>();

    if (attendanceIds.length > 0) {
      const { data: correctionsData } = await supabase
        .from('attendance_corrections')
        .select('attendance_id')
        .eq('kindergarten_id', kindergartenId)
        .in('attendance_id', attendanceIds);

      if (correctionsData) {
        correctedAttendanceIdSet = new Set(correctionsData.map((c) => c.attendance_id));
      }
    }

    // Index attendance by `${child_id}_${date}`
    const attendanceRecordMap = new Map<string, typeof attendanceRows[0]>();
    (attendanceRows ?? []).forEach((rec) => {
      attendanceRecordMap.set(`${rec.child_id}_${rec.date}`, rec);
    });

    // 5. Build Aggregations across Child-Days
    const dateRange = generateDateRange(filter.startDate, filter.endDate);

    // Track daily metrics: date -> { present, checkedOut, absentExcused, absentUnexcused, unrecorded }
    const dailyCounts = new Map<string, { present: number; checkedOut: number; absentExcused: number; absentUnexcused: number; unrecorded: number }>();
    dateRange.forEach((d) => dailyCounts.set(d, { present: 0, checkedOut: 0, absentExcused: 0, absentUnexcused: 0, unrecorded: 0 }));

    // Track class metrics: classId -> { present, checkedOut, absentExcused, absentUnexcused, unrecorded }
    const classCounts = new Map<string, { present: number; checkedOut: number; absentExcused: number; absentUnexcused: number; unrecorded: number }>();
    targetClassIds.forEach((cId) => classCounts.set(cId, { present: 0, checkedOut: 0, absentExcused: 0, absentUnexcused: 0, unrecorded: 0 }));

    const detailRows: AttendanceDetailRow[] = [];

    let totalPresent = 0;
    let totalCheckedOut = 0;
    let totalAbsentExcused = 0;
    let totalAbsentUnexcused = 0;
    let totalUnrecorded = 0;

    for (const d of dateRange) {
      const dCount = dailyCounts.get(d)!;

      for (const child of childrenList) {
        // Historical eligibility rule:
        // Child must not contribute expected child-days before creation boundary
        const childCreation = child.created_at ? new Date(child.created_at).toISOString() : '';
        if (childCreation && childCreation.split('T')[0] > d) {
          // Child was created after date d; not eligible on date d
          continue;
        }

        const cCount = classCounts.get(child.class_id);
        if (!cCount) continue;

        const record = attendanceRecordMap.get(`${child.id}_${d}`);
        const fullName = `${child.first_name} ${child.last_name}`.trim();
        const cName = classNameMap.get(child.class_id) || '';

        if (record) {
          const isCheckedOut = record.status === 'CHECKED_OUT' || (record.status === 'PRESENT' && record.check_out_time != null);
          const hasRecordCorrections = correctedAttendanceIdSet.has(record.id);

          if (isCheckedOut) {
            dCount.checkedOut++;
            cCount.checkedOut++;
            totalCheckedOut++;
            detailRows.push({
              date: d,
              classId: child.class_id,
              className: cName,
              childId: child.id,
              childName: fullName,
              status: 'CHECKED_OUT',
              checkInTime: record.check_in_time,
              checkOutTime: record.check_out_time,
              hasCorrections: hasRecordCorrections,
            });
          } else if (record.status === 'PRESENT') {
            dCount.present++;
            cCount.present++;
            totalPresent++;
            detailRows.push({
              date: d,
              classId: child.class_id,
              className: cName,
              childId: child.id,
              childName: fullName,
              status: 'PRESENT',
              checkInTime: record.check_in_time,
              checkOutTime: null,
              hasCorrections: hasRecordCorrections,
            });
          } else if (record.status === 'ABSENT_EXCUSED') {
            dCount.absentExcused++;
            cCount.absentExcused++;
            totalAbsentExcused++;
            detailRows.push({
              date: d,
              classId: child.class_id,
              className: cName,
              childId: child.id,
              childName: fullName,
              status: 'ABSENT_EXCUSED',
              checkInTime: null,
              checkOutTime: null,
              hasCorrections: hasRecordCorrections,
            });
          } else if (record.status === 'ABSENT_UNEXCUSED') {
            dCount.absentUnexcused++;
            cCount.absentUnexcused++;
            totalAbsentUnexcused++;
            detailRows.push({
              date: d,
              classId: child.class_id,
              className: cName,
              childId: child.id,
              childName: fullName,
              status: 'ABSENT_UNEXCUSED',
              checkInTime: null,
              checkOutTime: null,
              hasCorrections: hasRecordCorrections,
            });
          }
        } else {
          // Unrecorded child-day
          dCount.unrecorded++;
          cCount.unrecorded++;
          totalUnrecorded++;
          detailRows.push({
            date: d,
            classId: child.class_id,
            className: cName,
            childId: child.id,
            childName: fullName,
            status: 'UNRECORDED',
            checkInTime: null,
            checkOutTime: null,
            hasCorrections: false,
          });
        }
      }
    }

    // 6. Build final breakdown structures
    const overviewMetrics = calculateAttendanceMetrics(
      totalPresent,
      totalCheckedOut,
      totalAbsentExcused,
      totalAbsentUnexcused,
      totalUnrecorded
    );

    const byDay: DailyAttendanceBreakdown[] = dateRange.map((d) => {
      const c = dailyCounts.get(d)!;
      return {
        date: d,
        metrics: calculateAttendanceMetrics(
          c.present,
          c.checkedOut,
          c.absentExcused,
          c.absentUnexcused,
          c.unrecorded
        ),
      };
    });

    const byClass: ClassAttendanceBreakdown[] = targetClassIds.map((cId) => {
      const c = classCounts.get(cId)!;
      return {
        classId: cId,
        className: classNameMap.get(cId) || cId,
        metrics: calculateAttendanceMetrics(
          c.present,
          c.checkedOut,
          c.absentExcused,
          c.absentUnexcused,
          c.unrecorded
        ),
      };
    });

    return {
      data: {
        filter,
        overview: overviewMetrics,
        byDay,
        byClass,
        permittedClassIds,
      },
      error: null,
      detailRows,
    };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to generate attendance report';
    return { data: null, error: message, detailRows: [] };
  }
}
