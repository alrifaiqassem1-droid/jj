import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  UserCheck,
  ShieldAlert,
  Phone,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Lock,
} from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import {
  getAuthorizedPickupPersons,
  recordPickup,
} from '../attendanceService';
import type {
  AttendanceListItem,
  AuthorizedPickupPerson,
  Attendance,
  AttendanceErrorCode,
} from '../attendanceTypes';

interface PickupDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  child: AttendanceListItem | null;
  kindergartenId: string;
  currentRole: string | null;
  onPickupSuccess: (updatedRow: Attendance) => void;
}

export const PickupDrawer: React.FC<PickupDrawerProps> = ({
  isOpen,
  onClose,
  child,
  kindergartenId,
  currentRole,
  onPickupSuccess,
}) => {
  const { t } = useI18n();

  // Tabs: 'AUTHORIZED' or 'ADMIN_EXCEPTION'
  const [activeTab, setActiveTab] = useState<'AUTHORIZED' | 'ADMIN_EXCEPTION'>('AUTHORIZED');

  // Authorized persons state
  const [persons, setPersons] = useState<AuthorizedPickupPerson[]>([]);
  const [loadingPersons, setLoadingPersons] = useState<boolean>(false);
  const [selectedRelationshipId, setSelectedRelationshipId] = useState<string | null>(null);

  // Admin exception form state
  const [recipientName, setRecipientName] = useState<string>('');
  const [recipientIdNumber, setRecipientIdNumber] = useState<string>('');
  const [reason, setReason] = useState<string>('');

  // Submission state
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Focus trap / Accessibility ref
  const drawerRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  const isAdmin = currentRole === 'ADMIN';

  // Load authorized persons whenever drawer opens with a valid child
  useEffect(() => {
    if (!isOpen || !child || !kindergartenId) {
      setPersons([]);
      setSelectedRelationshipId(null);
      setRecipientName('');
      setRecipientIdNumber('');
      setReason('');
      setErrorMessage(null);
      setActiveTab('AUTHORIZED');
      return;
    }

    let isMounted = true;
    setLoadingPersons(true);
    setErrorMessage(null);

    getAuthorizedPickupPersons(child.child_id, kindergartenId)
      .then((res) => {
        if (!isMounted) return;
        if (res.error) {
          setErrorMessage(t.pickup.pickupError);
        } else {
          const list = res.data || [];
          setPersons(list);
          if (list.length > 0) {
            setSelectedRelationshipId(list[0].relationship_id);
          } else {
            setSelectedRelationshipId(null);
          }
        }
      })
      .catch(() => {
        if (isMounted) {
          setErrorMessage(t.pickup.SERVICE_NETWORK_ERROR);
        }
      })
      .finally(() => {
        if (isMounted) {
          setLoadingPersons(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, child, kindergartenId, t.pickup.pickupError, t.pickup.SERVICE_NETWORK_ERROR]);

  // Handle Escape key and focus
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isSubmitting) {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    closeButtonRef.current?.focus();

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, isSubmitting, onClose]);

  if (!isOpen || !child) return null;

  // Validation checks for submission
  const trimmedReason = reason.trim();
  const trimmedRecipientName = recipientName.trim();

  const isAuthorizedFormValid = Boolean(selectedRelationshipId);
  const isAdminExceptionFormValid =
    isAdmin &&
    trimmedRecipientName.length >= 3 &&
    trimmedRecipientName.length <= 150 &&
    trimmedReason.length >= 10 &&
    trimmedReason.length <= 500;

  const canSubmit = activeTab === 'AUTHORIZED' ? isAuthorizedFormValid : isAdminExceptionFormValid;

  const getRelationshipLabel = (rel: string) => {
    switch (rel) {
      case 'MOTHER':
        return t.parents.relationshipMother;
      case 'FATHER':
        return t.parents.relationshipFather;
      case 'GUARDIAN':
        return t.parents.relationshipGuardian;
      case 'GRANDPARENT':
        return t.parents.relationshipGrandparent;
      case 'RELATIVE':
        return t.parents.relationshipRelative;
      default:
        return rel;
    }
  };

  const getErrorMessage = (code?: AttendanceErrorCode, fallback?: string) => {
    if (!code) return fallback || t.pickup.pickupError;
    const localized = t.pickup[code as keyof typeof t.pickup];
    return typeof localized === 'string' ? localized : fallback || t.pickup.pickupError;
  };

  // Form submission handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit || isSubmitting) return;

    // Safety guard: Child must be PRESENT and have an attendance ID
    if (child.status !== 'PRESENT' || child.id.startsWith('unrecorded-')) {
      setErrorMessage(t.pickup.childNotPresentWarning);
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      if (activeTab === 'AUTHORIZED') {
        if (!selectedRelationshipId) return;

        const res = await recordPickup({
          pickup_type: 'AUTHORIZED_RELATIONSHIP',
          attendance_id: child.id,
          child_id: child.child_id,
          kindergarten_id: kindergartenId,
          relationship_id: selectedRelationshipId,
        });

        if (res.error || !res.data) {
          setErrorMessage(getErrorMessage(res.errorCode, res.error?.message));
        } else {
          onPickupSuccess(res.data);
          onClose();
        }
      } else {
        // ADMIN_EXCEPTION
        if (!isAdmin) return;

        const res = await recordPickup({
          pickup_type: 'ADMIN_EXCEPTION',
          attendance_id: child.id,
          child_id: child.child_id,
          kindergarten_id: kindergartenId,
          recipient_name: trimmedRecipientName,
          recipient_id_number: recipientIdNumber.trim() || undefined,
          reason: trimmedReason,
        });

        if (res.error || !res.data) {
          setErrorMessage(getErrorMessage(res.errorCode, res.error?.message));
        } else {
          onPickupSuccess(res.data);
          onClose();
        }
      }
    } catch {
      setErrorMessage(t.pickup.SERVICE_NETWORK_ERROR);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pickup-drawer-title"
      aria-describedby="pickup-drawer-subtitle"
    >
      {/* Backdrop overlay */}
      <div
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity"
        onClick={() => !isSubmitting && onClose()}
        aria-hidden="true"
      />

      <div className="fixed inset-y-0 end-0 max-w-full flex pl-0">
        <div
          ref={drawerRef}
          className="w-screen max-w-md bg-white shadow-2xl flex flex-col focus:outline-hidden"
        >
          {/* Drawer Header */}
          <div className="px-6 py-5 border-b border-slate-200 bg-slate-50/70 flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-teal-100 text-teal-800">
                  <UserCheck className="w-5 h-5 text-teal-700" aria-hidden="true" />
                </span>
                <h2
                  id="pickup-drawer-title"
                  className="text-lg font-bold text-slate-900 tracking-tight"
                >
                  {t.pickup.drawerTitle}
                </h2>
              </div>
              <p id="pickup-drawer-subtitle" className="text-xs text-slate-500 mt-1">
                {t.pickup.drawerSubtitle}
              </p>
              <div className="mt-2.5 inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-teal-50 border border-teal-200 text-teal-800 text-xs font-semibold">
                <span>{child.child_name}</span>
                {child.class_name && (
                  <span className="text-teal-600 font-normal">({child.class_name})</span>
                )}
              </div>
            </div>

            <button
              ref={closeButtonRef}
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              aria-label={t.pickup.closeDrawerAria}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 focus:outline-hidden focus:ring-2 focus:ring-teal-700 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center disabled:opacity-50"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>

          {/* Navigation Tabs (Admin Exception visible only for ADMIN) */}
          {isAdmin && (
            <div className="flex border-b border-slate-200 px-6 bg-white shrink-0">
              <button
                type="button"
                onClick={() => setActiveTab('AUTHORIZED')}
                disabled={isSubmitting}
                className={`py-3 px-4 text-xs font-bold border-b-2 transition-colors flex items-center gap-2 min-h-[44px] ${
                  activeTab === 'AUTHORIZED'
                    ? 'border-teal-700 text-teal-800'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                }`}
              >
                <UserCheck className="w-4 h-4" aria-hidden="true" />
                <span>{t.pickup.tabAuthorized}</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('ADMIN_EXCEPTION')}
                disabled={isSubmitting}
                className={`py-3 px-4 text-xs font-bold border-b-2 transition-colors flex items-center gap-2 min-h-[44px] ${
                  activeTab === 'ADMIN_EXCEPTION'
                    ? 'border-amber-600 text-amber-800'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                }`}
              >
                <ShieldAlert className="w-4 h-4" aria-hidden="true" />
                <span>{t.pickup.tabAdminException}</span>
              </button>
            </div>
          )}

          {/* Error Banner */}
          {errorMessage && (
            <div
              role="alert"
              className="m-6 mb-0 p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl flex items-start gap-2.5 text-xs animate-in fade-in duration-150"
            >
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" aria-hidden="true" />
              <div className="flex-1 font-medium leading-relaxed">{errorMessage}</div>
            </div>
          )}

          {/* Drawer Body Form */}
          <form onSubmit={handleSubmit} className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {activeTab === 'AUTHORIZED' ? (
                /* Tab 1: Authorized Persons Selection */
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700">
                      {t.pickup.tabAuthorized}
                    </span>
                    <span className="text-xs text-slate-400">
                      {persons.length > 0 && `(${persons.length})`}
                    </span>
                  </div>

                  {loadingPersons ? (
                    <div className="py-12 flex flex-col items-center justify-center gap-2.5 text-slate-500 text-xs">
                      <Loader2 className="w-6 h-6 animate-spin text-teal-700" />
                      <span>{t.pickup.loadingPersons}</span>
                    </div>
                  ) : persons.length === 0 ? (
                    <div className="p-8 text-center bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                      <Lock className="w-8 h-8 text-slate-400 mx-auto" aria-hidden="true" />
                      <p className="text-xs font-medium text-slate-700">
                        {t.pickup.noAuthorizedPersons}
                      </p>
                      {isAdmin && (
                        <p className="text-xs text-slate-500">
                          {t.pickup.adminNotice}
                        </p>
                      )}
                    </div>
                  ) : (
                    <div
                      role="radiogroup"
                      aria-label={t.pickup.selectPersonAria}
                      className="space-y-2.5"
                    >
                      {persons.map((person) => {
                        const isSelected = selectedRelationshipId === person.relationship_id;
                        return (
                          <div
                            key={person.relationship_id}
                            onClick={() => !isSubmitting && setSelectedRelationshipId(person.relationship_id)}
                            className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                              isSelected
                                ? 'bg-teal-50/70 border-teal-600 ring-2 ring-teal-600/20'
                                : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                            }`}
                          >
                            <div className="flex items-start gap-3 min-w-0">
                              <div
                                className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                                  isSelected
                                    ? 'border-teal-700 bg-teal-700 text-white'
                                    : 'border-slate-300 bg-white'
                                }`}
                                aria-hidden="true"
                              >
                                {isSelected && <span className="w-2 h-2 rounded-full bg-white" />}
                              </div>

                              <div className="min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-sm font-bold text-slate-900 truncate">
                                    {person.parent_name}
                                  </span>
                                  <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-700">
                                    {getRelationshipLabel(person.relationship)}
                                  </span>
                                </div>

                                <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-500 flex-wrap">
                                  {person.parent_phone && (
                                    <span className="flex items-center gap-1">
                                      <Phone className="w-3.5 h-3.5 text-slate-400" />
                                      <span dir="ltr">{person.parent_phone}</span>
                                    </span>
                                  )}
                                  {person.is_primary_contact && (
                                    <span className="text-teal-700 font-medium">
                                      • {t.pickup.primaryContact}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>

                            <div className="shrink-0">
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-50 text-emerald-800 border border-emerald-200">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" aria-hidden="true" />
                                <span>{t.pickup.verifiedCustody}</span>
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              ) : (
                /* Tab 2: Admin Exception Form */
                <div className="space-y-4">
                  <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-2.5">
                    <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" aria-hidden="true" />
                    <p className="leading-relaxed">{t.pickup.adminNotice}</p>
                  </div>

                  {/* Recipient Full Name */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="pickup-recipient-name"
                      className="block text-xs font-bold text-slate-700"
                    >
                      {t.pickup.recipientNameLabel}{' '}
                      <span className="text-rose-600 font-bold">*</span>
                    </label>
                    <input
                      id="pickup-recipient-name"
                      type="text"
                      value={recipientName}
                      onChange={(e) => setRecipientName(e.target.value)}
                      maxLength={150}
                      disabled={isSubmitting}
                      placeholder={t.pickup.recipientNamePlaceholder}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-600 focus:bg-white transition-colors min-h-[44px]"
                    />
                  </div>

                  {/* Recipient ID Number (Optional in schema) */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="pickup-recipient-id"
                      className="block text-xs font-bold text-slate-700"
                    >
                      {t.pickup.recipientIdLabel}
                    </label>
                    <input
                      id="pickup-recipient-id"
                      type="text"
                      value={recipientIdNumber}
                      onChange={(e) => setRecipientIdNumber(e.target.value)}
                      maxLength={50}
                      disabled={isSubmitting}
                      placeholder={t.pickup.recipientIdPlaceholder}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-600 focus:bg-white transition-colors min-h-[44px]"
                    />
                  </div>

                  {/* Exception Justification Reason (min 10 chars) */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label
                        htmlFor="pickup-exception-reason"
                        className="block text-xs font-bold text-slate-700"
                      >
                        {t.pickup.reasonLabel}{' '}
                        <span className="text-rose-600 font-bold">*</span>
                      </label>
                      <span
                        className={`text-[11px] font-medium ${
                          trimmedReason.length < 10
                            ? 'text-amber-700'
                            : 'text-emerald-700'
                        }`}
                      >
                        {trimmedReason.length}/10 {t.pickup.reasonMinCharsHint}
                      </span>
                    </div>
                    <textarea
                      id="pickup-exception-reason"
                      rows={3}
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      maxLength={500}
                      disabled={isSubmitting}
                      placeholder={t.pickup.reasonPlaceholder}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-600 focus:bg-white transition-colors"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Drawer Footer Actions */}
            <div className="p-6 border-t border-slate-200 bg-slate-50/70 flex items-center justify-end gap-3 shrink-0">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2.5 border border-slate-200 bg-white text-slate-700 rounded-lg text-xs font-bold hover:bg-slate-50 focus:outline-hidden focus:ring-2 focus:ring-slate-400 transition-colors min-h-[44px]"
              >
                {t.pickup.cancel}
              </button>

              <button
                type="submit"
                disabled={!canSubmit || isSubmitting}
                className={`px-5 py-2.5 rounded-lg text-xs font-bold text-white transition-colors flex items-center gap-2 min-h-[44px] focus:outline-hidden focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed ${
                  activeTab === 'AUTHORIZED'
                    ? 'bg-teal-800 hover:bg-teal-900 focus:ring-teal-700'
                    : 'bg-amber-700 hover:bg-amber-800 focus:ring-amber-600'
                }`}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" aria-hidden="true" />
                    <span>{t.pickup.submittingPickup}</span>
                  </>
                ) : (
                  <>
                    <UserCheck className="w-4 h-4 text-white" aria-hidden="true" />
                    <span>{t.pickup.confirmPickup}</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
