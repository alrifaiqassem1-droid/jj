import React from 'react';
import { AlertCircle, RefreshCw, Users, SearchX } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { AttendanceListItem, AttendanceStatus } from '../attendanceTypes';
import { AttendanceRow } from './AttendanceRow';

interface AttendanceListProps {
  items: AttendanceListItem[];
  isLoading: boolean;
  errorMessage: string | null;
  onRetry: () => void;
  onMarkStatus: (childId: string, status: AttendanceStatus) => Promise<void>;
  updatingChildId: string | null;
  canUpdate: boolean;
  searchQuery: string;
  hasActiveFilters: boolean;
  onClearFilters: () => void;
  onOpenPickup?: (child: AttendanceListItem) => void;
  onOpenCorrection?: (child: AttendanceListItem) => void;
}

export const AttendanceList: React.FC<AttendanceListProps> = ({
  items,
  isLoading,
  errorMessage,
  onRetry,
  onMarkStatus,
  updatingChildId,
  canUpdate,
  searchQuery,
  hasActiveFilters,
  onClearFilters,
  onOpenPickup,
  onOpenCorrection,
}) => {
  const { t } = useI18n();

  // 1. Loading Skeleton State
  if (isLoading) {
    return (
      <div className="space-y-3" aria-busy="true" aria-label={t.common.loading}>
        {[1, 2, 3, 4, 5].map((index) => (
          <div
            key={index}
            className="p-4 sm:p-5 bg-white border border-slate-200 rounded-xl shadow-xs animate-pulse flex flex-col md:flex-row md:items-center justify-between gap-4"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-full bg-slate-200 shrink-0" />
              <div className="space-y-2">
                <div className="h-4 w-32 bg-slate-200 rounded-md" />
                <div className="h-3 w-24 bg-slate-100 rounded-md" />
              </div>
            </div>
            <div className="h-9 w-48 bg-slate-100 rounded-lg self-end md:self-auto" />
          </div>
        ))}
      </div>
    );
  }

  // 2. Error State
  if (errorMessage) {
    return (
      <div
        className="p-8 bg-white border border-rose-200 rounded-2xl text-center shadow-xs"
        role="alert"
      >
        <div className="w-12 h-12 mx-auto rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mb-3">
          <AlertCircle className="w-6 h-6" aria-hidden="true" />
        </div>
        <h3 className="text-base font-semibold text-slate-900 mb-1">
          {t.attendance.errorLoadingAttendance}
        </h3>
        <p className="text-sm text-slate-600 mb-4 max-w-md mx-auto">
          {errorMessage}
        </p>
        <button
          type="button"
          onClick={onRetry}
          className="inline-flex items-center gap-2 px-4 py-2 bg-teal-800 text-white rounded-lg text-sm font-medium hover:bg-teal-900 focus:outline-hidden focus:ring-2 focus:ring-teal-700 focus:ring-offset-2 transition-colors min-h-[44px]"
        >
          <RefreshCw className="w-4 h-4" aria-hidden="true" />
          <span>{t.attendance.retryAction}</span>
        </button>
      </div>
    );
  }

  // 3. Filter/Search Empty State
  if (items.length === 0 && hasActiveFilters) {
    return (
      <div className="p-12 bg-white border border-slate-200 rounded-2xl text-center shadow-xs">
        <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-500 flex items-center justify-center mb-3">
          <SearchX className="w-6 h-6" aria-hidden="true" />
        </div>
        <h3 className="text-base font-semibold text-slate-900 mb-1">
          {t.attendance.noSearchResults}
        </h3>
        <p className="text-sm text-slate-500 mb-4">
          {searchQuery ? `"${searchQuery}"` : ''}
        </p>
        <button
          type="button"
          onClick={onClearFilters}
          className="inline-flex items-center gap-2 px-4 py-2 border border-slate-300 bg-white text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-50 focus:outline-hidden focus:ring-2 focus:ring-teal-700 min-h-[44px] transition-colors"
        >
          <span>{t.attendance.clearFilters}</span>
        </button>
      </div>
    );
  }

  // 4. Class Completely Empty State
  if (items.length === 0) {
    return (
      <div className="p-12 bg-white border border-slate-200 rounded-2xl text-center shadow-xs">
        <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-500 flex items-center justify-center mb-3">
          <Users className="w-6 h-6" aria-hidden="true" />
        </div>
        <h3 className="text-base font-semibold text-slate-900 mb-1">
          {t.attendance.noChildrenInClass}
        </h3>
        <p className="text-sm text-slate-500 max-w-sm mx-auto">
          {t.attendance.noClassesAssigned}
        </p>
      </div>
    );
  }

  // 5. Active Items List
  return (
    <div className="space-y-3" role="table" aria-label={t.attendance.title}>
      {items.map((item) => (
        <AttendanceRow
          key={item.child_id}
          item={item}
          onMarkStatus={onMarkStatus}
          isUpdating={updatingChildId === item.child_id}
          canUpdate={canUpdate}
          onOpenPickup={onOpenPickup}
          onOpenCorrection={onOpenCorrection}
        />
      ))}
    </div>
  );
};
