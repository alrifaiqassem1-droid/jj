import React from 'react';
import {
  Calendar as CalendarIcon,
  School,
  Search,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { AttendanceStatus } from '../attendanceTypes';

export type StatusFilterType = 'ALL' | AttendanceStatus;

interface ClassOption {
  id: string;
  name: string;
}

interface AttendanceMetrics {
  total: number;
  present: number;
  absent: number;
  checkedOut: number;
  unrecorded: number;
}

interface AttendanceToolbarProps {
  selectedDate: string;
  onDateChange: (newDate: string) => void;
  classes: ClassOption[];
  selectedClassId: string;
  onClassChange: (classId: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  statusFilter: StatusFilterType;
  onStatusFilterChange: (status: StatusFilterType) => void;
  metrics: AttendanceMetrics;
  onRefresh: () => void;
  isRefreshing: boolean;
}

export const AttendanceToolbar: React.FC<AttendanceToolbarProps> = ({
  selectedDate,
  onDateChange,
  classes,
  selectedClassId,
  onClassChange,
  searchQuery,
  onSearchChange,
  statusFilter,
  onStatusFilterChange,
  metrics,
  onRefresh,
  isRefreshing,
}) => {
  const { t, locale, dir } = useI18n();

  // Navigation chevrons respect RTL: in RTL, next day is left arrow, previous day is right arrow
  const PrevIcon = dir === 'rtl' ? ChevronRight : ChevronLeft;
  const NextIcon = dir === 'rtl' ? ChevronLeft : ChevronRight;

  const handleDayShift = (days: number) => {
    const current = new Date(selectedDate);
    current.setDate(current.getDate() + days);
    const isoString = current.toISOString().split('T')[0];
    onDateChange(isoString);
  };

  const formattedDisplayDate = (() => {
    try {
      const [year, month, day] = selectedDate.split('-').map(Number);
      const dateObj = new Date(year, month - 1, day);
      return new Intl.DateTimeFormat(locale, {
        weekday: 'long',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      }).format(dateObj);
    } catch {
      return selectedDate;
    }
  })();

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4">
      {/* Top Controls Row: Date Picker & Class Selector */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Date Selector with Next/Prev Steppers */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => handleDayShift(-1)}
            aria-label="Previous day"
            className="w-10 h-10 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors focus:outline-hidden focus:ring-2 focus:ring-teal-700 min-h-[44px] min-w-[44px]"
          >
            <PrevIcon className="w-5 h-5" aria-hidden="true" />
          </button>

          <div className="relative flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 hover:bg-white transition-colors focus-within:ring-2 focus-within:ring-teal-700">
            <CalendarIcon className="w-4 h-4 text-teal-700 shrink-0" aria-hidden="true" />
            <span className="text-sm font-semibold text-slate-800 select-none">
              {formattedDisplayDate}
            </span>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => e.target.value && onDateChange(e.target.value)}
              className="opacity-0 absolute inset-0 cursor-pointer w-full h-full"
              aria-label={t.attendance.dateLabel}
            />
          </div>

          <button
            type="button"
            onClick={() => handleDayShift(1)}
            aria-label="Next day"
            className="w-10 h-10 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors focus:outline-hidden focus:ring-2 focus:ring-teal-700 min-h-[44px] min-w-[44px]"
          >
            <NextIcon className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Classroom Dropdown & Refresh Action */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative min-w-[200px]">
            <School className="w-4 h-4 text-slate-400 absolute inset-inline-start-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <select
              value={selectedClassId}
              onChange={(e) => onClassChange(e.target.value)}
              aria-label={t.attendance.selectClassLabel}
              className="w-full ps-9 pe-8 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-700 focus:bg-white transition-colors min-h-[44px]"
            >
              {classes.length === 0 ? (
                <option value="">{t.attendance.noClassesAssigned}</option>
              ) : (
                classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))
              )}
            </select>
          </div>

          <button
            type="button"
            onClick={onRefresh}
            disabled={isRefreshing}
            aria-label={t.attendance.refreshTooltip}
            className="w-10 h-10 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors focus:outline-hidden focus:ring-2 focus:ring-teal-700 disabled:opacity-50 min-h-[44px] min-w-[44px]"
          >
            <RefreshCw
              className={`w-4 h-4 text-slate-600 ${isRefreshing ? 'animate-spin text-teal-700' : ''}`}
              aria-hidden="true"
            />
          </button>
        </div>
      </div>

      {/* Metrics Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 pt-1">
        <div className="px-3 py-2 bg-slate-50 border border-slate-100 rounded-xl text-center">
          <div className="text-xs text-slate-500 font-medium">{t.attendance.totalChildrenCount}</div>
          <div className="text-lg font-bold text-slate-800 mt-0.5">{metrics.total}</div>
        </div>

        <div className="px-3 py-2 bg-emerald-50/70 border border-emerald-100 rounded-xl text-center">
          <div className="text-xs text-emerald-800 font-medium">{t.attendance.presentCount}</div>
          <div className="text-lg font-bold text-emerald-800 mt-0.5">{metrics.present}</div>
        </div>

        <div className="px-3 py-2 bg-rose-50/70 border border-rose-100 rounded-xl text-center">
          <div className="text-xs text-rose-800 font-medium">{t.attendance.absentCount}</div>
          <div className="text-lg font-bold text-rose-800 mt-0.5">{metrics.absent}</div>
        </div>

        <div className="px-3 py-2 bg-indigo-50/70 border border-indigo-100 rounded-xl text-center">
          <div className="text-xs text-indigo-800 font-medium">{t.attendance.checkedOutCount}</div>
          <div className="text-lg font-bold text-indigo-800 mt-0.5">{metrics.checkedOut}</div>
        </div>

        <div className="px-3 py-2 bg-amber-50/70 border border-amber-100 rounded-xl text-center col-span-2 sm:col-span-1">
          <div className="text-xs text-amber-800 font-medium">{t.attendance.unrecordedCount}</div>
          <div className="text-lg font-bold text-amber-800 mt-0.5">{metrics.unrecorded}</div>
        </div>
      </div>

      {/* Search and Status Filters */}
      <div className="flex flex-col sm:flex-row items-center gap-3 pt-1 border-t border-slate-100">
        {/* Search Input */}
        <div className="relative w-full sm:flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute inset-inline-start-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={t.attendance.searchPlaceholder}
            className="w-full ps-9 pe-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-700 focus:bg-white transition-colors min-h-[44px]"
          />
        </div>

        {/* Status Filter Dropdown */}
        <div className="relative w-full sm:w-auto min-w-[170px]">
          <Filter className="w-4 h-4 text-slate-400 absolute inset-inline-start-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <select
            value={statusFilter}
            onChange={(e) => onStatusFilterChange(e.target.value as StatusFilterType)}
            aria-label={t.attendance.filterAllStatus}
            className="w-full ps-9 pe-8 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-700 focus:bg-white transition-colors min-h-[44px]"
          >
            <option value="ALL">{t.attendance.filterAllStatus}</option>
            <option value="PRESENT">{t.attendance.statusPresent}</option>
            <option value="ABSENT_EXCUSED">{t.attendance.statusAbsentExcused}</option>
            <option value="ABSENT_UNEXCUSED">{t.attendance.statusAbsentUnexcused}</option>
            <option value="CHECKED_OUT">{t.attendance.statusCheckedOut}</option>
            <option value="UNRECORDED">{t.attendance.statusUnrecorded}</option>
          </select>
        </div>
      </div>
    </div>
  );
};
