import React, { useState, useEffect, useCallback } from 'react';
import {
  BarChart3,
  Download,
  AlertCircle,
  RefreshCw,
  CheckCircle2,
  Clock,
  ShieldAlert,
  Layers,
} from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import { useAuth } from '../../auth/AuthContext';
import { supabase } from '../../../lib/supabase/client';
import type {
  AttendanceReportFilter,
  AttendanceReportData,
  AttendanceDetailRow,
} from '../types/attendanceReportTypes';
import {
  getAttendanceReport,
  generateCsvContent,
  sanitizeFilename,
} from '../services/attendanceReportService';

interface SimpleClass {
  id: string;
  name: string;
}

export const AttendanceReportsView: React.FC = () => {
  const { t, locale } = useI18n();
  const { user, activeMembership, activeRole } = useAuth();
  const activeKindergartenId = activeMembership?.kindergarten_id;

  // Date filters: default to last 7 days up to today
  const [startDate, setStartDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() - 6);
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });

  const [selectedClassId, setSelectedClassId] = useState<string>('ALL');
  const [classes, setClasses] = useState<SimpleClass[]>([]);
  const [classesLoading, setClassesLoading] = useState<boolean>(true);

  // Report state
  const [reportData, setReportData] = useState<AttendanceReportData | null>(null);
  const [detailRows, setDetailRows] = useState<AttendanceDetailRow[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Active view tab: 'overview' | 'byDay' | 'byClass'
  const [activeTab, setActiveTab] = useState<'overview' | 'byDay' | 'byClass'>('overview');

  // Export state
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // 1. Fetch permitted classes
  const loadPermittedClasses = useCallback(async () => {
    if (!activeKindergartenId || !user) return;
    setClassesLoading(true);

    try {
      if (activeRole === 'ADMIN') {
        const { data, error } = await supabase
          .from('classes')
          .select('id, name')
          .eq('kindergarten_id', activeKindergartenId)
          .is('deleted_at', null)
          .order('name');

        if (error) throw error;
        setClasses((data ?? []).map((c) => ({ id: c.id, name: c.name })));
      } else if (activeRole === 'TEACHER') {
        const { data: assignments, error: assignErr } = await supabase
          .from('teacher_class_assignments')
          .select('class_id')
          .eq('kindergarten_id', activeKindergartenId)
          .eq('teacher_id', user.id);

        if (assignErr) throw assignErr;
        const assignedIds = (assignments ?? []).map((a) => a.class_id);

        if (assignedIds.length > 0) {
          const { data: classRows, error: classErr } = await supabase
            .from('classes')
            .select('id, name')
            .in('id', assignedIds)
            .is('deleted_at', null)
            .order('name');

          if (classErr) throw classErr;
          const mapped = (classRows ?? []).map((c) => ({ id: c.id, name: c.name }));
          setClasses(mapped);
          if (mapped.length > 0 && selectedClassId === 'ALL') {
            setSelectedClassId('ALL');
          }
        } else {
          setClasses([]);
        }
      } else {
        setClasses([]);
      }
    } catch {
      setErrorMessage(t.attendanceReports.exportError);
    } finally {
      setClassesLoading(false);
    }
  }, [activeKindergartenId, user, activeRole, selectedClassId, t.attendanceReports.exportError]);

  useEffect(() => {
    loadPermittedClasses();
  }, [loadPermittedClasses]);

  // 2. Fetch Report Data
  const loadReport = useCallback(async () => {
    if (!activeKindergartenId || !user) return;

    if (startDate > endDate) {
      setErrorMessage(t.attendanceReports.invalidDateRange);
      setReportData(null);
      setDetailRows([]);
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    const filter: AttendanceReportFilter = {
      startDate,
      endDate,
      classId: selectedClassId,
    };

    const result = await getAttendanceReport({
      kindergartenId: activeKindergartenId,
      userRole: activeRole || '',
      userId: user.id,
      filter,
    });

    if (result.error) {
      setErrorMessage(result.error);
      setReportData(null);
      setDetailRows([]);
    } else {
      setReportData(result.data);
      setDetailRows(result.detailRows);
    }
    setIsLoading(false);
  }, [activeKindergartenId, user, activeRole, startDate, endDate, selectedClassId, t.attendanceReports.invalidDateRange]);

  useEffect(() => {
    loadReport();
  }, [loadReport]);

  // 3. Handle CSV Export
  const handleExportCsv = () => {
    if (!reportData || detailRows.length === 0) return;

    setIsExporting(true);
    try {
      const headers = [
        t.attendanceReports.csvHeaders.date,
        t.attendanceReports.csvHeaders.className,
        t.attendanceReports.csvHeaders.childName,
        t.attendanceReports.csvHeaders.status,
        t.attendanceReports.csvHeaders.checkInTime,
        t.attendanceReports.csvHeaders.checkOutTime,
        t.attendanceReports.csvHeaders.hasCorrections,
      ];

      const rows = detailRows.map((r) => [
        r.date,
        r.className,
        r.childName,
        r.status === 'PRESENT'
          ? t.attendance.statusPresent
          : r.status === 'CHECKED_OUT'
          ? t.attendance.statusCheckedOut
          : r.status === 'ABSENT_EXCUSED'
          ? t.attendance.statusAbsentExcused
          : r.status === 'ABSENT_UNEXCUSED'
          ? t.attendance.statusAbsentUnexcused
          : t.attendance.statusUnrecorded,
        r.checkInTime ? new Date(r.checkInTime).toLocaleTimeString(locale) : '-',
        r.checkOutTime ? new Date(r.checkOutTime).toLocaleTimeString(locale) : '-',
        r.hasCorrections ? t.attendanceReports.hasCorrectionsYes : t.attendanceReports.hasCorrectionsNo,
      ]);

      const csvContent = generateCsvContent(headers, rows);
      const safePrefix = sanitizeFilename(`attendance_report_${startDate}_to_${endDate}`);
      const filename = `${safePrefix}.csv`;

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setExportNotice(t.attendanceReports.exportSuccess);
      setTimeout(() => setExportNotice(null), 4000);
    } catch {
      setExportNotice(t.attendanceReports.exportError);
      setTimeout(() => setExportNotice(null), 4000);
    } finally {
      setIsExporting(false);
    }
  };

  const isTeacher = activeRole === 'TEACHER';

  return (
    <div className="space-y-6">
      {/* Header & Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              {t.attendanceReports.title}
            </h1>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-teal-100 text-teal-800 border border-teal-200">
              {t.attendanceReports.gateBadge}
            </span>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            {t.attendanceReports.subtitle}
          </p>
        </div>

        {/* CSV Export Button */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleExportCsv}
            disabled={isExporting || isLoading || !reportData || detailRows.length === 0}
            className="inline-flex items-center gap-2 px-4 py-2 bg-teal-800 text-white rounded-xl text-sm font-semibold hover:bg-teal-900 focus:outline-hidden focus:ring-2 focus:ring-teal-700 focus:ring-offset-2 transition-colors disabled:opacity-50 min-h-[44px] shadow-xs cursor-pointer"
            aria-label={t.attendanceReports.exportCsv}
          >
            <Download className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{isExporting ? t.attendanceReports.exportingCsv : t.attendanceReports.exportCsv}</span>
          </button>
        </div>
      </div>

      {/* Role Notice for Teachers */}
      {isTeacher && (
        <div
          role="note"
          className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 text-amber-900 text-xs sm:text-sm"
        >
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" aria-hidden="true" />
          <span>{t.attendanceReports.teacherRestrictedNotice}</span>
        </div>
      )}

      {/* Notification Toast */}
      {exportNotice && (
        <div
          role="status"
          className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl flex items-center gap-3 animate-in fade-in duration-200 shadow-xs"
        >
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" aria-hidden="true" />
          <p className="text-sm font-medium">{exportNotice}</p>
        </div>
      )}

      {/* Filter Toolbar */}
      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-end gap-4">
          {/* Start Date */}
          <div className="flex-1">
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {t.attendanceReports.startDateLabel}
            </label>
            <div className="relative">
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-700 focus:bg-white transition-colors min-h-[42px]"
              />
            </div>
          </div>

          {/* End Date */}
          <div className="flex-1">
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {t.attendanceReports.endDateLabel}
            </label>
            <div className="relative">
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-700 focus:bg-white transition-colors min-h-[42px]"
              />
            </div>
          </div>

          {/* Class Filter */}
          <div className="flex-1">
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {t.attendanceReports.filterClass}
            </label>
            <select
              value={selectedClassId}
              onChange={(e) => setSelectedClassId(e.target.value)}
              disabled={classesLoading}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-700 focus:bg-white transition-colors min-h-[42px]"
            >
              <option value="ALL">{t.attendanceReports.allClasses}</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Refresh Action */}
          <div className="self-end">
            <button
              type="button"
              onClick={loadReport}
              disabled={isLoading}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-sm font-medium transition-colors min-h-[42px] flex items-center gap-2 focus:outline-hidden focus:ring-2 focus:ring-teal-700 cursor-pointer"
              aria-label={t.common.filter}
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} aria-hidden="true" />
              <span>{t.common.filter}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Error state */}
      {errorMessage && (
        <div
          role="alert"
          className="p-6 bg-white border border-rose-200 rounded-2xl text-center shadow-xs"
        >
          <div className="w-12 h-12 mx-auto rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mb-3">
            <AlertCircle className="w-6 h-6" aria-hidden="true" />
          </div>
          <h3 className="text-base font-semibold text-slate-900 mb-1">
            {t.attendanceReports.exportError}
          </h3>
          <p className="text-sm text-slate-600 mb-4">{errorMessage}</p>
          <button
            type="button"
            onClick={loadReport}
            className="inline-flex items-center gap-2 px-4 py-2 bg-teal-800 text-white rounded-lg text-sm font-medium hover:bg-teal-900 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            <span>{t.attendance.retryAction}</span>
          </button>
        </div>
      )}

      {/* Loading Skeleton */}
      {isLoading && !errorMessage && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-pulse">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="p-5 bg-white border border-slate-200 rounded-2xl h-28" />
          ))}
        </div>
      )}

      {/* Report Content */}
      {!isLoading && !errorMessage && reportData && (
        <>
          {/* Key Metric Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Card 1: Attendance Rate */}
            <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-semibold">{t.attendanceReports.attendanceRate}</span>
                <BarChart3 className="w-4 h-4 text-teal-700" />
              </div>
              <div className="text-2xl font-bold text-slate-900">
                {reportData.overview.attendanceRate !== null
                  ? `${reportData.overview.attendanceRate}%`
                  : t.attendanceReports.rateNotAvailable}
              </div>
              <p className="text-2xs text-slate-500 mt-1">
                {t.attendanceReports.formulaHint}
              </p>
            </div>

            {/* Card 2: Total Child-Days */}
            <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-semibold">{t.attendanceReports.totalChildDays}</span>
                <Layers className="w-4 h-4 text-slate-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900">
                {reportData.overview.totalExpectedChildDays}
              </div>
              <p className="text-2xs text-slate-500 mt-1">
                {t.attendanceReports.coverageRate}:{' '}
                {reportData.overview.coverageRate !== null
                  ? `${reportData.overview.coverageRate}%`
                  : t.attendanceReports.rateNotAvailable}
              </p>
            </div>

            {/* Card 3: Present vs Checked Out */}
            <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-semibold">{t.attendanceReports.presentChildDays}</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-bold text-emerald-700">
                {reportData.overview.presentChildDays + reportData.overview.checkedOutChildDays}
              </div>
              <div className="text-2xs text-slate-500 mt-1 flex gap-2">
                <span>{t.attendanceReports.presentCountLabel} {reportData.overview.presentChildDays}</span>
                <span>•</span>
                <span>{t.attendanceReports.checkedOutCountLabel} {reportData.overview.checkedOutChildDays}</span>
              </div>
            </div>

            {/* Card 4: Absences (Excused / Unexcused) */}
            <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-semibold">{t.attendance.absentCount}</span>
                <Clock className="w-4 h-4 text-amber-600" />
              </div>
              <div className="text-2xl font-bold text-rose-700">
                {reportData.overview.absentExcusedChildDays + reportData.overview.absentUnexcusedChildDays}
              </div>
              <div className="text-2xs text-slate-500 mt-1 flex gap-2">
                <span>{t.attendanceReports.excusedCountLabel} {reportData.overview.absentExcusedChildDays}</span>
                <span>•</span>
                <span>{t.attendanceReports.unexcusedCountLabel} {reportData.overview.absentUnexcusedChildDays}</span>
              </div>
            </div>

            {/* Card 5: Unrecorded Child-Days */}
            <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-semibold">{t.attendanceReports.unrecordedChildDays}</span>
                <AlertCircle className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-600">
                {reportData.overview.unrecordedChildDays}
              </div>
              <p className="text-2xs text-slate-400 mt-1">
                {t.attendanceReports.unrecordedExcludedNotice}
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="border-b border-slate-200">
            <nav className="flex gap-4" aria-label={t.attendanceReports.tabsAriaLabel}>
              <button
                type="button"
                onClick={() => setActiveTab('overview')}
                className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors cursor-pointer ${
                  activeTab === 'overview'
                    ? 'border-teal-700 text-teal-800 font-semibold'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                }`}
              >
                {t.attendanceReports.overviewTab}
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('byDay')}
                className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors cursor-pointer ${
                  activeTab === 'byDay'
                    ? 'border-teal-700 text-teal-800 font-semibold'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                }`}
              >
                {t.attendanceReports.byDayTab}
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('byClass')}
                className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors cursor-pointer ${
                  activeTab === 'byClass'
                    ? 'border-teal-700 text-teal-800 font-semibold'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                }`}
              >
                {t.attendanceReports.byClassTab}
              </button>
            </nav>
          </div>

          {/* Tab 1: Overview Breakdown */}
          {activeTab === 'overview' && (
            <div className="p-6 bg-white border border-slate-200 rounded-2xl shadow-xs space-y-4">
              <h3 className="text-base font-bold text-slate-900">
                {t.attendanceReports.summaryPeriodTitle} ({startDate} {t.attendanceReports.summaryPeriodTo} {endDate})
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="p-4 bg-slate-50 rounded-xl space-y-2">
                  <div className="font-semibold text-slate-700 mb-1">{t.attendanceReports.actualAttendanceStatsTitle}</div>
                  <div className="flex justify-between text-slate-600">
                    <span>{t.attendanceReports.regularPresentLabel}</span>
                    <span className="font-bold text-slate-900">{reportData.overview.presentChildDays}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>{t.attendanceReports.checkedOutLabel}</span>
                    <span className="font-bold text-slate-900">{reportData.overview.checkedOutChildDays}</span>
                  </div>
                  <div className="flex justify-between text-teal-800 font-bold border-t border-slate-200 pt-1">
                    <span>{t.attendanceReports.totalCalculatedAttendanceLabel}</span>
                    <span>{reportData.overview.presentChildDays + reportData.overview.checkedOutChildDays}</span>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl space-y-2">
                  <div className="font-semibold text-slate-700 mb-1">{t.attendanceReports.absenceAndUnrecordedStatsTitle}</div>
                  <div className="flex justify-between text-slate-600">
                    <span>{t.attendanceReports.excusedAbsentLabel}</span>
                    <span className="font-bold text-slate-900">{reportData.overview.absentExcusedChildDays}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>{t.attendanceReports.unexcusedAbsentLabel}</span>
                    <span className="font-bold text-slate-900">{reportData.overview.absentUnexcusedChildDays}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>{t.attendanceReports.unrecordedDaysLabel}</span>
                    <span className="font-bold text-slate-900">{reportData.overview.unrecordedChildDays}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Daily Breakdown Table */}
          {activeTab === 'byDay' && (
            <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-xs sm:text-sm text-start" role="table">
                  <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4 text-start">{t.attendanceReports.tableHeaderDate}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderAttendanceRate}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderPresent}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderCheckedOut}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderExcused}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderUnexcused}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderUnrecorded}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderTotalExpected}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {reportData.byDay.map((d) => (
                      <tr key={d.date} className="hover:bg-slate-50 transition-colors">
                        <td className="py-3 px-4 font-medium text-slate-900">{d.date}</td>
                        <td className="py-3 px-4 text-center font-bold text-teal-800">
                          {d.metrics.attendanceRate !== null
                            ? `${d.metrics.attendanceRate}%`
                            : t.attendanceReports.rateNotAvailable}
                        </td>
                        <td className="py-3 px-4 text-center text-emerald-700 font-medium">
                          {d.metrics.presentChildDays}
                        </td>
                        <td className="py-3 px-4 text-center text-teal-700 font-medium">
                          {d.metrics.checkedOutChildDays}
                        </td>
                        <td className="py-3 px-4 text-center text-amber-700 font-medium">
                          {d.metrics.absentExcusedChildDays}
                        </td>
                        <td className="py-3 px-4 text-center text-rose-700 font-medium">
                          {d.metrics.absentUnexcusedChildDays}
                        </td>
                        <td className="py-3 px-4 text-center text-slate-500 font-medium">
                          {d.metrics.unrecordedChildDays}
                        </td>
                        <td className="py-3 px-4 text-center font-bold text-slate-900">
                          {d.metrics.totalExpectedChildDays}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Tab 3: Class Breakdown Table */}
          {activeTab === 'byClass' && (
            <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-xs sm:text-sm text-start" role="table">
                  <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4 text-start">{t.attendanceReports.tableHeaderClass}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderAttendanceRate}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderPresentChildDays}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderCheckedOutChildDays}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderExcused}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderUnexcused}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderUnrecorded}</th>
                      <th className="py-3 px-4 text-center">{t.attendanceReports.tableHeaderTotalExpected}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {reportData.byClass.map((c) => (
                      <tr key={c.classId} className="hover:bg-slate-50 transition-colors">
                        <td className="py-3 px-4 font-medium text-slate-900">{c.className}</td>
                        <td className="py-3 px-4 text-center font-bold text-teal-800">
                          {c.metrics.attendanceRate !== null
                            ? `${c.metrics.attendanceRate}%`
                            : t.attendanceReports.rateNotAvailable}
                        </td>
                        <td className="py-3 px-4 text-center text-emerald-700 font-medium">
                          {c.metrics.presentChildDays}
                        </td>
                        <td className="py-3 px-4 text-center text-teal-700 font-medium">
                          {c.metrics.checkedOutChildDays}
                        </td>
                        <td className="py-3 px-4 text-center text-amber-700 font-medium">
                          {c.metrics.absentExcusedChildDays}
                        </td>
                        <td className="py-3 px-4 text-center text-rose-700 font-medium">
                          {c.metrics.absentUnexcusedChildDays}
                        </td>
                        <td className="py-3 px-4 text-center text-slate-500 font-medium">
                          {c.metrics.unrecordedChildDays}
                        </td>
                        <td className="py-3 px-4 text-center font-bold text-slate-900">
                          {c.metrics.totalExpectedChildDays}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
