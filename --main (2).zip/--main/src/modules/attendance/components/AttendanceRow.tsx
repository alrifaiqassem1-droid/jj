import React from 'react';
import {
  CheckCircle2,
  Clock,
  XCircle,
  HelpCircle,
  LogOut,
  Edit3,
  User,
  UserCheck,
  Loader2,
} from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { AttendanceListItem, AttendanceStatus } from '../attendanceTypes';

interface AttendanceRowProps {
  item: AttendanceListItem;
  onMarkStatus: (childId: string, status: AttendanceStatus) => Promise<void>;
  isUpdating: boolean;
  canUpdate: boolean;
  onOpenPickup?: (child: AttendanceListItem) => void;
  onOpenCorrection?: (child: AttendanceListItem) => void;
}

export const AttendanceRow: React.FC<AttendanceRowProps> = ({
  item,
  onMarkStatus,
  isUpdating,
  canUpdate,
  onOpenPickup,
  onOpenCorrection,
}) => {
  const { t, locale } = useI18n();

  const formatTime = (timeIso: string | null) => {
    if (!timeIso) return null;
    try {
      const date = new Date(timeIso);
      return new Intl.DateTimeFormat(locale, {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
      }).format(date);
    } catch {
      return null;
    }
  };

  const getStatusBadge = (status: AttendanceStatus) => {
    switch (status) {
      case 'PRESENT':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" aria-hidden="true" />
            <span>{t.attendance.statusPresent}</span>
          </span>
        );
      case 'ABSENT_EXCUSED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200">
            <Clock className="w-3.5 h-3.5 text-amber-600" aria-hidden="true" />
            <span>{t.attendance.statusAbsentExcused}</span>
          </span>
        );
      case 'ABSENT_UNEXCUSED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-rose-50 text-rose-800 border border-rose-200">
            <XCircle className="w-3.5 h-3.5 text-rose-600" aria-hidden="true" />
            <span>{t.attendance.statusAbsentUnexcused}</span>
          </span>
        );
      case 'CHECKED_OUT':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-indigo-50 text-indigo-800 border border-indigo-200">
            <LogOut className="w-3.5 h-3.5 text-indigo-600" aria-hidden="true" />
            <span>{t.attendance.statusCheckedOut}</span>
          </span>
        );
      case 'CORRECTED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-purple-50 text-purple-800 border border-purple-200">
            <Edit3 className="w-3.5 h-3.5 text-purple-600" aria-hidden="true" />
            <span>{t.attendance.statusCorrected}</span>
          </span>
        );
      case 'UNRECORDED':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200">
            <HelpCircle className="w-3.5 h-3.5 text-slate-500" aria-hidden="true" />
            <span>{t.attendance.statusUnrecorded}</span>
          </span>
        );
    }
  };

  const formattedCheckIn = formatTime(item.check_in_time);
  const formattedCheckOut = formatTime(item.check_out_time);

  // Disable actions if child already checked out (requires pickup/correction workflow) or user lacks permission
  const isCheckedOut = item.status === 'CHECKED_OUT';
  const actionsDisabled = isUpdating || !canUpdate || isCheckedOut;

  return (
    <div
      className="p-4 sm:p-5 bg-white border border-slate-200 rounded-xl shadow-xs transition-colors hover:border-slate-300 flex flex-col md:flex-row md:items-center justify-between gap-4"
      role="row"
    >
      {/* Child Information & Status */}
      <div className="flex items-center gap-3.5 min-w-0">
        <div
          className="w-11 h-11 rounded-full bg-teal-50 text-teal-800 border border-teal-200 flex items-center justify-center shrink-0 font-medium text-sm"
          aria-hidden="true"
        >
          <User className="w-5 h-5 text-teal-700" />
        </div>

        <div className="min-w-0">
          <div className="flex items-center gap-2.5 flex-wrap">
            <h3 className="text-base font-semibold text-slate-900 truncate">
              {item.child_name}
            </h3>
            {getStatusBadge(item.status)}
          </div>

          {/* Time metadata */}
          <div className="flex items-center gap-3 mt-1 text-xs text-slate-500 flex-wrap">
            {formattedCheckIn && (
              <span className="flex items-center gap-1">
                <span>{t.attendance.checkInTimeLabel}:</span>
                <span className="font-medium text-slate-700" dir="ltr">
                  {formattedCheckIn}
                </span>
              </span>
            )}
            {formattedCheckOut && (
              <span className="flex items-center gap-1">
                <span>{t.attendance.checkOutTimeLabel}:</span>
                <span className="font-medium text-slate-700" dir="ltr">
                  {formattedCheckOut}
                </span>
                {item.picked_up_by_name && (
                  <span className="text-slate-600 truncate max-w-[160px]">
                    ({item.picked_up_by_name})
                  </span>
                )}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Quick Status Actions & Secure Pickup */}
      <div className="flex items-center gap-2.5 shrink-0 self-end md:self-auto flex-wrap">
        {/* Secure Pickup Action (Only for PRESENT children) */}
        {item.status === 'PRESENT' && canUpdate && onOpenPickup && (
          <button
            type="button"
            onClick={() => onOpenPickup(item)}
            disabled={isUpdating}
            aria-label={`${t.pickup.actionPickup} - ${item.child_name}`}
            className="min-h-[44px] px-3.5 py-1.5 rounded-lg text-xs font-bold text-teal-800 bg-teal-50 border border-teal-300 hover:bg-teal-100 hover:border-teal-400 focus:outline-hidden focus:ring-2 focus:ring-teal-700 transition-colors flex items-center gap-1.5 shadow-2xs disabled:opacity-50"
          >
            <UserCheck className="w-4 h-4 text-teal-700" aria-hidden="true" />
            <span>{t.pickup.actionPickup}</span>
          </button>
        )}

        {/* Correction Action (Only for recorded children) */}
        {!item.id.startsWith('unrecorded-') && canUpdate && onOpenCorrection && (
          <button
            type="button"
            onClick={() => onOpenCorrection(item)}
            disabled={isUpdating}
            aria-label={`${t.corrections.actionCorrection} - ${item.child_name}`}
            className="min-h-[44px] px-3 py-1.5 rounded-lg text-xs font-bold text-purple-800 bg-purple-50 border border-purple-200 hover:bg-purple-100 hover:border-purple-300 focus:outline-hidden focus:ring-2 focus:ring-purple-700 transition-colors flex items-center gap-1.5 shadow-2xs disabled:opacity-50"
          >
            <Edit3 className="w-4 h-4 text-purple-700" aria-hidden="true" />
            <span>{t.corrections.actionCorrection}</span>
          </button>
        )}

        {isUpdating ? (
          <div className="flex items-center gap-2 px-3 py-2 text-xs text-slate-500 font-medium">
            <Loader2 className="w-4 h-4 animate-spin text-teal-700" />
            <span>{t.common.loading}</span>
          </div>
        ) : (
          <div className="inline-flex rounded-lg bg-slate-100 p-1 border border-slate-200">
            {/* Present Button */}
            <button
              type="button"
              onClick={() => onMarkStatus(item.child_id, 'PRESENT')}
              disabled={actionsDisabled || item.status === 'PRESENT'}
              aria-label={`${t.attendance.markPresent} - ${item.child_name}`}
              className={`min-h-[38px] px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 focus:outline-hidden focus:ring-2 focus:ring-teal-700 ${
                item.status === 'PRESENT'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-white disabled:opacity-50 disabled:hover:bg-transparent'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t.attendance.presentCount}</span>
            </button>

            {/* Excused Absence Button */}
            <button
              type="button"
              onClick={() => onMarkStatus(item.child_id, 'ABSENT_EXCUSED')}
              disabled={actionsDisabled || item.status === 'ABSENT_EXCUSED'}
              aria-label={`${t.attendance.markAbsentExcused} - ${item.child_name}`}
              className={`min-h-[38px] px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 focus:outline-hidden focus:ring-2 focus:ring-teal-700 ${
                item.status === 'ABSENT_EXCUSED'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-white disabled:opacity-50 disabled:hover:bg-transparent'
              }`}
            >
              <Clock className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t.attendance.markAbsentExcused}</span>
            </button>

            {/* Unexcused Absence Button */}
            <button
              type="button"
              onClick={() => onMarkStatus(item.child_id, 'ABSENT_UNEXCUSED')}
              disabled={actionsDisabled || item.status === 'ABSENT_UNEXCUSED'}
              aria-label={`${t.attendance.markAbsentUnexcused} - ${item.child_name}`}
              className={`min-h-[38px] px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 focus:outline-hidden focus:ring-2 focus:ring-teal-700 ${
                item.status === 'ABSENT_UNEXCUSED'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-white disabled:opacity-50 disabled:hover:bg-transparent'
              }`}
            >
              <XCircle className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t.attendance.markAbsentUnexcused}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
