import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import { useAuth } from '../../auth/AuthContext';
import { supabase } from '../../../lib/supabase/client';
import { getActiveClasses } from '../../classes/classesService';
import {
  getDailyClassAttendance,
  recordDailyStatus,
} from '../attendanceService';
import type { AttendanceListItem, AttendanceStatus, Attendance, AttendanceCorrection } from '../attendanceTypes';
import { AttendanceToolbar, type StatusFilterType } from './AttendanceToolbar';
import { AttendanceList } from './AttendanceList';
import { PickupDrawer } from './PickupDrawer';
import { CorrectionDrawer } from './CorrectionDrawer';
import { CheckCircle2, Clock } from 'lucide-react';
import { checkDailyCutoff } from '../services/attendanceReportService';
import { getKindergartenProfile } from '../../kindergarten/kindergartenService';
import type { Kindergarten } from '../../../types/database';

interface SimpleClass {
  id: string;
  name: string;
}

export const AttendanceView: React.FC = () => {
  const { t } = useI18n();
  const { user, activeMembership, activeRole } = useAuth();
  const activeKindergartenId = activeMembership?.kindergarten_id;

  // Selected date in ISO format YYYY-MM-DD (defaults to today)
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });

  // Kindergarten Context & Settings state for dynamic Cutoff & Timezone
  const [kindergarten, setKindergarten] = useState<Kindergarten | null>(null);
  const [kindergartenLoading, setKindergartenLoading] = useState<boolean>(true);
  const [kindergartenError, setKindergartenError] = useState<boolean>(false);

  // Classes state
  const [classes, setClasses] = useState<SimpleClass[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [classesLoading, setClassesLoading] = useState<boolean>(true);

  // Attendance state
  const [attendanceItems, setAttendanceItems] = useState<AttendanceListItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Quick Action in-flight tracking
  const [updatingChildId, setUpdatingChildId] = useState<string | null>(null);

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<StatusFilterType>('ALL');

  // Success Toast notification
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Secure Pickup state
  const [pickupChild, setPickupChild] = useState<AttendanceListItem | null>(null);
  const [isPickupDrawerOpen, setIsPickupDrawerOpen] = useState<boolean>(false);

  // Correction Ledger state
  const [correctionChild, setCorrectionChild] = useState<AttendanceListItem | null>(null);
  const [isCorrectionDrawerOpen, setIsCorrectionDrawerOpen] = useState<boolean>(false);

  const showToast = useCallback((msg: string) => {
    setSuccessToast(msg);
    const timer = setTimeout(() => {
      setSuccessToast(null);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  // 1. Fetch available classes based on current role
  const loadClasses = useCallback(async () => {
    if (!activeKindergartenId || !user) return;

    setClassesLoading(true);
    try {
      if (activeRole === 'ADMIN') {
        const result = await getActiveClasses(activeKindergartenId);
        if (result.data) {
          const mapped = result.data.map((c) => ({ id: c.id, name: c.name }));
          setClasses(mapped);
          if (mapped.length > 0 && !selectedClassId) {
            setSelectedClassId(mapped[0].id);
          }
        }
      } else if (activeRole === 'TEACHER') {
        // Fetch classes assigned to this teacher
        const { data: assignments } = await supabase
          .from('teacher_class_assignments')
          .select('class_id')
          .eq('kindergarten_id', activeKindergartenId)
          .eq('teacher_id', user.id);

        const assignedClassIds = (assignments ?? []).map((a) => a.class_id);

        if (assignedClassIds.length > 0) {
          const { data: classRows } = await supabase
            .from('classes')
            .select('id, name')
            .in('id', assignedClassIds)
            .is('deleted_at', null)
            .order('name');

          const mapped = (classRows ?? []).map((c) => ({ id: c.id, name: c.name }));
          setClasses(mapped);
          if (mapped.length > 0 && !selectedClassId) {
            setSelectedClassId(mapped[0].id);
          }
        } else {
          setClasses([]);
          setSelectedClassId('');
        }
      } else {
        // STAFF / other permitted roles
        const result = await getActiveClasses(activeKindergartenId);
        if (result.data) {
          const mapped = result.data.map((c) => ({ id: c.id, name: c.name }));
          setClasses(mapped);
          if (mapped.length > 0 && !selectedClassId) {
            setSelectedClassId(mapped[0].id);
          }
        }
      }
    } catch {
      setErrorMessage(t.attendance.errorLoadingAttendance);
    } finally {
      setClassesLoading(false);
    }
  }, [activeKindergartenId, user, activeRole, selectedClassId, t.attendance.errorLoadingAttendance]);

  useEffect(() => {
    loadClasses();
  }, [loadClasses]);

  // 2. Load attendance records for the selected class and date
  const loadAttendance = useCallback(
    async (isManualRefresh = false) => {
      if (!activeKindergartenId || !selectedClassId || !selectedDate) {
        setAttendanceItems([]);
        setIsLoading(false);
        return;
      }

      if (isManualRefresh) {
        setIsRefreshing(true);
      } else {
        setIsLoading(true);
      }
      setErrorMessage(null);

      try {
        const result = await getDailyClassAttendance(
          activeKindergartenId,
          selectedClassId,
          selectedDate
        );

        if (result.error) {
          setErrorMessage(t.attendance.errorLoadingAttendance);
        } else {
          setAttendanceItems(result.data || []);
        }
      } catch {
        setErrorMessage(t.attendance.errorLoadingAttendance);
      } finally {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    },
    [activeKindergartenId, selectedClassId, selectedDate, t.attendance.errorLoadingAttendance]
  );

  useEffect(() => {
    loadAttendance();
  }, [loadAttendance]);

  // Load kindergarten profile for dynamic Cutoff time and Timezone
  useEffect(() => {
    let isMounted = true;
    async function loadKgProfile() {
      if (!activeKindergartenId) {
        setKindergarten(null);
        setKindergartenLoading(false);
        return;
      }
      setKindergartenLoading(true);
      setKindergartenError(false);
      try {
        const { data, error } = await getKindergartenProfile(activeKindergartenId);
        if (!isMounted) return;
        if (error || !data) {
          setKindergarten(null);
          setKindergartenError(true);
        } else {
          setKindergarten(data);
        }
      } catch {
        if (isMounted) {
          setKindergarten(null);
          setKindergartenError(true);
        }
      } finally {
        if (isMounted) {
          setKindergartenLoading(false);
        }
      }
    }
    loadKgProfile();
    return () => {
      isMounted = false;
    };
  }, [activeKindergartenId]);

  // Gate 6E: Daily Cutoff Controller Guard with dynamic settings and timezone
  const cutoffSettings = useMemo(() => {
    if (!kindergarten) return null;
    const settings = kindergarten.settings as Record<string, unknown> | null;
    const cutoffTime = typeof settings?.daily_cutoff_time === 'string' ? settings.daily_cutoff_time : null;
    return {
      cutoffTimeStr: cutoffTime,
      timezone: kindergarten.timezone || null,
    };
  }, [kindergarten]);

  const cutoffStatus = useMemo(() => {
    // If kindergarten profile is loading or failed to load, do NOT make an arbitrary cutoff decision
    if (kindergartenLoading || kindergartenError || !cutoffSettings) {
      return checkDailyCutoff(selectedDate, { isProfileLoaded: false });
    }
    return checkDailyCutoff(selectedDate, {
      cutoffTimeStr: cutoffSettings.cutoffTimeStr,
      timezone: cutoffSettings.timezone,
      isProfileLoaded: true,
    });
  }, [selectedDate, kindergartenLoading, kindergartenError, cutoffSettings]);

  // 3. Mark child status quick handler
  const handleMarkStatus = async (childId: string, status: AttendanceStatus) => {
    if (!activeKindergartenId || !selectedClassId) return;

    // Daily Cutoff Guard: Block normal recording for past dates / after cutoff
    if (cutoffStatus.isCutoffPassed) {
      showToast(t.attendanceReports.cutoffNoticeAlert);
      return;
    }

    setUpdatingChildId(childId);
    try {
      const result = await recordDailyStatus({
        kindergarten_id: activeKindergartenId,
        class_id: selectedClassId,
        child_id: childId,
        date: selectedDate,
        status,
      });

      if (result.error) {
        showToast(t.attendance.errorRecordingAttendance);
      } else if (result.data) {
        const updatedRow = result.data;
        // Optimistically update the list item in local state
        setAttendanceItems((prev) =>
          prev.map((item) =>
            item.child_id === childId
              ? {
                  ...item,
                  id: updatedRow.id,
                  status: updatedRow.status,
                  check_in_time: updatedRow.check_in_time,
                  check_out_time: updatedRow.check_out_time,
                  recorded_by: updatedRow.recorded_by,
                }
              : item
          )
        );
        showToast(t.attendance.updateSuccessMessage);
      }
    } catch {
      showToast(t.attendance.errorRecordingAttendance);
    } finally {
      setUpdatingChildId(null);
    }
  };

  // 4. Calculate summary metrics
  const metrics = useMemo(() => {
    let present = 0;
    let absent = 0;
    let checkedOut = 0;
    let unrecorded = 0;

    for (const item of attendanceItems) {
      if (item.status === 'PRESENT') {
        present++;
      } else if (item.status === 'ABSENT_EXCUSED' || item.status === 'ABSENT_UNEXCUSED') {
        absent++;
      } else if (item.status === 'CHECKED_OUT') {
        checkedOut++;
      } else {
        unrecorded++;
      }
    }

    return {
      total: attendanceItems.length,
      present,
      absent,
      checkedOut,
      unrecorded,
    };
  }, [attendanceItems]);

  // 5. Filter & Search items
  const filteredItems = useMemo(() => {
    let list = attendanceItems;

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      list = list.filter((item) => item.child_name.toLowerCase().includes(q));
    }

    // Filter by status
    if (statusFilter !== 'ALL') {
      list = list.filter((item) => item.status === statusFilter);
    }

    return list;
  }, [attendanceItems, searchQuery, statusFilter]);

  const hasActiveFilters = searchQuery.trim().length > 0 || statusFilter !== 'ALL';

  const handleClearFilters = () => {
    setSearchQuery('');
    setStatusFilter('ALL');
  };

  // Permission: STAFF cannot update existing rows or perform pickup
  const canUserUpdate = activeRole === 'ADMIN' || activeRole === 'TEACHER';

  // Secure Pickup handlers
  const handleOpenPickup = (child: AttendanceListItem) => {
    // Only allow pickup for PRESENT children with legitimate database records
    if (child.status !== 'PRESENT' || child.id.startsWith('unrecorded-') || !canUserUpdate) {
      return;
    }
    setPickupChild(child);
    setIsPickupDrawerOpen(true);
  };

  const handleClosePickup = () => {
    setIsPickupDrawerOpen(false);
    setPickupChild(null);
  };

  const handlePickupSuccess = (updatedRow: Attendance) => {
    // Pessimistic server-confirmed update to CHECKED_OUT
    setAttendanceItems((prev) =>
      prev.map((item) =>
        item.id === updatedRow.id || item.child_id === updatedRow.child_id
          ? {
              ...item,
              id: updatedRow.id,
              status: updatedRow.status,
              check_in_time: updatedRow.check_in_time,
              check_out_time: updatedRow.check_out_time,
              picked_up_by_name: updatedRow.picked_up_by_name,
              notes: updatedRow.notes,
            }
          : item
      )
    );
    showToast(t.pickup.pickupSuccess);
  };

  // Correction Ledger handlers
  const handleOpenCorrection = (child: AttendanceListItem) => {
    // Only allow correction for children with legitimate database records (not unrecorded) and permitted users
    if (child.id.startsWith('unrecorded-') || !canUserUpdate) {
      return;
    }
    setCorrectionChild(child);
    setIsCorrectionDrawerOpen(true);
  };

  const handleCloseCorrection = () => {
    setIsCorrectionDrawerOpen(false);
    setCorrectionChild(null);
  };

  const handleCorrectionSuccess = (updatedRow: Attendance, _correction: AttendanceCorrection) => {
    // Pessimistic server-confirmed update to new_status
    setAttendanceItems((prev) =>
      prev.map((item) =>
        item.id === updatedRow.id || item.child_id === updatedRow.child_id
          ? {
              ...item,
              id: updatedRow.id,
              status: updatedRow.status,
              check_in_time: updatedRow.check_in_time,
              check_out_time: updatedRow.check_out_time,
              picked_up_by_name: updatedRow.picked_up_by_name,
              notes: updatedRow.notes,
              has_corrections: true,
            }
          : item
      )
    );
    showToast(t.corrections.correctionSuccess);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            {t.attendance.title}
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            {t.attendance.subtitle}
          </p>
        </div>
      </div>

      {/* Success Toast */}
      {successToast && (
        <div
          role="status"
          className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl flex items-center gap-3 animate-in fade-in duration-200 shadow-xs"
        >
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" aria-hidden="true" />
          <p className="text-sm font-medium">{successToast}</p>
        </div>
      )}

      {/* Toolbar */}
      <AttendanceToolbar
        selectedDate={selectedDate}
        onDateChange={setSelectedDate}
        classes={classes}
        selectedClassId={selectedClassId}
        onClassChange={setSelectedClassId}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        statusFilter={statusFilter}
        onStatusFilterChange={setStatusFilter}
        metrics={metrics}
        onRefresh={() => loadAttendance(true)}
        isRefreshing={isRefreshing}
      />

      {/* Gate 6E: Daily Cutoff Notification Banner */}
      {cutoffStatus.isCutoffPassed && (
        <div
          role="alert"
          className="p-4 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl flex items-start gap-3 shadow-2xs"
        >
          <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <p className="text-sm font-semibold">{t.attendanceReports.cutoffNotice}</p>
            <p className="text-xs text-amber-700 mt-0.5">{t.attendanceReports.cutoffNoticeDesc}</p>
          </div>
        </div>
      )}

      {/* Attendance List */}
      <AttendanceList
        items={filteredItems}
        isLoading={isLoading || classesLoading}
        errorMessage={errorMessage}
        onRetry={() => loadAttendance(false)}
        onMarkStatus={handleMarkStatus}
        updatingChildId={updatingChildId}
        canUpdate={canUserUpdate}
        searchQuery={searchQuery}
        hasActiveFilters={hasActiveFilters}
        onClearFilters={handleClearFilters}
        onOpenPickup={handleOpenPickup}
        onOpenCorrection={handleOpenCorrection}
      />

      {/* Secure Pickup Drawer */}
      {activeKindergartenId && (
        <PickupDrawer
          isOpen={isPickupDrawerOpen}
          onClose={handleClosePickup}
          child={pickupChild}
          kindergartenId={activeKindergartenId}
          currentRole={activeRole || null}
          onPickupSuccess={handlePickupSuccess}
        />
      )}

      {/* Attendance Correction Drawer */}
      {activeKindergartenId && (
        <CorrectionDrawer
          isOpen={isCorrectionDrawerOpen}
          onClose={handleCloseCorrection}
          child={correctionChild}
          kindergartenId={activeKindergartenId}
          onCorrectionSuccess={handleCorrectionSuccess}
        />
      )}
    </div>
  );
};
