import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Edit3,
  AlertCircle,
  Loader2,
  Clock,
  History,
  CheckCircle2,
  ArrowRight,
  Shield,
} from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import {
  getAttendanceCorrections,
  recordCorrection,
} from '../attendanceService';
import type {
  AttendanceListItem,
  AttendanceCorrection,
  Attendance,
  AttendanceStatus,
  AttendanceErrorCode,
} from '../attendanceTypes';

interface CorrectionDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  child: AttendanceListItem | null;
  kindergartenId: string;
  onCorrectionSuccess: (updatedRow: Attendance, correction: AttendanceCorrection) => void;
}

export const CorrectionDrawer: React.FC<CorrectionDrawerProps> = ({
  isOpen,
  onClose,
  child,
  kindergartenId,
  onCorrectionSuccess,
}) => {
  const { t, locale, dir } = useI18n();

  // Form State
  const [newStatus, setNewStatus] = useState<AttendanceStatus | ''>('');
  const [reason, setReason] = useState<string>('');

  // History State
  const [history, setHistory] = useState<AttendanceCorrection[]>([]);
  const [loadingHistory, setLoadingHistory] = useState<boolean>(false);

  // Submission State
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Focus trap & restoration refs
  const drawerRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);

  // Available valid target statuses (UNRECORDED is strictly forbidden)
  const allowedStatuses: AttendanceStatus[] = [
    'PRESENT',
    'ABSENT_EXCUSED',
    'ABSENT_UNEXCUSED',
    'CHECKED_OUT',
  ];

  // Map status to localized name
  const getStatusLabel = (status: AttendanceStatus | string) => {
    switch (status) {
      case 'PRESENT':
        return t.attendance.statusPresent;
      case 'ABSENT_EXCUSED':
        return t.attendance.statusAbsentExcused;
      case 'ABSENT_UNEXCUSED':
        return t.attendance.statusAbsentUnexcused;
      case 'CHECKED_OUT':
        return t.attendance.statusCheckedOut;
      case 'CORRECTED':
        return t.attendance.statusCorrected;
      case 'UNRECORDED':
        return t.attendance.statusUnrecorded;
      default:
        return status;
    }
  };

  const formatTimestamp = (timeIso: string) => {
    try {
      const date = new Date(timeIso);
      return new Intl.DateTimeFormat(locale, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
      }).format(date);
    } catch {
      return timeIso;
    }
  };

  // Capture active element for focus restoration upon open
  useEffect(() => {
    if (isOpen) {
      previousFocusRef.current = document.activeElement as HTMLElement | null;
    }
  }, [isOpen]);

  // Reset form and fetch historical corrections when opening
  useEffect(() => {
    if (!isOpen || !child || !kindergartenId || child.id.startsWith('unrecorded-')) {
      setNewStatus('');
      setReason('');
      setHistory([]);
      setErrorMessage(null);
      return;
    }

    setNewStatus('');
    setReason('');
    setErrorMessage(null);
    setLoadingHistory(true);

    let isMounted = true;
    getAttendanceCorrections(child.id)
      .then((res) => {
        if (!isMounted) return;
        if (res.data) {
          setHistory(res.data);
        }
      })
      .catch(() => {
        if (isMounted) {
          setErrorMessage(t.corrections.SERVICE_NETWORK_ERROR);
        }
      })
      .finally(() => {
        if (isMounted) {
          setLoadingHistory(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, child, kindergartenId, t.corrections.SERVICE_NETWORK_ERROR]);

  // Focus trap, Escape listener, and Focus restoration
  useEffect(() => {
    if (!isOpen) return;

    // Focus close button initially
    const timer = setTimeout(() => {
      closeButtonRef.current?.focus();
    }, 50);

    const handleKeyDown = (e: KeyboardEvent) => {
      // 1. Escape key handling
      if (e.key === 'Escape' && !isSubmitting) {
        e.preventDefault();
        onClose();
        return;
      }

      // 2. Strict Focus Trap: keep Tab navigation inside drawer
      if (e.key === 'Tab' && drawerRef.current) {
        const focusableElements = drawerRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );

        if (focusableElements.length === 0) return;

        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        if (e.shiftKey) {
          // Shift + Tab
          if (document.activeElement === firstElement) {
            e.preventDefault();
            lastElement.focus();
          }
        } else {
          // Tab
          if (document.activeElement === lastElement) {
            e.preventDefault();
            firstElement.focus();
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('keydown', handleKeyDown);
      // Restore focus to original trigger element on unmount/close
      if (previousFocusRef.current && typeof previousFocusRef.current.focus === 'function') {
        previousFocusRef.current.focus();
      }
    };
  }, [isOpen, isSubmitting, onClose]);

  if (!isOpen || !child) return null;

  const trimmedReason = reason.trim();
  const isReasonValid = trimmedReason.length >= 10 && trimmedReason.length <= 1000;
  const isStatusValid = Boolean(newStatus) && newStatus !== child.status && newStatus !== 'UNRECORDED';
  const canSubmit = isReasonValid && isStatusValid && !isSubmitting;

  const getErrorMessage = (code?: AttendanceErrorCode, fallback?: string) => {
    if (!code) return fallback || t.corrections.correctionError;
    const localized = t.corrections[code as keyof typeof t.corrections];
    return typeof localized === 'string' ? localized : fallback || t.corrections.correctionError;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit || isSubmitting) return;

    if (child.id.startsWith('unrecorded-')) {
      setErrorMessage(t.corrections.unrecordedError);
      return;
    }

    if (newStatus === child.status) {
      setErrorMessage(t.corrections.sameStatusError);
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const res = await recordCorrection({
        attendance_id: child.id,
        kindergarten_id: kindergartenId,
        child_id: child.child_id,
        new_status: newStatus as AttendanceStatus,
        reason: trimmedReason,
        source: 'TEACHER_WEB_MANUAL',
      });

      if (res.error || !res.data) {
        setErrorMessage(getErrorMessage(res.errorCode, res.error?.message));
      } else {
        onCorrectionSuccess(res.data.attendance, res.data.correction);
        onClose();
      }
    } catch {
      setErrorMessage(t.corrections.SERVICE_NETWORK_ERROR);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden"
      role="dialog"
      aria-modal="true"
      aria-labelledby="correction-drawer-title"
      aria-describedby="correction-drawer-subtitle"
    >
      {/* Backdrop overlay */}
      <div
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity"
        onClick={() => !isSubmitting && onClose()}
        aria-hidden="true"
      />

      <div className="fixed inset-y-0 end-0 max-w-full flex ps-0">
        <div
          ref={drawerRef}
          className="w-screen max-w-lg bg-white shadow-2xl flex flex-col focus:outline-hidden"
        >
          {/* Drawer Header */}
          <div className="px-6 py-5 border-b border-slate-200 bg-slate-50/70 flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-purple-100 text-purple-800">
                  <Edit3 className="w-5 h-5 text-purple-700" aria-hidden="true" />
                </span>
                <h2
                  id="correction-drawer-title"
                  className="text-lg font-bold text-slate-900 tracking-tight"
                >
                  {t.corrections.title}
                </h2>
              </div>
              <p id="correction-drawer-subtitle" className="text-xs text-slate-500 mt-1">
                {t.corrections.description}
              </p>
              <div className="mt-2.5 inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-purple-50 border border-purple-200 text-purple-900 text-xs font-semibold">
                <span>{child.child_name}</span>
                {child.class_name && (
                  <span className="text-purple-600 font-normal">({child.class_name})</span>
                )}
              </div>
            </div>

            <button
              ref={closeButtonRef}
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              aria-label={t.corrections.closeDrawerAria}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 focus:outline-hidden focus:ring-2 focus:ring-purple-700 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center disabled:opacity-50"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>

          {/* Security Notice */}
          <div className="px-6 py-3 bg-purple-50/50 border-b border-purple-100 flex items-center gap-2 text-xs text-purple-900">
            <Shield className="w-4 h-4 text-purple-700 shrink-0" aria-hidden="true" />
            <span>{t.corrections.immutableNotice}</span>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div
              role="alert"
              className="m-6 mb-0 p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl flex items-start gap-2.5 text-xs animate-in fade-in duration-150"
            >
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" aria-hidden="true" />
              <div className="flex-1 font-medium leading-relaxed">{errorMessage}</div>
            </div>
          )}

          {/* Drawer Body Form */}
          <form onSubmit={handleSubmit} className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Status Section */}
              <div className="space-y-4 p-4 rounded-xl border border-slate-200 bg-slate-50/60">
                {/* Current Status Display */}
                <div className="space-y-1">
                  <span className="block text-xs font-semibold text-slate-500">
                    {t.corrections.currentStatusLabel}
                  </span>
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-slate-800 font-bold text-xs">
                    <span>{getStatusLabel(child.status)}</span>
                  </div>
                </div>

                {/* New Status Selection */}
                <div className="space-y-1.5">
                  <label
                    htmlFor="correction-new-status"
                    className="block text-xs font-bold text-slate-700"
                  >
                    {t.corrections.newStatusLabel}{' '}
                    <span className="text-rose-600 font-bold">*</span>
                  </label>
                  <select
                    id="correction-new-status"
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as AttendanceStatus)}
                    disabled={isSubmitting}
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-purple-700 transition-colors min-h-[44px]"
                  >
                    <option value="" disabled>
                      {t.corrections.selectStatusPlaceholder}
                    </option>
                    {allowedStatuses.map((st) => (
                      <option key={st} value={st} disabled={st === child.status}>
                        {getStatusLabel(st)} {st === child.status ? `(${t.corrections.currentStatusLabel})` : ''}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Justification Reason Section */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label
                    htmlFor="correction-reason"
                    className="block text-xs font-bold text-slate-700"
                  >
                    {t.corrections.reasonLabel}{' '}
                    <span className="text-rose-600 font-bold">*</span>
                  </label>
                  <span
                    className={`text-[11px] font-medium ${
                      trimmedReason.length < 10
                        ? 'text-amber-700'
                        : 'text-emerald-700'
                    }`}
                  >
                    {trimmedReason.length}/10 {t.corrections.characterCount}
                  </span>
                </div>
                <textarea
                  id="correction-reason"
                  rows={4}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  maxLength={1000}
                  disabled={isSubmitting}
                  placeholder={t.corrections.reasonPlaceholder}
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-purple-700 transition-colors"
                />
                <p className="text-[11px] text-slate-500">
                  {t.corrections.reasonMinCharsHint}
                </p>
              </div>

              {/* Immutable Historical Corrections Ledger */}
              <div className="space-y-3 pt-2 border-t border-slate-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                    <History className="w-4 h-4 text-purple-700" aria-hidden="true" />
                    <span>{t.corrections.historyTitle}</span>
                  </div>
                  {history.length > 0 && (
                    <span className="text-xs text-slate-400">({history.length})</span>
                  )}
                </div>

                {loadingHistory ? (
                  <div className="py-6 flex flex-col items-center justify-center gap-2 text-slate-500 text-xs">
                    <Loader2 className="w-5 h-5 animate-spin text-purple-700" />
                    <span>{t.corrections.historyLoading}</span>
                  </div>
                ) : history.length === 0 ? (
                  <div className="p-4 text-center bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-500">
                    {t.corrections.noHistory}
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-60 overflow-y-auto pe-1">
                    {history.map((record) => (
                      <div
                        key={record.id}
                        className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <div className="inline-flex items-center gap-1.5 font-bold">
                            <span className="px-2 py-0.5 rounded bg-slate-200 text-slate-700">
                              {getStatusLabel(record.previous_status)}
                            </span>
                            <ArrowRight
                              className={`w-3.5 h-3.5 text-slate-400 ${dir === 'rtl' ? 'rotate-180' : ''}`}
                              aria-hidden="true"
                            />
                            <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800">
                              {getStatusLabel(record.new_status)}
                            </span>
                          </div>

                          <div className="flex items-center gap-1 text-[11px] text-slate-500" dir="ltr">
                            <Clock className="w-3 h-3 text-slate-400" aria-hidden="true" />
                            <span>{formatTimestamp(record.created_at)}</span>
                          </div>
                        </div>

                        <p className="text-slate-700 leading-relaxed bg-white p-2 rounded-lg border border-slate-200/80">
                          {record.reason}
                        </p>

                        <div className="flex items-center justify-between text-[11px] text-slate-400">
                          <span>{t.corrections.sourceLabel}: {record.source}</span>
                          <span className="font-mono text-[10px]">ID: {record.id.slice(0, 8)}...</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Drawer Footer Actions */}
            <div className="p-6 border-t border-slate-200 bg-slate-50/70 flex items-center justify-end gap-3 shrink-0">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2.5 border border-slate-200 bg-white text-slate-700 rounded-lg text-xs font-bold hover:bg-slate-50 focus:outline-hidden focus:ring-2 focus:ring-slate-400 transition-colors min-h-[44px]"
              >
                {t.corrections.cancel}
              </button>

              <button
                type="submit"
                disabled={!canSubmit || isSubmitting}
                className="px-5 py-2.5 rounded-lg text-xs font-bold text-white bg-purple-700 hover:bg-purple-800 focus:outline-hidden focus:ring-2 focus:ring-purple-700 focus:ring-offset-2 transition-colors flex items-center gap-2 min-h-[44px] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" aria-hidden="true" />
                    <span>{t.corrections.submittingCorrection}</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-white" aria-hidden="true" />
                    <span>{t.corrections.submitCorrection}</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
