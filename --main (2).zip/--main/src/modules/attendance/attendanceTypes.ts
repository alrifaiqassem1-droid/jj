import type {
  AttendanceStatus,
  Attendance,
  AttendanceCorrection,
  RelationshipType,
} from '../../types/database';

export type { AttendanceStatus, Attendance, AttendanceCorrection, RelationshipType };

/**
 * Domain-specific error codes for attendance operations.
 */
export type AttendanceErrorCode =
  | 'ATTENDANCE_NOT_FOUND'
  | 'ATTENDANCE_ALREADY_EXISTS'
  | 'CHILD_NOT_FOUND'
  | 'CLASS_NOT_FOUND'
  | 'INVALID_STATUS'
  | 'INVALID_DATE'
  | 'UNAUTHORIZED_PICKUP_PERSON'
  | 'PICKUP_RELATIONSHIP_NOT_FOUND'
  | 'CUSTODY_NOT_VERIFIED'
  | 'PICKUP_NOT_AUTHORIZED'
  | 'RELATIONSHIP_ARCHIVED'
  | 'CROSS_CHILD_RELATIONSHIP'
  | 'ADMIN_ONLY_EXCEPTION'
  | 'ADMIN_EXCEPTION_REASON_TOO_SHORT'
  | 'CORRECTION_REASON_TOO_SHORT'
  | 'CORRECTION_STATUS_UNCHANGED'
  | 'CORRECTION_IMMUTABLE'
  | 'NOT_AUTHORIZED'
  | 'VALIDATION_FAILED'
  | 'STAFF_UPDATE_FORBIDDEN'
  | 'SERVICE_NETWORK_ERROR';

/**
 * Standard service result envelope.
 */
export interface ServiceResult<T> {
  data: T | null;
  error: Error | null;
  errorCode?: AttendanceErrorCode;
}

/**
 * Input for recording or initially marking daily attendance.
 */
export interface RecordDailyAttendanceInput {
  kindergarten_id: string;
  class_id: string;
  child_id: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  notes?: string;
  check_in_time?: string;
}

/**
 * Input for normal secure pickup via an authorized and verified parent/guardian relationship.
 */
export interface AuthorizedRelationshipPickupInput {
  pickup_type: 'AUTHORIZED_RELATIONSHIP';
  attendance_id: string;
  child_id: string;
  kindergarten_id: string;
  relationship_id: string; // ID from parent_child_relationships
}

/**
 * Input for administrative pickup exception (strictly restricted to kindergarten ADMIN).
 */
export interface AdminPickupExceptionInput {
  pickup_type: 'ADMIN_EXCEPTION';
  attendance_id: string;
  child_id: string;
  kindergarten_id: string;
  recipient_name: string;
  recipient_id_number?: string;
  reason: string; // Minimum 10 characters required
}

/**
 * Union type for pickup recording.
 */
export type RecordPickupInput = AuthorizedRelationshipPickupInput | AdminPickupExceptionInput;

/**
 * Input for correcting an already recorded attendance entry.
 */
export interface AttendanceCorrectionInput {
  attendance_id: string;
  kindergarten_id: string;
  child_id: string;
  new_status: AttendanceStatus;
  reason: string; // Minimum 10 characters required by DB constraint
  source?: string; // Default: 'TEACHER_WEB_MANUAL'
  request_session_id?: string;
}

/**
 * Details of an authorized pickup person linked to a child.
 */
export interface AuthorizedPickupPerson {
  relationship_id: string;
  parent_id: string;
  parent_name: string;
  parent_phone: string | null;
  relationship: RelationshipType;
  is_primary_contact: boolean;
  authorized_for_pickup: boolean;
  verified_at: string;
}

/**
 * Enriched attendance item for class listing and UI operations.
 */
export interface AttendanceListItem {
  id: string;
  child_id: string;
  child_name: string;
  class_id: string;
  class_name?: string;
  date: string;
  status: AttendanceStatus;
  check_in_time: string | null;
  check_out_time: string | null;
  picked_up_by_name: string | null;
  recorded_by: string;
  recorded_by_name?: string;
  notes: string | null;
  has_corrections?: boolean;
}
