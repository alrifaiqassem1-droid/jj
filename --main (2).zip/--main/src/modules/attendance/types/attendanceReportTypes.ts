/**
 * Gate 6E: Attendance Reporting, Analytics & Cutoff Types
 * Strictly defines Child-Day metrics, aggregations, filters, and export structures.
 */

export type ChildDayStatus =
  | 'PRESENT'
  | 'CHECKED_OUT'
  | 'ABSENT_EXCUSED'
  | 'ABSENT_UNEXCUSED'
  | 'UNRECORDED';

export interface AttendanceSummaryMetrics {
  /** Count of PRESENT Child-Days */
  presentChildDays: number;
  /** Count of CHECKED_OUT Child-Days (attended then departed) */
  checkedOutChildDays: number;
  /** Count of ABSENT_EXCUSED Child-Days */
  absentExcusedChildDays: number;
  /** Count of ABSENT_UNEXCUSED Child-Days */
  absentUnexcusedChildDays: number;
  /** Count of UNRECORDED Child-Days (excluded from rate denominator) */
  unrecordedChildDays: number;
  /**
   * Total recorded Child-Days =
   * PRESENT + CHECKED_OUT + ABSENT_EXCUSED + ABSENT_UNEXCUSED
   */
  totalRecordedChildDays: number;
  /**
   * Total expected Child-Days =
   * totalRecordedChildDays + unrecordedChildDays
   */
  totalExpectedChildDays: number;
  /**
   * Attendance Rate = (PRESENT + CHECKED_OUT) / (PRESENT + CHECKED_OUT + ABSENT_EXCUSED + ABSENT_UNEXCUSED)
   * If denominator is 0, returns null (represented in UI as N/A)
   */
  attendanceRate: number | null;
  /**
   * Recording Coverage Rate = (totalRecordedChildDays / totalExpectedChildDays) * 100
   * If totalExpectedChildDays is 0, returns null (N/A)
   */
  coverageRate: number | null;
}

export interface DailyAttendanceBreakdown {
  date: string; // YYYY-MM-DD
  metrics: AttendanceSummaryMetrics;
}

export interface ClassAttendanceBreakdown {
  classId: string;
  className: string;
  metrics: AttendanceSummaryMetrics;
}

export interface AttendanceReportFilter {
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  classId?: string; // specific class id or 'ALL'
}

export interface AttendanceReportData {
  filter: AttendanceReportFilter;
  overview: AttendanceSummaryMetrics;
  byDay: DailyAttendanceBreakdown[];
  byClass: ClassAttendanceBreakdown[];
  permittedClassIds: string[];
}

export interface AttendanceDetailRow {
  date: string;
  classId: string;
  className: string;
  childId: string;
  childName: string;
  status: ChildDayStatus;
  checkInTime: string | null;
  checkOutTime: string | null;
  hasCorrections: boolean;
}

export interface CutoffCheckResult {
  isCutoffPassed: boolean;
  reason: 'PAST_DATE' | 'TIME_PASSED' | 'NOT_PASSED' | 'FUTURE_DATE';
  cutoffTime: string; // HH:mm
}
