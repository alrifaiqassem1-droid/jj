import { z } from 'zod';

export const storageObjectKeySchema = z
  .string()
  .min(1, 'مسار الملف لا يمكن أن يكون فارغاً')
  .regex(
    /^[0-9a-fA-F-]{36}\/[a-zA-Z0-9_\-./]+$/,
    'مسار الملف يجب أن يبدأ بمعرف الروضة المعتمد UUID'
  );

export const createSignedMediaUrlSchema = z.object({
  mediaId: z.string().uuid('معرف الوسائط غير صالح'),
  accessReason: z
    .string()
    .min(5, 'سبب الوصول للملف يجب أن يتكون من 5 أحرف على الأقل')
    .max(255, 'سبب الوصول لا يمكن أن يتجاوز 255 حرفاً')
    .default('Authorized media inspection'),
  expiresInSeconds: z
    .number()
    .int()
    .min(60, 'مدة صلاحية الرابط لا تقل عن 60 ثانية')
    .max(14400, 'مدة صلاحية الرابط لا تزيد عن 4 ساعات (14400 ثانية)')
    .default(3600),
});

export type CreateSignedMediaUrlInput = z.infer<typeof createSignedMediaUrlSchema>;

export const uploadMediaMetadataSchema = z.object({
  kindergartenId: z.string().uuid('معرف الروضة غير صالح'),
  storagePath: storageObjectKeySchema,
  mimeType: z.enum([
    'image/jpeg',
    'image/png',
    'image/webp',
    'image/heic',
    'video/mp4',
    'application/pdf',
  ]),
  fileSizeBytes: z.number().int().positive('حجم الملف يجب أن يكون أكبر من صفر').max(52428800, 'الحد الأقصى لحجم الملف هو 50 ميغابايت'),
  sha256Checksum: z.string().length(64, 'تجزئة SHA256 يجب أن تتكون من 64 حرفاً'),
  childIds: z.array(z.string().uuid()).optional().default([]),
});

export type UploadMediaMetadataInput = z.infer<typeof uploadMediaMetadataSchema>;
