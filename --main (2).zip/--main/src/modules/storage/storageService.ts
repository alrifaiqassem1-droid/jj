import { supabase } from '../../lib/supabase/client';
import type { MediaVault, MediaChildTag } from '../../types/database';
import {
  createSignedMediaUrlSchema,
  uploadMediaMetadataSchema,
  type CreateSignedMediaUrlInput,
  type UploadMediaMetadataInput,
} from './storageValidation';

export interface StorageServiceResult<T> {
  data: T | null;
  error: Error | null;
  errorCode?: string;
}

export interface SignedUrlResponse {
  media_id: string;
  storage_path: string;
  signed_url: string;
  expires_in_seconds: number;
  mime_type: string;
  file_size_bytes: number;
}

/**
 * Storage Domain Service (Gate 7B — Storage Security Hardening)
 *
 * Core Security & Architectural Invariants:
 * 1. ZERO PUBLIC ACCESS: Sensitive child media resides in private 'media-vault' bucket.
 * 2. NO SERVICE ROLE IN CLIENT: Uses exclusively the authenticated user's RLS session.
 * 3. NO DIRECT URLS: File downloads and previews occur through audited RPC or Supabase signed URLs.
 * 4. TENANT ISOLATION: Object paths start with `{kindergarten_id}/...`. Cross-school access is blocked.
 * 5. PARENT AUTHORIZATION: Access to photos/videos requires active, verified custody in database.
 * 6. NO PHYSICAL DELETE: Media records are soft-deleted via `deleted_at`.
 * 7. IMMUTABLE AUDIT LOG: URL requests and permission checks create immutable audit trail events.
 */

/**
 * Generates an audited signed URL for a sensitive media asset.
 * Checks caller authorization against tenant, role, and custody rules via PostgreSQL RPC.
 */
export async function getSignedMediaUrl(
  input: CreateSignedMediaUrlInput
): Promise<StorageServiceResult<SignedUrlResponse>> {
  try {
    const validated = createSignedMediaUrlSchema.parse(input);

    const { data, error } = await supabase.rpc('rpc_create_signed_media_url', {
      p_media_id: validated.mediaId,
      p_access_reason: validated.accessReason,
      p_expires_in_seconds: validated.expiresInSeconds,
    });

    if (error) {
      let code = 'SERVICE_ERROR';
      if (error.message.includes('MEDIA_NOT_FOUND')) code = 'MEDIA_NOT_FOUND';
      if (error.message.includes('PERMISSION_DENIED')) code = 'PERMISSION_DENIED';
      if (error.message.includes('AUTHENTICATION_REQUIRED')) code = 'AUTHENTICATION_REQUIRED';

      return {
        data: null,
        error: new Error(error.message),
        errorCode: code,
      };
    }

    interface RpcMediaUrlPayload extends Partial<SignedUrlResponse> {
      success?: boolean;
      error_code?: string;
      message?: string;
      audit_logged?: boolean;
    }

    const payload = data as RpcMediaUrlPayload | null;
    if (!payload || payload.success === false || payload.error_code) {
      const code = payload?.error_code || (!payload ? 'EMPTY_RESPONSE' : 'PERMISSION_DENIED');
      const msg = payload?.message || 'Access denied to media asset';
      return {
        data: null,
        error: new Error(msg),
        errorCode: code,
      };
    }

    if (!payload?.signed_url) {
      return {
        data: null,
        error: new Error('Missing signed URL in RPC response'),
        errorCode: 'INVALID_RPC_RESPONSE',
      };
    }

    return {
      data: data as SignedUrlResponse,
      error: null,
    };
  } catch (err) {
    return {
      data: null,
      error: err instanceof Error ? err : new Error(String(err)),
      errorCode: 'VALIDATION_ERROR',
    };
  }
}

/**
 * Retrieves media metadata for a kindergarten.
 * RLS ensures caller only sees media they are authorized to view.
 */
export async function listMediaVaultItems(
  kindergartenId: string,
  options?: { childId?: string }
): Promise<StorageServiceResult<MediaVault[]>> {
  try {
    let query = supabase
      .from('media_vault')
      .select('*')
      .eq('kindergarten_id', kindergartenId)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    // If filtering by specific child, filter through media_child_tags
    if (options?.childId) {
      const { data: tagData, error: tagError } = await supabase
        .from('media_child_tags')
        .select('media_id')
        .eq('kindergarten_id', kindergartenId)
        .eq('child_id', options.childId);

      if (tagError) {
        return {
          data: null,
          error: new Error(tagError.message),
          errorCode: 'FETCH_TAGS_ERROR',
        };
      }

      const mediaIds = (tagData as { media_id: string }[]).map((t) => t.media_id);
      if (mediaIds.length === 0) {
        return { data: [], error: null };
      }

      query = query.in('id', mediaIds);
    }

    const { data, error } = await query;

    if (error) {
      return {
        data: null,
        error: new Error(error.message),
        errorCode: error.code || 'FETCH_MEDIA_ERROR',
      };
    }

    return {
      data: data as MediaVault[],
      error: null,
    };
  } catch (err) {
    return {
      data: null,
      error: err instanceof Error ? err : new Error(String(err)),
      errorCode: 'SERVICE_ERROR',
    };
  }
}

/**
 * Registers media metadata in media_vault and tags children.
 * RLS restricts execution to authorized ADMIN or TEACHER.
 */
export async function registerMediaMetadata(
  input: UploadMediaMetadataInput
): Promise<StorageServiceResult<{ media: MediaVault; tags: MediaChildTag[] }>> {
  try {
    const validated = uploadMediaMetadataSchema.parse(input);

    // Verify storage path starts with kindergarten_id
    if (!validated.storagePath.startsWith(validated.kindergartenId + '/')) {
      return {
        data: null,
        error: new Error('مسار التخزين يجب أن يبدأ بمعرف الروضة المعتمد للتحقق من العزل الأمني'),
        errorCode: 'TENANT_ISOLATION_VIOLATION',
      };
    }

    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) {
      return {
        data: null,
        error: new Error('المستخدم غير مسجل الدخول'),
        errorCode: 'UNAUTHENTICATED',
      };
    }

    // 1. Insert media_vault record
    const { data: mediaData, error: mediaError } = await supabase
      .from('media_vault')
      .insert({
        kindergarten_id: validated.kindergartenId,
        storage_path: validated.storagePath,
        mime_type: validated.mimeType,
        file_size_bytes: validated.fileSizeBytes,
        sha256_checksum: validated.sha256Checksum,
        uploaded_by: userData.user.id,
      })
      .select()
      .single();

    if (mediaError) {
      return {
        data: null,
        error: new Error(mediaError.message),
        errorCode: mediaError.code || 'INSERT_MEDIA_ERROR',
      };
    }

    const media = mediaData as MediaVault;
    const insertedTags: MediaChildTag[] = [];

    // 2. Tag children if provided
    if (validated.childIds && validated.childIds.length > 0) {
      const tagInserts = validated.childIds.map((cId) => ({
        kindergarten_id: validated.kindergartenId,
        media_id: media.id,
        child_id: cId,
        tagged_by: userData.user.id,
      }));

      const { data: tagData, error: tagError } = await supabase
        .from('media_child_tags')
        .insert(tagInserts)
        .select();

      if (tagError) {
        return {
          data: null,
          error: new Error(tagError.message),
          errorCode: tagError.code || 'INSERT_TAGS_ERROR',
        };
      }

      if (tagData) {
        insertedTags.push(...(tagData as MediaChildTag[]));
      }
    }

    return {
      data: { media, tags: insertedTags },
      error: null,
    };
  } catch (err) {
    return {
      data: null,
      error: err instanceof Error ? err : new Error(String(err)),
      errorCode: 'VALIDATION_ERROR',
    };
  }
}

/**
 * Soft deletes a media item from the vault (Admin only).
 * Physical deletion is strictly prohibited by database RLS.
 */
export async function archiveMediaItem(
  mediaId: string,
  kindergartenId: string
): Promise<StorageServiceResult<void>> {
  try {
    const { error } = await supabase
      .from('media_vault')
      .update({ deleted_at: new Date().toISOString() })
      .eq('id', mediaId)
      .eq('kindergarten_id', kindergartenId);

    if (error) {
      return {
        data: null,
        error: new Error(error.message),
        errorCode: error.code || 'ARCHIVE_MEDIA_ERROR',
      };
    }

    return { data: undefined, error: null };
  } catch (err) {
    return {
      data: null,
      error: err instanceof Error ? err : new Error(String(err)),
      errorCode: 'SERVICE_ERROR',
    };
  }
}
