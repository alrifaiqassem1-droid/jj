import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Heart, Volume2, ShieldCheck, ChevronRight, ChevronLeft, Sparkles } from 'lucide-react';
import { ScrollFadeContainer } from '../../components/ui/ScrollFadeContainer';

import artImg from '../../assets/images/adham_story_art_1792064935913.jpg';
import blocksImg from '../../assets/images/adham_story_blocks_1792064936402.jpg';
import gardenImg from '../../assets/images/adham_story_garden_1792064936536.jpg';
import readingImg from '../../assets/images/adham_story_reading_1792064936037.jpg';

export interface StoryItem {
  id: string;
  title: string;
  time: string;
  teacherName: string;
  image: string;
  caption: string;
  category: string;
  viewed?: boolean;
}

const DEFAULT_STORIES: StoryItem[] = [
  {
    id: 's1',
    title: 'الرسم الحر 🎨',
    time: '09:30 ص',
    teacherName: 'أ. نورة الشمري',
    image: artImg,
    caption: 'أدهم أبدع اليوم في مزج الألوان بالأصابع ورسم لوحة مميزة بكل ثقة وسعادة!',
    category: 'الفنون والتعبير',
    viewed: false,
  },
  {
    id: 's2',
    title: 'برج المكعبات 🧱',
    time: '10:15 ص',
    teacherName: 'أ. فاطمة العتيبي',
    image: blocksImg,
    caption: 'تركيز رائع في ركن منتسوري؛ تم بناء أطول برج خشبي بتوازن وتفكير منطقي مدهش.',
    category: 'الذكاء المكاني',
    viewed: false,
  },
  {
    id: 's3',
    title: 'حديقة الروضة 🌿',
    time: '11:00 ص',
    teacherName: 'أ. نورة الشمري',
    image: gardenImg,
    caption: 'جولة استكشافية ممتعة لسقاية الزهور والتعرف على دورة حياة النبات في باحة الروضة.',
    category: 'العلوم والطبيعة',
    viewed: false,
  },
  {
    id: 's4',
    title: 'قصة اليوم 📖',
    time: '12:00 م',
    teacherName: 'أ. منيرة الدوسري',
    image: readingImg,
    caption: 'حلقة القراءة التفاعلية: تفاعل أدهم بحماس مع قصة "الأسد الشجاع" وأجاب على الأسئلة بذكاء.',
    category: 'المهارات اللغوية',
    viewed: true,
  },
];

export const ParentStoriesBar: React.FC = () => {
  const [stories, setStories] = useState<StoryItem[]>(DEFAULT_STORIES);
  const [activeStoryIndex, setActiveStoryIndex] = useState<number | null>(null);
  const [progress, setProgress] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isLiked, setIsLiked] = useState<boolean>(false);
  const [quickComment, setQuickComment] = useState<string>('');
  const [sentComment, setSentComment] = useState<boolean>(false);

  const timerRef = useRef<number | null>(null);

  // Story progression
  useEffect(() => {
    if (activeStoryIndex === null || isPaused) return;

    const interval = 50; // update every 50ms
    const totalDuration = 5000; // 5s per story
    const step = (interval / totalDuration) * 100;

    timerRef.current = window.setInterval(() => {
      setProgress((prev) => {
        if (prev + step >= 100) {
          // move to next story or close
          if (activeStoryIndex < stories.length - 1) {
            setActiveStoryIndex(activeStoryIndex + 1);
            setIsLiked(false);
            setSentComment(false);
            return 0;
          } else {
            setActiveStoryIndex(null);
            return 0;
          }
        }
        return prev + step;
      });
    }, interval);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [activeStoryIndex, isPaused, stories.length]);

  const openStory = (index: number) => {
    setActiveStoryIndex(index);
    setProgress(0);
    setIsLiked(false);
    setSentComment(false);

    // Mark as viewed
    setStories((prev) =>
      prev.map((s, idx) => (idx === index ? { ...s, viewed: true } : s))
    );
  };

  const closeStory = () => {
    setActiveStoryIndex(null);
    setProgress(0);
  };

  const nextStory = () => {
    if (activeStoryIndex !== null && activeStoryIndex < stories.length - 1) {
      setActiveStoryIndex(activeStoryIndex + 1);
      setProgress(0);
      setIsLiked(false);
      setSentComment(false);
    } else {
      closeStory();
    }
  };

  const prevStory = () => {
    if (activeStoryIndex !== null && activeStoryIndex > 0) {
      setActiveStoryIndex(activeStoryIndex - 1);
      setProgress(0);
      setIsLiked(false);
      setSentComment(false);
    }
  };

  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickComment.trim()) return;
    setSentComment(true);
    setQuickComment('');
    setTimeout(() => setSentComment(false), 2000);
  };

  return (
    <div className="w-full bg-slate-900/60 border-b border-slate-800/80 py-3.5 px-2">
      <div className="flex items-center justify-between px-3 pb-2 text-xs">
        <div className="flex items-center gap-1.5 font-bold text-slate-200">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          <span>قصص ويوميات أدهم اليوم 📸</span>
        </div>
        <span className="text-[11px] text-emerald-400 font-medium">مباشر من الفصل</span>
      </div>

      <ScrollFadeContainer orientation="horizontal" fadeSize={24} fadeColor="#0f172a">
        <div className="flex items-center gap-4 px-3 py-1">
          {stories.map((story, idx) => {
            return (
              <button
                key={story.id}
                type="button"
                onClick={() => openStory(idx)}
                className="flex flex-col items-center gap-1.5 focus:outline-none group cursor-pointer shrink-0"
              >
                {/* Instagram Story Gradient Ring */}
                <div
                  className={`p-[2.5px] rounded-full transition-transform duration-200 group-hover:scale-105 ${
                    story.viewed
                      ? 'bg-slate-700'
                      : 'bg-gradient-to-tr from-emerald-500 via-teal-400 to-amber-400 shadow-md shadow-emerald-500/20'
                  }`}
                >
                  <div className="w-15 h-15 rounded-full p-[2px] bg-slate-950 overflow-hidden">
                    <img
                      src={story.image}
                      alt={story.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover rounded-full"
                    />
                  </div>
                </div>

                {/* Story Label */}
                <span className="text-[11px] font-medium text-slate-300 max-w-[70px] truncate text-center">
                  {story.title}
                </span>
              </button>
            );
          })}
        </div>
      </ScrollFadeContainer>

      {/* Full-screen Story Player Modal */}
      <AnimatePresence>
        {activeStoryIndex !== null && (
          <div
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-0 sm:p-4 select-none"
            role="dialog"
            aria-modal="true"
          >
            <motion.div
              initial={{ scale: 0.94, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.94, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="relative w-full max-w-sm h-full sm:h-[680px] bg-slate-950 rounded-none sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between"
              onMouseDown={() => setIsPaused(true)}
              onMouseUp={() => setIsPaused(false)}
              onTouchStart={() => setIsPaused(true)}
              onTouchEnd={() => setIsPaused(false)}
            >
              {/* Background Activity Image */}
              <img
                src={stories[activeStoryIndex].image}
                alt={stories[activeStoryIndex].title}
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover"
              />

              {/* Top & Bottom Gradient Scrim for Legibility */}
              <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-black/90 pointer-events-none" />

              {/* Story Header */}
              <div className="relative z-20 p-4 space-y-3">
                {/* Segmented Progress Bars */}
                <div className="flex items-center gap-1.5">
                  {stories.map((s, idx) => (
                    <div
                      key={s.id}
                      className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden"
                    >
                      <div
                        className="h-full bg-emerald-400 transition-all duration-75"
                        style={{
                          width:
                            idx < activeStoryIndex
                              ? '100%'
                              : idx === activeStoryIndex
                              ? `${progress}%`
                              : '0%',
                        }}
                      />
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between text-white">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-400/60 p-0.5 overflow-hidden">
                      <img
                        src={stories[activeStoryIndex].image}
                        alt="author"
                        className="w-full h-full object-cover rounded-full"
                      />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 text-xs font-bold leading-tight">
                        <span>{stories[activeStoryIndex].teacherName}</span>
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      </div>
                      <span className="text-[10px] text-slate-300">
                        {stories[activeStoryIndex].time} · {stories[activeStoryIndex].category}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Volume2 className="w-4 h-4 text-slate-300" />
                    <button
                      type="button"
                      onClick={closeStory}
                      aria-label="إغلاق القصة"
                      className="w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Nav Tap Areas (Left & Right) */}
              <button
                type="button"
                onClick={prevStory}
                aria-label="القصة السابقة"
                className="absolute inset-y-24 start-0 w-1/4 z-10 flex items-center justify-start ps-2 text-white/30 hover:text-white/80 transition-colors"
              >
                <ChevronRight className="w-7 h-7" />
              </button>

              <button
                type="button"
                onClick={nextStory}
                aria-label="القصة التالية"
                className="absolute inset-y-24 end-0 w-1/4 z-10 flex items-center justify-end pe-2 text-white/30 hover:text-white/80 transition-colors"
              >
                <ChevronLeft className="w-7 h-7" />
              </button>

              {/* Story Bottom Details & Reactions */}
              <div className="relative z-20 p-4 space-y-3">
                <div className="p-3 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/10 text-white space-y-1">
                  <h4 className="text-xs font-bold text-emerald-300">
                    {stories[activeStoryIndex].title}
                  </h4>
                  <p className="text-xs text-slate-200 leading-relaxed">
                    {stories[activeStoryIndex].caption}
                  </p>
                </div>

                {/* Parent Reply & Heart */}
                <form onSubmit={handleSendComment} className="flex items-center gap-2">
                  <div className="flex-1 relative">
                    <input
                      type="text"
                      value={quickComment}
                      onChange={(e) => setQuickComment(e.target.value)}
                      placeholder="أرسل رسالة فورية للمعلمة..."
                      className="w-full bg-black/50 border border-white/20 rounded-full py-2.5 px-4 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-400"
                    />
                    {sentComment && (
                      <span className="absolute end-3 top-2.5 text-[10px] text-emerald-400 font-bold">
                        تم الإرسال ✓
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => setIsLiked(!isLiked)}
                    aria-label="إعجاب"
                    className="w-10 h-10 rounded-full bg-black/50 border border-white/20 flex items-center justify-center text-white"
                  >
                    <Heart
                      className={`w-5 h-5 transition-transform ${
                        isLiked
                          ? 'fill-rose-500 text-rose-500 scale-125'
                          : 'text-white'
                      }`}
                    />
                  </button>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
