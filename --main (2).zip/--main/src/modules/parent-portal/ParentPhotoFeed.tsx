import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Heart,
  MessageCircle,
  Bookmark,
  Share2,
  Lock,
  ShieldCheck,
  Send,
  Sparkles,
  CheckCircle2
} from 'lucide-react';

import artImg from '../../assets/images/adham_story_art_1792064935913.jpg';
import blocksImg from '../../assets/images/adham_story_blocks_1792064936402.jpg';
import gardenImg from '../../assets/images/adham_story_garden_1792064936536.jpg';
import readingImg from '../../assets/images/adham_story_reading_1792064936037.jpg';
import { AIRecommendationsCard } from '../../components/ai/AIRecommendationsCard';

export interface CommentItem {
  id: string;
  author: string;
  role: string;
  text: string;
  time: string;
}

export interface PostItem {
  id: string;
  teacherName: string;
  teacherRole: string;
  childName: string;
  timeAgo: string;
  image: string;
  caption: string;
  skillTag: string;
  domain: string;
  likesCount: number;
  comments: CommentItem[];
}

const INITIAL_POSTS: PostItem[] = [
  {
    id: 'post-1',
    title: 'مهارة الفنون البصرية والمشاعر',
    teacherName: 'أ. نورة الشمري',
    teacherRole: 'معلمة فصل الزهور (المستوى الثاني)',
    childName: 'أدهم الرفاعي',
    timeAgo: 'منذ ساعتين',
    image: artImg,
    caption: 'خلال ورشة الفنون الصباحية، قام أدهم باختيار الألوان بنفسه ومزج درجات البرتقالي والأزرق للتعبير عن مشاعره. أظهر براعة فائقة في التحكم الدقيق بعضلات الأصابع والفرشاة.',
    skillTag: 'تطور المهارات الحركية الدقيقة والتعبير الانفعالي',
    domain: 'النمو الحركي والفني',
    likesCount: 14,
    comments: [
      {
        id: 'c1',
        author: 'أم أدهم (سارة)',
        role: 'ولي الأمر',
        text: 'ما شاء الله تبارك الرحمن! فخورة جداً بتركيزك يا حبيبي، شكراً أستاذة نورة على توجيهك الجميل.',
        time: 'منذ ساعة',
      },
      {
        id: 'c2',
        author: 'أ. نورة الشمري',
        role: 'معلم الصف',
        text: 'أدهم طفل موهوب ومستجيب جداً للأنشطة الإبداعية دائماً 🌟',
        time: 'منذ 45 دقيقة',
      },
    ],
  },
  {
    id: 'post-2',
    title: 'الذكاء المكاني وبناء المكعبات',
    teacherName: 'أ. فاطمة العتيبي',
    teacherRole: 'معلمة ركن الاكتشاف ومنتسوري',
    childName: 'أدهم الرفاعي',
    timeAgo: 'منذ 4 ساعات',
    image: blocksImg,
    caption: 'أظهر أدهم صبراً وذكاءً هندسياً لافتاً في موازنة المكعبات الخشبية؛ حاول أكثر من ثلاث مرات حتى نجح في بناء البرج دون أن يسقط وشارك فرحته مع زملائه.',
    skillTag: 'المثابرة والتفكير المنطقي والهندسي',
    domain: 'النمو الإدراكي والمعرفي',
    likesCount: 21,
    comments: [
      {
        id: 'c3',
        author: 'أبو أدهم (د. قاسم)',
        role: 'ولي الأمر',
        text: 'الله يحميك يا بطل! التوازن رائع والتركيز واضح. استمر دائماً.',
        time: 'منذ 3 ساعات',
      },
    ],
  },
  {
    id: 'post-3',
    title: 'المسؤولية البيئية وسقاية الحديقة',
    teacherName: 'أ. نورة الشمري',
    teacherRole: 'مشرفة الأنشطة الخارجية',
    childName: 'أدهم الرفاعي',
    timeAgo: 'منذ يوم',
    image: gardenImg,
    caption: 'سعدنا جداً بتفاعل أدهم في حديقة الروضة الصديقة للبيئة. تعلم اليوم أهمية الماء للزهور وقام بمساعدة زملائه بروح الفريق والمحبة.',
    skillTag: 'الوعي البيئي والعمل الجماعي',
    domain: 'النمو الاجتماعي والوجداني',
    likesCount: 18,
    comments: [],
  },
  {
    id: 'post-4',
    title: 'حلقة القراءة التفاعلية والإثراء اللغوي',
    teacherName: 'أ. منيرة الدوسري',
    teacherRole: 'معلمة اللغة العربية والتربية الإسلامية',
    childName: 'أدهم الرفاعي',
    timeAgo: 'منذ يومين',
    image: readingImg,
    caption: 'استمع أدهم باهتمام شديد لقصة اليوم، وشارك بمفردات جديدة وبناء جمل متناسقة أثناء مناقشة أحداث القصة مع المعلمة وزملائه.',
    skillTag: 'الطلاقة اللفظية والاستيعاب السمعي',
    domain: 'النمو اللغوي',
    likesCount: 29,
    comments: [],
  },
];

export const ParentPhotoFeed: React.FC = () => {
  const [posts, setPosts] = useState<PostItem[]>(INITIAL_POSTS);
  const [likedPosts, setLikedPosts] = useState<Record<string, boolean>>({});
  const [savedPosts, setSavedPosts] = useState<Record<string, boolean>>({});
  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({});
  const [newCommentText, setNewCommentText] = useState<Record<string, string>>({});
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [doubleTapHeart, setDoubleTapHeart] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleToggleLike = (postId: string) => {
    setLikedPosts((prev) => {
      const isCurrentlyLiked = !!prev[postId];
      const nextLiked = !isCurrentlyLiked;

      setPosts((currentPosts) =>
        currentPosts.map((p) => {
          if (p.id === postId) {
            return {
              ...p,
              likesCount: nextLiked ? p.likesCount + 1 : Math.max(0, p.likesCount - 1),
            };
          }
          return p;
        })
      );

      return { ...prev, [postId]: nextLiked };
    });
  };

  const handleDoubleTap = (postId: string) => {
    setDoubleTapHeart(postId);
    if (!likedPosts[postId]) {
      handleToggleLike(postId);
    }
    setTimeout(() => setDoubleTapHeart(null), 800);
  };

  const handleToggleSave = (postId: string) => {
    setSavedPosts((prev) => {
      const nextState = !prev[postId];
      showToast(
        nextState
          ? 'تم حفظ الصورة في ألبوم الإنجازات المحفوظة 📁'
          : 'تمت إزالة الصورة من المحفوظات'
      );
      return { ...prev, [postId]: nextState };
    });
  };

  const handleAddComment = (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    const comment = newCommentText[postId]?.trim();
    if (!comment) return;

    const newCommentItem: CommentItem = {
      id: `comm-${Date.now()}`,
      author: 'ولي الأمر (حساب موثق)',
      role: 'ولي الأمر',
      text: comment,
      time: 'الآن',
    };

    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            comments: [...p.comments, newCommentItem],
          };
        }
        return p;
      })
    );

    setNewCommentText((prev) => ({ ...prev, [postId]: '' }));
    setExpandedComments((prev) => ({ ...prev, [postId]: true }));
    showToast('تمت إضافة تعليقك وإشعار المعلمة بنجاح 💬');
  };

  return (
    <div className="w-full space-y-6 pb-20">
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-18 inset-x-4 max-w-sm mx-auto z-50 bg-emerald-950 border border-emerald-500/50 text-emerald-200 px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs font-semibold backdrop-blur-md"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Feed Posts */}
      {posts.map((post, idx) => {
        const isLiked = !!likedPosts[post.id];
        const isSaved = !!savedPosts[post.id];
        const isCommentsOpen = !!expandedComments[post.id];

        return (
          <React.Fragment key={post.id}>
            <article
              className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-lg transition-all"
            >
            {/* Post Header */}
            <div className="p-4 flex items-center justify-between border-b border-slate-800/80">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-400 p-[2px]">
                  <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center font-bold text-xs text-emerald-400">
                    {post.teacherName.charAt(2) || 'أ'}
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white">{post.teacherName}</span>
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400">
                    <span>{post.teacherRole}</span>
                    <span>·</span>
                    <span className="text-emerald-400 font-semibold">{post.childName}</span>
                  </div>
                </div>
              </div>

              {/* Verified Custody Privacy Badge */}
              <div
                title="محتوى محمي بموجب سياسات الخصوصية والوصاية المعتمدة"
                className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-[10px] text-emerald-300 font-medium"
              >
                <Lock className="w-3 h-3 text-emerald-400" />
                <span>محمي ومصرح</span>
              </div>
            </div>

            {/* Post Media with Double-Tap to Like */}
            <div
              className="relative w-full aspect-4/3 bg-slate-950 cursor-pointer overflow-hidden group select-none"
              onDoubleClick={() => handleDoubleTap(post.id)}
            >
              <img
                src={post.image}
                alt={post.caption}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
              />

              {/* Floating Heart Animation on Double Tap */}
              <AnimatePresence>
                {doubleTapHeart === post.id && (
                  <motion.div
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1.3, opacity: 1 }}
                    exit={{ scale: 0.8, opacity: 0 }}
                    transition={{ duration: 0.4, type: 'spring' }}
                    className="absolute inset-0 m-auto w-20 h-20 flex items-center justify-center pointer-events-none drop-shadow-2xl"
                  >
                    <Heart className="w-20 h-20 fill-rose-500 text-rose-500" />
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Subtle Domain Pill on Media */}
              <div className="absolute bottom-3 start-3 bg-slate-950/80 backdrop-blur-md border border-slate-700/60 px-3 py-1 rounded-full text-[10px] font-semibold text-slate-200">
                {post.domain}
              </div>
            </div>

            {/* Post Actions Bar */}
            <div className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  {/* Like Button */}
                  <button
                    type="button"
                    onClick={() => handleToggleLike(post.id)}
                    aria-label="إعجاب بالمنشور"
                    className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer group"
                  >
                    <Heart
                      className={`w-5 h-5 transition-transform duration-150 group-active:scale-125 ${
                        isLiked ? 'fill-rose-500 text-rose-500' : 'text-slate-300'
                      }`}
                    />
                    <span className="font-mono font-bold text-xs">
                      {post.likesCount}
                    </span>
                  </button>

                  {/* Comment Toggle */}
                  <button
                    type="button"
                    onClick={() =>
                      setExpandedComments((prev) => ({
                        ...prev,
                        [post.id]: !prev[post.id],
                      }))
                    }
                    aria-label="عرض التعليقات"
                    className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
                  >
                    <MessageCircle className="w-5 h-5 text-slate-300" />
                    <span className="font-mono font-bold text-xs">
                      {post.comments.length}
                    </span>
                  </button>

                  {/* Share / Save to Family Album */}
                  <button
                    type="button"
                    onClick={() =>
                      showToast('تم نسخ رابط التوثيق الآمن للوالدين فقط 🔗')
                    }
                    aria-label="مشاركة آمنة"
                    className="text-slate-300 hover:text-white transition-colors cursor-pointer"
                  >
                    <Share2 className="w-5 h-5" />
                  </button>
                </div>

                {/* Bookmark Button */}
                <button
                  type="button"
                  onClick={() => handleToggleSave(post.id)}
                  aria-label="حفظ في الألبوم"
                  className="text-slate-300 hover:text-white transition-colors cursor-pointer"
                >
                  <Bookmark
                    className={`w-5 h-5 transition-transform active:scale-125 ${
                      isSaved ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                    }`}
                  />
                </button>
              </div>

              {/* Developmental Skill Tag */}
              <div className="flex items-center gap-2 text-xs">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-lg">
                  <Sparkles className="w-3 h-3 text-emerald-400" />
                  <span>{post.skillTag}</span>
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  {post.timeAgo}
                </span>
              </div>

              {/* Caption Text */}
              <p className="text-xs text-slate-200 leading-relaxed font-normal">
                {post.caption}
              </p>

              {/* Comments Section */}
              {post.comments.length > 0 && !isCommentsOpen && (
                <button
                  type="button"
                  onClick={() =>
                    setExpandedComments((prev) => ({ ...prev, [post.id]: true }))
                  }
                  className="text-[11px] text-slate-400 hover:text-emerald-400 font-medium transition-colors cursor-pointer block"
                >
                  عرض جميع التعليقات ({post.comments.length})...
                </button>
              )}

              {/* Expanded Comments List */}
              <AnimatePresence>
                {isCommentsOpen && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-2 pt-2 border-t border-slate-800/80"
                  >
                    {post.comments.map((comm) => (
                      <div
                        key={comm.id}
                        className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-emerald-300 text-[11px]">
                            {comm.author}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {comm.time}
                          </span>
                        </div>
                        <p className="text-slate-300 text-xs">{comm.text}</p>
                      </div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Add Comment Input Form */}
              <form
                onSubmit={(e) => handleAddComment(post.id, e)}
                className="flex items-center gap-2 pt-1"
              >
                <input
                  type="text"
                  value={newCommentText[post.id] || ''}
                  onChange={(e) =>
                    setNewCommentText((prev) => ({
                      ...prev,
                      [post.id]: e.target.value,
                    }))
                  }
                  placeholder="اكتب كلمة تشجيعية لطفلك أو رسالة للمعلمة..."
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                />
                <button
                  type="submit"
                  disabled={!newCommentText[post.id]?.trim()}
                  aria-label="إرسال التعليق"
                  className="h-8 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 font-bold flex items-center justify-center transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          </article>

          {/* AI Pedagogical Recommendations Spotlight Card */}
          {idx === 0 && (
            <div className="my-2">
              <AIRecommendationsCard childName="أدهم الرفاعي" />
            </div>
          )}
        </React.Fragment>
        );
      })}
    </div>
  );
};
