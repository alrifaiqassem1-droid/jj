import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Sparkles,
  MessageCircleQuestion,
  Clock,
  CheckCircle2,
  Heart,
  Lightbulb,
  Check
} from 'lucide-react';
import { pedagogicalAiEngine } from '../../lib/ai/pedagogicalAiEngine';
import { soundService } from '../../lib/audio/soundEffects';
import { DynamicButton, type ButtonState } from '../../components/ui/DynamicButton';

interface ChildDailyAiInsightCardProps {
  childKey?: 'adham' | 'sara';
  className?: string;
}

export const ChildDailyAiInsightCard: React.FC<ChildDailyAiInsightCardProps> = ({
  childKey = 'adham',
  className = '',
}) => {
  const plan = pedagogicalAiEngine.getBridgePlan(childKey);
  const [completed, setCompleted] = useState<boolean>(false);
  const [buttonState, setButtonState] = useState<ButtonState>('idle');
  const [parentFeedback, setParentFeedback] = useState<string>('');
  const [savedFeedback, setSavedFeedback] = useState<string | null>(null);

  const handleCompleteActivity = () => {
    if (buttonState !== 'idle') return;

    setButtonState('loading');
    setTimeout(() => {
      // Play cheerful Do-Mi-Sol chime via Web Audio API
      soundService.playCheerfulChime();

      setCompleted(true);
      setButtonState('success');
      if (parentFeedback.trim()) {
        setSavedFeedback(parentFeedback.trim());
      }

      setTimeout(() => {
        setButtonState('idle');
      }, 3000);
    }, 700);
  };

  return (
    <article
      className={`bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/50 border border-emerald-500/30 rounded-3xl p-5 shadow-xl space-y-4 relative overflow-hidden select-none ${className}`}
      aria-label="بطاقة جسر التواصل التربوي الذكي بين الروضة والمنزل"
    >
      {/* Decorative gentle glow */}
      <div className="absolute top-0 end-0 w-44 h-44 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-[2px]">
            <div className="w-full h-full rounded-xl bg-slate-950 flex items-center justify-center font-bold text-xs text-emerald-400">
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight">
                جسر التواصل المسائي · مع {plan.childName}
              </h4>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                10 دقائق
              </span>
            </div>
            <p className="text-[10px] text-slate-400">
              {plan.domainLabel} · نشاط متكامل مع ما تعلمه اليوم بالروضة
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-slate-400">
          <Clock className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[11px] font-mono text-emerald-300">مساء اليوم</span>
        </div>
      </div>

      {/* Rationale / Reflection Note */}
      <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800/80 text-xs text-slate-300 space-y-1">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-300">
          <Lightbulb className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>ما لاحظته المعلمة اليوم:</span>
        </div>
        <p className="text-slate-300 leading-relaxed text-xs">
          {plan.rationale}
        </p>
      </div>

      {/* 10-Minute Micro-Activity Card */}
      <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 space-y-2 relative">
        <div className="flex items-center justify-between text-xs font-bold text-white">
          <span className="flex items-center gap-1.5 text-emerald-300">
            <Heart className="w-4 h-4 text-emerald-400 fill-emerald-400/20" />
            <span>{plan.parentBridge.headline}</span>
          </span>
          <span className="text-[10px] bg-emerald-950 border border-emerald-500/40 text-emerald-300 px-2 py-0.5 rounded-full font-mono">
            {plan.parentBridge.durationMinutes} دقائق فقط
          </span>
        </div>

        <p className="text-xs text-slate-200 leading-relaxed">
          {plan.parentBridge.homeMicroActivity}
        </p>
      </div>

      {/* Conversation Starter Question (سؤال مفتاح الحديث الودود) */}
      <div className="p-3.5 rounded-2xl bg-teal-950/30 border border-teal-500/30 space-y-1.5">
        <div className="flex items-center gap-1.5 text-xs font-bold text-teal-300">
          <MessageCircleQuestion className="w-4 h-4 text-teal-400 shrink-0" />
          <span>سؤال لبدء حديث دافئ مع الطفل اليوم:</span>
        </div>
        <p className="text-xs text-teal-100 font-medium leading-relaxed bg-slate-950/60 p-2.5 rounded-xl border border-teal-500/20 italic">
          {plan.parentBridge.conversationStarter}
        </p>
      </div>

      {/* Completion & Feedback Section */}
      <div className="pt-1 space-y-2.5">
        {completed ? (
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-xs text-emerald-200 flex items-center justify-between gap-3 shadow-md"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-bold shrink-0">
                <Check className="w-5 h-5 stroke-[3]" />
              </div>
              <div>
                <span className="font-extrabold text-white block">
                  رائع! أتممتم النشاط المنزلي بنجاح 🌟
                </span>
                <span className="text-[11px] text-emerald-300">
                  تم إشعار المعلمة بتفاعل الأهل وتسجيل إنجاز {plan.childName}.
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => soundService.playCheerfulChime()}
              title="إعادة سماع نغمة الإنجاز"
              className="text-emerald-400 hover:text-white p-2"
            >
              <Sparkles className="w-4 h-4" />
            </button>
          </motion.div>
        ) : (
          <div className="space-y-2">
            <input
              type="text"
              value={parentFeedback}
              onChange={(e) => setParentFeedback(e.target.value)}
              placeholder="اكتب كلمة شكر للمعلمة أو انطباع طفلك عن النشاط..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
            />

            <DynamicButton
              state={buttonState}
              variant="emerald"
              size="md"
              fullWidth
              onClick={handleCompleteActivity}
              loadingText="جارٍ تسجيل إتمام النشاط..."
              successText="تم الإنجاز وسماع نغمة الفرح! 🎉"
              icon={<CheckCircle2 className="w-4 h-4 stroke-[2.2]" />}
            >
              أتممنا النشاط المنزلي مع {plan.childName} (10 دقائق) 🌟
            </DynamicButton>
          </div>
        )}

        {savedFeedback && (
          <p className="text-[11px] text-slate-400 bg-slate-950 p-2 rounded-lg border border-slate-800">
            <strong className="text-emerald-300">رسالتكم للمعلمة:</strong> {savedFeedback}
          </p>
        )}
      </div>
    </article>
  );
};
