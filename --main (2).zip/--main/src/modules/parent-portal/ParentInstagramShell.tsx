import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bell,
  UserCheck,
  DoorOpen,
  Camera,
  Home,
  Compass,
  FileCheck2,
  User,
  CheckCircle2,
  Sparkles,
  ChevronDown
} from 'lucide-react';
import { DynamicButton, type ButtonState } from '../../components/ui/DynamicButton';
import { ParentStoriesBar } from './ParentStoriesBar';
import { ParentPhotoFeed } from './ParentPhotoFeed';
import { MagneticDropZone } from '../../components/ui/MagneticDropZone';
import { AppLogo } from '../../components/ui/AppLogo';
import { soundService } from '../../lib/audio/soundEffects';
import { ChildDailyAiInsightCard } from './ChildDailyAiInsightCard';

interface ParentInstagramShellProps {
  onBackToAdmin?: () => void;
}

export const ParentInstagramShell: React.FC<ParentInstagramShellProps> = ({
  onBackToAdmin,
}) => {
  const [activeTab, setActiveTab] = useState<'feed' | 'stories' | 'upload' | 'diary' | 'profile'>('feed');
  const [pickupButtonState, setPickupButtonState] = useState<ButtonState>('idle');
  const [pickupAlertBanner, setPickupAlertBanner] = useState<string | null>(null);
  const [activeChild, setActiveChild] = useState<'adham' | 'sara'>('adham');
  const [childDropdownOpen, setChildDropdownOpen] = useState<boolean>(false);
  const [unreadNotifications, setUnreadNotifications] = useState<number>(3);

  const handleDoorPickupClick = () => {
    if (pickupButtonState !== 'idle') return;

    setPickupButtonState('loading');
    setTimeout(() => {
      setPickupButtonState('success');
      // Play cheerful audio chime for parent feedback
      soundService.playCheerfulChime();

      const timeStr = new Date().toLocaleTimeString('ar-SA', {
        hour: '2-digit',
        minute: '2-digit',
      });
      setPickupAlertBanner(`تم إرسال إشعار فوري لطاقم الروضة الساعة ${timeStr} — يتم الآن مرافقة ${activeChild === 'adham' ? 'أدهم' : 'سارة'} إلى بوابة الاستلام الرئيسية.`);

      setTimeout(() => {
        setPickupButtonState('idle');
      }, 5000);
    }, 1500);
  };

  return (
    <div className="w-full flex justify-center py-2 sm:py-6 px-0 sm:px-4 bg-slate-950 min-h-screen">
      {/* Mobile Frame Container (Instagram App Look) */}
      <div className="w-full max-w-md bg-slate-900 border-x sm:border border-slate-800 rounded-none sm:rounded-[36px] overflow-hidden shadow-2xl flex flex-col min-h-screen sm:min-h-[880px] relative">
        {/* App Top Bar */}
        <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <AppLogo size="sm" variant="dark" showText={false} />
            <div className="relative">
              <button
                type="button"
                onClick={() => setChildDropdownOpen(!childDropdownOpen)}
                className="flex items-center gap-2 text-start focus:outline-none cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 p-[1.5px]">
                  <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center font-bold text-xs text-emerald-400">
                    {activeChild === 'adham' ? 'أ' : 'س'}
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1 font-bold text-xs sm:text-sm text-white group-hover:text-emerald-300 transition-colors">
                    <span>{activeChild === 'adham' ? 'أدهم الرفاعي' : 'سارة الرفاعي'}</span>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  </div>
                  <p className="text-[10px] text-emerald-400 font-medium leading-none">روضة الأدهم الذكية</p>
                </div>
              </button>

            {/* Child Selector Dropdown */}
            <AnimatePresence>
              {childDropdownOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute top-12 start-0 z-50 w-56 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-2 space-y-1"
                >
                  <button
                    type="button"
                    onClick={() => {
                      setActiveChild('adham');
                      setChildDropdownOpen(false);
                    }}
                    className={`w-full p-2.5 rounded-xl text-xs flex items-center justify-between transition-colors ${
                      activeChild === 'adham'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-bold'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>أدهم الرفاعي (فصل الزهور)</span>
                    {activeChild === 'adham' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setActiveChild('sara');
                      setChildDropdownOpen(false);
                    }}
                    className={`w-full p-2.5 rounded-xl text-xs flex items-center justify-between transition-colors ${
                      activeChild === 'sara'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-bold'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>سارة الرفاعي (فصل النجوم)</span>
                    {activeChild === 'sara' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Action Icons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setUnreadNotifications(0)}
              aria-label="الإشعارات"
              className="relative p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <Bell className="w-5 h-5" />
              {unreadNotifications > 0 && (
                <span className="absolute top-1.5 end-1.5 w-2 h-2 rounded-full bg-emerald-500" />
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('upload')}
              aria-label="رفع صور الأنشطة"
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <Camera className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Pickup Alert Success Banner */}
        <AnimatePresence>
          {pickupAlertBanner && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="bg-emerald-950 border-b border-emerald-500/40 px-4 py-2.5 text-xs text-emerald-200 flex items-start gap-2.5"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">{pickupAlertBanner}</div>
              <button
                type="button"
                onClick={() => setPickupAlertBanner(null)}
                className="text-emerald-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto">
          {/* TAB 1: FEED */}
          {activeTab === 'feed' && (
            <div className="space-y-4">
              {/* Daily Stories Bar */}
              <ParentStoriesBar />

              {/* Home-School Pedagogical AI Insight Card */}
              <div className="px-3">
                <ChildDailyAiInsightCard childKey={activeChild} />
              </div>

              {/* Feed Content */}
              <div className="px-3 pt-1">
                <ParentPhotoFeed />
              </div>
            </div>
          )}

          {/* TAB 2: STORIES (Direct Stories & Video Reels) */}
          {activeTab === 'stories' && (
            <div className="p-4 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>أرشيف القصص واليوميات المصورة</span>
              </h3>
              <ParentStoriesBar />
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-2">
                <p className="font-semibold text-emerald-300">توثيق مباشر وفق سياسة الحد الأدنى الضروري من الإفصاح</p>
                <p className="text-slate-400 leading-relaxed text-[11px]">
                  جميع الصور واليوميات المنشورة هنا مخصصة حصرياً لولي الأمر الموثق، ويتم تشفيرها وتخزينها بأمان دون مشاركتها للعامة.
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: UPLOAD ACTIVITY (MagneticDropZone) */}
          {activeTab === 'upload' && (
            <div className="p-4 space-y-4">
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Camera className="w-4 h-4 text-emerald-400" />
                  <span>مشاركة أنشطة الطفل المنزلية مع المعلمة</span>
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  يمكنك رفع صور وملاحظات أنشطة طفلك في المنزل (مثل القراءة، الرسم، المساعدة) لتعزيز التكامل التربوي بين المنزل والروضة.
                </p>
              </div>

              <MagneticDropZone
                title="اسحب صورة النشاط المنزلي وأفلتها هنا"
                subtitle="أو انقر لالتقاط صورة من كاميرا الهاتف أو معرض الصور"
                onFilesAccepted={() => {
                  setActiveTab('feed');
                }}
              />
            </div>
          )}

          {/* TAB 4: DIARY & MILESTONES */}
          {activeTab === 'diary' && (
            <div className="p-4 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileCheck2 className="w-4 h-4 text-emerald-400" />
                <span>سجل الملاحظات والتطور النمائي</span>
              </h3>

              <div className="space-y-3">
                <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-emerald-300">النمو الحركي الدقيق</span>
                    <span className="text-[10px] text-slate-400 font-mono">اليوم 10:15 ص</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    تمكن أدهم اليوم من مسك القلم والفرشاة بالطريقة الثلاثية الصحيحة، مع تركيز ممتاز واستجابة للتوجيهات.
                  </p>
                  <div className="pt-1 flex items-center gap-2 text-[10px] text-slate-400">
                    <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>سجلته المعلمة: أ. نورة الشمري</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-emerald-300">التفاعل الاجتماعي والمشاركة</span>
                    <span className="text-[10px] text-slate-400 font-mono">أمس 12:30 م</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    شارك أصدقاءه لعبة ترتيب المكعبات بكل رحابة صدر، واقترح أفكاراً مبتكرة في بناء القلعة الجماعية.
                  </p>
                  <div className="pt-1 flex items-center gap-2 text-[10px] text-slate-400">
                    <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>سجلته المعلمة: أ. فاطمة العتيبي</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: PROFILE & HEALTH */}
          {activeTab === 'profile' && (
            <div className="p-4 space-y-4">
              <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-950 border border-slate-800">
                <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 p-[2px]">
                  <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center font-bold text-base text-emerald-400">
                    أدهم
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">أدهم الرفاعي</h4>
                  <p className="text-xs text-slate-400">فصل الزهور · المستوى الثاني</p>
                  <span className="inline-block mt-1 text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-md font-semibold">
                    وصاية موثقة رسميًا ✓
                  </span>
                </div>
              </div>

              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-400">حالة الحضور اليوم</span>
                  <span className="text-emerald-400 font-bold">حاضر (08:05 ص)</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-400">تنبيهات الحساسية</span>
                  <span className="text-slate-300 font-medium">سليم — لا توجد حساسية دوائية</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-400">المعلمة المسؤولة</span>
                  <span className="text-slate-200 font-medium">أ. نورة الشمري</span>
                </div>
              </div>

              {onBackToAdmin && (
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={onBackToAdmin}
                    className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors text-center"
                  >
                    العودة إلى لوحة إدارة الروضة 🏢
                  </button>
                </div>
              )}
            </div>
          )}
        </main>

        {/* Sticky Parent Pickup Alert Button ("أنا عند الباب") */}
        <div className="sticky bottom-16 inset-x-0 z-30 p-3 bg-gradient-to-t from-slate-900 via-slate-900/95 to-transparent">
          <DynamicButton
            state={pickupButtonState}
            variant="emerald"
            size="lg"
            fullWidth
            onClick={handleDoorPickupClick}
            loadingText="جاري تأكيد الموقع وإشعار المعلمة..."
            successText="✓ تم إشعار المعلمة — أدهم يتجهز الآن!"
            icon={<DoorOpen className="w-5 h-5 stroke-[2.2]" />}
            className="shadow-xl"
          >
            🚪 أنا عند الباب — إشعار المعلمة للاستلام
          </DynamicButton>
        </div>

        {/* Bottom Navigation Tabs */}
        <nav className="sticky bottom-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 h-16 grid grid-cols-5 items-center px-1">
          <button
            type="button"
            onClick={() => setActiveTab('feed')}
            className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
              activeTab === 'feed' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-1">الرئيسية</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('stories')}
            className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
              activeTab === 'stories' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Compass className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-1">الأنشطة</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('upload')}
            className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
              activeTab === 'upload' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Camera className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-1">مشاركة</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('diary')}
            className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
              activeTab === 'diary' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCheck2 className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-1">اليوميات</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
              activeTab === 'profile' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-5 h-5" />
            <span className="text-[10px] font-semibold mt-1">طفلي</span>
          </button>
        </nav>
      </div>
    </div>
  );
};
