import { supabase } from '../../lib/supabase/client';
import type { Kindergarten } from '../../types/database';

/**
 * Kindergarten Context Service (Read-Only)
 *
 * Security Invariants:
 * 1. Read-only context retrieval. Never provides mutation/creation of institutional records.
 * 2. True authorization is strictly anchored in `auth.uid()` via the cryptographic JWT token.
 * 3. PostgreSQL RLS policy ("Kindergartens: Read Access") evaluates `auth.is_admin_for(id)`
 *    or active membership in `kindergarten_memberships`.
 * 4. The `kindergartenId` parameter is strictly a query selector, NEVER trusted as authorization proof.
 *    Any cross-tenant access attempt will yield zero rows or an RLS rejection.
 */
export async function getKindergartenProfile(
  kindergartenId: string
): Promise<{ data: Kindergarten | null; error: Error | null }> {
  try {
    if (!kindergartenId || typeof kindergartenId !== 'string') {
      return { data: null, error: new Error('معرف الروضة غير محدد أو غير صالح') };
    }

    const { data, error } = await supabase
      .from('kindergartens')
      .select('*')
      .eq('id', kindergartenId)
      .is('deleted_at', null)
      .maybeSingle();

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data: data as Kindergarten | null, error: null };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'خطأ غير متوقع أثناء استرجاع بيانات الروضة';
    return { data: null, error: new Error(message) };
  }
}
