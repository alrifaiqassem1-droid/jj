import { useState, useRef, useEffect } from 'react';
import { AdminGuard } from './AdminGuard';
import { AdminSidebar, type AdminTab } from './AdminSidebar';
import { AdminHeader } from './AdminHeader';
import { AdminOverviewView } from './AdminOverviewView';
import { AdminPlaceholderView } from './AdminPlaceholderView';
import { ClassesView } from '../../classes/components/ClassesView';
import { ChildrenView } from '../../children/ChildrenView';
import { TeachersView } from '../../staff/TeachersView';
import { ParentsView } from '../../parents/ParentsView';
import { AttendanceView } from '../../attendance/components/AttendanceView';
import { AttendanceReportsView } from '../../attendance/components/AttendanceReportsView';
import { useI18n } from '../../../lib/i18n/I18nContext';
import { X, Check } from 'lucide-react';

interface AdminShellProps {
  onBackToHome: () => void;
  onOpenSignIn: () => void;
}

export function AdminShell({ onBackToHome, onOpenSignIn }: AdminShellProps) {
  const [currentTab, setCurrentTab] = useState<AdminTab>('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [sheetOpen, setSheetOpen] = useState(false);

  const { t } = useI18n();

  // Focus restoration references
  const lastActiveElementRef = useRef<HTMLElement | null>(null);
  const drawerContainerRef = useRef<HTMLDivElement>(null);
  const sheetContainerRef = useRef<HTMLDivElement>(null);

  const handleOpenDrawer = () => {
    lastActiveElementRef.current = document.activeElement as HTMLElement;
    setDrawerOpen(true);
  };

  const handleCloseDrawer = () => {
    setDrawerOpen(false);
    if (lastActiveElementRef.current) {
      lastActiveElementRef.current.focus();
    }
  };

  const handleOpenSheet = () => {
    lastActiveElementRef.current = document.activeElement as HTMLElement;
    setSheetOpen(true);
  };

  const handleCloseSheet = () => {
    setSheetOpen(false);
    if (lastActiveElementRef.current) {
      lastActiveElementRef.current.focus();
    }
  };

  // Keyboard navigation & Focus trap for Drawer & Sheet
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (drawerOpen) {
          handleCloseDrawer();
        } else if (sheetOpen) {
          handleCloseSheet();
        }
      }
    };

    if (drawerOpen || sheetOpen) {
      document.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [drawerOpen, sheetOpen]);

  return (
    <AdminGuard onBackToHome={onBackToHome} onOpenSignIn={onOpenSignIn}>
      <div className="min-h-screen bg-slate-50 text-slate-900 flex selection:bg-teal-700/20 selection:text-teal-900">
        {/* Desktop Sidebar & Mobile Responsive Drawer */}
        <AdminSidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          onSwitchToBaseline={onBackToHome}
          mobileOpen={mobileNavOpen}
          onCloseMobile={() => setMobileNavOpen(false)}
        />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0">
          <AdminHeader
            currentTab={currentTab}
            onOpenMobileNav={() => setMobileNavOpen(true)}
            onSelectTab={setCurrentTab}
          />

          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
            {currentTab === 'overview' && (
              <AdminOverviewView
                onSelectTab={(tab) => setCurrentTab(tab)}
                onOpenDrawer={handleOpenDrawer}
                onOpenSheet={handleOpenSheet}
              />
            )}

            {currentTab === 'classes' && (
              <ClassesView />
            )}

            {currentTab === 'activities' && (
              <AdminPlaceholderView
                title={t.adminShell.navActivities}
              />
            )}

            {currentTab === 'children' && (
              <ChildrenView />
            )}

            {currentTab === 'teachers' && (
              <TeachersView />
            )}

            {currentTab === 'parents' && (
              <ParentsView />
            )}

            {currentTab === 'attendance' && (
              <AttendanceView />
            )}

            {currentTab === 'reports' && (
              <AttendanceReportsView />
            )}

            {currentTab === 'settings' && (
              <AdminPlaceholderView
                title={t.adminShell.navSettings}
              />
            )}
          </main>
        </div>

        {/* Structural Specification 14.1: Side Panel (Drawer) */}
        {drawerOpen && (
          <div
            className="fixed inset-0 z-50 flex justify-end"
            role="dialog"
            aria-modal="true"
            aria-labelledby="drawer-title"
          >
            {/* Backdrop Overlay */}
            <div
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
              onClick={handleCloseDrawer}
              aria-hidden="true"
            />

            {/* Sliding Panel from logical end (left in RTL) */}
            <div
              ref={drawerContainerRef}
              className="relative w-full sm:w-[420px] h-full bg-white shadow-xl flex flex-col justify-between z-10 animate-in slide-in-from-left duration-250 border-s border-slate-200"
            >
              {/* Drawer Header */}
              <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h3 id="drawer-title" className="text-base font-bold text-slate-900">
                    {t.adminShell.drawerTitle}
                  </h3>
                  <p className="text-xs text-slate-500 pt-0.5">{t.adminShell.drawerDesc}</p>
                </div>
                <button
                  onClick={handleCloseDrawer}
                  className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer focus-visible:outline-2 focus-visible:outline-teal-700"
                  aria-label={t.adminShell.closeAction}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Body */}
              <div className="flex-1 p-5 overflow-y-auto space-y-4 text-xs text-slate-700">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <span className="font-bold text-slate-900 block">{t.adminShell.platformBrand}</span>
                  <p className="leading-relaxed text-slate-600">{t.adminShell.subtitle}</p>
                </div>

                <div className="p-4 rounded-xl bg-teal-50 border border-teal-200 text-teal-900 space-y-1">
                  <span className="font-bold block">{t.adminShell.systemStatusLabel}</span>
                  <p className="text-xs text-teal-800">{t.adminShell.systemStatusActive}</p>
                </div>
              </div>

              {/* Drawer Footer */}
              <div className="p-4 border-t border-slate-200 flex items-center justify-end gap-2 bg-slate-50">
                <button
                  onClick={handleCloseDrawer}
                  className="px-4 py-2 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold transition shadow-xs cursor-pointer min-h-[44px] focus-visible:outline-2 focus-visible:outline-teal-700"
                >
                  {t.adminShell.closeAction}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Structural Specification 14.3: Bottom Sheet */}
        {sheetOpen && (
          <div
            className="fixed inset-0 z-50 flex items-end justify-center"
            role="dialog"
            aria-modal="true"
            aria-labelledby="sheet-title"
          >
            {/* Backdrop Overlay */}
            <div
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
              onClick={handleCloseSheet}
              aria-hidden="true"
            />

            {/* Bottom Sheet Container */}
            <div
              ref={sheetContainerRef}
              className="relative w-full sm:max-w-xl bg-white rounded-t-2xl shadow-xl flex flex-col z-10 animate-in slide-in-from-bottom duration-250 border-t border-slate-200 max-h-[85vh]"
            >
              {/* Drag Handle Indicator */}
              <div className="pt-3 pb-1 flex justify-center" aria-hidden="true">
                <div className="w-9 h-1 rounded-full bg-slate-300" />
              </div>

              {/* Sheet Header */}
              <div className="px-5 py-3 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 id="sheet-title" className="text-base font-bold text-slate-900">
                    {t.adminShell.sheetTitle}
                  </h3>
                  <p className="text-xs text-slate-500 pt-0.5">{t.adminShell.sheetDesc}</p>
                </div>
                <button
                  onClick={handleCloseSheet}
                  className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer focus-visible:outline-2 focus-visible:outline-teal-700"
                  aria-label={t.adminShell.closeAction}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Sheet Body */}
              <div className="p-5 overflow-y-auto space-y-3 text-xs text-slate-700">
                <p className="text-slate-600 leading-relaxed">
                  {t.adminShell.demoStatesDesc}
                </p>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-800">
                  <span className="font-semibold block">{t.adminShell.activeKindergarten}</span>
                  <span className="font-mono text-[11px] text-teal-800 font-bold block pt-1">
                    DEFAULT-KINDERGARTEN-ACTIVE
                  </span>
                </div>
              </div>

              {/* Sheet Footer */}
              <div className="p-4 border-t border-slate-100 flex items-center justify-end gap-2 bg-slate-50 rounded-b-2xl">
                <button
                  onClick={handleCloseSheet}
                  className="px-4 py-2.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold transition cursor-pointer min-h-[44px] focus-visible:outline-2 focus-visible:outline-slate-400"
                >
                  {t.adminShell.closeAction}
                </button>
                <button
                  onClick={handleCloseSheet}
                  className="flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold transition shadow-xs cursor-pointer min-h-[44px] focus-visible:outline-2 focus-visible:outline-teal-700"
                >
                  <Check className="w-4 h-4" />
                  <span>{t.adminShell.confirmAction}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminGuard>
  );
}
