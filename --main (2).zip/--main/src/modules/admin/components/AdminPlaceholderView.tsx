import { Construction, ShieldCheck } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';

interface AdminPlaceholderViewProps {
  title: string;
  icon?: React.ReactNode;
}

export function AdminPlaceholderView({ title, icon }: AdminPlaceholderViewProps) {
  const { t } = useI18n();

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-8 sm:p-12 text-center space-y-6 max-w-2xl mx-auto shadow-sm">
      <div className="w-16 h-16 rounded-2xl bg-teal-50 border border-teal-200 text-teal-700 mx-auto flex items-center justify-center shadow-xs">
        {icon || <Construction className="w-8 h-8" />}
      </div>

      <div className="space-y-2">
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-teal-800 bg-teal-50 px-3 py-1 rounded-full border border-teal-200 font-mono">
          <ShieldCheck className="w-3.5 h-3.5 text-teal-700" />
          <span>PHASE 1B SHELL</span>
        </div>
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">
          {title}
        </h2>
        <p className="text-xs text-slate-600 leading-relaxed max-w-lg mx-auto">
          {t.adminShell.placeholderDesc}
        </p>
      </div>

      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 leading-relaxed text-start space-y-1.5">
        <span className="font-semibold text-teal-800 block">{t.adminShell.placeholderTitle}</span>
        <p>{t.adminShell.placeholderPhaseNote}</p>
      </div>
    </div>
  );
}
