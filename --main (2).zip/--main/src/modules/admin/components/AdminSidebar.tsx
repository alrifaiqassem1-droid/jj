import { useEffect, useRef } from 'react';
import {
  LayoutDashboard,
  Calendar,
  Baby,
  GraduationCap,
  Clock,
  BarChart3,
  Settings,
  ChevronRight,
  ChevronLeft,
  Layers,
  X,
  School,
  Users2,
} from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';

import { AppLogo } from '../../../components/ui/AppLogo';

export type AdminTab =
  | 'overview'
  | 'classes'
  | 'activities'
  | 'children'
  | 'teachers'
  | 'parents'
  | 'attendance'
  | 'reports'
  | 'settings';

interface AdminSidebarProps {
  currentTab: AdminTab;
  onSelectTab: (tab: AdminTab) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  onSwitchToBaseline?: () => void;
  mobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export function AdminSidebar({
  currentTab,
  onSelectTab,
  collapsed,
  onToggleCollapse,
  onSwitchToBaseline,
  mobileOpen = false,
  onCloseMobile,
}: AdminSidebarProps) {
  const { t, dir } = useI18n();
  const drawerRef = useRef<HTMLDivElement>(null);

  // In RTL, collapsing shrinks towards right (start), so collapse icon points right, expand points left
  const CollapseIcon = dir === 'rtl'
    ? (collapsed ? ChevronLeft : ChevronRight)
    : (collapsed ? ChevronRight : ChevronLeft);

  const navItems: { id: AdminTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'overview', label: t.adminShell.navOverview, icon: LayoutDashboard },
    { id: 'classes', label: t.classes.title, icon: School },
    { id: 'activities', label: t.adminShell.navActivities, icon: Calendar },
    { id: 'children', label: t.adminShell.navChildren, icon: Baby },
    { id: 'teachers', label: t.adminShell.navTeachers, icon: GraduationCap },
    { id: 'parents', label: t.parents.title, icon: Users2 },
    { id: 'attendance', label: t.adminShell.navAttendance, icon: Clock },
    { id: 'reports', label: t.adminShell.navReports, icon: BarChart3 },
    { id: 'settings', label: t.adminShell.navSettings, icon: Settings },
  ];

  // Mobile Escape key and Focus Trap listener
  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape' && mobileOpen && onCloseMobile) {
        onCloseMobile();
      }
    }
    if (mobileOpen) {
      document.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [mobileOpen, onCloseMobile]);

  const sidebarContent = (
    <div className="flex flex-col justify-between h-full bg-white text-slate-800">
      <div className="p-4 space-y-4">
        {/* Brand / Title Header with Official AppLogo */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="overflow-hidden">
            <AppLogo
              size="md"
              variant="light"
              showText={!collapsed || mobileOpen}
            />
          </div>

          {/* Desktop Collapse Button */}
          <button
            onClick={onToggleCollapse}
            className="hidden lg:flex p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition cursor-pointer min-h-[36px] min-w-[36px] items-center justify-center focus-visible:outline-2 focus-visible:outline-teal-700"
            title={collapsed ? t.adminShell.expandSidebar : t.adminShell.collapseSidebar}
            aria-label={collapsed ? t.adminShell.expandSidebar : t.adminShell.collapseSidebar}
          >
            <CollapseIcon className="w-4 h-4" />
          </button>

          {/* Mobile Close Button */}
          {mobileOpen && onCloseMobile && (
            <button
              onClick={onCloseMobile}
              className="lg:hidden p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center focus-visible:outline-2 focus-visible:outline-teal-700"
              aria-label={t.adminShell.mobileNavClose}
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Navigation Items List */}
        <nav className="space-y-1" aria-label={t.adminShell.tabListLabel}>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectTab(item.id);
                  if (mobileOpen && onCloseMobile) {
                    onCloseMobile();
                  }
                }}
                title={collapsed && !mobileOpen ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer min-h-[44px] focus-visible:outline-2 focus-visible:outline-teal-700 ${
                  isActive
                    ? 'bg-teal-50 text-teal-900 border-s-3 border-teal-700 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                } ${collapsed && !mobileOpen ? 'justify-center px-0' : ''}`}
                aria-current={isActive ? 'page' : undefined}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-teal-700' : 'text-slate-500'}`} />
                {(!collapsed || mobileOpen) && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Sidebar Footer — Switch to Baseline */}
      <div className="p-4 border-t border-slate-100 space-y-2">
        {onSwitchToBaseline && (
          <button
            onClick={onSwitchToBaseline}
            title={collapsed && !mobileOpen ? t.adminShell.backToBaseline : undefined}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-medium text-slate-500 hover:text-slate-900 hover:bg-slate-50 transition cursor-pointer min-h-[44px] focus-visible:outline-2 focus-visible:outline-teal-700 ${
              collapsed && !mobileOpen ? 'justify-center px-0' : ''
            }`}
          >
            <Layers className="w-4 h-4 text-teal-700 shrink-0" />
            {(!collapsed || mobileOpen) && <span className="truncate">{t.adminShell.backToBaseline}</span>}
          </button>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside
        className={`hidden lg:flex bg-white border-e border-slate-200 transition-all duration-200 flex-col justify-between shrink-0 z-20 ${
          collapsed ? 'w-20' : 'w-64'
        }`}
      >
        {sidebarContent}
      </aside>

      {/* Mobile / Tablet Responsive Drawer Overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 flex"
          role="dialog"
          aria-modal="true"
          aria-label={t.adminShell.mobileNavOpen}
        >
          {/* Backdrop Overlay */}
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
            onClick={onCloseMobile}
            aria-hidden="true"
          />

          {/* Drawer Sliding Surface from logical start (right in RTL) */}
          <div
            ref={drawerRef}
            className="relative w-72 max-w-[85vw] h-full shadow-xl bg-white z-10 animate-in slide-in-from-start duration-200"
          >
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
}
