import { useState } from 'react';
import {
  Shield,
  Building2,
  UserCheck,
  Calendar,
  ArrowUpRight,
  Loader2,
  FolderOpen,
  AlertTriangle,
  Ban,
  PanelRight,
  Layers,
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { useAuth } from '../../auth/AuthContext';
import { useI18n } from '../../../lib/i18n/I18nContext';
import { AIRecommendationsCard } from '../../../components/ai/AIRecommendationsCard';
import { TeacherAiCopilotCard } from './TeacherAiCopilotCard';

interface AdminOverviewViewProps {
  onSelectTab: (tab: 'activities' | 'children' | 'teachers' | 'attendance') => void;
  onOpenDrawer?: () => void;
  onOpenSheet?: () => void;
}

type ShellState = 'default' | 'loading' | 'empty' | 'error' | 'disabled';
type ActiveTabKey = 'general' | 'security' | 'audit';

export function AdminOverviewView({ onSelectTab, onOpenDrawer, onOpenSheet }: AdminOverviewViewProps) {
  const { profile, user, activeMembership, activeRole } = useAuth();
  const { t, dir } = useI18n();

  const [inspectedState, setInspectedState] = useState<ShellState>('default');
  const [activeTabKey, setActiveTabKey] = useState<ActiveTabKey>('general');

  // Keyboard navigation for WAI-ARIA Tabs
  const handleTabKeyDown = (e: React.KeyboardEvent, current: ActiveTabKey) => {
    const tabs: ActiveTabKey[] = ['general', 'security', 'audit'];
    const idx = tabs.indexOf(current);

    if (dir === 'rtl') {
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        const prev = idx > 0 ? tabs[idx - 1] : tabs[tabs.length - 1];
        setActiveTabKey(prev);
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        const next = idx < tabs.length - 1 ? tabs[idx + 1] : tabs[0];
        setActiveTabKey(next);
      }
    } else {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        const prev = idx > 0 ? tabs[idx - 1] : tabs[tabs.length - 1];
        setActiveTabKey(prev);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        const next = idx < tabs.length - 1 ? tabs[idx + 1] : tabs[0];
        setActiveTabKey(next);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-teal-800 bg-teal-50 px-2.5 py-1 rounded-full border border-teal-200">
              <Shield className="w-4 h-4 text-teal-700" />
              <span>{t.adminShell.roleBadge}</span>
            </div>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              {t.auth.welcomeBack} - {profile?.full_name || user?.email}
            </h1>
            <p className="text-xs text-slate-600 max-w-2xl leading-relaxed">
              {t.adminShell.subtitle}
            </p>
          </div>

          {/* Active Kindergarten Context Card */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2 min-w-[240px]">
            <div className="flex items-center gap-2 text-teal-800 font-bold border-b border-slate-200 pb-2">
              <Building2 className="w-4 h-4 text-teal-700" />
              <span>{t.adminShell.activeKindergarten}</span>
            </div>
            <div className="text-slate-800 font-mono text-[11px] truncate">
              {activeMembership?.kindergarten_id || t.adminShell.noActiveKindergarten}
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
              <span>{t.common.status}:</span>
              <span className="text-emerald-700 font-bold">{t.common.active}</span>
            </div>
          </div>
        </div>
      </div>

      {/* AI Pedagogical Recommendations Engine Card */}
      <AIRecommendationsCard childName="أدهم الرفاعي (فصل الزهور)" />

      {/* Teacher AI Copilot Card - Classroom Corner Preparation */}
      <TeacherAiCopilotCard />

      {/* Shell Interactive States Inspection Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-teal-700" />
              <span>{t.adminShell.demoStatesTitle}</span>
            </h2>
            <p className="text-xs text-slate-500 pt-1">{t.adminShell.demoStatesDesc}</p>
          </div>

          {/* State Selector Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
            {(['default', 'loading', 'empty', 'error', 'disabled'] as ShellState[]).map((st) => (
              <button
                key={st}
                onClick={() => setInspectedState(st)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer min-h-[36px] focus-visible:outline-2 focus-visible:outline-teal-700 ${
                  inspectedState === st
                    ? 'bg-white text-teal-900 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st === 'default' && t.adminShell.stateDefault}
                {st === 'loading' && t.adminShell.stateLoading}
                {st === 'empty' && t.adminShell.stateEmpty}
                {st === 'error' && t.adminShell.stateError}
                {st === 'disabled' && t.adminShell.stateDisabled}
              </button>
            ))}
          </div>
        </div>

        {/* State Content Rendering */}
        <div className="p-4 sm:p-6 rounded-xl border border-slate-200 bg-slate-50 min-h-[160px] flex items-center justify-center">
          {inspectedState === 'default' && (
            <div className="w-full space-y-4">
              {/* Structural WAI-ARIA Tabs Demonstration */}
              <div className="space-y-3">
                <div
                  role="tablist"
                  aria-label={t.adminShell.tabListLabel}
                  className="flex items-center gap-2 border-b border-slate-200"
                >
                  <button
                    role="tab"
                    id="tab-btn-general"
                    aria-selected={activeTabKey === 'general'}
                    aria-controls="panel-general"
                    tabIndex={activeTabKey === 'general' ? 0 : -1}
                    onClick={() => setActiveTabKey('general')}
                    onKeyDown={(e) => handleTabKeyDown(e, 'general')}
                    className={`pb-2.5 px-3 text-xs font-semibold transition border-b-2 cursor-pointer focus-visible:outline-2 focus-visible:outline-teal-700 ${
                      activeTabKey === 'general'
                        ? 'border-teal-700 text-teal-900 font-bold'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {t.adminShell.tabGeneral}
                  </button>

                  <button
                    role="tab"
                    id="tab-btn-security"
                    aria-selected={activeTabKey === 'security'}
                    aria-controls="panel-security"
                    tabIndex={activeTabKey === 'security' ? 0 : -1}
                    onClick={() => setActiveTabKey('security')}
                    onKeyDown={(e) => handleTabKeyDown(e, 'security')}
                    className={`pb-2.5 px-3 text-xs font-semibold transition border-b-2 cursor-pointer focus-visible:outline-2 focus-visible:outline-teal-700 ${
                      activeTabKey === 'security'
                        ? 'border-teal-700 text-teal-900 font-bold'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {t.adminShell.tabSecurity}
                  </button>

                  <button
                    role="tab"
                    id="tab-btn-audit"
                    aria-selected={activeTabKey === 'audit'}
                    aria-controls="panel-audit"
                    tabIndex={activeTabKey === 'audit' ? 0 : -1}
                    onClick={() => setActiveTabKey('audit')}
                    onKeyDown={(e) => handleTabKeyDown(e, 'audit')}
                    className={`pb-2.5 px-3 text-xs font-semibold transition border-b-2 cursor-pointer focus-visible:outline-2 focus-visible:outline-teal-700 ${
                      activeTabKey === 'audit'
                        ? 'border-teal-700 text-teal-900 font-bold'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {t.adminShell.tabAudit}
                  </button>
                </div>

                {/* Tab Panels */}
                <div
                  role="tabpanel"
                  id="panel-general"
                  aria-labelledby="tab-btn-general"
                  hidden={activeTabKey !== 'general'}
                  tabIndex={0}
                  className="p-4 bg-white rounded-xl border border-slate-200 text-xs text-slate-700 space-y-2"
                >
                  <p className="font-bold text-slate-900">{t.adminShell.platformBrand}</p>
                  <p className="text-slate-600 leading-relaxed">{t.adminShell.subtitle}</p>
                </div>

                <div
                  role="tabpanel"
                  id="panel-security"
                  aria-labelledby="tab-btn-security"
                  hidden={activeTabKey !== 'security'}
                  tabIndex={0}
                  className="p-4 bg-white rounded-xl border border-slate-200 text-xs text-slate-700 space-y-2"
                >
                  <p className="font-bold text-slate-900">{t.adminShell.roleBadge}</p>
                  <p className="text-slate-600 leading-relaxed font-mono">
                    User: {user?.email} · Role: {activeRole}
                  </p>
                </div>

                <div
                  role="tabpanel"
                  id="panel-audit"
                  aria-labelledby="tab-btn-audit"
                  hidden={activeTabKey !== 'audit'}
                  tabIndex={0}
                  className="p-4 bg-white rounded-xl border border-slate-200 text-xs text-slate-700 space-y-2"
                >
                  <p className="font-bold text-slate-900">{t.adminShell.systemStatusActive}</p>
                  <p className="text-slate-600 leading-relaxed">
                    Kindergarten: {activeMembership?.kindergarten_id || 'DEFAULT'}
                  </p>
                </div>
              </div>

              {/* Drawer & Sheet Action Triggers */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                {onOpenDrawer && (
                  <button
                    onClick={onOpenDrawer}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-slate-200 text-slate-800 hover:text-teal-900 hover:border-teal-700 text-xs font-bold transition shadow-xs cursor-pointer min-h-[44px] focus-visible:outline-2 focus-visible:outline-teal-700"
                  >
                    <PanelRight className="w-4 h-4 text-teal-700" />
                    <span>{t.adminShell.openDrawerBtn}</span>
                  </button>
                )}

                {onOpenSheet && (
                  <button
                    onClick={onOpenSheet}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-slate-200 text-slate-800 hover:text-teal-900 hover:border-teal-700 text-xs font-bold transition shadow-xs cursor-pointer min-h-[44px] focus-visible:outline-2 focus-visible:outline-teal-700"
                  >
                    <Layers className="w-4 h-4 text-teal-700" />
                    <span>{t.adminShell.openSheetBtn}</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {inspectedState === 'loading' && (
            <div
              className="flex flex-col items-center gap-3 text-slate-600 py-6"
              role="status"
              aria-live="polite"
              aria-busy="true"
            >
              <Loader2 className="w-8 h-8 text-teal-700 animate-spin" />
              <p className="text-xs font-semibold text-slate-700">{t.adminShell.stateLoadingText}</p>
            </div>
          )}

          {inspectedState === 'empty' && (
            <div className="text-center py-6 space-y-3 max-w-sm">
              <div className="w-12 h-12 rounded-xl bg-slate-200 text-slate-500 mx-auto flex items-center justify-center">
                <FolderOpen className="w-6 h-6" />
              </div>
              <p className="text-xs font-semibold text-slate-700">{t.adminShell.stateEmptyText}</p>
              <button
                disabled
                className="px-4 py-2 bg-slate-200 text-slate-500 text-xs font-semibold rounded-lg cursor-not-allowed"
              >
                {t.adminShell.stateEmptyAction}
              </button>
            </div>
          )}

          {inspectedState === 'error' && (
            <div className="text-center py-6 space-y-3 max-w-sm" role="alert">
              <div className="w-12 h-12 rounded-xl bg-rose-100 text-rose-700 mx-auto flex items-center justify-center">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <p className="text-xs font-semibold text-rose-800">{t.adminShell.stateErrorText}</p>
              <button
                onClick={() => setInspectedState('default')}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold rounded-lg transition shadow-xs cursor-pointer focus-visible:outline-2 focus-visible:outline-rose-700 min-h-[40px]"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>{t.adminShell.stateErrorRetry}</span>
              </button>
            </div>
          )}

          {inspectedState === 'disabled' && (
            <div className="text-center py-6 space-y-3 max-w-md">
              <div className="w-12 h-12 rounded-xl bg-slate-200 text-slate-500 mx-auto flex items-center justify-center">
                <Ban className="w-6 h-6" />
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                {t.adminShell.stateDisabledNotice}
              </p>
              <button
                disabled
                aria-disabled="true"
                className="px-5 py-2.5 rounded-lg bg-slate-200 text-slate-400 text-xs font-bold cursor-not-allowed min-h-[44px]"
              >
                {t.adminShell.stateDisabled}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Navigation Shortcuts Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Activities Shortcut */}
        <button
          onClick={() => onSelectTab('activities')}
          className="p-5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-teal-700 transition text-start space-y-3 cursor-pointer group shadow-xs min-h-[44px] focus-visible:outline-2 focus-visible:outline-teal-700"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center group-hover:scale-105 transition">
              <Calendar className="w-4 h-4" />
            </div>
            <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-teal-700 transition" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 group-hover:text-teal-900 transition">
              {t.adminShell.navActivities}
            </h3>
            <p className="text-[11px] text-slate-500 pt-1">
              {t.adminShell.placeholderTitle}
            </p>
          </div>
        </button>

        {/* Children Shortcut */}
        <button
          onClick={() => onSelectTab('children')}
          className="p-5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-teal-700 transition text-start space-y-3 cursor-pointer group shadow-xs min-h-[44px] focus-visible:outline-2 focus-visible:outline-teal-700"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center group-hover:scale-105 transition">
              <UserCheck className="w-4 h-4" />
            </div>
            <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-teal-700 transition" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 group-hover:text-teal-900 transition">
              {t.adminShell.navChildren}
            </h3>
            <p className="text-[11px] text-slate-500 pt-1">
              {t.adminShell.placeholderTitle}
            </p>
          </div>
        </button>

        {/* Teachers Shortcut */}
        <button
          onClick={() => onSelectTab('teachers')}
          className="p-5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-teal-700 transition text-start space-y-3 cursor-pointer group shadow-xs min-h-[44px] focus-visible:outline-2 focus-visible:outline-teal-700"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center group-hover:scale-105 transition">
              <Shield className="w-4 h-4" />
            </div>
            <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-teal-700 transition" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 group-hover:text-teal-900 transition">
              {t.adminShell.navTeachers}
            </h3>
            <p className="text-[11px] text-slate-500 pt-1">
              {t.adminShell.placeholderTitle}
            </p>
          </div>
        </button>

        {/* Attendance Shortcut */}
        <button
          onClick={() => onSelectTab('attendance')}
          className="p-5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-teal-700 transition text-start space-y-3 cursor-pointer group shadow-xs min-h-[44px] focus-visible:outline-2 focus-visible:outline-teal-700"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center group-hover:scale-105 transition">
              <Building2 className="w-4 h-4" />
            </div>
            <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-teal-700 transition" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 group-hover:text-teal-900 transition">
              {t.adminShell.navAttendance}
            </h3>
            <p className="text-[11px] text-slate-500 pt-1">
              {t.adminShell.placeholderTitle}
            </p>
          </div>
        </button>
      </div>
    </div>
  );
}
