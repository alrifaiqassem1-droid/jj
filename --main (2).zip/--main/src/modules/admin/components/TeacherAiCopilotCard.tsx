import React, { useState } from 'react';
import {
  Sparkles,
  CheckCircle2,
  Layers,
  School,
  Check,
  UserCheck,
  BookOpen
} from 'lucide-react';
import { pedagogicalAiEngine } from '../../../lib/ai/pedagogicalAiEngine';
import { soundService } from '../../../lib/audio/soundEffects';
import { DynamicButton, type ButtonState } from '../../../components/ui/DynamicButton';

interface TeacherAiCopilotCardProps {
  className?: string;
}

export const TeacherAiCopilotCard: React.FC<TeacherAiCopilotCardProps> = ({
  className = '',
}) => {
  const [selectedChild, setSelectedChild] = useState<'adham' | 'sara'>('adham');
  const [buttonState, setButtonState] = useState<ButtonState>('idle');
  const [preparedCorners, setPreparedCorners] = useState<Record<string, boolean>>({});
  const [isApproved, setIsApproved] = useState<boolean>(false);

  const plan = pedagogicalAiEngine.getBridgePlan(selectedChild);

  const toggleMaterial = (material: string) => {
    setPreparedCorners((prev) => ({
      ...prev,
      [material]: !prev[material],
    }));
  };

  const handleApproveCornerPrep = () => {
    if (buttonState !== 'idle') return;

    setButtonState('loading');
    setTimeout(() => {
      // Play cheerful Do-Mi-Sol chime via Web Audio API
      soundService.playCheerfulChime();

      setIsApproved(true);
      setButtonState('success');

      setTimeout(() => {
        setButtonState('idle');
      }, 3000);
    }, 700);
  };

  return (
    <div
      className={`rounded-3xl border border-teal-500/30 bg-gradient-to-br from-slate-900 via-slate-900 to-teal-950/40 p-5 sm:p-6 shadow-xl space-y-4 relative overflow-hidden select-none ${className}`}
      aria-label="مساعد المعلمة الذكي لتحضير أركان الفصل ليوم الغد"
    >
      {/* Decorative ambient aura */}
      <div className="absolute top-0 end-0 w-48 h-48 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-teal-950/80 border border-teal-500/40 text-teal-300 flex items-center justify-center shrink-0 shadow-sm">
            <School className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-bold text-white tracking-tight">
                مساعد المعلمة الذكي (تحضير أركان الغد)
              </h3>
              <span className="text-[10px] text-teal-400 font-bold bg-teal-950 px-2 py-0.5 rounded-full border border-teal-500/30">
                فصل الزهور & النجوم
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              توجيهات صفية مبنية على الملاحظات الميدانية المسجلة اليوم
            </p>
          </div>
        </div>

        {/* Child Selector Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => {
              setSelectedChild('adham');
              setIsApproved(false);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              selectedChild === 'adham'
                ? 'bg-teal-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            أدهم (فصل الزهور)
          </button>
          <button
            type="button"
            onClick={() => {
              setSelectedChild('sara');
              setIsApproved(false);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              selectedChild === 'sara'
                ? 'bg-teal-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            سارة (فصل النجوم)
          </button>
        </div>
      </div>

      {/* Target Learning Corner Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left: Step & Target */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-teal-300 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-teal-400" />
              <span>الركن المستهدف: {plan.teacherPlan.targetCorner}</span>
            </span>
            <span className="text-[10px] text-slate-400 font-mono">ليوم الغد</span>
          </div>

          <p className="text-xs text-slate-200 leading-relaxed bg-slate-900/60 p-3 rounded-xl border border-slate-800/80">
            {plan.teacherPlan.actionStep}
          </p>

          {plan.teacherPlan.suggestedPeerPairing && (
            <div className="flex items-center gap-2 text-[11px] text-slate-400 pt-1">
              <UserCheck className="w-3.5 h-3.5 text-teal-400 shrink-0" />
              <span>{plan.teacherPlan.suggestedPeerPairing}</span>
            </div>
          )}
        </div>

        {/* Right: Materials Checklist */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs font-bold text-slate-200">
            <span className="flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-teal-400" />
              <span>قائمة تجهيز الأدوات المطلوبة للركن:</span>
            </span>
            <span className="text-[10px] text-teal-400 font-mono">
              {Object.values(preparedCorners).filter(Boolean).length} / {plan.teacherPlan.materialsToPrepare.length}
            </span>
          </div>

          <div className="space-y-1.5">
            {plan.teacherPlan.materialsToPrepare.map((material) => {
              const isChecked = !!preparedCorners[material];
              return (
                <div
                  key={material}
                  onClick={() => toggleMaterial(material)}
                  className={`p-2.5 rounded-xl border text-xs flex items-center justify-between cursor-pointer transition ${
                    isChecked
                      ? 'bg-teal-950/40 border-teal-500/50 text-teal-200 line-through'
                      : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <span>{material}</span>
                  <div
                    className={`w-4 h-4 rounded-md border flex items-center justify-center transition-colors ${
                      isChecked
                        ? 'bg-teal-600 border-teal-600 text-white'
                        : 'border-slate-700 bg-slate-950'
                    }`}
                  >
                    {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Action approval footer */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
        <div className="flex items-center gap-2 text-[11px] text-slate-400">
          <Sparkles className="w-3.5 h-3.5 text-teal-400" />
          <span>الذكاء الاصطناعي مساعد صفي خاضع لاعتماد المعلمة الصريح.</span>
        </div>

        <DynamicButton
          state={buttonState}
          variant="primary"
          size="md"
          onClick={handleApproveCornerPrep}
          loadingText="جارٍ تثبيت خطة الركن..."
          successText="تم اعتماد وتجهيز الركن ليوم الغد! ✓"
          icon={<CheckCircle2 className="w-4 h-4 stroke-[2.2]" />}
        >
          {isApproved ? 'الخطة معتمدة بنجاح ✓' : `اعتماد وتجهيز ركن ${plan.childName} ليوم الغد`}
        </DynamicButton>
      </div>
    </div>
  );
};
