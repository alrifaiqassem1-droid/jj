import React from 'react';
import { ShieldAlert, LogIn, ArrowRight, ArrowLeft } from 'lucide-react';
import { useAuth } from '../../auth/AuthContext';
import { useI18n } from '../../../lib/i18n/I18nContext';

interface AdminGuardProps {
  children: React.ReactNode;
  onBackToHome?: () => void;
  onOpenSignIn?: () => void;
}

export function AdminGuard({ children, onBackToHome, onOpenSignIn }: AdminGuardProps) {
  const { user, activeRole, loading } = useAuth();
  const { t, dir } = useI18n();

  const ArrowIcon = dir === 'rtl' ? ArrowRight : ArrowLeft;

  // 1. Loading state
  if (loading) {
    return (
      <div
        className="min-h-screen bg-slate-50 flex items-center justify-center p-6 text-slate-600"
        role="status"
        aria-live="polite"
      >
        <div className="flex flex-col items-center gap-3">
          <div className="w-9 h-9 border-3 border-teal-700 border-t-transparent rounded-full animate-spin" />
          <span className="text-xs font-semibold text-slate-700">{t.common.loading}</span>
        </div>
      </div>
    );
  }

  // 2. Unauthenticated check
  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 text-slate-900">
        <div className="max-w-md w-full bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-5 shadow-lg text-center">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 mx-auto flex items-center justify-center">
            <LogIn className="w-6 h-6" />
          </div>
          <div className="space-y-2">
            <h2 className="text-lg font-bold text-slate-900">{t.adminShell.unauthenticatedTitle}</h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              {t.adminShell.unauthenticatedDesc}
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            {onOpenSignIn && (
              <button
                onClick={onOpenSignIn}
                className="flex-1 min-h-[44px] py-2.5 px-4 bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold rounded-lg transition shadow-sm cursor-pointer flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-teal-700 focus-visible:outline-offset-2"
              >
                <LogIn className="w-4 h-4" />
                <span>{t.auth.signIn}</span>
              </button>
            )}
            {onBackToHome && (
              <button
                onClick={onBackToHome}
                className="flex-1 min-h-[44px] py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-lg transition cursor-pointer flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-slate-400 focus-visible:outline-offset-2"
              >
                <ArrowIcon className="w-4 h-4" />
                <span>{t.adminShell.backToHome}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // 3. Role authorization check (Strict ADMIN / SUPER_ADMIN requirement)
  const isAuthorizedAdmin = activeRole === 'ADMIN' || activeRole === 'SUPER_ADMIN';

  if (!isAuthorizedAdmin) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 text-slate-900">
        <div className="max-w-md w-full bg-white border border-rose-200 rounded-2xl p-6 sm:p-8 space-y-5 shadow-lg text-center">
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-700 mx-auto flex items-center justify-center">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div className="space-y-2">
            <h2 className="text-lg font-bold text-slate-900">{t.adminShell.accessDeniedTitle}</h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              {t.adminShell.accessDeniedDesc}
            </p>
            <div className="pt-2 text-[11px] text-slate-600 font-mono bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              Role: <span className="text-amber-700 font-bold">{activeRole}</span> · User: {user.email}
            </div>
          </div>
          <div className="pt-2">
            {onBackToHome && (
              <button
                onClick={onBackToHome}
                className="w-full min-h-[44px] py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition cursor-pointer flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-slate-400 focus-visible:outline-offset-2"
              >
                <ArrowIcon className="w-4 h-4" />
                <span>{t.adminShell.accessDeniedAction}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // 4. Authorized Admin
  return <>{children}</>;
}
