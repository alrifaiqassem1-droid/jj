import { useState, useRef, useEffect } from 'react';
import {
  Building2,
  Languages,
  LogOut,
  ShieldCheck,
  Menu,
  ChevronLeft,
  ChevronRight,
  CheckCircle2
} from 'lucide-react';
import { useAuth } from '../../auth/AuthContext';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { AdminTab } from './AdminSidebar';
import { AppLogo } from '../../../components/ui/AppLogo';

interface AdminHeaderProps {
  currentTab: AdminTab;
  onOpenMobileNav?: () => void;
  onSelectTab?: (tab: AdminTab) => void;
}

export function AdminHeader({ currentTab, onOpenMobileNav, onSelectTab }: AdminHeaderProps) {
  const { user, profile, activeMembership, activeRole, signOut } = useAuth();
  const { t, locale, setLocale, dir } = useI18n();
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  const BreadcrumbSeparator = dir === 'rtl' ? ChevronLeft : ChevronRight;

  const tabTitles: Record<AdminTab, string> = {
    overview: t.adminShell.navOverview,
    classes: t.classes.title,
    activities: t.adminShell.navActivities,
    children: t.adminShell.navChildren,
    teachers: t.adminShell.navTeachers,
    parents: t.parents.title,
    attendance: t.adminShell.navAttendance,
    reports: t.adminShell.navReports,
    settings: t.adminShell.navSettings,
  };

  // Close dropdown on outside click or Escape key
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setUserMenuOpen(false);
      }
    }

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setUserMenuOpen(false);
      }
    }

    if (userMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [userMenuOpen]);

  const initials = profile?.full_name
    ? profile.full_name
        .split(' ')
        .map((n) => n[0])
        .slice(0, 2)
        .join('')
        .toUpperCase()
    : user?.email
    ? user.email[0].toUpperCase()
    : 'U';

  return (
    <header className="h-16 border-b border-slate-200 bg-white/95 backdrop-blur sticky top-0 z-30 px-4 sm:px-6 flex items-center justify-between gap-3 shadow-xs">
      {/* Start (Right in RTL): Hamburger + Brand + Breadcrumbs */}
      <div className="flex items-center gap-3 min-w-0">
        {/* Mobile Hamburger Menu Toggle */}
        <button
          onClick={onOpenMobileNav}
          className="lg:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 min-h-[44px] min-w-[44px] flex items-center justify-center transition cursor-pointer focus-visible:outline-2 focus-visible:outline-teal-700"
          aria-label={t.adminShell.mobileNavOpen}
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Mobile App Logo Emblem */}
        <div className="lg:hidden flex items-center">
          <AppLogo size="sm" variant="light" showText={false} />
        </div>

        {/* Breadcrumb Navigation Hierarchy */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs text-slate-500 overflow-hidden">
          <button
            onClick={() => onSelectTab && onSelectTab('overview')}
            className="hidden lg:flex items-center gap-1.5 text-slate-700 hover:text-teal-700 font-bold transition cursor-pointer p-1 rounded-lg hover:bg-slate-50"
            title={t.adminShell.breadcrumbHome}
          >
            <AppLogo size="sm" variant="light" showText={false} />
            <span className="text-slate-800">روضة الأدهم</span>
          </button>

          <BreadcrumbSeparator className="w-3.5 h-3.5 text-slate-400 shrink-0 hidden lg:inline" aria-hidden="true" />

          <span className="text-slate-600 font-medium hidden md:inline truncate">
            {t.adminShell.breadcrumbAdmin}
          </span>

          <BreadcrumbSeparator className="w-3.5 h-3.5 text-slate-400 shrink-0 hidden md:inline" aria-hidden="true" />

          {/* Current Page Item */}
          <span className="font-bold text-slate-900 truncate" aria-current="page">
            {tabTitles[currentTab]}
          </span>
        </nav>
      </div>

      {/* End (Left in RTL): Kindergarten Context + Language + User Menu */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Active Kindergarten Context Badge */}
        <div
          className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs shadow-2xs"
          title={activeMembership?.kindergarten_id || t.adminShell.noActiveKindergarten}
        >
          <Building2 className="w-3.5 h-3.5 text-teal-700 shrink-0" />
          <span className="text-slate-500 font-medium">{t.adminShell.activeKindergarten}:</span>
          <span className="text-teal-800 font-mono text-[11px] font-semibold max-w-[130px] truncate">
            {activeMembership?.kindergarten_id ? activeMembership.kindergarten_id.slice(0, 8) + '...' : 'DEFAULT'}
          </span>
        </div>

        {/* Role Badge */}
        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-teal-50 border border-teal-200 text-teal-800 text-xs font-semibold">
          <ShieldCheck className="w-3.5 h-3.5 text-teal-700" />
          <span>{t.adminShell.roleBadge}</span>
        </div>

        {/* Language Switcher */}
        <button
          onClick={() => setLocale(locale === 'ar' ? 'en' : 'ar')}
          className="flex items-center gap-1.5 text-xs text-slate-700 hover:text-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 transition cursor-pointer min-h-[36px] focus-visible:outline-2 focus-visible:outline-teal-700"
          title="تبديل اللغة / Toggle Language"
        >
          <Languages className="w-3.5 h-3.5 text-teal-700" />
          <span className="font-semibold">{t.common.languageToggle}</span>
        </button>

        {/* User Account Popover Area */}
        <div className="relative ps-2 border-s border-slate-200" ref={userMenuRef}>
          <button
            onClick={() => setUserMenuOpen(!userMenuOpen)}
            className="flex items-center gap-2.5 p-1 rounded-xl hover:bg-slate-100 transition cursor-pointer min-h-[44px] focus-visible:outline-2 focus-visible:outline-teal-700"
            aria-expanded={userMenuOpen}
            aria-haspopup="true"
            aria-label={t.adminShell.userMenuOpen}
          >
            <div className="w-8 h-8 rounded-full bg-teal-700 text-white flex items-center justify-center font-bold text-xs shadow-2xs">
              {initials}
            </div>
            <div className="hidden xl:block text-start leading-tight">
              <p className="text-xs font-bold text-slate-900 truncate max-w-[120px]">
                {profile?.full_name || user?.email}
              </p>
              <p className="text-[10px] text-teal-700 font-semibold">{activeRole || 'ADMIN'}</p>
            </div>
          </button>

          {/* User Account Popover Card */}
          {userMenuOpen && (
            <div
              className="absolute end-0 top-full mt-2 w-72 bg-white border border-slate-200 rounded-2xl shadow-lg p-4 space-y-3 z-50 text-slate-900 animate-in fade-in zoom-in-95 duration-150"
              role="menu"
              aria-label={t.adminShell.userMenuOpen}
            >
              <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
                <div className="w-10 h-10 rounded-full bg-teal-50 text-teal-800 flex items-center justify-center font-bold text-sm border border-teal-200">
                  {initials}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-slate-900 truncate">
                    {profile?.full_name || t.adminShell.userProfile}
                  </p>
                  <p className="text-xs text-slate-500 font-mono truncate">{user?.email}</p>
                </div>
              </div>

              {/* Status & Info Items */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="text-slate-500">{t.adminShell.systemStatusLabel}:</span>
                  <div className="flex items-center gap-1 text-emerald-700 font-semibold">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{t.adminShell.systemStatusActive}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="text-slate-500">{t.adminShell.activeKindergarten}:</span>
                  <span className="font-mono text-slate-700 font-semibold text-[11px] truncate max-w-[140px]">
                    {activeMembership?.kindergarten_id ? activeMembership.kindergarten_id.slice(0, 10) + '...' : 'DEFAULT'}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-100 space-y-1.5">
                <button
                  onClick={() => {
                    setUserMenuOpen(false);
                    signOut();
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 transition cursor-pointer min-h-[40px] focus-visible:outline-2 focus-visible:outline-rose-600"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{t.nav.logout}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
