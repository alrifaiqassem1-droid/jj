import { supabase } from '../../lib/supabase/client';
import type { SuperAdminSupportSession } from '../../types/database';

export interface InitiateSupportSessionInput {
  targetKindergartenId: string;
  reason: string;
  durationMinutes?: number;
  scope?: string;
}

export interface SupportSessionResult<T> {
  data: T | null;
  error: Error | null;
  errorCode?: string;
}

/**
 * Service to manage audited SUPER_ADMIN Support Sessions.
 *
 * Invariants:
 * 1. Sessions CANNOT exceed 60 minutes.
 * 2. Reason MUST be at least 30 characters.
 * 3. Cannot be created via direct client INSERT (blocked by RLS).
 * 4. Must invoke audited `rpc_initiate_support_session`.
 */
export async function initiateSupportSession(
  input: InitiateSupportSessionInput
): Promise<SupportSessionResult<SuperAdminSupportSession>> {
  try {
    const trimmedReason = input.reason.trim();
    if (trimmedReason.length < 30) {
      return {
        data: null,
        error: new Error('سبب جلسة الدعم يجب أن يتكون من 30 حرفاً على الأقل'),
        errorCode: 'SESSION_REASON_TOO_SHORT',
      };
    }

    const duration = input.durationMinutes ?? 60;
    if (duration < 1 || duration > 60) {
      return {
        data: null,
        error: new Error('مدة جلسة الدعم يجب أن تكون بين 1 و 60 دقيقة كحد أقصى'),
        errorCode: 'SESSION_DURATION_EXCEEDED',
      };
    }

    const { data, error } = await supabase.rpc('rpc_initiate_support_session', {
      p_target_kindergarten_id: input.targetKindergartenId,
      p_reason: trimmedReason,
      p_duration_minutes: duration,
      p_scope: input.scope || 'EMERGENCY_SUPPORT',
    });

    if (error) {
      let code = 'SERVICE_ERROR';
      if (error.message.includes('SESSION_REASON_TOO_SHORT')) code = 'SESSION_REASON_TOO_SHORT';
      if (error.message.includes('SESSION_DURATION_EXCEEDED')) code = 'SESSION_DURATION_EXCEEDED';
      if (error.message.includes('PERMISSION_DENIED')) code = 'PERMISSION_DENIED';
      if (error.message.includes('KINDERGARTEN_NOT_FOUND')) code = 'KINDERGARTEN_NOT_FOUND';

      return {
        data: null,
        error: new Error(error.message),
        errorCode: code,
      };
    }

    return { data: data as SuperAdminSupportSession, error: null };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'خطأ غير متوقع أثناء بدء جلسة الدعم';
    return { data: null, error: new Error(message), errorCode: 'UNEXPECTED_ERROR' };
  }
}

/**
 * Revokes an existing support session immediately.
 */
export async function revokeSupportSession(
  sessionId: string,
  reason?: string
): Promise<SupportSessionResult<{ success: boolean; sessionId: string }>> {
  try {
    const { error } = await supabase.rpc('rpc_revoke_support_session', {
      p_session_id: sessionId,
      p_revoke_reason: reason || 'Session terminated by operator',
    });

    if (error) {
      return {
        data: null,
        error: new Error(error.message),
        errorCode: 'REVOKE_FAILED',
      };
    }

    return { data: { success: true, sessionId }, error: null };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'خطأ غير متوقع أثناء إنهاء جلسة الدعم';
    return { data: null, error: new Error(message), errorCode: 'UNEXPECTED_ERROR' };
  }
}

/**
 * Fetches the currently active support session for the logged-in super admin and target kindergarten.
 */
export async function getActiveSupportSession(
  targetKindergartenId: string
): Promise<SupportSessionResult<SuperAdminSupportSession | null>> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return { data: null, error: new Error('User not authenticated'), errorCode: 'UNAUTHENTICATED' };
    }

    const { data, error } = await supabase
      .from('super_admin_support_sessions')
      .select('*')
      .eq('target_kindergarten_id', targetKindergartenId)
      .eq('super_admin_id', user.id)
      .eq('is_active', true)
      .gt('expires_at', new Date().toISOString())
      .is('revoked_at', null)
      .maybeSingle();

    if (error) {
      return { data: null, error: new Error(error.message), errorCode: 'FETCH_FAILED' };
    }

    return { data: data as SuperAdminSupportSession | null, error: null };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'خطأ أثناء استرجاع جلسة الدعم النشطة';
    return { data: null, error: new Error(message), errorCode: 'UNEXPECTED_ERROR' };
  }
}
