import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Users2,
  Plus,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Search,
  X,
  Filter,
} from 'lucide-react';
import { useI18n } from '../../lib/i18n/I18nContext';
import { useAuth } from '../auth/AuthContext';
import { supabase } from '../../lib/supabase/client';
import type {
  ChildOption,
  ChildRelationshipItem,
  ParentUserOption,
} from './parentTypes';
import {
  getKindergartenRelationships,
  archiveParentRelationship,
} from './parentRelationshipsService';
import { ChildRelationshipsList } from './components/ChildRelationshipsList';
import { LinkParentDrawer } from './components/LinkParentDrawer';
import { VerifyCustodyDialog } from './components/VerifyCustodyDialog';
import { ArchiveRelationshipDialog } from './components/ArchiveRelationshipDialog';

export type StatusFilter = 'ALL' | 'VERIFIED' | 'UNVERIFIED';

export const ParentsView: React.FC = () => {
  const { t } = useI18n();
  const { activeMembership } = useAuth();
  const activeKindergartenId = activeMembership?.kindergarten_id;

  // Primary Data
  const [relationships, setRelationships] = useState<ChildRelationshipItem[]>([]);
  const [childrenList, setChildrenList] = useState<ChildOption[]>([]);
  const [parentsList, setParentsList] = useState<ParentUserOption[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [serverError, setServerError] = useState<string | null>(null);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('ALL');

  // Drawer / Dialog state
  const [isLinkDrawerOpen, setIsLinkDrawerOpen] = useState<boolean>(false);
  const [verifyTarget, setVerifyTarget] = useState<ChildRelationshipItem | null>(null);
  const [archiveTarget, setArchiveTarget] = useState<ChildRelationshipItem | null>(null);
  const [isArchiving, setIsArchiving] = useState<boolean>(false);

  // Success Toast
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setSuccessToast(msg);
    const timer = setTimeout(() => {
      setSuccessToast(null);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  // Central Data Loader (Single Source of Truth)
  const loadData = useCallback(async () => {
    if (!activeKindergartenId) return;

    setIsLoading(true);
    setServerError(null);

    try {
      // 1. Fetch active children for selection
      const { data: childrenData } = await supabase
        .from('children')
        .select('id, first_name, last_name, class_id')
        .eq('kindergarten_id', activeKindergartenId)
        .is('deleted_at', null)
        .order('first_name');

      const mappedChildren: ChildOption[] = (childrenData ?? []).map((c) => ({
        id: c.id,
        fullName: `${c.first_name} ${c.last_name}`,
      }));
      setChildrenList(mappedChildren);

      // 2. Fetch eligible parent users (memberships with role = 'PARENT' and active)
      const { data: parentMemberships } = await supabase
        .from('kindergarten_memberships')
        .select('user_id')
        .eq('kindergarten_id', activeKindergartenId)
        .eq('role', 'PARENT')
        .eq('is_active', true)
        .is('deleted_at', null);

      if (parentMemberships && parentMemberships.length > 0) {
        const parentUserIds = parentMemberships.map((m) => m.user_id);
        const { data: profiles } = await supabase
          .from('user_profiles')
          .select('id, full_name, phone_number')
          .in('id', parentUserIds)
          .is('deleted_at', null);

        const mappedParents: ParentUserOption[] = (profiles ?? []).map((p) => ({
          userId: p.id,
          fullName: p.full_name,
          phoneNumber: p.phone_number,
        }));
        setParentsList(mappedParents);
      } else {
        setParentsList([]);
      }

      // 3. Fetch relationships via domain service
      const relResult = await getKindergartenRelationships(activeKindergartenId);
      if (relResult.error) {
        const code = relResult.errorCode;
        setServerError(code && t.parents[code] ? t.parents[code] : t.parents.SERVICE_NETWORK_ERROR);
      } else {
        setRelationships(relResult.data ?? []);
      }
    } catch {
      setServerError(t.parents.SERVICE_NETWORK_ERROR);
    } finally {
      setIsLoading(false);
    }
  }, [activeKindergartenId, t]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Filtered Relationships
  const filteredRelationships = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    return relationships.filter((rel) => {
      // Search by parent name, child name, or phone
      const matchesSearch =
        !q ||
        rel.parentName.toLowerCase().includes(q) ||
        rel.childName.toLowerCase().includes(q) ||
        (rel.parentPhone && rel.parentPhone.includes(q));

      // Filter by verification status
      const isVerified = !!rel.verifiedAt;
      const matchesStatus =
        statusFilter === 'ALL' ||
        (statusFilter === 'VERIFIED' && isVerified) ||
        (statusFilter === 'UNVERIFIED' && !isVerified);

      return matchesSearch && matchesStatus;
    });
  }, [relationships, searchQuery, statusFilter]);

  // Handle Archive Confirm
  const handleConfirmArchive = async () => {
    if (!archiveTarget || isArchiving) return;

    setIsArchiving(true);
    const result = await archiveParentRelationship(archiveTarget.id);
    setIsArchiving(false);

    if (result.error) {
      const code = result.errorCode;
      showToast(code && t.parents[code] ? t.parents[code] : t.parents.SERVICE_NETWORK_ERROR);
    } else {
      showToast(t.parents.archiveSuccessMessage);
      setArchiveTarget(null);
      loadData();
    }
  };

  return (
    <div className="w-full">
      {/* Toast Notification */}
      {successToast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed top-6 inset-inline-end-6 z-50 flex items-center gap-2.5 px-4 py-3 bg-teal-900 text-white text-xs font-semibold rounded-xl shadow-xl border border-teal-700 animate-in slide-in-from-top-2 duration-200"
        >
          <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" aria-hidden="true" />
          <span>{successToast}</span>
        </div>
      )}

      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl font-bold text-slate-900">
              {t.parents.title}
            </h1>
            <span className="text-[11px] font-semibold text-teal-800 bg-teal-50 border border-teal-200/60 px-2 py-0.5 rounded-full">
              {t.parents.phaseTag}
            </span>
          </div>
          <p className="text-xs text-slate-500">
            {t.parents.subtitle}
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsLinkDrawerOpen(true)}
          disabled={isLoading || childrenList.length === 0 || parentsList.length === 0}
          className="inline-flex items-center justify-center gap-2 px-4 h-11 rounded-lg text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 transition-colors disabled:opacity-50 shadow-xs shrink-0"
        >
          <Plus className="w-4 h-4" aria-hidden="true" />
          <span>{t.parents.linkParentAction}</span>
        </button>
      </div>

      {/* Toolbar */}
      <div className="bg-white rounded-xl border border-slate-200/80 p-4 mb-6 shadow-xs flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
        {/* Search */}
        <div className="relative flex-1 min-w-[240px]">
          <div className="absolute inset-y-0 inset-inline-start-0 ps-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" aria-hidden="true" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.parents.searchPlaceholder}
            className="w-full h-11 ps-10 pe-10 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none transition-all"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 inset-inline-end-0 pe-3 flex items-center text-slate-400 hover:text-slate-600 focus:outline-none"
            >
              <X className="w-4 h-4" aria-hidden="true" />
            </button>
          )}
        </div>

        {/* Verification Status Filter */}
        <div className="flex items-center gap-3">
          <div className="relative min-w-[160px]">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
              className="w-full h-11 ps-3 pe-8 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 font-medium focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none cursor-pointer transition-all"
            >
              <option value="ALL">{t.parents.filterAllStatus}</option>
              <option value="VERIFIED">{t.parents.filterVerified}</option>
              <option value="UNVERIFIED">{t.parents.filterUnverified}</option>
            </select>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 h-11 bg-teal-50 border border-teal-200/60 rounded-lg text-xs font-semibold text-teal-800">
            <Filter className="w-3.5 h-3.5 text-teal-700" aria-hidden="true" />
            <span>
              {filteredRelationships.length} {t.parents.totalRelationshipsCount}
            </span>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 animate-pulse">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white rounded-xl border border-slate-200 p-5 h-48" />
          ))}
        </div>
      ) : serverError ? (
        <div className="bg-red-50/70 border border-red-200 rounded-2xl p-8 text-center max-w-lg mx-auto my-12">
          <AlertCircle className="w-10 h-10 text-red-600 mx-auto mb-3" aria-hidden="true" />
          <h2 className="text-sm font-bold text-red-900 mb-1">{t.common.error}</h2>
          <p className="text-xs text-red-700 mb-4">{serverError}</p>
          <button
            type="button"
            onClick={loadData}
            className="inline-flex items-center gap-2 px-4 h-9 bg-white border border-red-200 rounded-lg text-xs font-semibold text-red-800 hover:bg-red-50 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{t.parents.retryAction}</span>
          </button>
        </div>
      ) : relationships.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-12 text-center max-w-md mx-auto my-12 shadow-xs">
          <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mx-auto mb-4 border border-teal-100">
            <Users2 className="w-7 h-7" aria-hidden="true" />
          </div>
          <h2 className="text-base font-bold text-slate-900 mb-1.5">
            {t.parents.noRelationshipsTitle}
          </h2>
          <p className="text-xs text-slate-500 leading-relaxed">
            {t.parents.noRelationshipsDesc}
          </p>
        </div>
      ) : filteredRelationships.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-10 text-center max-w-md mx-auto my-10 shadow-xs">
          <p className="text-sm font-semibold text-slate-700 mb-2">
            {t.parents.noSearchResults}
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setStatusFilter('ALL');
            }}
            className="text-xs font-bold text-teal-800 hover:underline"
          >
            {t.parents.clearFilters}
          </button>
        </div>
      ) : (
        <ChildRelationshipsList
          relationships={filteredRelationships}
          onOpenVerify={(rel) => setVerifyTarget(rel)}
          onOpenArchive={(rel) => setArchiveTarget(rel)}
          isActionDisabled={isArchiving}
        />
      )}

      {/* Link Parent Drawer */}
      {activeKindergartenId && (
        <LinkParentDrawer
          isOpen={isLinkDrawerOpen}
          kindergartenId={activeKindergartenId}
          childrenList={childrenList}
          parentsList={parentsList}
          onClose={() => setIsLinkDrawerOpen(false)}
          onSuccess={() => {
            showToast(t.parents.linkSuccessMessage);
            loadData();
          }}
        />
      )}

      {/* Verify Custody Dialog */}
      <VerifyCustodyDialog
        isOpen={!!verifyTarget}
        relationship={verifyTarget}
        onClose={() => setVerifyTarget(null)}
        onSuccess={() => {
          showToast(t.parents.verifySuccessMessage);
          loadData();
        }}
      />

      {/* Archive Relationship Dialog */}
      <ArchiveRelationshipDialog
        isOpen={!!archiveTarget}
        relationship={archiveTarget}
        isSubmitting={isArchiving}
        onConfirm={handleConfirmArchive}
        onClose={() => setArchiveTarget(null)}
      />
    </div>
  );
};
