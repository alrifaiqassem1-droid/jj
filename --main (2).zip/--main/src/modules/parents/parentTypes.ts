import type { RelationshipType, ParentChildRelationship } from '../../types/database';

export type { RelationshipType, ParentChildRelationship };

export interface ChildRelationshipItem {
  id: string;
  kindergartenId: string;
  parentId: string;
  parentName: string;
  parentPhone: string | null;
  parentAvatarUrl: string | null;
  childId: string;
  childName: string;
  childGradeLevel?: string;
  className?: string;
  relationship: RelationshipType;
  isPrimaryContact: boolean;
  authorizedForPickup: boolean;
  verifiedAt: string | null;
  verifiedByAdminId: string | null;
  verifiedByAdminName?: string | null;
  verificationNotes: string | null;
  createdAt: string;
  deletedAt: string | null;
}

export interface ParentUserOption {
  userId: string;
  fullName: string;
  phoneNumber: string | null;
}

export interface ChildOption {
  id: string;
  fullName: string;
  className?: string;
}

export type ParentErrorCode =
  | 'PARENT_NOT_FOUND'
  | 'PARENT_NOT_ELIGIBLE'
  | 'CHILD_NOT_FOUND'
  | 'CHILD_ARCHIVED'
  | 'CROSS_TENANT_CHILD'
  | 'RELATIONSHIP_ALREADY_EXISTS'
  | 'RELATIONSHIP_NOT_FOUND'
  | 'NOT_AUTHORIZED'
  | 'ALREADY_VERIFIED'
  | 'VALIDATION_FAILED'
  | 'SERVICE_NETWORK_ERROR';

export interface ServiceResult<T> {
  data: T | null;
  error: Error | null;
  errorCode?: ParentErrorCode;
}

export interface LinkParentInput {
  child_id: string;
  parent_id: string;
  relationship: RelationshipType;
  is_primary_contact?: boolean;
  authorized_for_pickup?: boolean;
  auto_verify?: boolean;
  verification_notes?: string;
}

export interface UpdateRelationshipInput {
  relationship?: RelationshipType;
  is_primary_contact?: boolean;
  authorized_for_pickup?: boolean;
  verification_notes?: string;
}

export interface VerifyCustodyInput {
  verification_notes?: string;
}
