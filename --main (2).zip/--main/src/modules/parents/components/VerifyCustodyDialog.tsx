import React, { useState, useEffect, useRef } from 'react';
import { ShieldCheck } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { ChildRelationshipItem } from '../parentTypes';
import { verifyParentCustody } from '../parentRelationshipsService';
import { DynamicButton, type ButtonState } from '../../../components/ui/DynamicButton';

interface VerifyCustodyDialogProps {
  isOpen: boolean;
  relationship: ChildRelationshipItem | null;
  onClose: () => void;
  onSuccess: () => void;
}

export const VerifyCustodyDialog: React.FC<VerifyCustodyDialogProps> = ({
  isOpen,
  relationship,
  onClose,
  onSuccess,
}) => {
  const { t } = useI18n();
  const previouslyFocusedElementRef = useRef<HTMLElement | null>(null);

  const [notes, setNotes] = useState<string>('');
  const [buttonState, setButtonState] = useState<ButtonState>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      previouslyFocusedElementRef.current = document.activeElement as HTMLElement | null;
      setNotes(relationship?.verificationNotes ?? '');
      setErrorMessage(null);
      setButtonState('idle');
    } else {
      previouslyFocusedElementRef.current?.focus();
    }
  }, [isOpen, relationship]);

  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape' && buttonState !== 'loading') {
        onClose();
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, buttonState, onClose]);

  const handleVerify = async () => {
    if (!relationship || buttonState !== 'idle') return;

    setButtonState('loading');
    setErrorMessage(null);

    const result = await verifyParentCustody(relationship.id, notes.trim() || undefined);

    if (result.error) {
      setButtonState('idle');
      const code = result.errorCode;
      if (code && t.parents[code]) {
        setErrorMessage(t.parents[code]);
      } else {
        setErrorMessage(t.parents.SERVICE_NETWORK_ERROR);
      }
      return;
    }

    setButtonState('success');
    setTimeout(() => {
      onSuccess();
      onClose();
    }, 700);
  };

  if (!isOpen || !relationship) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="verify-dialog-title"
      aria-describedby="verify-dialog-desc"
    >
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 animate-in zoom-in-95 duration-200">
        <div className="flex items-start gap-4">
          <div className="w-11 h-11 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0 border border-teal-100">
            <ShieldCheck className="w-5 h-5" aria-hidden="true" />
          </div>

          <div className="flex-1">
            <h3 id="verify-dialog-title" className="text-base font-bold text-slate-900">
              {t.parents.verifyCustodyTitle}
            </h3>
            <p id="verify-dialog-desc" className="text-xs text-slate-500 mt-1 leading-relaxed">
              {t.parents.verifyCustodyDesc}
            </p>

            {/* Target Details Badge */}
            <div className="mt-3.5 p-3 bg-slate-50 rounded-lg border border-slate-200/80 text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">{t.parents.selectParentLabel}:</span>
                <span className="font-bold text-slate-900">{relationship.parentName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">{t.parents.selectChildLabel}:</span>
                <span className="font-bold text-teal-800">{relationship.childName}</span>
              </div>
            </div>

            {/* Optional Notes */}
            <div className="mt-4">
              <label htmlFor="verify-notes" className="block text-xs font-semibold text-slate-700 mb-1">
                {t.parents.notesLabel}
              </label>
              <textarea
                id="verify-notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={t.parents.notesPlaceholder}
                disabled={buttonState !== 'idle'}
                rows={2}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none transition-all resize-none"
              />
            </div>

            {errorMessage && (
              <p className="mt-2 text-xs text-red-600 font-medium">{errorMessage}</p>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="mt-6 flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            disabled={buttonState !== 'idle'}
            className="px-4 h-11 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors disabled:opacity-50"
          >
            {t.common.cancel}
          </button>

          <DynamicButton
            type="button"
            state={buttonState}
            variant="primary"
            size="md"
            onClick={handleVerify}
            loadingText={t.parents.verifyingAction}
            successText={t.common.success}
          >
            {t.parents.confirmVerifyAction}
          </DynamicButton>
        </div>
      </div>
    </div>
  );
};
