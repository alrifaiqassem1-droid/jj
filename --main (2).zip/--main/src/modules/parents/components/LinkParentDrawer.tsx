import React, { useState, useEffect, useRef } from 'react';
import { X, Loader2, Link2 } from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type {
  ChildOption,
  ParentUserOption,
  RelationshipType,
} from '../parentTypes';
import { linkParentToChild } from '../parentRelationshipsService';

interface LinkParentDrawerProps {
  isOpen: boolean;
  kindergartenId: string;
  childrenList: ChildOption[];
  parentsList: ParentUserOption[];
  onClose: () => void;
  onSuccess: () => void;
}

export const LinkParentDrawer: React.FC<LinkParentDrawerProps> = ({
  isOpen,
  kindergartenId,
  childrenList,
  parentsList,
  onClose,
  onSuccess,
}) => {
  const { t, dir } = useI18n();
  const containerRef = useRef<HTMLDivElement>(null);
  const previouslyFocusedElementRef = useRef<HTMLElement | null>(null);

  const [selectedChildId, setSelectedChildId] = useState<string>('');
  const [selectedParentId, setSelectedParentId] = useState<string>('');
  const [relationshipType, setRelationshipType] = useState<RelationshipType>('MOTHER');
  const [isPrimaryContact, setIsPrimaryContact] = useState<boolean>(false);
  const [authorizedForPickup, setAuthorizedForPickup] = useState<boolean>(true);
  const [autoVerify, setAutoVerify] = useState<boolean>(true);
  const [verificationNotes, setVerificationNotes] = useState<string>('');

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      previouslyFocusedElementRef.current = document.activeElement as HTMLElement | null;
      setSelectedChildId(childrenList[0]?.id ?? '');
      setSelectedParentId(parentsList[0]?.userId ?? '');
      setRelationshipType('MOTHER');
      setIsPrimaryContact(false);
      setAuthorizedForPickup(true);
      setAutoVerify(true);
      setVerificationNotes('');
      setErrorMessage(null);

      setTimeout(() => {
        containerRef.current?.focus();
      }, 50);
    } else {
      previouslyFocusedElementRef.current?.focus();
    }
  }, [isOpen, childrenList, parentsList]);

  // Focus trap & Escape listener
  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape' && !isSubmitting) {
        onClose();
        return;
      }

      if (event.key === 'Tab' && containerRef.current) {
        const focusable = containerRef.current.querySelectorAll<HTMLElement>(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (focusable.length === 0) return;

        const first = focusable[0];
        const last = focusable[focusable.length - 1];

        if (event.shiftKey) {
          if (document.activeElement === first) {
            last.focus();
            event.preventDefault();
          }
        } else {
          if (document.activeElement === last) {
            first.focus();
            event.preventDefault();
          }
        }
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, isSubmitting, onClose]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedChildId || !selectedParentId || isSubmitting) return;

    setIsSubmitting(true);
    setErrorMessage(null);

    const result = await linkParentToChild(kindergartenId, {
      child_id: selectedChildId,
      parent_id: selectedParentId,
      relationship: relationshipType,
      is_primary_contact: isPrimaryContact,
      authorized_for_pickup: authorizedForPickup,
      auto_verify: autoVerify,
      verification_notes: verificationNotes.trim() || undefined,
    });

    setIsSubmitting(false);

    if (result.error) {
      const code = result.errorCode;
      if (code && t.parents[code]) {
        setErrorMessage(t.parents[code]);
      } else {
        setErrorMessage(t.parents.SERVICE_NETWORK_ERROR);
      }
      return;
    }

    onSuccess();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden"
      role="dialog"
      aria-modal="true"
      aria-labelledby="link-parent-title"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={!isSubmitting ? onClose : undefined}
        aria-hidden="true"
      />

      {/* Logical Drawer Container */}
      <div className="fixed inset-y-0 inset-inline-end-0 flex max-w-full">
        <div
          ref={containerRef}
          tabIndex={-1}
          className={`w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between border-inline-start border-slate-200 animate-in ${
            dir === 'rtl' ? 'slide-in-from-left' : 'slide-in-from-right'
          } duration-300 focus:outline-none`}
        >
          {/* Header */}
          <div className="p-6 border-b border-slate-100 flex items-start justify-between gap-4">
            <div>
              <h2 id="link-parent-title" className="text-lg font-bold text-slate-900">
                {t.parents.linkDrawerTitle}
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                {t.parents.linkDrawerSubtitle}
              </p>
            </div>

            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="w-11 h-11 flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors disabled:opacity-50"
              aria-label={t.parents.closeDrawerAria}
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>

          {/* Form */}
          <form id="link-parent-form" onSubmit={handleSubmit} className="flex-1 p-6 space-y-5 overflow-y-auto">
            {errorMessage && (
              <div className="p-3.5 bg-red-50 border border-red-200 rounded-lg text-xs font-medium text-red-800 animate-in fade-in">
                {errorMessage}
              </div>
            )}

            {/* Select Child */}
            <div>
              <label htmlFor="link-child-select" className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t.parents.selectChildLabel} <span className="text-red-700">*</span>
              </label>
              <select
                id="link-child-select"
                value={selectedChildId}
                onChange={(e) => setSelectedChildId(e.target.value)}
                disabled={isSubmitting}
                className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none transition-all"
                required
              >
                {childrenList.map((child) => (
                  <option key={child.id} value={child.id}>
                    {child.fullName} {child.className ? `(${child.className})` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Select Parent User */}
            <div>
              <label htmlFor="link-parent-select" className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t.parents.selectParentLabel} <span className="text-red-700">*</span>
              </label>
              <select
                id="link-parent-select"
                value={selectedParentId}
                onChange={(e) => setSelectedParentId(e.target.value)}
                disabled={isSubmitting}
                className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none transition-all"
                required
              >
                {parentsList.map((parent) => (
                  <option key={parent.userId} value={parent.userId}>
                    {parent.fullName} {parent.phoneNumber ? `(${parent.phoneNumber})` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Relationship Type */}
            <div>
              <label htmlFor="link-relationship-select" className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t.parents.relationshipTypeLabel} <span className="text-red-700">*</span>
              </label>
              <select
                id="link-relationship-select"
                value={relationshipType}
                onChange={(e) => setRelationshipType(e.target.value as RelationshipType)}
                disabled={isSubmitting}
                className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none transition-all font-medium"
                required
              >
                <option value="MOTHER">{t.parents.relationshipMother}</option>
                <option value="FATHER">{t.parents.relationshipFather}</option>
                <option value="LEGAL_GUARDIAN">{t.parents.relationshipGuardian}</option>
                <option value="GRANDPARENT">{t.parents.relationshipGrandparent}</option>
                <option value="AUTHORIZED_RELATIVE">{t.parents.relationshipRelative}</option>
              </select>
            </div>

            {/* Checkboxes: Primary Contact & Pickup */}
            <div className="space-y-3 pt-2">
              <label className="flex items-start gap-3 p-3 bg-slate-50 border border-slate-200/80 rounded-xl cursor-pointer hover:bg-slate-100/70 transition-colors">
                <input
                  type="checkbox"
                  checked={isPrimaryContact}
                  onChange={(e) => setIsPrimaryContact(e.target.checked)}
                  disabled={isSubmitting}
                  className="mt-0.5 w-4 h-4 text-teal-700 rounded border-slate-300 focus:ring-teal-700 cursor-pointer"
                />
                <div>
                  <span className="text-xs font-bold text-slate-900 block">
                    {t.parents.isPrimaryCheckboxLabel}
                  </span>
                  <span className="text-[11px] text-slate-500 block mt-0.5">
                    {t.parents.isPrimaryCheckboxHelp}
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-3 p-3 bg-slate-50 border border-slate-200/80 rounded-xl cursor-pointer hover:bg-slate-100/70 transition-colors">
                <input
                  type="checkbox"
                  checked={authorizedForPickup}
                  onChange={(e) => setAuthorizedForPickup(e.target.checked)}
                  disabled={isSubmitting}
                  className="mt-0.5 w-4 h-4 text-teal-700 rounded border-slate-300 focus:ring-teal-700 cursor-pointer"
                />
                <div>
                  <span className="text-xs font-bold text-slate-900 block">
                    {t.parents.authorizedPickupCheckboxLabel}
                  </span>
                  <span className="text-[11px] text-slate-500 block mt-0.5">
                    {t.parents.authorizedPickupCheckboxHelp}
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-3 p-3 bg-teal-50/60 border border-teal-200/80 rounded-xl cursor-pointer hover:bg-teal-50 transition-colors">
                <input
                  type="checkbox"
                  checked={autoVerify}
                  onChange={(e) => setAutoVerify(e.target.checked)}
                  disabled={isSubmitting}
                  className="mt-0.5 w-4 h-4 text-teal-700 rounded border-slate-300 focus:ring-teal-700 cursor-pointer"
                />
                <div>
                  <span className="text-xs font-bold text-teal-900 block">
                    {t.parents.autoVerifyCheckboxLabel}
                  </span>
                  <span className="text-[11px] text-teal-700 block mt-0.5">
                    {t.parents.autoVerifyCheckboxHelp}
                  </span>
                </div>
              </label>
            </div>

            {/* Verification Notes */}
            <div>
              <label htmlFor="link-notes" className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t.parents.notesLabel}
              </label>
              <textarea
                id="link-notes"
                value={verificationNotes}
                onChange={(e) => setVerificationNotes(e.target.value)}
                placeholder={t.parents.notesPlaceholder}
                disabled={isSubmitting}
                rows={3}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:bg-white focus:border-teal-700 focus:ring-2 focus:ring-teal-700/20 outline-none transition-all resize-none"
              />
            </div>
          </form>

          {/* Footer */}
          <div className="p-6 border-t border-slate-100 flex items-center justify-end gap-3 bg-slate-50/50">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 h-11 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-200/70 transition-colors disabled:opacity-50"
            >
              {t.common.cancel}
            </button>

            <button
              type="submit"
              form="link-parent-form"
              disabled={isSubmitting || !selectedChildId || !selectedParentId}
              className="inline-flex items-center justify-center gap-2 px-5 h-11 rounded-lg text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 transition-colors disabled:opacity-50 shadow-xs"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                  <span>{t.parents.submittingLinkAction}</span>
                </>
              ) : (
                <>
                  <Link2 className="w-4 h-4" aria-hidden="true" />
                  <span>{t.parents.submitLinkAction}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
