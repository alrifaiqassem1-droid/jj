import React from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Phone,
  User,
  Star,
  Car,
  Trash2,
} from 'lucide-react';
import { useI18n } from '../../../lib/i18n/I18nContext';
import type { ChildRelationshipItem } from '../parentTypes';

interface ChildRelationshipsListProps {
  relationships: ChildRelationshipItem[];
  onOpenVerify: (rel: ChildRelationshipItem) => void;
  onOpenArchive: (rel: ChildRelationshipItem) => void;
  isActionDisabled?: boolean;
}

export const ChildRelationshipsList: React.FC<ChildRelationshipsListProps> = ({
  relationships,
  onOpenVerify,
  onOpenArchive,
  isActionDisabled = false,
}) => {
  const { t } = useI18n();

  const getRelationshipLabel = (type: string) => {
    switch (type) {
      case 'MOTHER':
        return t.parents.relationshipMother;
      case 'FATHER':
        return t.parents.relationshipFather;
      case 'LEGAL_GUARDIAN':
        return t.parents.relationshipGuardian;
      case 'GRANDPARENT':
        return t.parents.relationshipGrandparent;
      case 'AUTHORIZED_RELATIVE':
        return t.parents.relationshipRelative;
      default:
        return type;
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
      {relationships.map((rel) => {
        const isVerified = !!rel.verifiedAt;

        return (
          <div
            key={rel.id}
            className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
          >
            <div>
              {/* Header: Parent Avatar & Info */}
              <div className="flex items-start gap-3.5 mb-4">
                <div className="w-12 h-12 rounded-full bg-teal-100 border border-teal-200/80 text-teal-800 font-bold flex items-center justify-center shrink-0">
                  {rel.parentAvatarUrl ? (
                    <img
                      src={rel.parentAvatarUrl}
                      alt={rel.parentName}
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <User className="w-6 h-6 text-teal-800" aria-hidden="true" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h3 className="text-base font-bold text-slate-900 truncate">
                      {rel.parentName}
                    </h3>
                    <span className="text-[11px] font-semibold text-teal-800 bg-teal-50 border border-teal-200/60 px-2 py-0.5 rounded-full">
                      {getRelationshipLabel(rel.relationship)}
                    </span>
                  </div>

                  {rel.parentPhone && (
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
                      <bdi className="font-mono text-slate-600">{rel.parentPhone}</bdi>
                    </div>
                  )}
                </div>
              </div>

              {/* Linked Child Info */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/70 mb-3.5">
                <span className="text-[11px] text-slate-500 block mb-0.5">
                  {t.parents.selectChildLabel}:
                </span>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">
                    {rel.childName}
                  </span>
                  {rel.className && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 text-slate-700 font-medium">
                      {rel.className}
                    </span>
                  )}
                </div>
              </div>

              {/* Badges: Primary Contact & Pickup */}
              <div className="flex flex-wrap gap-1.5 mb-3.5">
                {rel.isPrimaryContact && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200/60">
                    <Star className="w-3 h-3 text-teal-700" aria-hidden="true" />
                    {t.parents.primaryContactBadge}
                  </span>
                )}
                {rel.authorizedForPickup && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-800 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-200/60">
                    <Car className="w-3 h-3 text-indigo-700" aria-hidden="true" />
                    {t.parents.authorizedPickupBadge}
                  </span>
                )}
              </div>

              {/* Custody Verification Status */}
              <div className="pt-3 border-t border-slate-100">
                {isVerified ? (
                  <div className="flex items-start gap-2 text-xs text-teal-800 bg-teal-50/70 p-2.5 rounded-lg border border-teal-200/50">
                    <ShieldCheck className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" aria-hidden="true" />
                    <div className="min-w-0 flex-1">
                      <span className="font-bold block">{t.parents.verifiedBadge}</span>
                      {rel.verifiedByAdminName && (
                        <span className="text-[10px] text-slate-500 block mt-0.5">
                          {t.parents.verifiedByLabel} {rel.verifiedByAdminName}
                        </span>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start gap-2 text-xs text-amber-800 bg-amber-50/70 p-2.5 rounded-lg border border-amber-200/60">
                    <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" aria-hidden="true" />
                    <div className="min-w-0 flex-1">
                      <span className="font-bold block">{t.parents.pendingVerificationBadge}</span>
                      <button
                        type="button"
                        onClick={() => onOpenVerify(rel)}
                        disabled={isActionDisabled}
                        className="text-[11px] font-bold text-teal-800 hover:underline mt-1 block"
                      >
                        {t.parents.confirmVerifyAction}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Footer Actions */}
            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[10px] text-slate-400">
                {new Date(rel.createdAt).toLocaleDateString()}
              </span>

              <button
                type="button"
                onClick={() => onOpenArchive(rel)}
                disabled={isActionDisabled}
                className="inline-flex items-center gap-1.5 px-2.5 h-8 rounded-lg text-xs font-semibold text-red-700 hover:bg-red-50 transition-colors disabled:opacity-50"
                aria-label={t.parents.archiveDialogTitle}
              >
                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t.parents.confirmArchiveAction}</span>
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
};
