import { z } from 'zod';

export const relationshipTypeSchema = z.enum([
  'MOTHER',
  'FATHER',
  'LEGAL_GUARDIAN',
  'GRANDPARENT',
  'AUTHORIZED_RELATIVE',
]);

export const linkParentSchema = z.object({
  child_id: z.string().uuid({ message: 'INVALID_CHILD_ID' }),
  parent_id: z.string().uuid({ message: 'INVALID_PARENT_ID' }),
  relationship: relationshipTypeSchema,
  is_primary_contact: z.boolean().default(false),
  authorized_for_pickup: z.boolean().default(false),
  auto_verify: z.boolean().default(false),
  verification_notes: z.string().max(500).optional(),
});

export const updateRelationshipSchema = z.object({
  relationship: relationshipTypeSchema.optional(),
  is_primary_contact: z.boolean().optional(),
  authorized_for_pickup: z.boolean().optional(),
  verification_notes: z.string().max(500).optional(),
});

export const verifyCustodySchema = z.object({
  verification_notes: z.string().max(500).optional(),
});

export type ValidatedLinkParentInput = z.infer<typeof linkParentSchema>;
export type ValidatedUpdateRelationshipInput = z.infer<typeof updateRelationshipSchema>;
export type ValidatedVerifyCustodyInput = z.infer<typeof verifyCustodySchema>;
