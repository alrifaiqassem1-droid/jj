import { supabase } from '../../lib/supabase/client';
import type {
  ChildRelationshipItem,
  LinkParentInput,
  ParentChildRelationship,
  ParentErrorCode,
  ServiceResult,
  UpdateRelationshipInput,
} from './parentTypes';
import {
  linkParentSchema,
  updateRelationshipSchema,
  verifyCustodySchema,
} from './parentValidation';

/**
 * Normalizes PostgreSQL and Supabase errors to domain-specific error codes.
 */
function normalizePostgresError(error: { code?: string; message: string }): ParentErrorCode {
  if (error.code === '23505' || error.message.includes('unique_parent_child')) {
    return 'RELATIONSHIP_ALREADY_EXISTS';
  }
  if (error.code === '42501' || error.message.includes('row-level security')) {
    return 'NOT_AUTHORIZED';
  }
  return 'SERVICE_NETWORK_ERROR';
}

/**
 * Fetches all active parent-child relationships for a kindergarten with joined profiles and child info.
 */
export async function getKindergartenRelationships(
  kindergartenId: string
): Promise<ServiceResult<ChildRelationshipItem[]>> {
  try {
    // 1. Fetch relationships for this kindergarten
    const { data: relationships, error: relError } = await supabase
      .from('parent_child_relationships')
      .select('*')
      .eq('kindergarten_id', kindergartenId)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (relError) {
      return {
        data: null,
        error: new Error(relError.message),
        errorCode: normalizePostgresError(relError),
      };
    }

    if (!relationships || relationships.length === 0) {
      return { data: [], error: null };
    }

    const parentIds = Array.from(new Set(relationships.map((r) => r.parent_id)));
    const childIds = Array.from(new Set(relationships.map((r) => r.child_id)));
    const adminIds = Array.from(
      new Set(
        relationships
          .map((r) => r.verified_by_admin_id)
          .filter((id): id is string => typeof id === 'string')
      )
    );

    // 2. Fetch parent user profiles
    const { data: parentProfiles } = await supabase
      .from('user_profiles')
      .select('id, full_name, phone_number, avatar_url')
      .in('id', parentIds);

    const parentMap = new Map((parentProfiles ?? []).map((p) => [p.id, p]));

    // 3. Fetch admin user profiles
    let adminMap = new Map<string, string>();
    if (adminIds.length > 0) {
      const { data: adminProfiles } = await supabase
        .from('user_profiles')
        .select('id, full_name')
        .in('id', adminIds);
      adminMap = new Map((adminProfiles ?? []).map((a) => [a.id, a.full_name]));
    }

    // 4. Fetch children info
    const { data: childrenData } = await supabase
      .from('children')
      .select('id, first_name, last_name, class_id')
      .in('id', childIds)
      .is('deleted_at', null);

    const childMap = new Map((childrenData ?? []).map((c) => [c.id, c]));

    // 5. Fetch classes info
    const classIds = Array.from(
      new Set((childrenData ?? []).map((c) => c.class_id).filter(Boolean))
    );
    let classMap = new Map<string, { name: string; grade_level: string }>();
    if (classIds.length > 0) {
      const { data: classesData } = await supabase
        .from('classes')
        .select('id, name, grade_level')
        .in('id', classIds);
      classMap = new Map((classesData ?? []).map((c) => [c.id, c]));
    }

    // 6. Map to unified domain item
    const items: ChildRelationshipItem[] = relationships.map((r) => {
      const parent = parentMap.get(r.parent_id);
      const child = childMap.get(r.child_id);
      const classInfo = child?.class_id ? classMap.get(child.class_id) : undefined;
      const childFullName = child ? `${child.first_name} ${child.last_name}` : 'طفل غير مسمى';

      return {
        id: r.id,
        kindergartenId: r.kindergarten_id,
        parentId: r.parent_id,
        parentName: parent?.full_name ?? 'ولي أمر غير معروف',
        parentPhone: parent?.phone_number ?? null,
        parentAvatarUrl: parent?.avatar_url ?? null,
        childId: r.child_id,
        childName: childFullName,
        childGradeLevel: classInfo?.grade_level,
        className: classInfo?.name,
        relationship: r.relationship,
        isPrimaryContact: r.is_primary_contact,
        authorizedForPickup: r.authorized_for_pickup,
        verifiedAt: r.verified_at,
        verifiedByAdminId: r.verified_by_admin_id,
        verifiedByAdminName: r.verified_by_admin_id ? adminMap.get(r.verified_by_admin_id) : null,
        verificationNotes: r.verification_notes,
        createdAt: r.created_at,
        deletedAt: r.deleted_at,
      };
    });

    return { data: items, error: null };
  } catch (err) {
    const errorObj = err instanceof Error ? err : new Error(String(err));
    return {
      data: null,
      error: errorObj,
      errorCode: 'SERVICE_NETWORK_ERROR',
    };
  }
}

/**
 * Fetches relationships specifically for a single child.
 */
export async function getChildRelationships(
  kindergartenId: string,
  childId: string
): Promise<ServiceResult<ChildRelationshipItem[]>> {
  const result = await getKindergartenRelationships(kindergartenId);
  if (result.error || !result.data) {
    return result;
  }
  const filtered = result.data.filter((r) => r.childId === childId);
  return { data: filtered, error: null };
}

/**
 * Links an eligible parent to a child in the target kindergarten.
 *
 * Enforces:
 * 1. Schema validation (Zod).
 * 2. SECURITY CONSTRAINT #1: Child exists, is active, and child.kindergarten_id === target kindergartenId.
 * 3. SECURITY CONSTRAINT #2: Parent exists, is active, and holds role = 'PARENT' in kindergarten_memberships.
 * 4. SECURITY CONSTRAINT #3: Uniqueness check for (parent_id, child_id).
 */
export async function linkParentToChild(
  kindergartenId: string,
  input: LinkParentInput
): Promise<ServiceResult<ParentChildRelationship>> {
  // 1. Zod Schema Validation
  const parseResult = linkParentSchema.safeParse(input);
  if (!parseResult.success) {
    return {
      data: null,
      error: new Error(parseResult.error.message),
      errorCode: 'VALIDATION_FAILED',
    };
  }

  const {
    child_id,
    parent_id,
    relationship,
    is_primary_contact,
    authorized_for_pickup,
    auto_verify,
    verification_notes,
  } = parseResult.data;

  try {
    // 2. SECURITY CONSTRAINT #1: Child verification & Tenant consistency
    const { data: child, error: childError } = await supabase
      .from('children')
      .select('id, kindergarten_id, deleted_at')
      .eq('id', child_id)
      .maybeSingle();

    if (childError || !child) {
      return {
        data: null,
        error: new Error('CHILD_NOT_FOUND'),
        errorCode: 'CHILD_NOT_FOUND',
      };
    }

    if (child.deleted_at !== null) {
      return {
        data: null,
        error: new Error('CHILD_ARCHIVED'),
        errorCode: 'CHILD_ARCHIVED',
      };
    }

    if (child.kindergarten_id !== kindergartenId) {
      return {
        data: null,
        error: new Error('CROSS_TENANT_CHILD'),
        errorCode: 'CROSS_TENANT_CHILD',
      };
    }

    // 3. SECURITY CONSTRAINT #2: Parent eligibility verification
    const { data: parentMembership, error: membershipError } = await supabase
      .from('kindergarten_memberships')
      .select('id, role, is_active, deleted_at')
      .eq('kindergarten_id', kindergartenId)
      .eq('user_id', parent_id)
      .eq('role', 'PARENT')
      .eq('is_active', true)
      .is('deleted_at', null)
      .maybeSingle();

    if (membershipError || !parentMembership) {
      return {
        data: null,
        error: new Error('PARENT_NOT_ELIGIBLE'),
        errorCode: 'PARENT_NOT_ELIGIBLE',
      };
    }

    // 4. SECURITY CONSTRAINT #3: Uniqueness check
    const { data: existingRel } = await supabase
      .from('parent_child_relationships')
      .select('id, deleted_at')
      .eq('parent_id', parent_id)
      .eq('child_id', child_id)
      .maybeSingle();

    if (existingRel) {
      if (existingRel.deleted_at === null) {
        return {
          data: null,
          error: new Error('RELATIONSHIP_ALREADY_EXISTS'),
          errorCode: 'RELATIONSHIP_ALREADY_EXISTS',
        };
      }
      // If previously soft-deleted, reactivate and update
      const { data: userData } = await supabase.auth.getUser();
      const currentAdminId = userData?.user?.id ?? null;

      const { data: reactivated, error: reactivateError } = await supabase
        .from('parent_child_relationships')
        .update({
          relationship,
          is_primary_contact,
          authorized_for_pickup,
          verification_notes: verification_notes ?? null,
          verified_at: auto_verify ? new Date().toISOString() : null,
          verified_by_admin_id: auto_verify ? currentAdminId : null,
          deleted_at: null,
        })
        .eq('id', existingRel.id)
        .select()
        .single();

      if (reactivateError) {
        return {
          data: null,
          error: new Error(reactivateError.message),
          errorCode: normalizePostgresError(reactivateError),
        };
      }

      return { data: reactivated as ParentChildRelationship, error: null };
    }

    // 5. Insert new relationship
    const { data: userData } = await supabase.auth.getUser();
    const currentAdminId = userData?.user?.id ?? null;

    const { data: inserted, error: insertError } = await supabase
      .from('parent_child_relationships')
      .insert({
        kindergarten_id: kindergartenId,
        child_id,
        parent_id,
        relationship,
        is_primary_contact,
        authorized_for_pickup,
        verification_notes: verification_notes ?? null,
        verified_at: auto_verify ? new Date().toISOString() : null,
        verified_by_admin_id: auto_verify ? currentAdminId : null,
      })
      .select()
      .single();

    if (insertError) {
      return {
        data: null,
        error: new Error(insertError.message),
        errorCode: normalizePostgresError(insertError),
      };
    }

    return { data: inserted as ParentChildRelationship, error: null };
  } catch (err) {
    const errorObj = err instanceof Error ? err : new Error(String(err));
    return {
      data: null,
      error: errorObj,
      errorCode: 'SERVICE_NETWORK_ERROR',
    };
  }
}

/**
 * Formally signs and verifies a parent custody relationship by an authorized ADMIN.
 * Activates auth.is_parent_of_child() permission gate in PostgreSQL RLS.
 */
export async function verifyParentCustody(
  relationshipId: string,
  verificationNotes?: string
): Promise<ServiceResult<ParentChildRelationship>> {
  const parseResult = verifyCustodySchema.safeParse({ verification_notes: verificationNotes });
  if (!parseResult.success) {
    return {
      data: null,
      error: new Error(parseResult.error.message),
      errorCode: 'VALIDATION_FAILED',
    };
  }

  try {
    // 1. Check existing relationship state
    const { data: current, error: fetchError } = await supabase
      .from('parent_child_relationships')
      .select('id, verified_at, deleted_at')
      .eq('id', relationshipId)
      .maybeSingle();

    if (fetchError || !current) {
      return {
        data: null,
        error: new Error('RELATIONSHIP_NOT_FOUND'),
        errorCode: 'RELATIONSHIP_NOT_FOUND',
      };
    }

    if (current.verified_at !== null) {
      return {
        data: null,
        error: new Error('ALREADY_VERIFIED'),
        errorCode: 'ALREADY_VERIFIED',
      };
    }

    // 2. Identify the active verifying admin
    const { data: authData } = await supabase.auth.getUser();
    const adminId = authData?.user?.id;
    if (!adminId) {
      return {
        data: null,
        error: new Error('NOT_AUTHORIZED'),
        errorCode: 'NOT_AUTHORIZED',
      };
    }

    // 3. Update verification timestamp and admin signature
    const { data: verified, error: updateError } = await supabase
      .from('parent_child_relationships')
      .update({
        verified_at: new Date().toISOString(),
        verified_by_admin_id: adminId,
        verification_notes: verificationNotes ?? null,
      })
      .eq('id', relationshipId)
      .select()
      .single();

    if (updateError) {
      return {
        data: null,
        error: new Error(updateError.message),
        errorCode: normalizePostgresError(updateError),
      };
    }

    return { data: verified as ParentChildRelationship, error: null };
  } catch (err) {
    const errorObj = err instanceof Error ? err : new Error(String(err));
    return {
      data: null,
      error: errorObj,
      errorCode: 'SERVICE_NETWORK_ERROR',
    };
  }
}

/**
 * Updates relationship parameters (contact, pickup, notes, or relationship type).
 */
export async function updateRelationshipDetails(
  relationshipId: string,
  input: UpdateRelationshipInput
): Promise<ServiceResult<ParentChildRelationship>> {
  const parseResult = updateRelationshipSchema.safeParse(input);
  if (!parseResult.success) {
    return {
      data: null,
      error: new Error(parseResult.error.message),
      errorCode: 'VALIDATION_FAILED',
    };
  }

  try {
    const { data: updated, error: updateError } = await supabase
      .from('parent_child_relationships')
      .update(parseResult.data)
      .eq('id', relationshipId)
      .select()
      .single();

    if (updateError) {
      return {
        data: null,
        error: new Error(updateError.message),
        errorCode: normalizePostgresError(updateError),
      };
    }

    return { data: updated as ParentChildRelationship, error: null };
  } catch (err) {
    const errorObj = err instanceof Error ? err : new Error(String(err));
    return {
      data: null,
      error: errorObj,
      errorCode: 'SERVICE_NETWORK_ERROR',
    };
  }
}

/**
 * Soft-deletes / archives a custody relationship.
 * Instantly revokes parent child access via auth.is_parent_of_child() without physical data loss.
 */
export async function archiveParentRelationship(
  relationshipId: string
): Promise<ServiceResult<{ archived: boolean }>> {
  try {
    const { error: archiveError } = await supabase
      .from('parent_child_relationships')
      .update({ deleted_at: new Date().toISOString() })
      .eq('id', relationshipId);

    if (archiveError) {
      return {
        data: null,
        error: new Error(archiveError.message),
        errorCode: normalizePostgresError(archiveError),
      };
    }

    return { data: { archived: true }, error: null };
  } catch (err) {
    const errorObj = err instanceof Error ? err : new Error(String(err));
    return {
      data: null,
      error: errorObj,
      errorCode: 'SERVICE_NETWORK_ERROR',
    };
  }
}
