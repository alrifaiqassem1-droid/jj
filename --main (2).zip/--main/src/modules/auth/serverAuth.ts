import { z } from 'zod';
import type { AppRole, StaffPermission } from '../../types/database';

export const sessionUserSchema = z.object({
  id: z.string().uuid(),
  email: z.string().email(),
  role: z.enum(['SUPER_ADMIN', 'ADMIN', 'TEACHER', 'STAFF', 'PARENT'] as const),
  kindergartenId: z.string().uuid().optional(),
  permissions: z.array(z.string()).default([]),
});

export type SessionUser = z.infer<typeof sessionUserSchema>;

export interface AuthContextState {
  isAuthenticated: boolean;
  user: SessionUser | null;
  activeKindergartenId: string | null;
  isLoading: boolean;
}

/**
 * Server-Side Session Token Extractor
 * Validates JWT Bearer format without exposing secrets.
 */
export function extractBearerToken(authHeader: string | undefined): string | null {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.substring(7).trim();
  return token.length > 0 ? token : null;
}

/**
 * Authority Guard for Server Route Handlers
 */
export function assertPermission(
  userRole: AppRole,
  userPermissions: StaffPermission[],
  requiredPermission: StaffPermission
): boolean {
  if (userRole === 'ADMIN' || userRole === 'SUPER_ADMIN') {
    return true;
  }
  return userPermissions.includes(requiredPermission);
}
