import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import type { User } from '@supabase/supabase-js';
import { supabase } from '../../lib/supabase/client';
import type { UserProfile, KindergartenMembership, AppRole } from '../../types/database';

export interface AuthContextValue {
  user: User | null;
  profile: UserProfile | null;
  memberships: KindergartenMembership[];
  activeMembership: KindergartenMembership | null;
  activeRole: AppRole | 'GUEST';
  loading: boolean;
  error: string | null;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signUp: (email: string, password: string, fullName: string, phone?: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  claimInvitation: (tokenHash: string) => Promise<{ success: boolean; code?: string; message?: string }>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [memberships, setMemberships] = useState<KindergartenMembership[]>([]);
  const [activeMembership, setActiveMembership] = useState<KindergartenMembership | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchUserData = useCallback(async (userId: string) => {
    try {
      // 1. Fetch user_profiles (auto-provisioned by Migration 00004)
      const { data: profileData, error: profileErr } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (!profileErr && profileData) {
        setProfile(profileData as UserProfile);
      }

      // 2. Fetch memberships
      const { data: membershipData, error: membershipErr } = await supabase
        .from('kindergarten_memberships')
        .select('*')
        .eq('user_id', userId)
        .eq('is_active', true);

      if (!membershipErr && membershipData) {
        setMemberships(membershipData as KindergartenMembership[]);
        if (membershipData.length > 0) {
          setActiveMembership(membershipData[0] as KindergartenMembership);
        } else {
          setActiveMembership(null);
        }
      }
    } catch (err: unknown) {
      console.warn('Profile fetch encountered network or config limitation:', err);
    }
  }, []);

  useEffect(() => {
    let isMounted = true;

    async function initAuth() {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user && isMounted) {
          setUser(session.user);
          await fetchUserData(session.user.id);
        }
      } catch (err: unknown) {
        console.warn('Initial session lookup caught (mock/placeholder env):', err);
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    }

    initAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (!isMounted) return;
      if (session?.user) {
        setUser(session.user);
        await fetchUserData(session.user.id);
      } else {
        setUser(null);
        setProfile(null);
        setMemberships([]);
        setActiveMembership(null);
      }
      setLoading(false);
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, [fetchUserData]);

  const signIn = async (email: string, password: string) => {
    setError(null);
    try {
      const { data, error: signInErr } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (signInErr) {
        setError(signInErr.message);
        return { success: false, error: signInErr.message };
      }

      if (data.user) {
        setUser(data.user);
        await fetchUserData(data.user.id);
      }
      return { success: true };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطأ أثناء تسجيل الدخول';
      setError(msg);
      return { success: false, error: msg };
    }
  };

  const signUp = async (email: string, password: string, fullName: string, phone?: string) => {
    setError(null);
    try {
      const { data, error: signUpErr } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: {
            full_name: fullName.trim(),
            name: fullName.trim(),
            phone: phone ? phone.trim() : undefined,
            preferred_language: 'ar',
          },
        },
      });

      if (signUpErr) {
        setError(signUpErr.message);
        return { success: false, error: signUpErr.message };
      }

      if (data.user) {
        setUser(data.user);
        await fetchUserData(data.user.id);
      }
      return { success: true };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطأ أثناء إنشاء الحساب';
      setError(msg);
      return { success: false, error: msg };
    }
  };

  const signOut = async () => {
    setError(null);
    try {
      await supabase.auth.signOut();
    } catch (err: unknown) {
      console.warn('Sign out error:', err);
    } finally {
      setUser(null);
      setProfile(null);
      setMemberships([]);
      setActiveMembership(null);
    }
  };

  const claimInvitation = async (tokenHash: string) => {
    try {
      const { data, error: rpcErr } = await supabase.rpc('claim_parent_invitation', {
        p_token_hash: tokenHash.trim(),
        p_ip_address: null,
        p_user_agent: typeof navigator !== 'undefined' ? navigator.userAgent : null,
      });

      if (rpcErr) {
        return { success: false, message: rpcErr.message };
      }

      if (user) {
        await fetchUserData(user.id);
      }

      return data as { success: boolean; code?: string; message?: string };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطأ أثناء معالجة الدعوة';
      return { success: false, message: msg };
    }
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchUserData(user.id);
    }
  };

  const activeRole: AppRole | 'GUEST' = activeMembership ? activeMembership.role : 'GUEST';

  const value: AuthContextValue = {
    user,
    profile,
    memberships,
    activeMembership,
    activeRole,
    loading,
    error,
    signIn,
    signUp,
    signOut,
    claimInvitation,
    refreshProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
