# Rawdaty Smart (روضتي الذكية) — Cryptographic Invitation & Identity Verification Lifecycle (V4 Remediated)

**Document Version:** 4.1.0-REMEDIATED  
**Specification:** Finite State Machine for Tokenized Onboarding & Custody Verification  
**Standard Compliance:** Zero-Trust, Anti-Account-Takeover, Anti-Token-Replay, Saudi PDPL Compliant  
**Canonical Registry Reference:** Fully synchronized with `FINAL_ENTITY_REGISTRY.md` (Entities 10 & 11)

---

## 1. The Core Triad: Three Separate Security Concepts

In early childhood platforms, conflating link delivery with legal custody is a catastrophic design flaw. Rawdaty Smart strictly separates three distinct operational concepts:

```
+-----------------------------------------------------------------------------------+
| 1. INVITATION TOKEN POSSESSION                                                    |
| - Proves only that the client possesses the 256-bit entropy token.                |
| - Conveys ZERO rights to child data, zero legal identity, and zero authorization.  |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
| 2. ACCOUNT AUTHENTICATION                                                         |
| - Proves control over user credentials in Supabase Auth (email, password / OTP).  |
| - Enforces strict email matching between account email and target_email.          |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
| 3. IDENTITY & CUSTODY VERIFICATION                                                |
| - Offline / administrative inspection of official government documents.           |
| - Executed by kindergarten administration; sets verified_at in database.          |
| - ONLY this final step unlocks access to child records.                           |
+-----------------------------------------------------------------------------------+
```

---

## 2. Finite State Machine (FSM) Lifecycle

The lifecycle follows strict, unidirectional state transitions:

```
[ CREATED ] ─── (Admin creates token pre-bound to kindergarten_id, child_id, target_email)
     │
     v
[ OPENED ] ─── (Recipient clicks link; token hash verified, displays invitation screen)
     │
     v
[ ACCOUNT_CREATED ] ─── (Recipient signs up or signs in; email matched against target_email)
     │
     v
[ IDENTITY_VERIFICATION_PENDING ] ─── (Token claimed; parent account linked, but ACCESS LOCKED)
     │
     v
[ CLAIMED ] ─── (Kindergarten Admin validates National ID; verified_at set; ACCESS UNLOCKED)
     │
     ├── [ REVOKED ] ─── (Admin revokes token prior to claim or verification)
     └── [ EXPIRED ] ─── (Time-to-live expired; default 48 hours)
```

### Transition Table

| Current State | Event / Trigger | Target State | Permitted Actor | Prerequisite Conditions |
|---|---|---|---|---|
| `CREATED` | Link clicked / Landing page loaded | `OPENED` | Anonymous Recipient | Hash matches, not expired, not revoked |
| `OPENED` | Auth session established | `ACCOUNT_CREATED` | Authenticated User | Auth UID verified, `lower(auth.email) = lower(target_email)` |
| `ACCOUNT_CREATED` | Claim RPC executed | `IDENTITY_VERIFICATION_PENDING` | Authenticated User | Replay checks pass, `parent_child_relationships` row created with `verified_at = NULL` |
| `IDENTITY_VERIFICATION_PENDING` | Admin reviews physical ID & signs off | `CLAIMED` | School Admin | Admin verifies identity; sets `verified_at = NOW()` |
| `CREATED` / `OPENED` / `ACCOUNT_CREATED` | TTL expires (default 48h) | `EXPIRED` | System / Clock | `NOW() > expires_at` |
| Any active state | Admin cancels invitation | `REVOKED` | School Admin | Admin manual revocation |

---

## 3. Threat Model & Safeguards

1. **Anti-Replay Protection:** The invitation row is locked with `FOR UPDATE` inside a database transaction. `uses_count` is incremented and validated against `max_uses` (strictly 1).
2. **Anti-Forwarding & Anti-Takeover (Strict Email Match):** If an invitation link sent to `parent@example.com` is intercepted or forwarded to `stranger@evil.com`, the claim RPC aborts immediately with an `IDENTITY_MISMATCH` exception.
3. **Anti-Arbitrary Child Selection:** The client CANNOT supply a `child_id`. The target child ID is read directly from the locked invitation row in the database.
4. **Anti-Plaintext Exposure:** The database stores ONLY `SHA-256(raw_token + pepper)`. Raw tokens are never persisted.

---

## 4. Production Database Implementation

### 4.1 Step 1: Open Invitation (Audit & State Transition)

```sql
CREATE OR REPLACE FUNCTION rpc_open_invitation(
    p_token_hash CHAR(64),
    p_ip_address INET,
    p_user_agent TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_inv invitations%ROWTYPE;
BEGIN
    SELECT * INTO v_inv FROM invitations
    WHERE token_hash = p_token_hash
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'code', 'INVALID_TOKEN', 'message', 'Invitation not found.');
    END IF;

    IF v_inv.status = 'REVOKED' OR v_inv.revoked_at IS NOT NULL THEN
        RETURN jsonb_build_object('success', false, 'code', 'REVOKED', 'message', 'Invitation has been revoked.');
    END IF;

    IF NOW() > v_inv.expires_at OR v_inv.status = 'EXPIRED' THEN
        UPDATE invitations SET status = 'EXPIRED' WHERE id = v_inv.id;
        RETURN jsonb_build_object('success', false, 'code', 'EXPIRED', 'message', 'Invitation has expired.');
    END IF;

    IF v_inv.status IN ('IDENTITY_VERIFICATION_PENDING', 'CLAIMED') THEN
        RETURN jsonb_build_object('success', false, 'code', 'ALREADY_CLAIMED', 'message', 'Invitation has already been claimed.');
    END IF;

    IF v_inv.status = 'CREATED' THEN
        UPDATE invitations
        SET status = 'OPENED', opened_at = NOW()
        WHERE id = v_inv.id;
    END IF;

    RETURN jsonb_build_object(
        'success', true,
        'kindergarten_id', v_inv.kindergarten_id,
        'target_email', v_inv.target_email,
        'target_role', v_inv.target_role,
        'status', 'OPENED'
    );
END;
$$;
```

### 4.2 Step 2: Atomic Claim RPC with Identity Matching

```sql
CREATE OR REPLACE FUNCTION claim_parent_invitation(
    p_token_hash CHAR(64),
    p_ip_address INET,
    p_user_agent TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_inv invitations%ROWTYPE;
    v_caller_id UUID;
    v_caller_email VARCHAR(255);
BEGIN
    -- 1. Assert Caller Authentication
    v_caller_id := auth.uid();
    IF v_caller_id IS NULL THEN
        RAISE EXCEPTION 'UNAUTHENTICATED: Must be logged in to claim an invitation.';
    END IF;

    -- Fetch caller email from auth.users
    SELECT email INTO v_caller_email FROM auth.users WHERE id = v_caller_id;

    -- 2. Lock invitation row
    SELECT * INTO v_inv FROM invitations
    WHERE token_hash = p_token_hash
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'code', 'NOT_FOUND', 'message', 'Invalid invitation token.');
    END IF;

    -- 3. Strict State Validations
    IF v_inv.status = 'REVOKED' OR v_inv.revoked_at IS NOT NULL THEN
        RETURN jsonb_build_object('success', false, 'code', 'REVOKED', 'message', 'This invitation was revoked.');
    END IF;

    IF NOW() > v_inv.expires_at OR v_inv.status = 'EXPIRED' THEN
        UPDATE invitations SET status = 'EXPIRED' WHERE id = v_inv.id;
        RETURN jsonb_build_object('success', false, 'code', 'EXPIRED', 'message', 'Invitation link has expired.');
    END IF;

    IF v_inv.status IN ('IDENTITY_VERIFICATION_PENDING', 'CLAIMED') OR v_inv.uses_count >= v_inv.max_uses THEN
        RETURN jsonb_build_object('success', false, 'code', 'ALREADY_CLAIMED', 'message', 'Invitation already claimed.');
    END IF;

    -- 4. Mandatory Anti-Takeover Identity Match
    IF lower(v_caller_email) != lower(v_inv.target_email) THEN
        -- Log suspicious mismatch incident
        INSERT INTO audit_logs (
            kindergarten_id, actor_id, action, resource_type, resource_id, reason, metadata
        ) VALUES (
            v_inv.kindergarten_id,
            v_caller_id,
            'INVITATION_EMAIL_MISMATCH_REJECTED',
            'invitations',
            v_inv.id,
            'Logged-in user email does not match invitation target_email.',
            jsonb_build_object(
                'caller_email', v_caller_email,
                'target_email', v_inv.target_email,
                'token_hash', p_token_hash
            )
        );
        RETURN jsonb_build_object(
            'success', false,
            'code', 'IDENTITY_MISMATCH',
            'message', 'Your account email does not match the recipient email for this invitation.'
        );
    END IF;

    -- 5. Create Parent Membership
    INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role, is_active)
    VALUES (v_inv.kindergarten_id, v_caller_id, v_inv.target_role, TRUE)
    ON CONFLICT (kindergarten_id, user_id) DO NOTHING;

    -- 6. Insert Unverified Custody Record (verified_at remains NULL)
    IF v_inv.target_role = 'PARENT' AND v_inv.target_child_id IS NOT NULL THEN
        INSERT INTO parent_child_relationships (
            kindergarten_id,
            parent_id,
            child_id,
            relationship,
            is_primary_contact,
            authorized_for_pickup,
            verified_at -- CRITICAL: NULL by default; access remains strictly locked
        ) VALUES (
            v_inv.kindergarten_id,
            v_caller_id,
            v_inv.target_child_id, -- Pre-bound from server database row
            COALESCE(v_inv.target_relationship, 'LEGAL_GUARDIAN'),
            FALSE,
            FALSE,
            NULL
        )
        ON CONFLICT (parent_id, child_id) DO NOTHING;
    END IF;

    -- 7. Advance Lifecycle State
    UPDATE invitations
    SET status = 'IDENTITY_VERIFICATION_PENDING',
        uses_count = uses_count + 1,
        claimed_at = NOW(),
        claimed_by_user_id = v_caller_id
    WHERE id = v_inv.id;

    -- 8. Append Immutable Redemption Audit Trail
    INSERT INTO invitation_redemptions (invitation_id, redeemed_by, ip_address, user_agent)
    VALUES (v_inv.id, v_caller_id, p_ip_address, p_user_agent);

    RETURN jsonb_build_object(
        'success', true,
        'kindergarten_id', v_inv.kindergarten_id,
        'target_child_id', v_inv.target_child_id,
        'status', 'IDENTITY_VERIFICATION_PENDING',
        'message', 'Account linked. Child records will unlock upon kindergarten director document verification.'
    );
END;
$$;
```

### 4.3 Step 3: Administrative Custody Verification RPC (Unlocking Access)

```sql
CREATE OR REPLACE FUNCTION rpc_verify_parent_custody(
    p_parent_id UUID,
    p_child_id UUID,
    p_verification_notes TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_rel parent_child_relationships%ROWTYPE;
BEGIN
    -- Assert caller is admin for this child's kindergarten
    SELECT * INTO v_rel FROM parent_child_relationships
    WHERE parent_id = p_parent_id AND child_id = p_child_id AND deleted_at IS NULL;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'RELATIONSHIP_NOT_FOUND: Relationship record does not exist.';
    END IF;

    IF NOT auth.is_admin_for(v_rel.kindergarten_id) THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: Only the kindergarten director can verify custody.';
    END IF;

    -- Unlock custody access
    UPDATE parent_child_relationships
    SET verified_at = NOW(),
        verified_by_admin_id = auth.uid(),
        verification_notes = p_verification_notes
    WHERE id = v_rel.id;

    -- Advance invitation to CLAIMED if linked
    UPDATE invitations
    SET status = 'CLAIMED'
    WHERE kindergarten_id = v_rel.kindergarten_id
      AND target_child_id = p_child_id
      AND claimed_by_user_id = p_parent_id
      AND status = 'IDENTITY_VERIFICATION_PENDING';

    -- Audit log
    INSERT INTO audit_logs (
        kindergarten_id, actor_id, actor_role, action, resource_type, resource_id, reason, metadata
    ) VALUES (
        v_rel.kindergarten_id,
        auth.uid(),
        'ADMIN',
        'PARENT_CHILD_CUSTODY_VERIFIED',
        'parent_child_relationships',
        v_rel.id,
        p_verification_notes,
        jsonb_build_object('parent_id', p_parent_id, 'child_id', p_child_id, 'unlocked_at', NOW())
    );

    RETURN jsonb_build_object('success', true, 'status', 'CLAIMED', 'verified_at', NOW());
END;
$$;
```
