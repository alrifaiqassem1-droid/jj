# Rawdaty Smart (روضتي الذكية) — Final Entity Registry

**Document Version:** 4.1.0-REMEDIATED  
**Status:** Canonical Single Source of Truth for Entity Model  
**Total Entities:** Exactly 25 Entities  
**Auditor:** Principal Enterprise & Security Architect  

---

## 1. Resolution of Entity Count (24 vs. 25 Entities)

### 1.1 Historical Discrepancy Analysis
* **Architecture Gate V1:** Cataloged 22 entities, but lacked granular tables for AI provenance, break-glass security, health privacy isolation, and attendance immutability.
* **Architecture Gate V2 & V3:** Decomposed the data model to satisfy defense-in-depth security:
  - Split child data into `children` (demographic) and `child_health_profiles` (clinical/emergency).
  - Added `super_admin_support_sessions` (ephemeral 60m break-glass access).
  - Decomposed AI into 5 derived tables (`ai_analysis`, `ai_evidence`, `ai_insights`, `ai_recommendations`, `ai_followups`).
  - Added `attendance_corrections` (append-only ledger).
  - Included `tuition_invoices` in Table 3 of `ARCHITECTURE_GATE_V3.md` (Total = 25 entities).
* **Gate V4 Audit Finding:** Early drafts of Gate V4 counted 24 active entities by excluding `tuition_invoices` because fee billing was deferred to Phase 5. However, leaving `tuition_invoices` uncataloged created a documentation mismatch between V3 and V4.

### 1.2 Definitive Resolution
**The platform defines exactly 25 entities.**  
All 25 entities are formally cataloged below, and all 25 have complete DDL definitions in `DATABASE_SCHEMA.md` and complete RLS security policies in `SECURITY_ARCHITECTURE.md`.  
Entity #23 (`tuition_invoices`) is explicitly categorized as **Phase 5 (Deferred)**, but its schema, multi-tenancy, and RLS are fully documented and locked to prevent future schema drift.

---

## 2. Master Entity Specification Matrix (Entities 1 to 25)

| # | Entity Name | Purpose | Provenance | Tenant Owner | Parent Entity | Foreign Keys | Classification | RLS | SELECT | INSERT | UPDATE | DELETE | Soft Delete | Retention | Audit Req. | Phase |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **1** | `kindergartens` | Tenant boundary & institutional profile | Source-of-Truth | Platform / Tenant | None | None | Operational | Yes | Admin (own), Super Admin | Super Admin | Admin (own), Super Admin | Super Admin | `deleted_at` | 7 Years | Mandatory | Phase 1 |
| **2** | `user_profiles` | Global user identity, contact & preferences | Source-of-Truth | Global / User | Auth User | `id -> auth.users.id` | Sensitive (PII) | Yes | Self, School Admin | Auth Hook | Self, Super Admin | Self / Admin | `deleted_at` | 7 Years | Mandatory | Phase 1 |
| **3** | `kindergarten_memberships` | Role binding & granular staff permissions | Source-of-Truth | Tenant | Kindergarten & User | `kindergarten_id -> kindergartens.id`, `user_id -> user_profiles.id` | Security Sensitive | Yes | Self, School Admin | School Admin | School Admin | School Admin | `deleted_at` | 7 Years | Mandatory | Phase 1 |
| **4** | `super_admin_support_sessions` | Ephemeral 60m break-glass emergency access | Source-of-Truth | Platform | Kindergarten | `target_kindergarten_id -> kindergartens.id`, `super_admin_id -> user_profiles.id` | Security Sensitive | Yes | Super Admin, School Admin | Super Admin (with reason) | System (Expire) | Prohibited | Hard TTL (60m) | Permanent | Mandatory | Phase 1 |
| **5** | `classes` | Classrooms, cohorts & age groups | Source-of-Truth | Tenant | Kindergarten | `kindergarten_id -> kindergartens.id` | Operational | Yes | Admin, Assigned Teachers, Parents | School Admin | School Admin | School Admin | `deleted_at` | 5 Years | Standard | Phase 1 |
| **6** | `teacher_class_assignments` | Restricts teachers strictly to assigned rooms | Source-of-Truth | Tenant | Class & Teacher | `kindergarten_id -> kindergartens.id`, `class_id -> classes.id`, `teacher_id -> user_profiles.id` | Operational | Yes | Admin, Assigned Teacher | School Admin | School Admin | School Admin | Hard Delete | Academic Yr | Mandatory | Phase 1 |
| **7** | `children` | Child demographics & emergency numbers | Source-of-Truth | Tenant | Class | `kindergarten_id -> kindergartens.id`, `class_id -> classes.id` | Sensitive (Minors) | Yes | Admin, Class Teacher, Verified Parent, Staff | School Admin | School Admin | School Admin | `deleted_at` | 7 Years | Mandatory | Phase 1 |
| **8** | `child_health_profiles` | Allergies, chronic conditions & EpiPen | Source-of-Truth | Tenant | Child | `kindergarten_id -> kindergartens.id`, `child_id -> children.id` | Highly Sensitive (Clinical) | Yes | Admin, Authorized Nurse, Verified Parent | Admin, Health Staff | Admin, Health Staff | School Admin | `deleted_at` | 10 Years | Mandatory (RPC Audited) | Phase 1 |
| **9** | `parent_child_relationships` | Legal custody & administrative verification gate | Source-of-Truth | Tenant | Child & Parent | `kindergarten_id -> kindergartens.id`, `parent_id -> user_profiles.id`, `child_id -> children.id` | Highly Sensitive (Legal Custody) | Yes | Admin, Verified Parent, Class Teacher | Admin (RPC Verification) | Admin | School Admin | `deleted_at` | 7 Years | Mandatory | Phase 1 |
| **10** | `invitations` | Cryptographic onboarding tokens (SHA-256) | Source-of-Truth | Tenant | Kindergarten | `kindergarten_id -> kindergartens.id`, `created_by -> user_profiles.id`, `target_child_id -> children.id`, `target_class_id -> classes.id` | Security Sensitive (Tokens) | Yes | School Admin only | School Admin | Admin (Revoke) | Prohibited | Status-driven | 90 Days post-expiry | Mandatory | Phase 1 |
| **11** | `invitation_redemptions` | Token redemption network & identity audit | Source-of-Truth | Tenant | Invitation | `invitation_id -> invitations.id`, `redeemed_by -> user_profiles.id` | Security Sensitive | Yes | School Admin only | System RPC | Prohibited | Prohibited | Immutable | 5 Years | Mandatory | Phase 1 |
| **12** | `attendance` | Daily attendance master state | Source-of-Truth | Tenant | Child & Class | `kindergarten_id -> kindergartens.id`, `class_id -> classes.id`, `child_id -> children.id`, `recorded_by -> user_profiles.id` | Sensitive | Yes | Admin, Class Teacher, Verified Parent | Class Teacher, Staff | Class Teacher (same day) | School Admin | `deleted_at` | 5 Years | Sensitive | Phase 1 |
| **13** | `attendance_corrections` | Append-only ledger of attendance edits | Source-of-Truth | Tenant | Attendance | `attendance_id -> attendance.id`, `kindergarten_id -> kindergartens.id`, `child_id -> children.id`, `corrected_by_user_id -> user_profiles.id` | Security Sensitive | Yes | Admin, Class Teacher | Trigger / RPC only | Prohibited | Prohibited | Immutable | 5 Years | Mandatory | Phase 1 |
| **14** | `teacher_observations` | Pedagogical notes in classroom | Source-of-Truth | Tenant | Child & Teacher | `kindergarten_id -> kindergartens.id`, `class_id -> classes.id`, `child_id -> children.id`, `teacher_id -> user_profiles.id` | Sensitive (Pedagogical) | Yes | Admin, Class Teacher, Verified Parent | Class Teacher | Class Teacher (24h) | School Admin | `deleted_at` | Academic Yr | Sensitive | Phase 2 |
| **15** | `parent_observations` | Home play moments & parent reflections | Source-of-Truth | Tenant | Child & Parent | `kindergarten_id -> kindergartens.id`, `child_id -> children.id`, `parent_id -> user_profiles.id` | Private (Family) | Yes | Admin, Class Teacher, Verified Parent | Verified Parent (own child) | Verified Parent (24h) | Verified Parent | `deleted_at` | Academic Yr | Standard | Phase 2 |
| **16** | `ai_analysis` | AI inference job metadata & token metrics | Derived | Tenant | Child | `kindergarten_id -> kindergartens.id`, `child_id -> children.id` | Operational Analytical | Yes | Admin, Class Teacher | AI Worker (System) | Prohibited | School Admin | Hard Retention | 1 Academic Yr | Standard | Phase 3 |
| **17** | `ai_evidence` | Pointers linking insights to source records | Derived | Tenant | AI Analysis | `analysis_id -> ai_analysis.id`, `kindergarten_id -> kindergartens.id` | Analytical | Yes | Admin, Class Teacher | AI Worker (System) | Prohibited | School Admin | Hard Retention | 1 Academic Yr | Standard | Phase 3 |
| **18** | `ai_insights` | Synthesized strengths & learning patterns | Derived | Tenant | Child | `kindergarten_id -> kindergartens.id`, `child_id -> children.id`, `analysis_id -> ai_analysis.id` | Sensitive (Developmental) | Yes | Admin, Class Teacher, Verified Parent | AI Worker (System) | Class Teacher (Sign-off) | School Admin | Hard Retention | 1 Academic Yr | Sensitive | Phase 3 |
| **19** | `ai_recommendations` | Actionable 10-minute home play activity cards | Derived | Tenant | Child | `kindergarten_id -> kindergartens.id`, `child_id -> children.id`, `insight_id -> ai_insights.id`, `approved_by_teacher_id -> user_profiles.id` | Pedagogical Guidance | Yes | Admin, Class Teacher, Verified Parent (Post-Approval) | AI Worker (System) | Class Teacher (Approve/Reject) | School Admin | Hard Retention | 1 Academic Yr | Mandatory | Phase 3 |
| **20** | `ai_followups` | Activity feedback & home-school loop results | Derived | Tenant | Recommendation | `recommendation_id -> ai_recommendations.id`, `kindergarten_id -> kindergartens.id`, `child_id -> children.id`, `logged_by_user_id -> user_profiles.id` | Pedagogical Progress | Yes | Admin, Class Teacher, Verified Parent | Verified Parent, Teacher | Class Teacher | School Admin | Hard Retention | 1 Academic Yr | Standard | Phase 3 |
| **21** | `media_vault` | Encrypted media metadata (UUID storage paths) | Source-of-Truth | Tenant | Kindergarten | `kindergarten_id -> kindergartens.id`, `uploaded_by -> user_profiles.id` | Highly Sensitive (Media) | Yes | Admin, Class Teacher, Tagged Parent | Admin, Class Teacher | School Admin | School Admin | `deleted_at` | 3 Years | Sensitive | Phase 2 |
| **22** | `media_child_tags` | Child isolation mapping for media | Source-of-Truth | Tenant | Media & Child | `kindergarten_id -> kindergartens.id`, `media_id -> media_vault.id`, `child_id -> children.id`, `tagged_by -> user_profiles.id` | Highly Sensitive (Child Photos) | Yes | Admin, Class Teacher, Tagged Parent | Admin, Class Teacher | Prohibited | School Admin | Hard Delete | 3 Years | Sensitive | Phase 2 |
| **23** | `tuition_invoices` | Tuition fees, payments & official receipts | Source-of-Truth | Tenant | Child & Parent | `kindergarten_id -> kindergartens.id`, `child_id -> children.id`, `parent_id -> user_profiles.id` | Financial Confidential | Yes | Admin, Billed Parent | School Admin | School Admin | School Admin | `deleted_at` (VOID) | 10 Years | Mandatory | Phase 5 (Deferred) |
| **24** | `notifications` | In-app notification queue & delivery status | Derived / Log | Tenant | User | `kindergarten_id -> kindergartens.id`, `recipient_user_id -> user_profiles.id` | Operational Communication | Yes | Recipient User only | System / Dispatcher | Recipient (Mark Read) | Recipient / Purge | Purge post-read | 90 Days | Standard | Phase 1 |
| **25** | `audit_logs` | Tamper-evident cryptographic system ledger | Source-of-Truth | Platform / Tenant | None | `kindergarten_id -> kindergartens.id`, `actor_id -> user_profiles.id` | Security Sensitive (Kernel) | Yes | School Admin (own), Super Admin | Trigger / RPC only | **NEVER (BLOCKED)** | **NEVER (BLOCKED)** | Prohibited | Permanent | Mandatory | Phase 1 |

---

## 3. Cross-Document Verification Assertions

1. **Schema Check:** Every entity listed above (1–25) MUST exist as an explicit `CREATE TABLE` statement in `DATABASE_SCHEMA.md`. No entity may exist in DDL without being registered here.
2. **Security Check:** Every entity listed above MUST have explicit `ENABLE ROW LEVEL SECURITY` and `CREATE POLICY` statements documented in `SECURITY_ARCHITECTURE.md`.
3. **Custody Invariant Check:** No parent may query any record linked to `child_id` unless `auth.is_parent_of_child(child_id)` evaluates to TRUE, which requires `parent_child_relationships.verified_at IS NOT NULL` and `parent_child_relationships.deleted_at IS NULL`.
4. **Phase Boundary Check:** Entities 1–13, 24, and 25 belong to Phase 1. Entities 14, 15, 21, and 22 belong to Phase 2. Entities 16–20 belong to Phase 3. Entity 23 belongs to Phase 5.
