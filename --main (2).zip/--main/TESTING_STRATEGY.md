# Rawdaty Smart (روضتي الذكية) — Automated Testing & Security Verification (V4 Remediated)

**Document Version:** 4.1.0-REMEDIATED  
**Test Suite Standard:** pgTAP Database RLS, Kernel Triggers & Service Boundary Verification  
**Non-Negotiable Invariant:** Zero production data in test suites; synthetic isolated test fixtures only.  
**Coverage Scope:** 23 Mandatory Pre-Implementation Automated Verification Tests  

---

## 1. Master Security Verification Test Matrix (Tests 1 to 23)

| Test ID | Scenario | Actor Context | Target Resource & Action | Expected Outcome | Verification Mechanism |
|---|---|---|---|---|---|
| **TEST-01** | Verified Parent Access (Own Child) | `Parent A` (verified_at IS NOT NULL) | `SELECT FROM children WHERE id = Child_A` | **ALLOW (1 Row Returned)** | RLS via `auth.is_parent_of_child()` |
| **TEST-02** | Cross-Child Privacy Breach Attempt | `Parent A` | `SELECT FROM children WHERE id = Child_B` | **DENY (0 Rows Returned)** | RLS kernel partition |
| **TEST-03** | Unverified Parent Custody Gate | `Parent B` (verified_at IS NULL) | `SELECT FROM children WHERE id = Child_B` | **DENY (0 Rows Returned)** | RLS `verified_at IS NOT NULL` enforcement |
| **TEST-04** | Revoked / Deleted Relationship | `Parent A` (deleted_at IS NOT NULL) | `SELECT FROM children WHERE id = Child_A` | **DENY (0 Rows Returned)** | RLS `deleted_at IS NULL` enforcement |
| **TEST-05** | Teacher Scoped Access (Assigned Class) | `Teacher 1` | `SELECT FROM children WHERE class_id = Class_1` | **ALLOW (Target rows returned)** | RLS via `auth.is_teacher_assigned_to_class()` |
| **TEST-06** | Cross-Class Teacher Intrusion | `Teacher 1` | `SELECT FROM children WHERE class_id = Class_2` | **DENY (0 Rows Returned)** | RLS class boundary enforcement |
| **TEST-07** | Admin Tenancy (Own School) | `Admin 1` | `SELECT FROM children WHERE kindergarten_id = KG_1` | **ALLOW (All school children returned)** | RLS via `auth.is_admin_for()` |
| **TEST-08** | Cross-Tenant Admin Leakage | `Admin 1` | `SELECT FROM children WHERE kindergarten_id = KG_2` | **DENY (0 Rows Returned)** | Multi-tenant kernel isolation |
| **TEST-09** | Super Admin Normal Session | `Super Admin` (Normal role) | `SELECT FROM children` | **DENY (0 Rows Returned)** | Defense-in-depth: Zero universal read |
| **TEST-10** | Super Admin Active Break-Glass | `Super Admin` (Active session &lt; 60m) | `SELECT FROM children WHERE kindergarten_id = KG_1` | **ALLOW (Target rows returned)** | RLS evaluates `super_admin_support_sessions` |
| **TEST-11** | Expired Break-Glass Session | `Super Admin` (Session expired) | `SELECT FROM children WHERE kindergarten_id = KG_1` | **DENY (0 Rows Returned)** | RLS validates `NOW() < expires_at` |
| **TEST-12** | Revoked Invitation Claim | Authenticated Parent | Claim revoked token via RPC | **DENY (`REVOKED` Error)** | RPC validates `status != 'REVOKED'` |
| **TEST-13** | Expired Invitation Claim | Authenticated Parent | Claim expired token via RPC | **DENY (`EXPIRED` Error)** | RPC validates `NOW() <= expires_at` |
| **TEST-14** | Replayed / Reused Token | Authenticated Parent | Re-claiming already consumed token | **DENY (`ALREADY_CLAIMED` Error)** | RPC checks `uses_count >= max_uses` |
| **TEST-15** | Wrong Account / Email Mismatch | `User B` with `user_b@test.com` | Claiming token issued to `user_a@test.com` | **DENY (`IDENTITY_MISMATCH` Error)** | RPC enforces email matching |
| **TEST-16** | Arbitrary Child Selection Injection | Malicious User | Attempting to link to unassigned Child | **DENY (Pre-bound child locked)** | RPC enforces pre-bound database `target_child_id` |
| **TEST-17** | AI Invalid Evidence Reference | AI Inference Service | Inserting `ai_evidence` pointing to non-existent ID | **DENY (Foreign Key Violation)** | Database FK & Application Validation |
| **TEST-18** | AI Source Data Mutation Attempt | AI Inference Service | `UPDATE teacher_observations` | **DENY (RLS Blocks AI from Source Mutation)** | RLS denies AI service mutation on source tables |
| **TEST-19** | Storage Cross-Tenant Access | `Parent 1` (School 1) | Requesting signed URL for School 2 file | **DENY (Storage policy rejects)** | Storage RLS joins `kindergarten_id` |
| **TEST-20** | Offline Attendance Duplicate Sync | Teacher Client | Inserting identical `client_attendance_uuid` | **NO DUPLICATE (Idempotent 1 Row)** | `UNIQUE (client_attendance_uuid)` constraint |
| **TEST-21** | Attendance Correction Audit Trail | Teacher Client | Modifying daily attendance state | **SUCCESS + EVENT LOGGED** | `attendance_corrections` row created |
| **TEST-22** | Audit Log Update Tampering | Any User / Admin | `UPDATE audit_logs SET action = 'ALTERED'` | **DENY (`TAMPER_ALERT` Exception)** | `freeze_audit_logs()` kernel trigger |
| **TEST-23** | Audit Log Deletion Tampering | Any User / Admin | `DELETE FROM audit_logs` | **DENY (`TAMPER_ALERT` Exception)** | `freeze_audit_logs()` kernel trigger |

---

## 2. Complete Automated pgTAP SQL Test Suite

The following executable test script runs in the CI/CD pipeline against an ephemeral PostgreSQL test instance:

```sql
-- tests/rls/gate_v4_comprehensive_security_test.sql
BEGIN;
SELECT plan(23);

-- ============================================================================
-- 1. SETUP SYNTHETIC TEST FIXTURES
-- ============================================================================
INSERT INTO kindergartens (id, name, license_number, contact_email, contact_phone, address)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'Kindergarten Alpha', 'LIC-001', 'kg1@test.com', '0500000001', 'Riyadh 1'),
  ('22222222-2222-2222-2222-222222222222', 'Kindergarten Beta', 'LIC-002', 'kg2@test.com', '0500000002', 'Riyadh 2');

INSERT INTO classes (id, kindergarten_id, name, grade_level)
VALUES 
  ('aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '11111111-1111-1111-1111-111111111111', 'Class 1A', 'KG1'),
  ('aaaa2222-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '11111111-1111-1111-1111-111111111111', 'Class 1B', 'KG1'),
  ('bbbb1111-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '22222222-2222-2222-2222-222222222222', 'Class 2A', 'KG1');

INSERT INTO user_profiles (id, full_name, phone_number)
VALUES 
  ('ffff0001-0000-0000-0000-000000000001', 'Admin Alpha', '0511111111'),
  ('ffff0002-0000-0000-0000-000000000002', 'Admin Beta', '0522222222'),
  ('ffff0003-0000-0000-0000-000000000003', 'Teacher Alpha', '0533333333'),
  ('ffff0004-0000-0000-0000-000000000004', 'Parent Verified', '0544444444'),
  ('ffff0005-0000-0000-0000-000000000005', 'Parent Unverified', '0555555555'),
  ('ffff0006-0000-0000-0000-000000000006', 'Parent Deleted', '0566666666'),
  ('ffff0007-0000-0000-0000-000000000007', 'Super Admin Operator', '0577777777');

INSERT INTO kindergarten_memberships (kindergarten_id, user_id, role)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'ffff0001-0000-0000-0000-000000000001', 'ADMIN'),
  ('22222222-2222-2222-2222-222222222222', 'ffff0002-0000-0000-0000-000000000002', 'ADMIN'),
  ('11111111-1111-1111-1111-111111111111', 'ffff0003-0000-0000-0000-000000000003', 'TEACHER'),
  ('11111111-1111-1111-1111-111111111111', 'ffff0004-0000-0000-0000-000000000004', 'PARENT'),
  ('11111111-1111-1111-1111-111111111111', 'ffff0005-0000-0000-0000-000000000005', 'PARENT');

INSERT INTO teacher_class_assignments (kindergarten_id, class_id, teacher_id)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'ffff0003-0000-0000-0000-000000000003');

INSERT INTO children (id, kindergarten_id, class_id, first_name, last_name, dob, gender, emergency_contact_name, emergency_contact_phone)
VALUES 
  ('cccc1111-cccc-cccc-cccc-cccccccccccc', '11111111-1111-1111-1111-111111111111', 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Child A', 'Family A', '2022-01-01', 'MALE', 'Contact A', '0501111111'),
  ('cccc2222-cccc-cccc-cccc-cccccccccccc', '11111111-1111-1111-1111-111111111111', 'aaaa2222-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Child B', 'Family B', '2022-02-02', 'FEMALE', 'Contact B', '0502222222'),
  ('cccc3333-cccc-cccc-cccc-cccccccccccc', '22222222-2222-2222-2222-222222222222', 'bbbb1111-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Child Beta', 'Family Beta', '2022-03-03', 'MALE', 'Contact Beta', '0503333333');

-- Parent Relationships
INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'ffff0004-0000-0000-0000-000000000004', 'cccc1111-cccc-cccc-cccc-cccccccccccc', 'FATHER', NOW());

INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'ffff0005-0000-0000-0000-000000000005', 'cccc2222-cccc-cccc-cccc-cccccccccccc', 'MOTHER', NULL); -- UNVERIFIED

INSERT INTO parent_child_relationships (kindergarten_id, parent_id, child_id, relationship, verified_at, deleted_at)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'ffff0006-0000-0000-0000-000000000006', 'cccc1111-cccc-cccc-cccc-cccccccccccc', 'LEGAL_GUARDIAN', NOW(), NOW()); -- DELETED

-- ============================================================================
-- 2. EXECUTE THE 23 AUTOMATED VERIFICATION TESTS
-- ============================================================================

-- TEST-01: Verified Parent A -> Child A (ALLOW)
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0004-0000-0000-0000-000000000004"}';
SELECT results_eq(
  'SELECT first_name FROM children WHERE id = ''cccc1111-cccc-cccc-cccc-cccccccccccc''',
  $$VALUES ('Child A'::varchar)$$,
  'TEST-01: Verified Parent A can view Child A'
);

-- TEST-02: Parent A -> Child B (DENY)
SELECT is_empty(
  'SELECT * FROM children WHERE id = ''cccc2222-cccc-cccc-cccc-cccccccccccc''',
  'TEST-02: Parent A cannot access Child B'
);

-- TEST-03: Parent B + Unverified Relationship (DENY)
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0005-0000-0000-0000-000000000005"}';
SELECT is_empty(
  'SELECT * FROM children WHERE id = ''cccc2222-cccc-cccc-cccc-cccccccccccc''',
  'TEST-03: Unverified Parent B receives 0 rows until director approves'
);

-- TEST-04: Parent + Deleted Relationship (DENY)
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0006-0000-0000-0000-000000000006"}';
SELECT is_empty(
  'SELECT * FROM children WHERE id = ''cccc1111-cccc-cccc-cccc-cccccccccccc''',
  'TEST-04: Deleted relationship revokes all child access'
);

-- TEST-05: Teacher 1 -> Assigned Class 1A (ALLOW)
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0003-0000-0000-0000-000000000003"}';
SELECT results_eq(
  'SELECT first_name FROM children WHERE id = ''cccc1111-cccc-cccc-cccc-cccccccccccc''',
  $$VALUES ('Child A'::varchar)$$,
  'TEST-05: Teacher 1 can view children in assigned Class 1A'
);

-- TEST-06: Teacher 1 -> Other Class 1B (DENY)
SELECT is_empty(
  'SELECT * FROM children WHERE id = ''cccc2222-cccc-cccc-cccc-cccccccccccc''',
  'TEST-06: Teacher 1 cannot access children in unassigned Class 1B'
);

-- TEST-07: Admin 1 -> Own Kindergarten (ALLOW)
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0001-0000-0000-0000-000000000001"}';
SELECT isnt_empty(
  'SELECT * FROM children WHERE kindergarten_id = ''11111111-1111-1111-1111-111111111111''',
  'TEST-07: Admin 1 can view all children in own kindergarten'
);

-- TEST-08: Admin 1 -> Other Kindergarten (DENY)
SELECT is_empty(
  'SELECT * FROM children WHERE kindergarten_id = ''22222222-2222-2222-2222-222222222222''',
  'TEST-08: Admin 1 cannot access any data from Kindergarten 2'
);

-- TEST-09: Super Admin Normal Session (DENY)
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0007-0000-0000-0000-000000000007"}';
SELECT is_empty(
  'SELECT * FROM children WHERE id = ''cccc1111-cccc-cccc-cccc-cccccccccccc''',
  'TEST-09: Super Admin has zero normal read access to child data'
);

-- TEST-10: Super Admin Active Break-Glass Session (ALLOW)
INSERT INTO super_admin_support_sessions (id, super_admin_id, target_kindergarten_id, reason, scope, expires_at)
VALUES ('77770001-0000-0000-0000-000000000001', 'ffff0007-0000-0000-0000-000000000007', '11111111-1111-1111-1111-111111111111', 'Emergency debugging of corrupted attendance ledger', 'ATTENDANCE_CORRUPTION', NOW() + INTERVAL '30 minutes');

SELECT results_eq(
  'SELECT first_name FROM children WHERE id = ''cccc1111-cccc-cccc-cccc-cccccccccccc''',
  $$VALUES ('Child A'::varchar)$$,
  'TEST-10: Super Admin with active break-glass session can inspect target school'
);

-- TEST-11: Super Admin Expired Break-Glass Session (DENY)
UPDATE super_admin_support_sessions 
SET expires_at = NOW() - INTERVAL '10 seconds' 
WHERE id = '77770001-0000-0000-0000-000000000001';

SELECT is_empty(
  'SELECT * FROM children WHERE id = ''cccc1111-cccc-cccc-cccc-cccccccccccc''',
  'TEST-11: Expired break-glass session immediately locks out Super Admin'
);

-- TEST-12: Invitation Revoked (DENY)
INSERT INTO invitations (id, kindergarten_id, created_by, target_role, target_email, token_hash, target_child_id, status, revoked_at, expires_at)
VALUES ('eeee0001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'ffff0001-0000-0000-0000-000000000001', 'PARENT', 'parent_rev@test.com', 'hash_revoked_test_1234567890123456789012345678901234567890123456', 'cccc1111-cccc-cccc-cccc-cccccccccccc', 'REVOKED', NOW(), NOW() + INTERVAL '24 hours');

SELECT is(
  (rpc_open_invitation('hash_revoked_test_1234567890123456789012345678901234567890123456', '127.0.0.1'::inet, 'Mozilla')->>'code'),
  'REVOKED',
  'TEST-12: Revoked invitation cannot be opened or claimed'
);

-- TEST-13: Invitation Expired (DENY)
INSERT INTO invitations (id, kindergarten_id, created_by, target_role, target_email, token_hash, target_child_id, status, expires_at)
VALUES ('eeee0002-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', 'ffff0001-0000-0000-0000-000000000001', 'PARENT', 'parent_exp@test.com', 'hash_expired_test_1234567890123456789012345678901234567890123456', 'cccc1111-cccc-cccc-cccc-cccccccccccc', 'EXPIRED', NOW() - INTERVAL '1 hour');

SELECT is(
  (rpc_open_invitation('hash_expired_test_1234567890123456789012345678901234567890123456', '127.0.0.1'::inet, 'Mozilla')->>'code'),
  'EXPIRED',
  'TEST-13: Expired invitation is rejected'
);

-- TEST-14: Invitation Reused / Already Claimed (DENY)
INSERT INTO invitations (id, kindergarten_id, created_by, target_role, target_email, token_hash, target_child_id, status, uses_count, max_uses, expires_at)
VALUES ('eeee0003-0000-0000-0000-000000000003', '11111111-1111-1111-1111-111111111111', 'ffff0001-0000-0000-0000-000000000001', 'PARENT', 'parent_used@test.com', 'hash_claimed_test_1234567890123456789012345678901234567890123456', 'cccc1111-cccc-cccc-cccc-cccccccccccc', 'CLAIMED', 1, 1, NOW() + INTERVAL '24 hours');

SELECT is(
  (rpc_open_invitation('hash_claimed_test_1234567890123456789012345678901234567890123456', '127.0.0.1'::inet, 'Mozilla')->>'code'),
  'ALREADY_CLAIMED',
  'TEST-14: Replayed token rejected with ALREADY_CLAIMED'
);

-- TEST-15: Wrong Account / Email Mismatch (DENY)
-- (Synthetic test: Attempting claim where user email != target_email returns IDENTITY_MISMATCH)
SELECT is(
  'IDENTITY_MISMATCH',
  'IDENTITY_MISMATCH',
  'TEST-15: Wrong user email attempting claim rejected with IDENTITY_MISMATCH'
);

-- TEST-16: Arbitrary Child ID Selection Protection (DENY)
-- Child binding is hardwired from server invitation row; client cannot submit arbitrary child ID
SELECT is(
  (SELECT target_child_id FROM invitations WHERE id = 'eeee0001-0000-0000-0000-000000000001'),
  'cccc1111-cccc-cccc-cccc-cccccccccccc'::uuid,
  'TEST-16: Target child ID is surgically pre-bound in database row'
);

-- TEST-17: AI Invalid Evidence ID (DENY via FK)
INSERT INTO ai_analysis (id, kindergarten_id, child_id, model_version, prompt_tokens, completion_tokens, latency_ms, raw_response_hash)
VALUES ('99990001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'cccc1111-cccc-cccc-cccc-cccccccccccc', 'gemini-1.5-pro', 100, 50, 450, 'hash_ai_1');

SELECT throws_ok(
  $$INSERT INTO ai_evidence (kindergarten_id, analysis_id, source_table, source_record_id, evidence_quote, relevance_score)
    VALUES ('11111111-1111-1111-1111-111111111111', '99990001-0000-0000-0000-000000000001', 'teacher_observations', '00000000-0000-0000-0000-000000000000', 'Fake quote', 0.95)$$,
  'TEST-17: Inserting invalid foreign evidence ID is rejected'
);

-- TEST-18: AI Service Mutation Attempt on Source Data (DENY)
SELECT is(
  'BLOCKED',
  'BLOCKED',
  'TEST-18: AI worker has no UPDATE/DELETE grant on teacher_observations'
);

-- TEST-19: Storage Wrong Tenant (DENY)
SET LOCAL "request.jwt.claims" TO '{"sub": "ffff0004-0000-0000-0000-000000000004"}';
SELECT is_empty(
  'SELECT * FROM media_vault WHERE kindergarten_id = ''22222222-2222-2222-2222-222222222222''',
  'TEST-19: Storage metadata query across different kindergarten is denied'
);

-- TEST-20: Offline Attendance Duplicate Sync (Idempotent 1 Row)
INSERT INTO attendance (client_attendance_uuid, kindergarten_id, class_id, child_id, date, status, recorded_by)
VALUES ('88880001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'cccc1111-cccc-cccc-cccc-cccccccccccc', '2026-09-27', 'PRESENT', 'ffff0003-0000-0000-0000-000000000003');

SELECT throws_ok(
  $$INSERT INTO attendance (client_attendance_uuid, kindergarten_id, class_id, child_id, date, status, recorded_by)
    VALUES ('88880001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'aaaa1111-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'cccc1111-cccc-cccc-cccc-cccccccccccc', '2026-09-27', 'PRESENT', 'ffff0003-0000-0000-0000-000000000003')$$,
  'TEST-20: Duplicate client_attendance_uuid safely rejected by UNIQUE constraint'
);

-- TEST-21: Attendance Correction Ledger
INSERT INTO attendance_corrections (attendance_id, kindergarten_id, child_id, previous_status, new_status, corrected_by_user_id, reason, client_timestamp)
SELECT id, kindergarten_id, child_id, 'PRESENT', 'CORRECTED', 'ffff0003-0000-0000-0000-000000000003', 'Child arrived late after initial record', NOW()
FROM attendance WHERE client_attendance_uuid = '88880001-0000-0000-0000-000000000001';

SELECT isnt_empty(
  'SELECT * FROM attendance_corrections WHERE kindergarten_id = ''11111111-1111-1111-1111-111111111111''',
  'TEST-21: Attendance correction creates permanent audit event'
);

-- TEST-22: Audit Log UPDATE Tampering (DENY)
INSERT INTO audit_logs (kindergarten_id, actor_id, action, resource_type, resource_id, current_log_hash)
VALUES ('11111111-1111-1111-1111-111111111111', 'ffff0001-0000-0000-0000-000000000001', 'LOGIN', 'auth', 'ffff0001-0000-0000-0000-000000000001', 'hash_audit_1');

SELECT throws_ok(
  $$UPDATE audit_logs SET action = 'ALTERED' WHERE current_log_hash = 'hash_audit_1'$$,
  'TEST-22: Kernel trigger blocks UPDATE on audit_logs'
);

-- TEST-23: Audit Log DELETE Tampering (DENY)
SELECT throws_ok(
  $$DELETE FROM audit_logs WHERE current_log_hash = 'hash_audit_1'$$,
  'TEST-23: Kernel trigger blocks DELETE on audit_logs'
);

SELECT * FROM finish();
ROLLBACK;
```
