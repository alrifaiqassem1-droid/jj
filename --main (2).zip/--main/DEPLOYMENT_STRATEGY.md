# Rawdaty Smart (روضتي الذكية) — Deployment, Environments & CI/CD Strategy

**Document Version:** 1.0.0  
**Environment Model:** Three-Tier Isolated Infrastructure (Dev -> Staging -> Production)  
**Migration Philosophy:** Strictly Forward-Compatible, Zero-Downtime Database Migrations  

---

## 1. Multi-Tier Environment Isolation Matrix

To prevent data contamination and guarantee stability, Rawdaty Smart maintains three strictly isolated environments:

| Environment | Purpose | Database Instance | Storage Bucket | Data Policy |
| :--- | :--- | :--- | :--- | :--- |
| **Development (`dev`)** | Feature development & local testing | Local Dockerized Supabase or Dev Project | `dev-rawdaty-media` | 100% Synthetic mock data generated via Faker.js |
| **Staging (`stg`)** | Pre-release validation, QA, E2E regression, Admin demos | Dedicated Staging Supabase Project | `stg-rawdaty-media` | Anonymized synthetic datasets with realistic kindergarten loads |
| **Production (`prod`)** | Live kindergartens, real children & families | High-Availability Multi-AZ Supabase Enterprise | `prod-rawdaty-media` (Encrypted) | Strictly live data. Zero developer write access except via audited migrations |

---

## 2. Database Migration Lifecycle & Zero-Downtime Rule

Schema modifications never occur through manual UI clicking or unversioned scripts.

### 2.1 The Migration Workflow
```
[ Developer Branch ]
       |
       v
`npx supabase migration new add_emergency_contact_phone`
       |
       v
Writes SQL file to `supabase/migrations/20260927000000_add_emergency_contact_phone.sql`
       |
       v
Local dry-run & pgTAP RLS test execution (`npx supabase test db`)
       |
       v
Pull Request opened on GitHub -> CI runs automated migration linter
       |
       v
Merge to `main` -> Automated GitHub Action deploys migration to Staging
       |
       v
Approval Gate -> Migration applies to Production during low-traffic maintenance window
```

### 2.2 The Expand-and-Contract Migration Pattern
For zero downtime, breaking schema changes are divided into two releases:
1. **Phase 1 (Expand):** Add new column or table without removing old columns. Both old and new application code versions can read/write.
2. **Phase 2 (Migrate):** Backfill historical data in background batch jobs.
3. **Phase 3 (Contract):** Deploy updated application code utilizing the new column exclusively, then drop the legacy column in a subsequent release.

---

## 3. GitHub Actions Continuous Integration / Continuous Deployment (CI/CD)

```yaml
# .github/workflows/production-deploy.yml
name: Production Deployment Pipeline

on:
  push:
    branches: [main]
  workflow_dispatch:

jobs:
  validate-and-test:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Setup Node.js 22
        uses: actions/setup-node@v4
        with:
          node-version: 22
          cache: 'npm'

      - name: Install Dependencies
        run: npm ci

      - name: Code Quality & Type Check
        run: |
          npm run lint
          npm run typecheck

      - name: Secret Leak Detection
        uses: gitleaks/gitleaks-action@v2

      - name: Unit & AI Guardrail Tests
        run: npm run test:unit

  database-migrations:
    needs: validate-and-test
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Setup Supabase CLI
        uses: supabase/setup-cli@v1

      - name: Apply Migrations to Production
        env:
          SUPABASE_ACCESS_TOKEN: ${{ secrets.SUPABASE_ACCESS_TOKEN }}
          SUPABASE_DB_PASSWORD: ${{ secrets.PROD_DB_PASSWORD }}
        run: |
          supabase db push --linked

  deploy-application:
    needs: database-migrations
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to Cloud Hosting (Vercel / Cloud Run)
        env:
          VERCEL_TOKEN: ${{ secrets.VERCEL_TOKEN }}
        run: |
          npx vercel --prod --token ${{ secrets.VERCEL_TOKEN }}

      - name: Notify Engineering Team on Slack / WhatsApp
        run: echo "Rawdaty Smart successfully deployed to production."
```

---

## 4. Error Tracking, Telemetry & Sentry Configuration

### 4.1 Error Boundaries & Sentry Setup
- All frontend and backend errors are captured by **Sentry**.
- **Child Privacy Masking in Telemetry:**
  - Before sending error stack traces or breadcrumbs to Sentry, an automated scrubber strips all children names, birthdates, national IDs, and parent phone numbers:

```typescript
// src/lib/sentry.ts
import * as Sentry from '@sentry/nextjs';

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  environment: process.env.NODE_ENV,
  tracesSampleRate: 0.1,
  beforeSend(event) {
    // Sanitize any accidental child PII in breadcrumbs or error messages
    if (event.request?.data) {
      const dataStr = JSON.stringify(event.request.data);
      const sanitized = dataStr
        .replace(/"first_name":\s*"[^"]+"/g, '"first_name":"[REDACTED]"')
        .replace(/"phone_number":\s*"[^"]+"/g, '"phone_number":"[REDACTED]"')
        .replace(/"allergies":\s*\[[^\]]+\]/g, '"allergies":["[REDACTED]"]');
      event.request.data = JSON.parse(sanitized);
    }
    return event;
  },
});
```

---

## 5. Structured Roadmap & Phased Implementation Plan

```
+----------------------------------------------------------------------------------------------------+
|                                    IMPLEMENTATION ROADMAP PHASES                                   |
+----------------------------------------------------------------------------------------------------+

Phase 0: Architecture Blueprint & Security Schema (CURRENT STAGE - PENDING APPROVAL)
  |-- Complete Technical Specifications & Data Models
  |-- Security RLS Architecture & Threat Mitigation Matrix
  |-- Cryptographic Invitation Protocol Design
  |-- Visual Architecture Diagrams & Approval Gate

Phase 1: Foundation, Multi-Tenancy & Cryptographic Authentication
  |-- Supabase PostgreSQL Setup with Initial Migrations
  |-- Custom Enums, Base Tables (`kindergartens`, `user_profiles`, `memberships`)
  |-- RLS Engine & Custom JWT Claims Helper Functions
  |-- Admin Cryptographic Invitation Generation (256-bit CSPRNG + SHA-256)
  |-- Invitation Redemption Flow & Atomic Transaction Linking

Phase 2: Academic Core, Classroom & Attendance System
  |-- Classrooms & Capacity Management
  |-- Teacher-to-Class Assignments
  |-- Child Registry with Encrypted Medical & Emergency Contact Fields
  |-- Verified Parent-Child Custody Relationships
  |-- Real-Time Daily Attendance Logging (Check-in/Check-out with Pickup Authorization)

Phase 3: Private Media Vault & Classroom Activity Feeds
  |-- Private Supabase Storage Buckets with RLS on `storage.objects`
  |-- Signed URL Pipeline (60s TTL)
  |-- Classroom Activity Feed (Categorized by Developmental Domains)
  |-- Media Tagging & Strict Parent Isolation (Parents see only their child)

Phase 4: Developmental Engine & The Bi-Directional Home-School Loop
  |-- Early Childhood Skills Taxonomy & Milestone Badges
  |-- Teacher Classroom Observation Logging (Source Record 1)
  |-- Parent Home Observation Logging & Play Moments (Source Record 2)
  |-- Server-Side Gemini AI Pedagogical Synthesizer (Strict Non-Diagnostic Guardrails)
  |-- Teacher Review, Approval & Publication Pipeline
  |-- Explainability Evidence Trail Viewer

Phase 5: Automated Communication, WhatsApp & Financials
  |-- Meta WhatsApp Cloud API Integration (Webhook with HMAC-SHA256 Verification)
  |-- Automated Instant Attendance WhatsApp Ping (Check-in / Check-out Alerts)
  |-- Tuition Invoicing, Fee Management & PDF Receipt Generation
  |-- Emergency Broadcast Channel

Phase 6: Hardening, PWA Offline Sync, Disaster Drills & Launch
  |-- PWA Service Worker (Workbox) with Offline Attendance Queue
  |-- End-to-End Automated RLS pgTAP Regression Testing
  |-- Tabletop Disaster Recovery Simulation & PITR Verification
  |-- Performance Index Audits & Production Go-Live
```
