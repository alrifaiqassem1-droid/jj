# Rawdaty Smart (روضتي الذكية) — System Architecture Blueprint (V3)

**Document Version:** 3.0.0-FINAL  
**Architecture Type:** High-Assurance Modular Monolith  
**Author:** Principal Software Architect  

---

## 1. System Invariants & Authoritative Boundaries

### 1.1 Stateless JWT vs. Authoritative Database RLS
- **No Dynamic Claims in JWT:** The application **strictly rejects** placing dynamic authorization lists (e.g. `linked_child_ids`, `assigned_class_ids`) into JWT claims as the authoritative permission decider.
- **The Threat:** In early childhood custody disputes or staff reassignments, authorization states change instantaneously. A cached JWT array would allow revoked guardians or reassigned teachers to access child records until token expiration.
- **V3 Architecture:**
  - JWT contains **strictly stable identity credentials:** `sub` (User UUID), `email`, and active `current_kindergarten_id`.
  - The authoritative access check is executed **at runtime in PostgreSQL Row Level Security (RLS)** via indexed relationship tables (`parent_child_relationships WHERE verified_at IS NOT NULL`, `teacher_class_assignments`).
  - Cache invalidation: If any server-side caching is employed, it is governed by transactional invalidation triggers (`LISTEN / NOTIFY`).

---

## 2. Decoupled Notification Architecture

Modules such as Attendance, Billing, and Observations **never couple directly** to external messaging services. Communication is governed by a 4-tier event-driven abstraction:

```
+-----------------------------------------------------------------------------------+
| 1. DOMAIN EVENT GENERATOR                                                         |
| - AttendanceCheckinEvent (Child checked in at 07:45 AM)                           |
| - TuitionInvoiceIssuedEvent (Tuition statement ready)                             |
| - WeeklyDevelopmentalCardEvent (Teacher approved home play suggestion)            |
+-----------------------------------------------------------------------------------+
                                         │
                                         v
+-----------------------------------------------------------------------------------+
| 2. NOTIFICATION ORCHESTRATION SERVICE                                             |
| - Aggregates events into digests where appropriate                                |
| - Validates recipient active status and kindergarten tenant boundary              |
| - Evaluates event urgency (URGENT / STANDARD / DIGEST)                            |
+-----------------------------------------------------------------------------------+
                                         │
                                         v
+-----------------------------------------------------------------------------------+
| 3. RECIPIENT PREFERENCES ENGINE                                                   |
| - Evaluates user-defined delivery preferences (e.g. In-App vs. WhatsApp)          |
| - Checks quiet hours and opt-out registries (STOP protocol)                       |
+-----------------------------------------------------------------------------------+
                                         │
                                         v
+-----------------------------------------------------------------------------------+
| 4. DELIVERY CHANNEL ADAPTERS                                                      |
|                                                                                   |
| ├── In-App Notification Center (Native PWA Service Worker Web Push) [PHASE 1]     |
| ├── Transactional Email Adapter (Resend / Postmark via Server-Side SDK) [PHASE 1]|
| ├── Meta WhatsApp Cloud API Adapter [PHASE 5 DEFERRED]                            |
| └── SMS Gateway Adapter (Twilio / Unifonic Contingency) [EVALUATED AT SCALE]      |
+-----------------------------------------------------------------------------------+
```

---

## 3. High-Level Modular Domain Boundaries

```
[ Authentication & Identity ]
  ├── Supabase Auth (Argon2 Hashing, Session Lifecycle)
  └── Profile Registry (user_profiles, kindergarten_memberships)

[ Authorization & Governance ]
  ├── PostgreSQL Row Level Security (RLS) Engine
  ├── Granular Staff Permission Evaluator (staff_permission[])
  └── Break-Glass Support Session Controller (super_admin_support_sessions)

[ Academic Registry ]
  ├── Classroom Management (classes)
  ├── Teacher Class Allocations (teacher_class_assignments)
  ├── Basic Child Registry (children)
  └── Restricted Clinical Health Profiles (child_health_profiles)

[ Custody & Onboarding ]
  ├── Cryptographic Invitation Finite State Machine (invitations)
  └── Verified Parent-Child Legal Custody (parent_child_relationships)

[ Classroom Operations ]
  ├── Offline-First Attendance Queue (client_attendance_uuid)
  ├── Attendance Correction Event Ledger (attendance_corrections)
  └── Private Media Vault with 60-Second Ephemeral Signed URLs (media_vault)

[ Pedagogical Developmental Loop ]
  ├── Teacher Classroom Observations (teacher_observations - Immutable Source 1)
  ├── Parent Home Observations (parent_observations - Immutable Source 2)
  ├── AI Derivative Analysis & Non-Diagnostic Recommendations (ai_recommendations)
  └── Milestone Achievement Badges

[ Notification & Messaging ]
  ├── Domain Event Dispatcher
  └── Delivery Channel Adapters (PWA, Email, Deferred WhatsApp)

[ Compliance & Recovery ]
  ├── Cryptographic Tamper-Evident Hash-Chained Audit Ledger (audit_logs)
  └── Cold Storage Encryption & Disaster Recovery Runbook
```
