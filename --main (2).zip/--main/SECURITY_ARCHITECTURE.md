# Rawdaty Smart (روضتي الذكية) — Security Architecture & RLS Model (V4 Remediated)

**Document Version:** 4.1.0-REMEDIATED  
**Classification:** Restricted Engineering Blueprint  
**Standard Compliance:** Defense-in-Depth, Zero-Trust Architecture, GDPR-K, COPPA & Saudi PDPL Compliant  
**Canonical Registry Reference:** Fully synchronized with `FINAL_ENTITY_REGISTRY.md` (25 Entities)

---

## 1. The 5-Layer Defense-in-Depth Principle

Rawdaty Smart strictly prohibits relying on client-side UI visibility (such as hiding buttons or conditional rendering) as a security control. Every single request is validated across **five independent defensive layers**:

```
+-----------------------------------------------------------------------------------+
| 1. FRONTEND AUTHORIZATION                                                         |
| - Route guards & UI ergonomics (prevents navigation to unauthorized screens)      |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
| 2. SERVER-SIDE API AUTHORIZATION                                                  |
| - Zod input validation schemas                                                    |
| - Cryptographic session token verification (Ed25519)                              |
| - Tenant context assertion & rate limiting                                        |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
| 3. DATABASE KERNEL ROW LEVEL SECURITY (RLS)                                       |
| - PostgreSQL kernel policies executed on 100% of tables (25 entities)             |
| - Physically impossible for SQL injection or buggy API code to leak cross-tenant  |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
| 4. STORAGE ACCESS POLICIES                                                        |
| - 100% private buckets (zero public URLs)                                         |
| - Short-lived ephemeral signed URLs (60-second maximum TTL)                       |
| - Media filenames randomized with cryptographic nonces (zero child PII in paths)  |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
| 5. COMPREHENSIVE APPEND-ONLY AUDIT LOGGING                                        |
| - Kernel-level triggers preventing UPDATE or DELETE on audit logs                 |
| - Mandatory audit records on login, invitation, health data access & break-glass  |
+-----------------------------------------------------------------------------------+
```

---

## 2. Authorization Kernel Helper Functions

All helper functions run with explicit `SECURITY DEFINER` semantics, fixed `search_path`, and are engineered to prevent recursion and SQL injection.

```sql
-- Helper 1: Check if user is an active Administrator for a specific kindergarten
CREATE OR REPLACE FUNCTION auth.is_admin_for(target_kindergarten_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.kindergarten_memberships km
    WHERE km.user_id = auth.uid()
      AND km.kindergarten_id = target_kindergarten_id
      AND km.role = 'ADMIN'
      AND km.is_active = TRUE
      AND km.deleted_at IS NULL
  );
$$;

-- Helper 2: Get user's role within a specific kindergarten
CREATE OR REPLACE FUNCTION auth.get_role_for_kindergarten(target_kindergarten_id UUID)
RETURNS app_role
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT km.role FROM public.kindergarten_memberships km
  WHERE km.user_id = auth.uid()
    AND km.kindergarten_id = target_kindergarten_id
    AND km.is_active = TRUE
    AND km.deleted_at IS NULL
  LIMIT 1;
$$;

-- Helper 3: Check if teacher is assigned to a specific class
CREATE OR REPLACE FUNCTION auth.is_teacher_assigned_to_class(target_class_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.teacher_class_assignments tca
    WHERE tca.teacher_id = auth.uid()
      AND tca.class_id = target_class_id
  );
$$;

-- Helper 4: Check if parent is legally verified for a child (CRITICAL REMEDIATION)
-- Invariant: Mere existence of relationship does NOT grant access. verified_at MUST be set.
CREATE OR REPLACE FUNCTION auth.is_parent_of_child(target_child_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.parent_child_relationships pcr
    WHERE pcr.parent_id = auth.uid()
      AND pcr.child_id = target_child_id
      AND pcr.verified_at IS NOT NULL
      AND pcr.deleted_at IS NULL
  );
$$;

-- Helper 5: Check if user has explicit health viewing permissions
CREATE OR REPLACE FUNCTION auth.has_health_permission(target_kindergarten_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.kindergarten_memberships km
    WHERE km.user_id = auth.uid()
      AND km.kindergarten_id = target_kindergarten_id
      AND km.is_active = TRUE
      AND km.deleted_at IS NULL
      AND (
        km.role = 'ADMIN'
        OR 'VIEW_CHILD_HEALTH_INFO' = ANY(km.permissions)
      )
  );
$$;

-- Helper 6: Check for active emergency break-glass support session
CREATE OR REPLACE FUNCTION auth.has_active_support_session(target_kindergarten_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.super_admin_support_sessions sass
    WHERE sass.super_admin_id = auth.uid()
      AND sass.target_kindergarten_id = target_kindergarten_id
      AND sass.is_active = TRUE
      AND sass.expires_at > NOW()
      AND sass.revoked_at IS NULL
  );
$$;
```

---

## 3. Production Row Level Security (RLS) Policies (All 25 Tables)

### 3.1 Tenancy & Identity Tables (Entities 1 – 4)

```sql
-- 1. kindergartens
ALTER TABLE kindergartens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Kindergartens: Read Access" ON kindergartens
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(id)
    OR EXISTS (
      SELECT 1 FROM kindergarten_memberships km
      WHERE km.user_id = auth.uid() AND km.kindergarten_id = id AND km.is_active = TRUE
    )
    OR auth.has_active_support_session(id)
  )
);

CREATE POLICY "Kindergartens: Admin Update" ON kindergartens
FOR UPDATE USING (auth.is_admin_for(id)) WITH CHECK (auth.is_admin_for(id));

-- 2. user_profiles
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "User Profiles: Read Self or School Affiliated" ON user_profiles
FOR SELECT USING (
  deleted_at IS NULL AND (
    id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM kindergarten_memberships my_km
      JOIN kindergarten_memberships target_km ON target_km.kindergarten_id = my_km.kindergarten_id
      WHERE my_km.user_id = auth.uid()
        AND target_km.user_id = user_profiles.id
        AND (my_km.role = 'ADMIN' OR my_km.role = 'TEACHER')
    )
  )
);

CREATE POLICY "User Profiles: Self Update" ON user_profiles
FOR UPDATE USING (id = auth.uid()) WITH CHECK (id = auth.uid());

-- 3. kindergarten_memberships
ALTER TABLE kindergarten_memberships ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Memberships: Read" ON kindergarten_memberships
FOR SELECT USING (
  deleted_at IS NULL AND (
    user_id = auth.uid()
    OR auth.is_admin_for(kindergarten_id)
    OR auth.has_active_support_session(kindergarten_id)
  )
);

CREATE POLICY "Memberships: Admin Manage" ON kindergarten_memberships
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 4. super_admin_support_sessions
ALTER TABLE super_admin_support_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Support Sessions: View" ON super_admin_support_sessions
FOR SELECT USING (
  super_admin_id = auth.uid()
  OR auth.is_admin_for(target_kindergarten_id)
);
```

---

### 3.2 Classes, Children & Custody Gate (Entities 5 – 9)

```sql
-- 5. classes
ALTER TABLE classes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Classes: Read" ON classes
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR auth.is_teacher_assigned_to_class(id)
    OR EXISTS (
      SELECT 1 FROM children c
      WHERE c.class_id = classes.id
        AND auth.is_parent_of_child(c.id)
    )
    OR auth.has_active_support_session(kindergarten_id)
  )
);

CREATE POLICY "Classes: Admin Manage" ON classes
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 6. teacher_class_assignments
ALTER TABLE teacher_class_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Teacher Assignments: Read" ON teacher_class_assignments
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR teacher_id = auth.uid()
  OR auth.has_active_support_session(kindergarten_id)
);

CREATE POLICY "Teacher Assignments: Admin Manage" ON teacher_class_assignments
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 7. children (Demographic & Emergency Base Info)
ALTER TABLE children ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Children: Basic Info Tiered Read" ON children
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
      AND auth.is_teacher_assigned_to_class(class_id)
    )
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'STAFF'
      AND EXISTS (
        SELECT 1 FROM kindergarten_memberships km
        WHERE km.user_id = auth.uid()
          AND km.kindergarten_id = children.kindergarten_id
          AND 'VIEW_CHILD_BASIC_INFO' = ANY(km.permissions)
      )
    )
    -- STRICT INVARIANT: Legal parent with verified_at IS NOT NULL
    OR auth.is_parent_of_child(id)
    OR auth.has_active_support_session(kindergarten_id)
  )
);

CREATE POLICY "Children: Admin Manage" ON children
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 8. child_health_profiles (Highly Sensitive Medical Data)
ALTER TABLE child_health_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Health Profiles: Clinical Access Read" ON child_health_profiles
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR auth.has_health_permission(kindergarten_id)
    -- STRICT INVARIANT: Verified parent only
    OR auth.is_parent_of_child(child_id)
    OR auth.has_active_support_session(kindergarten_id)
  )
);

CREATE POLICY "Health Profiles: Clinical Manage" ON child_health_profiles
FOR ALL USING (
  auth.is_admin_for(kindergarten_id)
  OR auth.has_health_permission(kindergarten_id)
) WITH CHECK (
  auth.is_admin_for(kindergarten_id)
  OR auth.has_health_permission(kindergarten_id)
);

-- 9. parent_child_relationships (Custody Gate)
ALTER TABLE parent_child_relationships ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parent Child Relationships: Read" ON parent_child_relationships
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR parent_id = auth.uid()
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
      AND EXISTS (
        SELECT 1 FROM children c
        WHERE c.id = parent_child_relationships.child_id
          AND auth.is_teacher_assigned_to_class(c.class_id)
      )
    )
    OR auth.has_active_support_session(kindergarten_id)
  )
);

CREATE POLICY "Parent Child Relationships: Admin Manage" ON parent_child_relationships
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));
```

---

### 3.3 Onboarding & Invitations (Entities 10 – 11)

```sql
-- 10. invitations
ALTER TABLE invitations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Invitations: Admin Manage" ON invitations
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 11. invitation_redemptions
ALTER TABLE invitation_redemptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Invitation Redemptions: Admin Read" ON invitation_redemptions
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM invitations inv
    WHERE inv.id = invitation_redemptions.invitation_id
      AND auth.is_admin_for(inv.kindergarten_id)
  )
);
```

---

### 3.4 Attendance & Event Corrections (Entities 12 – 13)

```sql
-- 12. attendance (Daily Attendance Master State)
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Attendance: Read" ON attendance
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
      AND auth.is_teacher_assigned_to_class(class_id)
    )
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'STAFF'
      AND EXISTS (
        SELECT 1 FROM kindergarten_memberships km
        WHERE km.user_id = auth.uid()
          AND km.kindergarten_id = attendance.kindergarten_id
          AND 'VIEW_ATTENDANCE' = ANY(km.permissions)
      )
    )
    -- STRICT INVARIANT: Verified parent only
    OR auth.is_parent_of_child(child_id)
    OR auth.has_active_support_session(kindergarten_id)
  )
);

CREATE POLICY "Attendance: Teacher/Staff Record" ON attendance
FOR INSERT WITH CHECK (
  auth.is_admin_for(kindergarten_id)
  OR (
    auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
    AND auth.is_teacher_assigned_to_class(class_id)
  )
  OR (
    auth.get_role_for_kindergarten(kindergarten_id) = 'STAFF'
    AND EXISTS (
      SELECT 1 FROM kindergarten_memberships km
      WHERE km.user_id = auth.uid()
        AND km.kindergarten_id = attendance.kindergarten_id
        AND 'RECORD_ATTENDANCE' = ANY(km.permissions)
    )
  )
);

CREATE POLICY "Attendance: Teacher Update" ON attendance
FOR UPDATE USING (
  auth.is_admin_for(kindergarten_id)
  OR (
    auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
    AND auth.is_teacher_assigned_to_class(class_id)
  )
) WITH CHECK (
  auth.is_admin_for(kindergarten_id)
  OR (
    auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
    AND auth.is_teacher_assigned_to_class(class_id)
  )
);

-- 13. attendance_corrections (Append-Only Event Ledger)
ALTER TABLE attendance_corrections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Attendance Corrections: Read" ON attendance_corrections
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = attendance_corrections.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  OR auth.has_active_support_session(kindergarten_id)
);

CREATE POLICY "Attendance Corrections: Insert" ON attendance_corrections
FOR INSERT WITH CHECK (
  corrected_by_user_id = auth.uid()
  AND (
    auth.is_admin_for(kindergarten_id)
    OR EXISTS (
      SELECT 1 FROM children c
      WHERE c.id = attendance_corrections.child_id
        AND auth.is_teacher_assigned_to_class(c.class_id)
    )
  )
);
```

---

### 3.5 Observations Loop (Entities 14 – 15)

```sql
-- 14. teacher_observations
ALTER TABLE teacher_observations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Teacher Observations: Read" ON teacher_observations
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR (
      auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
      AND auth.is_teacher_assigned_to_class(class_id)
    )
    -- STRICT INVARIANT: Verified parent only
    OR auth.is_parent_of_child(child_id)
    OR auth.has_active_support_session(kindergarten_id)
  )
);

CREATE POLICY "Teacher Observations: Teacher Insert" ON teacher_observations
FOR INSERT WITH CHECK (
  teacher_id = auth.uid()
  AND (
    auth.is_admin_for(kindergarten_id)
    OR auth.is_teacher_assigned_to_class(class_id)
  )
);

-- 15. parent_observations
ALTER TABLE parent_observations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parent Observations: Read" ON parent_observations
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR EXISTS (
      SELECT 1 FROM children c
      WHERE c.id = parent_observations.child_id
        AND auth.is_teacher_assigned_to_class(c.class_id)
    )
    -- STRICT INVARIANT: Verified parent only
    OR (parent_id = auth.uid() AND auth.is_parent_of_child(child_id))
    OR auth.has_active_support_session(kindergarten_id)
  )
);

CREATE POLICY "Parent Observations: Parent Insert" ON parent_observations
FOR INSERT WITH CHECK (
  parent_id = auth.uid()
  AND auth.is_parent_of_child(child_id)
);
```

---

### 3.6 AI Synthesis & Evidence Pipeline (Entities 16 – 20)

```sql
-- 16. ai_analysis
ALTER TABLE ai_analysis ENABLE ROW LEVEL SECURITY;

CREATE POLICY "AI Analysis: Read" ON ai_analysis
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_analysis.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  OR auth.has_active_support_session(kindergarten_id)
);

-- 17. ai_evidence
ALTER TABLE ai_evidence ENABLE ROW LEVEL SECURITY;

CREATE POLICY "AI Evidence: Read" ON ai_evidence
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM ai_analysis a
    JOIN children c ON c.id = a.child_id
    WHERE a.id = ai_evidence.analysis_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  OR auth.has_active_support_session(kindergarten_id)
);

-- 18. ai_insights
ALTER TABLE ai_insights ENABLE ROW LEVEL SECURITY;

CREATE POLICY "AI Insights: Read" ON ai_insights
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_insights.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  -- Parents can read ONLY if teacher has signed off AND parent is verified
  OR (
    is_signed_off_by_teacher = TRUE
    AND auth.is_parent_of_child(child_id)
  )
  OR auth.has_active_support_session(kindergarten_id)
);

CREATE POLICY "AI Insights: Teacher Signoff Update" ON ai_insights
FOR UPDATE USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_insights.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
);

-- 19. ai_recommendations
ALTER TABLE ai_recommendations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "AI Recommendations: Read" ON ai_recommendations
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_recommendations.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  -- Parents can see ONLY approved activities AND if verified parent
  OR (
    approval_status = 'APPROVED'
    AND auth.is_parent_of_child(child_id)
  )
  OR auth.has_active_support_session(kindergarten_id)
);

CREATE POLICY "AI Recommendations: Teacher Review" ON ai_recommendations
FOR UPDATE USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_recommendations.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
);

-- 20. ai_followups
ALTER TABLE ai_followups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "AI Followups: Read" ON ai_followups
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR EXISTS (
    SELECT 1 FROM children c
    WHERE c.id = ai_followups.child_id
      AND auth.is_teacher_assigned_to_class(c.class_id)
  )
  -- STRICT INVARIANT: Verified parent only
  OR auth.is_parent_of_child(child_id)
  OR auth.has_active_support_session(kindergarten_id)
);

CREATE POLICY "AI Followups: Insert" ON ai_followups
FOR INSERT WITH CHECK (
  logged_by_user_id = auth.uid()
  AND (
    auth.is_admin_for(kindergarten_id)
    OR auth.is_parent_of_child(child_id)
  )
);
```

---

### 3.7 Storage Vault & Child Tag Isolation (Entities 21 – 22)

```sql
-- 21. media_vault
ALTER TABLE media_vault ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Media Vault: Metadata Read" ON media_vault
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
    OR EXISTS (
      SELECT 1 FROM media_child_tags mct
      WHERE mct.media_id = media_vault.id
        -- STRICT INVARIANT: Verified parent only
        AND auth.is_parent_of_child(mct.child_id)
    )
    OR auth.has_active_support_session(kindergarten_id)
  )
);

-- 22. media_child_tags
ALTER TABLE media_child_tags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Media Child Tags: Read" ON media_child_tags
FOR SELECT USING (
  auth.is_admin_for(kindergarten_id)
  OR auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
  -- STRICT INVARIANT: Verified parent only
  OR auth.is_parent_of_child(child_id)
  OR auth.has_active_support_session(kindergarten_id)
);

CREATE POLICY "Media Child Tags: Admin/Teacher Manage" ON media_child_tags
FOR ALL USING (
  auth.is_admin_for(kindergarten_id)
  OR auth.get_role_for_kindergarten(kindergarten_id) = 'TEACHER'
);

-- Storage Kernel Policy on storage.objects
CREATE POLICY "Private Media Storage Policy"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'kindergarten-media'
  AND EXISTS (
    SELECT 1 FROM public.media_vault mv
    WHERE mv.storage_path = name
      AND mv.deleted_at IS NULL
      AND (
        auth.is_admin_for(mv.kindergarten_id)
        OR auth.get_role_for_kindergarten(mv.kindergarten_id) = 'TEACHER'
        OR EXISTS (
          SELECT 1 FROM public.media_child_tags mct
          JOIN public.parent_child_relationships pcr ON pcr.child_id = mct.child_id
          WHERE mct.media_id = mv.id 
            AND pcr.parent_id = auth.uid()
            -- STRICT INVARIANT: Verified custody required
            AND pcr.verified_at IS NOT NULL
            AND pcr.deleted_at IS NULL
        )
      )
  )
);
```

---

### 3.8 Billing, Notifications & Audit Log (Entities 23 – 25)

```sql
-- 23. tuition_invoices (Phase 5)
ALTER TABLE tuition_invoices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Invoices: Read" ON tuition_invoices
FOR SELECT USING (
  deleted_at IS NULL AND (
    auth.is_admin_for(kindergarten_id)
    OR (
      parent_id = auth.uid()
      AND auth.is_parent_of_child(child_id)
    )
    OR auth.has_active_support_session(kindergarten_id)
  )
);

CREATE POLICY "Invoices: Admin Manage" ON tuition_invoices
FOR ALL USING (auth.is_admin_for(kindergarten_id)) WITH CHECK (auth.is_admin_for(kindergarten_id));

-- 24. notifications
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Notifications: Recipient Read" ON notifications
FOR SELECT USING (recipient_user_id = auth.uid());

CREATE POLICY "Notifications: Recipient Mark Read" ON notifications
FOR UPDATE USING (recipient_user_id = auth.uid()) WITH CHECK (recipient_user_id = auth.uid());

-- 25. audit_logs
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Audit Logs: Admin Read Own School" ON audit_logs
FOR SELECT USING (
  (kindergarten_id IS NOT NULL AND auth.is_admin_for(kindergarten_id))
  OR auth.has_active_support_session(kindergarten_id)
);
```

---

## 4. Audited Clinical Access to Health Data (RPC Gateway)

PostgreSQL does not natively provide application-level triggers on `SELECT` queries. Direct client `SELECT` access to `child_health_profiles` via REST is therefore restricted, and all clinical access is routed through an audited security definer function:

```sql
CREATE OR REPLACE FUNCTION rpc_get_child_health_profile(
    p_child_id UUID,
    p_access_reason TEXT DEFAULT 'Standard clinical inspection'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_child children%ROWTYPE;
    v_health child_health_profiles%ROWTYPE;
    v_is_authorized BOOLEAN := FALSE;
    v_actor_role app_role;
BEGIN
    -- 1. Fetch child record
    SELECT * INTO v_child FROM children WHERE id = p_child_id AND deleted_at IS NULL;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'CHILD_NOT_FOUND: Requested child does not exist.';
    END IF;

    -- 2. Determine authorization
    IF auth.is_admin_for(v_child.kindergarten_id) THEN
        v_is_authorized := TRUE;
        v_actor_role := 'ADMIN';
    ELSIF auth.has_health_permission(v_child.kindergarten_id) THEN
        v_is_authorized := TRUE;
        v_actor_role := 'STAFF';
    ELSIF auth.is_parent_of_child(p_child_id) THEN
        v_is_authorized := TRUE;
        v_actor_role := 'PARENT';
    ELSIF auth.has_active_support_session(v_child.kindergarten_id) THEN
        v_is_authorized := TRUE;
        v_actor_role := 'SUPER_ADMIN';
    END IF;

    -- 3. If unauthorized: Log security incident and reject
    IF NOT v_is_authorized THEN
        INSERT INTO audit_logs (
            kindergarten_id, actor_id, actor_role, action, resource_type, resource_id, reason, metadata
        ) VALUES (
            v_child.kindergarten_id,
            auth.uid(),
            auth.get_role_for_kindergarten(v_child.kindergarten_id),
            'CHILD_HEALTH_INFO_ACCESS_DENIED',
            'child_health_profiles',
            p_child_id,
            p_access_reason,
            jsonb_build_object('attempted_child_id', p_child_id, 'denied_at', NOW())
        );
        RAISE EXCEPTION 'PERMISSION_DENIED: Unauthorized access to confidential health data.';
    END IF;

    -- 4. If authorized: Fetch health profile
    SELECT * INTO v_health FROM child_health_profiles
    WHERE child_id = p_child_id AND deleted_at IS NULL;

    -- 5. Mandatory Audit Log of Authorized Read
    INSERT INTO audit_logs (
        kindergarten_id, actor_id, actor_role, action, resource_type, resource_id, reason, metadata
    ) VALUES (
        v_child.kindergarten_id,
        auth.uid(),
        v_actor_role,
        'CHILD_HEALTH_INFO_VIEWED',
        'child_health_profiles',
        v_health.id,
        p_access_reason,
        jsonb_build_object(
            'child_id', p_child_id,
            'has_epipen', v_health.has_epipen,
            'accessed_at', NOW()
        )
    );

    RETURN to_jsonb(v_health);
END;
$$;
```
