# Rawdaty Smart (روضتي الذكية) — AI Child Development Engine (V4 Remediated)

**Document Version:** 4.1.0-REMEDIATED  
**Specification:** 7-Stage Layered Safety Pipeline & Non-Diagnostic Evidence Lineage  
**Standard Compliance:** Defense-in-Depth, Anti-Diagnostic Guarantee, Evidence Provenance Locked  
**Canonical Registry Reference:** Fully synchronized with `FINAL_ENTITY_REGISTRY.md` (Entities 16 – 20)

---

## 1. Ethical, Legal & Non-Diagnostic Foundations

Rawdaty Smart strictly prohibits:
- Medical diagnosis
- Psychiatric diagnosis
- Developmental disorder diagnosis (e.g. ASD, ADHD, Dyspraxia, Global Developmental Delay)
- Disease or behavioral risk prediction
- Definitive claims about a child's clinical, psychological, or neurological condition

The platform **is permitted** to:
- Summarize documented educational observations entered by teachers and parents.
- Highlight emerging strengths in early learning domains (Saudi Early Childhood Curriculum / Montessori).
- Suggest ordinary, play-based, age-appropriate educational activities (10 minutes) using household materials.
- Maintain a strict visual and data-level distinction between **Documented Source Facts** and **AI Pedagogical Inferences**.

---

## 2. The 7-Stage Layered AI Safety Pipeline

We reject relying solely on regular expressions. Rawdaty Smart implements a defense-in-depth pipeline where each stage can halt execution:

```
[ STAGE 1: SOURCE DATA INTEGRITY ]
│ - Verified human records only (teacher_observations, parent_observations)
│ - AI service has strictly read-only access (ZERO mutation privilege on source records)
v
[ STAGE 2: CONTROLLED AI GENERATION ]
│ - System prompt enforces role as an Early Childhood Pedagogical Specialist
│ - Strict instructions to identify milestone strengths, not clinical deficiencies
v
[ STAGE 3: STRUCTURED OUTPUT VALIDATION ]
│ - Output must strictly conform to Zod JSON Schema (no freeform Markdown text)
│ - Missing fields or malformed structures trigger immediate pipeline abort
v
[ STAGE 4: EVIDENCE LINEAGE VALIDATION ]
│ - Server iterates over every cited observation UUID in output
│ - Verifies that cited UUIDs physically exist in database for this specific child
│ - Any unverified, missing, or cross-tenant ID triggers immediate rejection
v
[ STAGE 5: MULTI-TIER SAFETY & POLICY AUDIT ]
│ - Tier A: System prompt negative constraints
│ - Tier B: Forbidden clinical terms classifier & semantic tone check
│ - Tier C: Regex Gatekeeper scanning for prohibited diagnostic keywords
v
[ STAGE 6: HUMAN TEACHER REVIEW & APPROVAL ]
│ - Recommendation enters teacher queue (status = PENDING_REVIEW)
│ - Lead teacher reviews, edits wording, substitutes materials, or approves
v
[ STAGE 7: PARENT DISPLAY ]
  - Rendered in Parent PWA with explicit "Pedagogical Play Card" banner
  - Interactive "View Evidence Trail" button displaying human-authored quotes
  - Visible ONLY to parents with verified_at IS NOT NULL
```

---

## 3. Strict Source Invariant & Immutability Rules

1. **AI Never Mutates Source Records:** The AI service role has `SELECT` permission on `teacher_observations` and `parent_observations`. It has **NO INSERT, UPDATE, or DELETE grants** on any source-of-truth table (`children`, `attendance`, `teacher_observations`, `parent_observations`, `child_health_profiles`).
2. **AI Writes Derived Records Only:** All AI inference jobs produce rows strictly within:
   - `ai_analysis` (execution metadata, prompt/completion tokens, latency)
   - `ai_evidence` (pointers to source observation UUIDs)
   - `ai_insights` (synthesized learning strengths)
   - `ai_recommendations` (actionable play activities)
   - `ai_followups` (engagement feedback)
3. **Evidence Linkage Assertion:** If the AI model cites an observation UUID that does not exist or belongs to another child/tenant, the server-side validator aborts the insertion with an `INVALID_EVIDENCE_REFERENCE` error and records a security audit log.
4. **Mandatory Human Sign-off:** No recommendation or insight is displayed to a parent until a certified teacher sets `approval_status = 'APPROVED'` or `is_signed_off_by_teacher = TRUE`.
