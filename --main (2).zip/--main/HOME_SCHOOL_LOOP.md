# Rawdaty Smart (روضتي الذكية) — The Home-School Development Loop (V3)

**Document Version:** 3.0.0-FINAL  
**Classification:** First-Class Pedagogical Domain Concept  
**Pedagogical Standard:** Bi-Directional Collaborative Child Growth  

---

## 1. The Core Philosophy: First-Class Domain Status

In traditional kindergarten software, parent communication is an afterthought: a bulletin board for fee invoices and lunch schedules. 

In **Rawdaty Smart**, the **Home-School Development Loop** is promoted to a **first-class architectural domain**. It models child development as an ongoing, respectful dialogue between certified early childhood educators and family guardians.

---

## 2. The 8-Stage Bi-Directional Loop Architecture

```
                  +-------------------------------------------------------------+
                  |              STAGE 1: Teacher Classroom Observation         |
                  | Educator records milestone in classroom station             |
                  | (Source Record 1: teacher_observations)                     |
                  +------------------------------+------------------------------+
                                                 |
                                                 v
                  +-------------------------------------------------------------+
                  |              STAGE 2: Parent Home Observation               |
                  | Guardian records home routine or weekend moment             |
                  | (Source Record 2: parent_observations)                      |
                  +------------------------------+------------------------------+
                                                 |
                                                 v
                  +-------------------------------------------------------------+
                  |              STAGE 3: AI Evidence Aggregation               |
                  | Server worker queries both tables, assembling exact UUIDs   |
                  | (Entity: ai_evidence)                                       |
                  +------------------------------+------------------------------+
                                                 |
                                                 v
                  +-------------------------------------------------------------+
                  |              STAGE 4: AI Developmental Insight              |
                  | Synthesizes cross-context strengths without diagnosis       |
                  | (Entity: ai_insights)                                       |
                  +------------------------------+------------------------------+
                                                 |
                                                 v
                  +-------------------------------------------------------------+
                  |              STAGE 5: Human Teacher Review                  |
                  | Lead teacher edits, approves, or rejects suggestion         |
                  | (status = 'APPROVED', reviewed_by_teacher_id)               |
                  +------------------------------+------------------------------+
                                                 |
                                                 v
                  +-------------------------------------------------------------+
                  |              STAGE 6: Suggested Home Activity               |
                  | 10-minute accessible home play card unlocked in Parent PWA  |
                  | (Entity: ai_recommendations, is_visible_to_parent = TRUE)   |
                  +------------------------------+------------------------------+
                                                 |
                                                 v
                  +-------------------------------------------------------------+
                  |              STAGE 7: Parent Feedback & Reflection          |
                  | Family tries activity; submits voice/text reflection        |
                  | (Entity: ai_followups, parent_feedback_received = TRUE)     |
                  +------------------------------+------------------------------+
                                                 |
                                                 v
                  +-------------------------------------------------------------+
                  |              STAGE 8: Follow-Up Classroom Observation       |
                  | Educator observes reinforced milestone during circle time   |
                  | (Closes loop and seeds Stage 1 for the following week)      |
                  +------------------------------+------------------------------+
```

---

## 3. Separation of Source Records & Data Provenance

1. **`teacher_observations` (Classroom Truth):**
   - Authored exclusively by assigned teachers.
   - Immutable once signed (24-hour typographical edit grace period).
   - Parents have strictly read-only access.
2. **`parent_observations` (Home Truth):**
   - Authored exclusively by verified parents.
   - Teachers cannot alter, edit, or delete the parent's words.
   - Teachers can attach celebratory reflection badges and pedagogical notes.
3. **`ai_insights` & `ai_recommendations` (Derivative Inferences):**
   - Clearly labeled as AI-generated and teacher-approved.
   - Always link back to the underlying Stage 1 and Stage 2 evidence IDs.
