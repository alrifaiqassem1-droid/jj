# Rawdaty Smart (روضتي الذكية) — Backup, Disaster Recovery & Cost Governance (V2)

**Document Version:** 2.0.0  
**Classification:** Operational Continuity & Cost Assessment  
**Engineering Invariant:** All resilience metrics are documented as **Architectural Targets**, strictly separated from commercial provider guarantees.  

---

## 1. Resilience Target Matrix: Desired vs. Provider Reality vs. Cost

To maintain financial discipline during the early stages of kindergarten adoption, we differentiate between theoretical engineering desires, actual cloud vendor SLAs, and the associated infrastructure costs.

| Dimension | Engineering Desired Target | Technically Supported Capability | Actual Provider Guarantee / SLA | Expected Operational Cost |
| :--- | :--- | :--- | :--- | :--- |
| **Recovery Point Objective (RPO)** | **Target: &le; 15 minutes** | Continuous PostgreSQL Write-Ahead Log (WAL) streaming archived every 60 seconds to secondary storage | **Free/Pro Base:** Daily snapshot (RPO ~24 hours).<br>**With PITR Add-on:** Continuous WAL (RPO ~1 to 5 minutes). | **Tier 1 (Early Stage):** $0 added (Nightly script).<br>**Tier 2 (Scale):** ~$100/month (Supabase PITR addon). |
| **Recovery Time Objective (RTO)** | **Target: &le; 60 minutes** | Automated script restoring logical dump to a freshly provisioned container or managed PostgreSQL instance | **Supabase Managed SLA:** 99.9% monthly platform uptime (no contractual RTO guarantee on standard tiers). | Manual runbook execution by DevOps engineer: 30–60 minutes. |
| **Database Durability** | **Target: 99.999%** | Multi-AZ disk replication with secondary cloud backup | AWS S3 object durability: 99.999999999% (11 9s). Multi-AZ RDS/Supabase volume redundancy. | Standard cloud storage fees (~$0.023/GB/month active; $0.004/GB/month Glacier). |
| **Child Media Vault Redundancy** | **Target: Zero lost photos/videos** | Cross-region bucket replication (CRR) with WORM object locking for 90 days | Cloudflare R2 / AWS S3 Standard durability: 99.999999999%. | Pay-per-GB (~$0.015/GB/month for primary + replicated storage). |

---

## 2. Phased Backup Strategy by Financial Tier

### Tier 1: Early-Stage Cost-Controlled Backup (1 to 5 Kindergartens)
- **Database Architecture:**
  - Automated nightly cron job executing `pg_dump` with gzip compression and AES-256 symmetric encryption.
  - Shipped directly to a dedicated S3 Glacier Instant Retrieval cold bucket.
  - Cost: **&lt; $2.00 / month total**.
  - Tradeoff: In the event of a catastrophic midday crash, transactions after 02:00 AM UTC would require manual re-entry from physical/offline classroom logs.

```bash
#!/bin/bash
# scripts/ops/nightly-backup-cost-effective.sh
set -euo pipefail
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="/tmp/rawdaty_${TIMESTAMP}.sql.gz"
ENCRYPTED_FILE="${BACKUP_FILE}.gpg"

# 1. Export database dump
pg_dump "${DATABASE_URL}" --format=plain --no-owner --no-privileges | gzip -9 > "${BACKUP_FILE}"

# 2. Encrypt with AES-256
gpg --batch --yes --passphrase "${BACKUP_ENCRYPTION_KEY}" --symmetric --cipher-algo AES256 -o "${ENCRYPTED_FILE}" "${BACKUP_FILE}"

# 3. Ship to low-cost Glacier cold vault
aws s3 cp "${ENCRYPTED_FILE}" "s3://rawdaty-cold-vault/database/${TIMESTAMP}/" --storage-class GLACIER_IR

rm -f "${BACKUP_FILE}" "${ENCRYPTED_FILE}"
```

### Tier 2: Institutional Production Scale (10+ Kindergartens / Enterprise)
- **Database Architecture:**
  - Enable Supabase Enterprise Point-in-Time Recovery (PITR).
  - Continuous WAL archiving allowing restoration to any second within the last 30 days.
  - Cost: **Supabase Pro ($25/mo) + PITR Add-on ($100/mo) = $125/month**.
  - Delivers true 15-minute RPO under all operational scenarios.

---

## 3. Disaster Recovery (DR) Execution Runbook

### Phase 1: Outage Declaration & Parent Notice (T + 0 to 10m)
1. Triage confirmed database outage.
2. Route domain to edge maintenance page: *"Rawdaty Smart is undergoing brief scheduled maintenance. Morning attendance continues via classroom offline mode."*

### Phase 2: Database Restoration (T + 10 to 45m)
- **Under Tier 1 (Cold Dump):**
  ```bash
  gpg --batch --yes --passphrase "$BACKUP_ENCRYPTION_KEY" -d backup.sql.gz.gpg | gunzip | psql "$RESTORE_DATABASE_URL"
  ```
- **Under Tier 2 (PITR):**
  ```bash
  supabase db restore --timestamp "$TARGET_TIMESTAMP"
  ```

### Phase 3: Integrity & Permission Verification (T + 45 to 55m)
Run automated verification script:
- Asserts that all 22 tables have RLS enabled.
- Validates total child count and kindergarten membership counts.
- Verifies that `super_admin_support_sessions` are expired.

### Phase 4: Re-route Traffic (T + 55 to 60m)
Cut over API gateway to restored instance and send operational notification to Kindergarten Directors.
